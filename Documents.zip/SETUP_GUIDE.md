# ZK Fingerprint Attendance — Setup Guide

Ye system ZKTeco K40/K50/F18 devices ko aapke Angular + EF (SQL Server) project
mein integrate karta hai using ZK ka **iClock / ADMS Push protocol** — SDK ki
zaroorat nahi, isliye Linux/Cloud par bhi chalta hai.

---

## 1. Backend files kahan rakhein

| File | Kahan |
|------|-------|
| `Models.cs` | apni `Models/` folder mein |
| `AttendanceDbContext.cs` | agar aapka pehle se DbContext hai to sirf 3 DbSet lines usme add karein |
| `IClockController.cs` | `Controllers/` |
| `AttendanceController.cs` | `Controllers/` |

Namespaces apne project ke mutabiq change karlein.

## 2. Database migration (SQL Server)

```bash
dotnet ef migrations add AddZkAttendance
dotnet ef database update
```

## 3. CONFIG — yahan aapko credentials/values dalne hain

### 3a. `appsettings.json` (connection string aapki already hogi)
```json
"ConnectionStrings": {
  "Default": "Server=YOUR_SQL_SERVER;Database=YOUR_DB;User Id=YOUR_USER;Password=YOUR_PASSWORD;TrustServerCertificate=True;"
}
```

### 3b. IMPORTANT — iClock endpoints ko auth se EXCLUDE karein
Device JWT/cookie nahi bhejta. Agar aapke project mein global `[Authorize]`
hai to `/iclock/*` par `[AllowAnonymous]` lagana zaroori hai (already controller
par nahi laga — aap apni policy ke hisaab se `[AllowAnonymous]` add karein).

### 3c. Angular `environment.ts`
```ts
export const environment = {
  production: false,
  apiUrl: 'https://your-api-domain.com'   // <-- yahan apna API URL
};
```

## 4. Angular component register karein
`attendance.service.ts`, `attendance.component.*` ko apne module mein daalein:
```ts
@NgModule({
  declarations: [AttendanceComponent],
  imports: [CommonModule, FormsModule, HttpClientModule],
})
```
Route add karein: `{ path: 'attendance', component: AttendanceComponent }`

---

## 5. ZK DEVICE PAR SETTING (ye physically device par karni hai)

Device par: **Menu > Comm (COMM) > Cloud Server Setting / ADMS**

| Field | Value |
|-------|-------|
| Server Mode | **ADMS** |
| Server Address | aapka server IP ya domain (bina http://) |
| Server Port | jis port par API sun rahi hai (80 / 443 / 8080) |
| Enable Domain Name | ON (agar domain use kar rahe ho) |
| HTTPS | sirf naye firmware par; agar connect na ho to HTTP par port 80 |

Device par network (Menu > Comm > Ethernet) mein IP/gateway sahi set karein.
Save karke device restart karein.

## 6. Test karein

1. Device restart hone ke baad `/iclock/cdata?SN=...` hit hoga — check server logs.
2. Angular UI par "Devices" strip mein device **Offline/Unregistered** dikhega.
3. Usko **Approve** karein (naam + location dein) — ab IsActive = true.
4. Kisi employee ka finger device par register karein (device menu se), uski
   PIN note karein.
5. Angular mein us PIN ko real employee se map karein (employees API / UI form).
6. Finger lagayein — 10-15 second mein UI par punch nazar aayega. Done ✅

---

## 7. Common issues

- **Device connect nahi ho raha:** port firewall mein khula ho; server address
  bina `http://`; device aur server same/reachable network par hon.
- **Logs aa rahe hain par employee "(unknown)":** us PIN ko employee se map karein.
- **Duplicate punches:** unique index inhe khud rok deta hai.
- **HTTPS handshake fail:** purane firmware HTTPS support nahi karte — HTTP:80 use karein
  ya device ka firmware update karein.

## 8. Employee ko device par add karne ka scale-up (optional)
Abhi finger enrollment device par manually hoti hai. Agar aap chahein ke web se
"Add User" command device ko bheja jaye, to `getrequest` endpoint mein command
queue return karni hoti hai (e.g. `C:1:DATA UPDATE USERINFO PIN=...`). Ye next
phase mein add kiya ja sakta hai — bata dena to woh bhi bana dunga.
