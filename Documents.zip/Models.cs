using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Distribution.Attendance.Models
{
    // A physical ZK device registered in your system.
    public class ZkDevice
    {
        [Key]
        public int Id { get; set; }

        // Serial number reported by the device (SN). This is how the device
        // identifies itself in every iClock request. MUST be unique.
        [Required, MaxLength(50)]
        public string SerialNumber { get; set; }

        [MaxLength(100)]
        public string Name { get; set; }          // e.g. "Main Gate - Lahore"

        [MaxLength(100)]
        public string Location { get; set; }

        public bool IsActive { get; set; } = true;

        public DateTime? LastSeenUtc { get; set; } // updated on every handshake

        // Cursor the device uses so it does not resend old logs.
        public long LastStamp { get; set; }
    }

    // Maps a device-side enroll number (PIN) to your real employee.
    public class Employee
    {
        [Key]
        public int Id { get; set; }

        // The "PIN"/enroll number stored on the ZK device for this person.
        [Required, MaxLength(50)]
        public string DeviceUserId { get; set; }

        [Required, MaxLength(150)]
        public string FullName { get; set; }

        [MaxLength(50)]
        public string EmployeeCode { get; set; }

        public bool IsActive { get; set; } = true;
    }

    // One punch record pushed by the device.
    public class AttendanceLog
    {
        [Key]
        public long Id { get; set; }

        [Required, MaxLength(50)]
        public string DeviceUserId { get; set; }   // PIN from device

        public int? EmployeeId { get; set; }        // resolved link (nullable if unknown)
        [ForeignKey(nameof(EmployeeId))]
        public Employee Employee { get; set; }

        public int ZkDeviceId { get; set; }
        [ForeignKey(nameof(ZkDeviceId))]
        public ZkDevice Device { get; set; }

        public DateTime PunchTimeLocal { get; set; }

        // Raw ZK fields (for auditing / debugging)
        public int Status { get; set; }             // check-in/out state from device
        public int VerifyMode { get; set; }         // 1 = fingerprint, 15 = face, etc.

        public DateTime CreatedUtc { get; set; } = DateTime.UtcNow;
    }
}
