using Microsoft.EntityFrameworkCore;
using Distribution.Attendance.Models;

namespace Distribution.Attendance.Data
{
    // NOTE: If your existing project already has a DbContext, DO NOT create a new one.
    // Instead just add these three DbSet<> lines into your current context and run a migration.
    public class AttendanceDbContext : DbContext
    {
        public AttendanceDbContext(DbContextOptions<AttendanceDbContext> options)
            : base(options) { }

        public DbSet<ZkDevice> ZkDevices { get; set; }
        public DbSet<Employee> Employees { get; set; }
        public DbSet<AttendanceLog> AttendanceLogs { get; set; }

        protected override void OnModelCreating(ModelBuilder mb)
        {
            mb.Entity<ZkDevice>()
              .HasIndex(d => d.SerialNumber)
              .IsUnique();

            mb.Entity<Employee>()
              .HasIndex(e => e.DeviceUserId);

            // Prevent duplicate punches (same device, same user, same second).
            mb.Entity<AttendanceLog>()
              .HasIndex(a => new { a.ZkDeviceId, a.DeviceUserId, a.PunchTimeLocal })
              .IsUnique();

            base.OnModelCreating(mb);
        }
    }
}
