using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Distribution.Attendance.Data;
using Distribution.Attendance.Models;

namespace Distribution.Attendance.Controllers
{
    // This is what your Angular app talks to. Secure it with your existing auth
    // (e.g. [Authorize]) the same way as the rest of your project.
    [ApiController]
    [Route("api/attendance")]
    public class AttendanceController : ControllerBase
    {
        private readonly AttendanceDbContext _db;
        public AttendanceController(AttendanceDbContext db) => _db = db;

        // GET /api/attendance/logs?from=2026-09-01&to=2026-09-14&deviceId=&search=
        [HttpGet("logs")]
        public async Task<IActionResult> GetLogs(
            DateTime? from, DateTime? to, int? deviceId, string search,
            int page = 1, int pageSize = 50)
        {
            var q = _db.AttendanceLogs
                       .Include(a => a.Employee)
                       .Include(a => a.Device)
                       .AsQueryable();

            if (from.HasValue) q = q.Where(a => a.PunchTimeLocal >= from.Value);
            if (to.HasValue)   q = q.Where(a => a.PunchTimeLocal < to.Value.AddDays(1));
            if (deviceId.HasValue) q = q.Where(a => a.ZkDeviceId == deviceId.Value);
            if (!string.IsNullOrWhiteSpace(search))
                q = q.Where(a => a.DeviceUserId.Contains(search) ||
                                 (a.Employee != null && a.Employee.FullName.Contains(search)));

            var total = await q.CountAsync();
            var items = await q.OrderByDescending(a => a.PunchTimeLocal)
                .Skip((page - 1) * pageSize).Take(pageSize)
                .Select(a => new {
                    a.Id,
                    a.DeviceUserId,
                    employeeName = a.Employee != null ? a.Employee.FullName : "(unknown)",
                    employeeCode = a.Employee != null ? a.Employee.EmployeeCode : null,
                    device = a.Device.Name,
                    punchTime = a.PunchTimeLocal,
                    a.Status,
                    verify = a.VerifyMode == 1 ? "Fingerprint"
                           : a.VerifyMode == 15 ? "Face"
                           : a.VerifyMode == 0 ? "Password" : "Other"
                }).ToListAsync();

            return Ok(new { total, page, pageSize, items });
        }

        // Daily first-in / last-out summary per employee
        // GET /api/attendance/daily?date=2026-09-14
        [HttpGet("daily")]
        public async Task<IActionResult> Daily(DateTime? date)
        {
            var d = (date ?? DateTime.Today).Date;
            var next = d.AddDays(1);

            var rows = await _db.AttendanceLogs
                .Where(a => a.PunchTimeLocal >= d && a.PunchTimeLocal < next)
                .Include(a => a.Employee)
                .GroupBy(a => new { a.DeviceUserId,
                                    Name = a.Employee != null ? a.Employee.FullName : "(unknown)" })
                .Select(g => new {
                    deviceUserId = g.Key.DeviceUserId,
                    name = g.Key.Name,
                    firstIn = g.Min(x => x.PunchTimeLocal),
                    lastOut = g.Max(x => x.PunchTimeLocal),
                    punches = g.Count()
                })
                .OrderBy(x => x.name)
                .ToListAsync();

            return Ok(rows);
        }

        // ---- Device management ----------------------------------------------
        [HttpGet("devices")]
        public async Task<IActionResult> Devices() =>
            Ok(await _db.ZkDevices.OrderBy(d => d.Name).ToListAsync());

        [HttpPost("devices/{id}/activate")]
        public async Task<IActionResult> Activate(int id, [FromBody] DeviceUpdate dto)
        {
            var dev = await _db.ZkDevices.FindAsync(id);
            if (dev == null) return NotFound();
            dev.IsActive = true;
            if (!string.IsNullOrWhiteSpace(dto?.Name)) dev.Name = dto.Name;
            if (!string.IsNullOrWhiteSpace(dto?.Location)) dev.Location = dto.Location;
            await _db.SaveChangesAsync();
            return Ok(dev);
        }

        // ---- Employee mapping (link a device PIN to a real employee) --------
        [HttpPost("employees")]
        public async Task<IActionResult> UpsertEmployee([FromBody] Employee e)
        {
            var existing = await _db.Employees
                .FirstOrDefaultAsync(x => x.DeviceUserId == e.DeviceUserId);
            if (existing == null) { _db.Employees.Add(e); }
            else {
                existing.FullName = e.FullName;
                existing.EmployeeCode = e.EmployeeCode;
                existing.IsActive = e.IsActive;
            }
            await _db.SaveChangesAsync();

            // Back-link any orphan logs that came in before mapping existed.
            var pin = e.DeviceUserId;
            var empId = (existing ?? e).Id;
            await _db.AttendanceLogs
                .Where(a => a.DeviceUserId == pin && a.EmployeeId == null)
                .ExecuteUpdateAsync(s => s.SetProperty(a => a.EmployeeId, empId));

            return Ok();
        }

        public class DeviceUpdate { public string Name { get; set; } public string Location { get; set; } }
    }
}
