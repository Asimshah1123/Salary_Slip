import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';

// Adjust base to match your API. If you use a proxy, keep '/api/attendance'.
const BASE = `${environment.apiUrl}/api/attendance`;

export interface AttendanceLog {
  id: number;
  deviceUserId: string;
  employeeName: string;
  employeeCode: string | null;
  device: string;
  punchTime: string;
  status: number;
  verify: string;
}

export interface LogPage {
  total: number; page: number; pageSize: number; items: AttendanceLog[];
}

export interface ZkDevice {
  id: number; serialNumber: string; name: string;
  location: string; isActive: boolean; lastSeenUtc: string | null;
}

@Injectable({ providedIn: 'root' })
export class AttendanceService {
  constructor(private http: HttpClient) {}

  getLogs(opts: {
    from?: string; to?: string; deviceId?: number; search?: string;
    page?: number; pageSize?: number;
  }): Observable<LogPage> {
    let p = new HttpParams();
    Object.entries(opts).forEach(([k, v]) => {
      if (v !== undefined && v !== null && v !== '') p = p.set(k, String(v));
    });
    return this.http.get<LogPage>(`${BASE}/logs`, { params: p });
  }

  getDaily(date: string): Observable<any[]> {
    return this.http.get<any[]>(`${BASE}/daily`, { params: { date } });
  }

  getDevices(): Observable<ZkDevice[]> {
    return this.http.get<ZkDevice[]>(`${BASE}/devices`);
  }

  activateDevice(id: number, name: string, location: string): Observable<any> {
    return this.http.post(`${BASE}/devices/${id}/activate`, { name, location });
  }

  upsertEmployee(e: { deviceUserId: string; fullName: string; employeeCode: string; isActive: boolean; }) {
    return this.http.post(`${BASE}/employees`, e);
  }
}
