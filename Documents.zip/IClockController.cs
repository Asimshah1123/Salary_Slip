using System;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Distribution.Attendance.Data;
using Distribution.Attendance.Models;

namespace Distribution.Attendance.Controllers
{
    // =========================================================================
    //  ZK iClock / ADMS "Push" protocol endpoint.
    //
    //  On the device:  Menu > Comm > Cloud Server / ADMS
    //     Server Mode : ADMS
    //     Server Addr : <your server IP or domain>
    //     Server Port : <port your API listens on, e.g. 80 / 443 / 8080>
    //     Enable Domain Name : ON if you use a domain
    //     HTTPS is supported by newer firmware only; if handshake fails use HTTP.
    //
    //  The device then calls these routes automatically:
    //     GET  /iclock/cdata?SN=...&options=all         -> initial handshake / config
    //     GET  /iclock/getrequest?SN=...                -> polls for commands
    //     POST /iclock/cdata?SN=...&table=ATTLOG        -> pushes punch logs
    //     POST /iclock/cdata?SN=...&table=OPERLOG       -> pushes operation logs
    //  All responses are PLAIN TEXT, not JSON. The device is picky about this.
    // =========================================================================
    [ApiController]
    [Route("iclock")]
    public class IClockController : ControllerBase
    {
        private readonly AttendanceDbContext _db;
        public IClockController(AttendanceDbContext db) => _db = db;

        // ---- 1. Handshake: device announces itself ----------------------------
        [HttpGet("cdata")]
        public async Task<IActionResult> Handshake([FromQuery] string SN)
        {
            if (string.IsNullOrWhiteSpace(SN))
                return Content("ERROR: no SN", "text/plain");

            var device = await _db.ZkDevices.FirstOrDefaultAsync(d => d.SerialNumber == SN);
            if (device == null)
            {
                // Auto-register unknown devices as inactive so an admin can approve them.
                device = new ZkDevice { SerialNumber = SN, Name = "Unregistered " + SN, IsActive = false };
                _db.ZkDevices.Add(device);
                await _db.SaveChangesAsync();
            }

            device.LastSeenUtc = DateTime.UtcNow;
            await _db.SaveChangesAsync();

            // Tell the device how to behave. Stamp cursors resume from last known.
            var body =
                $"GET OPTION FROM: {SN}\n" +
                "Stamp=9999\n" +
                "OpStamp=9999\n" +
                "ErrorDelay=30\n" +
                "Delay=10\n" +               // seconds between polls
                "TransTimes=00:00;14:05\n" +
                "TransInterval=1\n" +
                "TransFlag=1111000000\n" +   // 1st '1' = upload attendance
                "Realtime=1\n" +            // push in real time
                "Encrypt=0\n";
            return Content(body, "text/plain");
        }

        // ---- 2. Device polls for commands to run (add user, clear, etc.) ------
        [HttpGet("getrequest")]
        public async Task<IActionResult> GetRequest([FromQuery] string SN)
        {
            var device = await _db.ZkDevices.FirstOrDefaultAsync(d => d.SerialNumber == SN);
            if (device != null)
            {
                device.LastSeenUtc = DateTime.UtcNow;
                await _db.SaveChangesAsync();
            }
            // No queued commands -> device expects literally "OK".
            return Content("OK", "text/plain");
        }

        // ---- 3. Device pushes data (attendance logs) -------------------------
        [HttpPost("cdata")]
        public async Task<IActionResult> ReceiveData([FromQuery] string SN, [FromQuery] string table)
        {
            var device = await _db.ZkDevices.FirstOrDefaultAsync(d => d.SerialNumber == SN);
            if (device == null)
                return Content("ERROR: unknown SN", "text/plain");

            device.LastSeenUtc = DateTime.UtcNow;

            string raw;
            using (var reader = new StreamReader(Request.Body))
                raw = await reader.ReadToEndAsync();

            // We only care about attendance uploads here.
            if (!string.Equals(table, "ATTLOG", StringComparison.OrdinalIgnoreCase))
            {
                await _db.SaveChangesAsync();
                return Content("OK", "text/plain");
            }

            int inserted = 0;
            // Each line is tab-separated:  PIN \t YYYY-MM-DD HH:mm:ss \t status \t verify \t ...
            var lines = raw.Replace("\r", "").Split('\n', StringSplitOptions.RemoveEmptyEntries);
            foreach (var line in lines)
            {
                var p = line.Split('\t');
                if (p.Length < 2) continue;

                var pin = p[0].Trim();
                if (!DateTime.TryParse(p[1].Trim(), CultureInfo.InvariantCulture,
                                       DateTimeStyles.None, out var punchTime))
                    continue;

                int status = p.Length > 2 && int.TryParse(p[2], out var s) ? s : 0;
                int verify = p.Length > 3 && int.TryParse(p[3], out var v) ? v : 0;

                // De-dupe against the unique index.
                bool exists = await _db.AttendanceLogs.AnyAsync(a =>
                    a.ZkDeviceId == device.Id &&
                    a.DeviceUserId == pin &&
                    a.PunchTimeLocal == punchTime);
                if (exists) continue;

                var emp = await _db.Employees
                    .FirstOrDefaultAsync(e => e.DeviceUserId == pin && e.IsActive);

                _db.AttendanceLogs.Add(new AttendanceLog
                {
                    ZkDeviceId     = device.Id,
                    DeviceUserId   = pin,
                    EmployeeId     = emp?.Id,
                    PunchTimeLocal = punchTime,
                    Status         = status,
                    VerifyMode     = verify
                });
                inserted++;
            }

            await _db.SaveChangesAsync();

            // Device expects: "OK: <number of records accepted>"
            return Content($"OK: {inserted}", "text/plain");
        }
    }
}
