import { Component, OnInit, OnDestroy } from '@angular/core';
import { Subscription, interval } from 'rxjs';
import { switchMap } from 'rxjs/operators';
import { AttendanceService, AttendanceLog, ZkDevice } from './attendance.service';

@Component({
  selector: 'app-attendance',
  templateUrl: './attendance.component.html',
  styleUrls: ['./attendance.component.css']
})
export class AttendanceComponent implements OnInit, OnDestroy {
  logs: AttendanceLog[] = [];
  devices: ZkDevice[] = [];
  total = 0;
  page = 1;
  pageSize = 50;
  loading = false;

  // filters
  from = this.today();
  to = this.today();
  deviceId?: number;
  search = '';

  autoRefresh = true;
  private sub?: Subscription;

  constructor(private svc: AttendanceService) {}

  ngOnInit(): void {
    this.loadDevices();
    this.load();
    // Real-time feel: re-poll every 15s. Device pushes to server; UI pulls from server.
    this.sub = interval(15000)
      .pipe(switchMap(() => this.svc.getLogs(this.filters())))
      .subscribe(res => { if (this.autoRefresh) { this.logs = res.items; this.total = res.total; } });
  }

  ngOnDestroy(): void { this.sub?.unsubscribe(); }

  private filters() {
    return {
      from: this.from, to: this.to, deviceId: this.deviceId,
      search: this.search, page: this.page, pageSize: this.pageSize
    };
  }

  load(): void {
    this.loading = true;
    this.svc.getLogs(this.filters()).subscribe({
      next: res => { this.logs = res.items; this.total = res.total; this.loading = false; },
      error: () => { this.loading = false; }
    });
  }

  loadDevices(): void {
    this.svc.getDevices().subscribe(d => this.devices = d);
  }

  changePage(delta: number): void {
    const next = this.page + delta;
    if (next < 1 || (next - 1) * this.pageSize >= this.total) return;
    this.page = next; this.load();
  }

  activate(dev: ZkDevice): void {
    const name = prompt('Device name?', dev.name) || dev.name;
    const loc = prompt('Location?', dev.location) || dev.location;
    this.svc.activateDevice(dev.id, name, loc).subscribe(() => this.loadDevices());
  }

  isOnline(dev: ZkDevice): boolean {
    if (!dev.lastSeenUtc) return false;
    return (Date.now() - new Date(dev.lastSeenUtc).getTime()) < 60_000; // seen in last 60s
  }

  private today(): string { return new Date().toISOString().slice(0, 10); }
}
