import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { InvoiceService } from '../../services/invoice.service';
import { Invoice, InvoiceStatus } from '../../models/invoice.model';

@Component({
  selector: 'app-invoice-list',
  imports: [CommonModule, RouterLink],
  templateUrl: './invoice-list.html',
  styleUrl: './invoice-list.scss'
})
export class InvoiceList implements OnInit {
  invoices = signal<Invoice[]>([]);
  loading = signal(true);
  error = signal<string | null>(null);
  InvoiceStatus = InvoiceStatus;

  constructor(private invoiceService: InvoiceService) {}

  ngOnInit(): void {
    this.load();
  }

  load(): void {
    this.loading.set(true);
    this.invoiceService.getAll().subscribe({
      next: (data) => {
        this.invoices.set(data);
        this.loading.set(false);
      },
      error: () => {
        this.error.set('Could not reach the invoicing API. Is the backend running on http://localhost:5141?');
        this.loading.set(false);
      }
    });
  }

  statusLabel(status: InvoiceStatus): string {
    switch (status) {
      case InvoiceStatus.Draft: return 'Draft';
      case InvoiceStatus.Generated: return 'Phase 1 generated';
      case InvoiceStatus.Signed: return 'Phase 2 signed';
      case InvoiceStatus.Submitted: return 'Submitted';
      case InvoiceStatus.Cleared: return 'Cleared';
      case InvoiceStatus.Reported: return 'Reported';
      case InvoiceStatus.Rejected: return 'Rejected';
      default: return 'Unknown';
    }
  }

  delete(id: string, event: Event): void {
    event.stopPropagation();
    event.preventDefault();
    if (!confirm('Delete this invoice? This cannot be undone.')) return;
    this.invoiceService.delete(id).subscribe(() => this.load());
  }
}
