import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { SellerProfileService } from '../../services/seller-profile.service';

@Component({
  selector: 'app-seller-settings',
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './seller-settings.html',
  styleUrl: './seller-settings.scss'
})
export class SellerSettings implements OnInit {
  form: FormGroup;
  saved = signal(false);
  loading = signal(true);

  constructor(private fb: FormBuilder, private sellerProfileService: SellerProfileService) {
    this.form = this.fb.group({
      name: ['', Validators.required],
      vatNumber: ['', [Validators.required, Validators.pattern(/^\d{15}$/)]],
      crNumber: [''],
      streetName: [''],
      buildingNumber: [''],
      citySubdivision: [''],
      city: [''],
      postalCode: [''],
      country: ['SA']
    });
  }

  ngOnInit(): void {
    this.sellerProfileService.get().subscribe((profile) => {
      this.form.patchValue(profile.party);
      this.loading.set(false);
    });
  }

  save(): void {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }
    this.sellerProfileService.save({ party: this.form.value }).subscribe(() => {
      this.saved.set(true);
      setTimeout(() => this.saved.set(false), 2500);
    });
  }
}
