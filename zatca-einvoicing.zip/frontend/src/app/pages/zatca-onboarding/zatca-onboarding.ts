import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { ZatcaOnboardingService } from '../../services/zatca-onboarding.service';
import { ZatcaConfig, ZatcaOnboardingStage } from '../../models/invoice.model';

@Component({
  selector: 'app-zatca-onboarding',
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './zatca-onboarding.html',
  styleUrl: './zatca-onboarding.scss'
})
export class ZatcaOnboarding implements OnInit {
  form: FormGroup;
  config = signal<ZatcaConfig | null>(null);
  loading = signal(true);
  saving = signal(false);
  requesting = signal<'compliance' | 'production' | null>(null);
  saved = signal(false);
  Stage = ZatcaOnboardingStage;

  constructor(private fb: FormBuilder, private onboarding: ZatcaOnboardingService) {
    this.form = this.fb.group({
      environment: ['Sandbox', Validators.required],
      otpCode: ['', Validators.required],
      egsSerialNumber: ['', Validators.required],
      vatRegistrationNumber: ['', [Validators.required, Validators.pattern(/^\d{15}$/)]],
      organizationName: ['', Validators.required],
      organizationUnitName: ['', Validators.required],
      commonName: ['', Validators.required],
      country: ['SA', Validators.required],
      invoiceType: ['1100', Validators.required],
      location: ['', Validators.required],
      businessCategory: ['', Validators.required]
    });
  }

  ngOnInit(): void {
    this.load();
  }

  private load(): void {
    this.onboarding.getConfig().subscribe((config) => {
      this.applyConfig(config);
      this.loading.set(false);
    });
  }

  private applyConfig(config: ZatcaConfig): void {
    this.config.set(config);
    this.form.patchValue(config);
  }

  get csrUrl(): string {
    return this.onboarding.getCsrUrl();
  }

  stageLabel(stage: ZatcaOnboardingStage): string {
    switch (stage) {
      case ZatcaOnboardingStage.NotStarted: return 'Not started';
      case ZatcaOnboardingStage.CsrGenerated: return 'CSR generated';
      case ZatcaOnboardingStage.ComplianceCsidIssued: return 'Compliance CSID issued';
      case ZatcaOnboardingStage.ProductionCsidIssued: return 'Production CSID issued — ready to submit invoices';
      default: return 'Unknown';
    }
  }

  saveDetails(): void {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }
    this.saving.set(true);
    this.onboarding.updateConfig(this.form.value).subscribe((config) => {
      this.applyConfig(config);
      this.saving.set(false);
      this.saved.set(true);
      setTimeout(() => this.saved.set(false), 2500);
    });
  }

  requestComplianceCsid(): void {
    this.requesting.set('compliance');
    this.onboarding.requestComplianceCsid().subscribe((config) => {
      this.applyConfig(config);
      this.requesting.set(null);
    });
  }

  requestProductionCsid(): void {
    this.requesting.set('production');
    this.onboarding.requestProductionCsid().subscribe((config) => {
      this.applyConfig(config);
      this.requesting.set(null);
    });
  }
}
