import { Component, ElementRef, OnInit, signal, ViewChild, AfterViewInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { InvoiceService } from '../../services/invoice.service';
import { QrService } from '../../services/qr.service';
import { Invoice, InvoiceStatus } from '../../models/invoice.model';

@Component({
  selector: 'app-invoice-detail',
  imports: [CommonModule, RouterLink],
  templateUrl: './invoice-detail.html',
  styleUrl: './invoice-detail.scss'
})
export class InvoiceDetail implements OnInit, AfterViewInit {
  @ViewChild('qrCanvas') qrCanvas?: ElementRef<HTMLCanvasElement>;

  invoice = signal<Invoice | null>(null);
  loading = signal(true);
  error = signal<string | null>(null);
  showRawTlv = signal(false);
  submitting = signal(false);
  InvoiceStatus = InvoiceStatus;

  constructor(
    private route: ActivatedRoute,
    private invoiceService: InvoiceService,
    private qrService: QrService
  ) {}

  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get('id')!;
    this.invoiceService.getById(id).subscribe({
      next: (inv) => {
        this.invoice.set(inv);
        this.loading.set(false);
        setTimeout(() => this.renderQr());
      },
      error: () => {
        this.error.set('Invoice not found, or the backend is unreachable.');
        this.loading.set(false);
      }
    });
  }

  ngAfterViewInit(): void {
    this.renderQr();
  }

  private renderQr(): void {
    const inv = this.invoice();
    const canvas = this.qrCanvas?.nativeElement;
    const qr = inv?.phase2QrBase64 ?? inv?.phase1QrBase64;
    if (!canvas || !qr) return;
    this.qrService.renderToCanvas(canvas, qr).catch(() => this.error.set('Could not render the QR code.'));
  }

  get xmlUrl(): string {
    const inv = this.invoice();
    return inv ? this.invoiceService.getXmlUrl(inv.id) : '';
  }

  get printUrl(): string {
    const inv = this.invoice();
    return inv ? this.invoiceService.getPrintUrl(inv.id) : '';
  }

  printThisPage(): void {
    window.print();
  }

  statusLabel(status: InvoiceStatus): string {
    switch (status) {
      case InvoiceStatus.Draft: return 'Draft';
      case InvoiceStatus.Generated: return 'Phase 1 generated';
      case InvoiceStatus.Signed: return 'Phase 2 signed';
      case InvoiceStatus.Submitted: return 'Submitted to ZATCA';
      case InvoiceStatus.Cleared: return 'Cleared by ZATCA';
      case InvoiceStatus.Reported: return 'Reported to ZATCA';
      case InvoiceStatus.Rejected: return 'Rejected by ZATCA';
      default: return 'Unknown';
    }
  }

  submitToZatca(): void {
    const inv = this.invoice();
    if (!inv) return;
    this.submitting.set(true);
    this.invoiceService.submit(inv.id).subscribe({
      next: (updated) => {
        this.invoice.set(updated);
        this.submitting.set(false);
      },
      error: (err) => {
        this.submitting.set(false);
        this.error.set(err?.error?.error || 'Could not submit to ZATCA.');
      }
    });
  }
}
