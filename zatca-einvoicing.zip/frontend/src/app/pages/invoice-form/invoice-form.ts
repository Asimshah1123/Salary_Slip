import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, FormArray, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { InvoiceService } from '../../services/invoice.service';
import { SellerProfileService } from '../../services/seller-profile.service';
import { InvoiceDocumentType, InvoiceSubject } from '../../models/invoice.model';

@Component({
  selector: 'app-invoice-form',
  imports: [CommonModule, ReactiveFormsModule, RouterLink],
  templateUrl: './invoice-form.html',
  styleUrl: './invoice-form.scss'
})
export class InvoiceForm implements OnInit {
  form: FormGroup;
  submitting = signal(false);
  error = signal<string | null>(null);
  sellerName = signal<string>('');

  documentTypes = [
    { value: InvoiceDocumentType.TaxInvoice, label: 'Tax invoice' },
    { value: InvoiceDocumentType.CreditNote, label: 'Credit note' },
    { value: InvoiceDocumentType.DebitNote, label: 'Debit note' }
  ];

  subjects = [
    { value: InvoiceSubject.Simplified, label: 'Simplified (B2C) — reporting model' },
    { value: InvoiceSubject.Standard, label: 'Standard (B2B/B2G) — clearance model' }
  ];

  constructor(
    private fb: FormBuilder,
    private invoiceService: InvoiceService,
    private sellerProfileService: SellerProfileService,
    private router: Router
  ) {
    this.form = this.fb.group({
      invoiceNumber: [''],
      documentType: [InvoiceDocumentType.TaxInvoice, Validators.required],
      subject: [InvoiceSubject.Simplified, Validators.required],
      currency: ['SAR', Validators.required],
      buyer: this.fb.group({
        name: ['', Validators.required],
        vatNumber: [''],
        crNumber: [''],
        streetName: [''],
        buildingNumber: [''],
        citySubdivision: [''],
        city: [''],
        postalCode: [''],
        country: ['SA']
      }),
      lineItems: this.fb.array([this.newLineItem()]),
      notes: ['']
    });
  }

  ngOnInit(): void {
    this.sellerProfileService.get().subscribe((p) => this.sellerName.set(p.party.name));
  }

  get lineItems(): FormArray {
    return this.form.get('lineItems') as FormArray;
  }

  newLineItem(): FormGroup {
    return this.fb.group({
      description: ['', Validators.required],
      quantity: [1, [Validators.required, Validators.min(0.001)]],
      unitPrice: [0, [Validators.required, Validators.min(0)]],
      vatRate: [15, [Validators.required, Validators.min(0), Validators.max(100)]],
      vatCategoryCode: ['S', Validators.required]
    });
  }

  addLineItem(): void {
    this.lineItems.push(this.newLineItem());
  }

  removeLineItem(index: number): void {
    if (this.lineItems.length === 1) return;
    this.lineItems.removeAt(index);
  }

  lineNet(index: number): number {
    const li = this.lineItems.at(index).value;
    return (li.quantity || 0) * (li.unitPrice || 0);
  }

  lineVat(index: number): number {
    const li = this.lineItems.at(index).value;
    return this.lineNet(index) * (li.vatRate || 0) / 100;
  }

  get subtotal(): number {
    return this.lineItems.controls.reduce((sum, _, i) => sum + this.lineNet(i), 0);
  }

  get vatTotal(): number {
    return this.lineItems.controls.reduce((sum, _, i) => sum + this.lineVat(i), 0);
  }

  get grandTotal(): number {
    return this.subtotal + this.vatTotal;
  }

  submit(): void {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      this.error.set('Fill in the required fields highlighted below.');
      return;
    }

    this.submitting.set(true);
    this.error.set(null);

    const value = this.form.value;
    this.invoiceService
      .create({
        invoiceNumber: value.invoiceNumber || undefined,
        documentType: value.documentType,
        subject: value.subject,
        currency: value.currency,
        buyer: value.buyer,
        lineItems: value.lineItems,
        notes: value.notes || undefined
      })
      .subscribe({
        next: (created) => this.router.navigate(['/invoices', created.id]),
        error: (err) => {
          this.submitting.set(false);
          this.error.set(err?.error?.error || 'Could not create the invoice. Is the backend running?');
        }
      });
  }
}
