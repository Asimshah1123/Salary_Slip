import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Party } from '../models/invoice.model';

const API_BASE = 'http://localhost:5141/api';

export interface SellerProfile {
  party: Party;
}

@Injectable({ providedIn: 'root' })
export class SellerProfileService {
  constructor(private http: HttpClient) {}

  get(): Observable<SellerProfile> {
    return this.http.get<SellerProfile>(`${API_BASE}/sellerprofile`);
  }

  save(profile: SellerProfile): Observable<SellerProfile> {
    return this.http.put<SellerProfile>(`${API_BASE}/sellerprofile`, profile);
  }
}
