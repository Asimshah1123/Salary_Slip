import { Injectable } from '@angular/core';
import * as QRCode from 'qrcode';

/**
 * ZATCA's QR code must encode the raw TLV *bytes*, not the Base64 text that
 * carries them over the wire. We decode the Base64 string back to a byte
 * array and pass it to the QR encoder as an explicit "byte mode" segment so
 * the library writes those exact bytes into the QR symbol instead of
 * re-encoding a JS string as UTF-8 (which would corrupt bytes > 0x7F).
 */
@Injectable({ providedIn: 'root' })
export class QrService {
  private base64ToBytes(base64: string): Uint8Array {
    const binary = atob(base64);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) {
      bytes[i] = binary.charCodeAt(i);
    }
    return bytes;
  }

  async renderToCanvas(canvas: HTMLCanvasElement, base64Tlv: string): Promise<void> {
    const bytes = this.base64ToBytes(base64Tlv);
    const segments = [{ data: bytes, mode: 'byte' }] as unknown as QRCode.QRCodeSegment[];
    await QRCode.toCanvas(canvas, segments, { width: 220, margin: 1 });
  }

  async toDataUrl(base64Tlv: string): Promise<string> {
    const bytes = this.base64ToBytes(base64Tlv);
    const segments = [{ data: bytes, mode: 'byte' }] as unknown as QRCode.QRCodeSegment[];
    return QRCode.toDataURL(segments, { width: 220, margin: 1 });
  }
}
