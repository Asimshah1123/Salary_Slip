import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ZatcaConfig } from '../models/invoice.model';

const API_BASE = 'http://localhost:5141/api/zatca';

export type ZatcaConfigEditable = Omit<
  ZatcaConfig,
  'stage' | 'hasCsr' | 'complianceRequestId' | 'hasComplianceCsid' | 'productionRequestId' | 'hasProductionCsid' | 'lastError' | 'updatedAtUtc'
>;

@Injectable({ providedIn: 'root' })
export class ZatcaOnboardingService {
  constructor(private http: HttpClient) {}

  getConfig(): Observable<ZatcaConfig> {
    return this.http.get<ZatcaConfig>(`${API_BASE}/config`);
  }

  updateConfig(config: ZatcaConfigEditable): Observable<ZatcaConfig> {
    return this.http.put<ZatcaConfig>(`${API_BASE}/config`, config);
  }

  requestComplianceCsid(): Observable<ZatcaConfig> {
    return this.http.post<ZatcaConfig>(`${API_BASE}/onboarding/compliance`, {});
  }

  requestProductionCsid(): Observable<ZatcaConfig> {
    return this.http.post<ZatcaConfig>(`${API_BASE}/onboarding/production`, {});
  }

  getCsrUrl(): string {
    return `${API_BASE}/onboarding/csr`;
  }
}
