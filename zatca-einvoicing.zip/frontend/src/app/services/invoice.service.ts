import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Invoice, InvoiceCreateRequest, QrInfo } from '../models/invoice.model';

const API_BASE = 'http://localhost:5141/api';

@Injectable({ providedIn: 'root' })
export class InvoiceService {
  constructor(private http: HttpClient) {}

  getAll(): Observable<Invoice[]> {
    return this.http.get<Invoice[]>(`${API_BASE}/invoices`);
  }

  getById(id: string): Observable<Invoice> {
    return this.http.get<Invoice>(`${API_BASE}/invoices/${id}`);
  }

  create(request: InvoiceCreateRequest): Observable<Invoice> {
    return this.http.post<Invoice>(`${API_BASE}/invoices`, request);
  }

  delete(id: string): Observable<void> {
    return this.http.delete<void>(`${API_BASE}/invoices/${id}`);
  }

  getQr(id: string): Observable<QrInfo> {
    return this.http.get<QrInfo>(`${API_BASE}/invoices/${id}/qr`);
  }

  getXmlUrl(id: string): string {
    return `${API_BASE}/invoices/${id}/xml`;
  }

  submit(id: string): Observable<Invoice> {
    return this.http.post<Invoice>(`${API_BASE}/invoices/${id}/submit`, {});
  }

  getPrintUrl(id: string): string {
    return `${API_BASE}/invoices/${id}/print`;
  }
}
