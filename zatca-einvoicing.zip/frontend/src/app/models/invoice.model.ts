export interface Party {
  name: string;
  vatNumber: string;
  crNumber?: string | null;
  streetName: string;
  buildingNumber: string;
  plotIdentification?: string;
  citySubdivision: string;
  city: string;
  postalCode: string;
  country: string;
}

export interface LineItem {
  id?: string;
  description: string;
  quantity: number;
  unitPrice: number;
  vatRate: number;
  vatCategoryCode: string;
  lineExtensionAmount?: number;
  vatAmount?: number;
  lineTotalWithVat?: number;
}

/** Mirrors backend InvoiceDocumentType enum values. */
export enum InvoiceDocumentType {
  TaxInvoice = 388,
  DebitNote = 383,
  CreditNote = 381
}

/** Mirrors backend InvoiceSubject enum values. */
export enum InvoiceSubject {
  Standard = 1,
  Simplified = 2
}

export enum InvoiceStatus {
  Draft = 0,
  Generated = 1,
  Signed = 2,
  Submitted = 3,
  Cleared = 4,
  Reported = 5,
  Rejected = 6
}

export interface InvoiceCreateRequest {
  invoiceNumber?: string;
  documentType: InvoiceDocumentType;
  subject: InvoiceSubject;
  currency: string;
  seller?: Party | null;
  buyer: Party;
  lineItems: LineItem[];
  notes?: string;
}

export interface Invoice extends Omit<InvoiceCreateRequest, 'seller'> {
  id: string;
  uuid: string;
  icv: number;
  seller: Party;
  previousInvoiceHash: string;
  invoiceHash?: string | null;
  issueDateTimeUtc: string;
  status: InvoiceStatus;
  phase1QrBase64?: string | null;
  ublXml?: string | null;
  phase2QrBase64?: string | null;
  signatureBase64?: string | null;
  publicKeyBase64?: string | null;
  certificateSignatureBase64?: string | null;
  zatcaSubmissionResponseJson?: string | null;
  zatcaWarnings: string[];
  zatcaErrors: string[];
  clearedInvoiceXml?: string | null;
  taxExclusiveAmount: number;
  vatTotal: number;
  taxInclusiveAmount: number;
}

/** Mirrors backend ZatcaOnboardingStage enum values. */
export enum ZatcaOnboardingStage {
  NotStarted = 0,
  CsrGenerated = 1,
  ComplianceCsidIssued = 2,
  ProductionCsidIssued = 3
}

export interface ZatcaConfig {
  environment: string;
  otpCode: string;
  egsSerialNumber: string;
  vatRegistrationNumber: string;
  organizationName: string;
  organizationUnitName: string;
  commonName: string;
  country: string;
  invoiceType: string;
  location: string;
  businessCategory: string;
  stage: ZatcaOnboardingStage;
  hasCsr: boolean;
  complianceRequestId?: string | null;
  hasComplianceCsid: boolean;
  productionRequestId?: string | null;
  hasProductionCsid: boolean;
  lastError?: string | null;
  updatedAtUtc?: string | null;
}

export interface QrInfo {
  base64: string;
  phase: 1 | 2;
  tags: { tag: number; value: string }[];
}

export function emptyParty(): Party {
  return {
    name: '',
    vatNumber: '',
    crNumber: '',
    streetName: '',
    buildingNumber: '',
    plotIdentification: '',
    citySubdivision: '',
    city: '',
    postalCode: '',
    country: 'SA'
  };
}

export function emptyLineItem(): LineItem {
  return {
    description: '',
    quantity: 1,
    unitPrice: 0,
    vatRate: 15,
    vatCategoryCode: 'S'
  };
}
