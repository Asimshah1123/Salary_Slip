import { Routes } from '@angular/router';
import { InvoiceList } from './pages/invoice-list/invoice-list';
import { InvoiceForm } from './pages/invoice-form/invoice-form';
import { InvoiceDetail } from './pages/invoice-detail/invoice-detail';
import { SellerSettings } from './pages/seller-settings/seller-settings';
import { ZatcaOnboarding } from './pages/zatca-onboarding/zatca-onboarding';

export const routes: Routes = [
  { path: '', pathMatch: 'full', redirectTo: 'invoices' },
  { path: 'invoices', component: InvoiceList },
  { path: 'invoices/new', component: InvoiceForm },
  { path: 'invoices/:id', component: InvoiceDetail },
  { path: 'settings', component: SellerSettings },
  { path: 'zatca-onboarding', component: ZatcaOnboarding }
];
