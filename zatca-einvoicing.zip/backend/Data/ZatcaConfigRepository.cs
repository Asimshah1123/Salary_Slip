using Zatca.Api.Models;

namespace Zatca.Api.Data;

public class ZatcaConfigRepository
{
    private readonly JsonFileStore<ZatcaConfig> _store = new("zatca-config.json");
    private readonly object _lock = new();

    public ZatcaConfig Get()
    {
        lock (_lock)
        {
            var all = _store.LoadAll();
            if (all.Count == 0)
            {
                var config = new ZatcaConfig();
                _store.SaveAll(new List<ZatcaConfig> { config });
                return config;
            }
            return all[0];
        }
    }

    public ZatcaConfig Save(ZatcaConfig config)
    {
        lock (_lock)
        {
            config.UpdatedAtUtc = DateTime.UtcNow;
            _store.SaveAll(new List<ZatcaConfig> { config });
            return config;
        }
    }
}
