using Zatca.Api.Models;

namespace Zatca.Api.Data;

public class InvoiceRepository
{
    private readonly JsonFileStore<Invoice> _store = new("invoices.json");
    private readonly object _lock = new();

    public List<Invoice> GetAll()
    {
        lock (_lock)
        {
            return _store.LoadAll().OrderByDescending(i => i.Icv).ToList();
        }
    }

    public Invoice? GetById(string id)
    {
        lock (_lock)
        {
            return _store.LoadAll().FirstOrDefault(i => i.Id == id);
        }
    }

    /// <summary>Returns the most recent invoice in ICV order, or null if none exist yet.</summary>
    public Invoice? GetLatest()
    {
        lock (_lock)
        {
            return _store.LoadAll().OrderByDescending(i => i.Icv).FirstOrDefault();
        }
    }

    public Invoice Add(Invoice invoice)
    {
        lock (_lock)
        {
            var all = _store.LoadAll();
            all.Add(invoice);
            _store.SaveAll(all);
            return invoice;
        }
    }

    public Invoice? Update(Invoice invoice)
    {
        lock (_lock)
        {
            var all = _store.LoadAll();
            var idx = all.FindIndex(i => i.Id == invoice.Id);
            if (idx < 0) return null;
            all[idx] = invoice;
            _store.SaveAll(all);
            return invoice;
        }
    }

    public bool Delete(string id)
    {
        lock (_lock)
        {
            var all = _store.LoadAll();
            var removed = all.RemoveAll(i => i.Id == id);
            if (removed > 0) _store.SaveAll(all);
            return removed > 0;
        }
    }
}
