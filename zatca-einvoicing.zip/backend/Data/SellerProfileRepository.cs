using Zatca.Api.Models;

namespace Zatca.Api.Data;

public class SellerProfileRepository
{
    private readonly JsonFileStore<SellerProfile> _store = new("seller-profile.json");
    private readonly object _lock = new();

    public SellerProfile Get()
    {
        lock (_lock)
        {
            var all = _store.LoadAll();
            if (all.Count == 0)
            {
                var defaultProfile = new SellerProfile();
                _store.SaveAll(new List<SellerProfile> { defaultProfile });
                return defaultProfile;
            }
            return all[0];
        }
    }

    public SellerProfile Save(SellerProfile profile)
    {
        lock (_lock)
        {
            _store.SaveAll(new List<SellerProfile> { profile });
            return profile;
        }
    }
}
