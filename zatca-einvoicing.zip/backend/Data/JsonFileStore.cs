using System.Text.Json;

namespace Zatca.Api.Data;

/// <summary>
/// Minimal, thread-safe, file-backed JSON store. Stands in for a real database
/// (this environment cannot restore EF Core / SQLite NuGet packages). Swap this
/// out for EF Core + a real database in production without changing callers,
/// since everything goes through the small Load/Save API below.
/// </summary>
public class JsonFileStore<T>
{
    private readonly string _filePath;
    private readonly object _lock = new();
    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        WriteIndented = true,
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase
    };

    public JsonFileStore(string fileName)
    {
        var dataDir = Path.Combine(AppContext.BaseDirectory, "App_Data");
        Directory.CreateDirectory(dataDir);
        _filePath = Path.Combine(dataDir, fileName);
    }

    public List<T> LoadAll()
    {
        lock (_lock)
        {
            if (!File.Exists(_filePath))
            {
                return new List<T>();
            }

            var json = File.ReadAllText(_filePath);
            if (string.IsNullOrWhiteSpace(json))
            {
                return new List<T>();
            }

            return JsonSerializer.Deserialize<List<T>>(json, JsonOptions) ?? new List<T>();
        }
    }

    public void SaveAll(List<T> items)
    {
        lock (_lock)
        {
            var json = JsonSerializer.Serialize(items, JsonOptions);
            File.WriteAllText(_filePath, json);
        }
    }
}
