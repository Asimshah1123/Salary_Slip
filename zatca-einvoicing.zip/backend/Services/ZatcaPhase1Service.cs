using System.Globalization;
using Zatca.Api.Models;

namespace Zatca.Api.Services;

/// <summary>
/// ZATCA Phase 1 ("Generation Phase") QR code: a Base64 TLV string carrying 5 fields.
/// No ZATCA onboarding, certificate, or API call is required to produce this.
/// Tags: 1=Seller name, 2=VAT number, 3=Timestamp (ISO 8601), 4=Invoice total (incl. VAT), 5=VAT total.
/// </summary>
public class ZatcaPhase1Service
{
    public string BuildQrBase64(Invoice invoice)
    {
        var timestamp = invoice.IssueDateTimeUtc.ToString("yyyy-MM-ddTHH:mm:ssZ", CultureInfo.InvariantCulture);
        var total = invoice.TaxInclusiveAmount.ToString("F2", CultureInfo.InvariantCulture);
        var vat = invoice.VatTotal.ToString("F2", CultureInfo.InvariantCulture);

        return TlvEncoder.ToBase64(
            TlvEncoder.Encode(1, invoice.Seller.Name),
            TlvEncoder.Encode(2, invoice.Seller.VatNumber),
            TlvEncoder.Encode(3, timestamp),
            TlvEncoder.Encode(4, total),
            TlvEncoder.Encode(5, vat)
        );
    }

    /// <summary>Decodes a Phase 1 (or the first 5 tags of a Phase 2) TLV Base64 string — useful for the UI's "verify" view.</summary>
    public List<(byte Tag, string Value)> Decode(string base64)
    {
        var bytes = Convert.FromBase64String(base64);
        var result = new List<(byte, string)>();
        var i = 0;
        while (i < bytes.Length)
        {
            var tag = bytes[i];
            var len = bytes[i + 1];
            var value = System.Text.Encoding.UTF8.GetString(bytes, i + 2, len);
            result.Add((tag, value));
            i += 2 + len;
        }
        return result;
    }
}
