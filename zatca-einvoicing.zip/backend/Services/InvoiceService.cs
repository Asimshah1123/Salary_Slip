using Zatca.Api.Data;
using Zatca.Api.Models;

namespace Zatca.Api.Services;

public class InvoiceService
{
    private readonly InvoiceRepository _repo;
    private readonly SellerProfileRepository _profileRepo;
    private readonly ZatcaPhase1Service _phase1;
    private readonly ZatcaPhase2Service _phase2;

    public InvoiceService(
        InvoiceRepository repo,
        SellerProfileRepository profileRepo,
        ZatcaPhase1Service phase1,
        ZatcaPhase2Service phase2)
    {
        _repo = repo;
        _profileRepo = profileRepo;
        _phase1 = phase1;
        _phase2 = phase2;
    }

    public List<Invoice> GetAll() => _repo.GetAll();

    public Invoice? GetById(string id) => _repo.GetById(id);

    /// <summary>Creates a new invoice, assigns the next ICV, chains PIH, and runs Phase 1 + Phase 2.</summary>
    public Invoice Create(Invoice draft)
    {
        if (draft.Seller is null || string.IsNullOrWhiteSpace(draft.Seller.Name))
        {
            draft.Seller = _profileRepo.Get().Party;
        }

        var latest = _repo.GetLatest();
        draft.Icv = (latest?.Icv ?? 0) + 1;
        draft.PreviousInvoiceHash = latest?.InvoiceHash ?? ZatcaPhase2Service.GenesisPreviousHash();
        draft.IssueDateTimeUtc = DateTime.UtcNow;

        if (string.IsNullOrWhiteSpace(draft.InvoiceNumber))
        {
            draft.InvoiceNumber = $"INV-{draft.Icv:D4}";
        }

        draft.Phase1QrBase64 = _phase1.BuildQrBase64(draft);
        draft.Status = InvoiceStatus.Generated;

        _phase2.SignInvoice(draft); // also sets Status = Signed, UblXml, hash, Phase2 QR

        return _repo.Add(draft);
    }

    public bool Delete(string id) => _repo.Delete(id);
}
