using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Xml.Linq;

namespace Zatca.Api.Services;

/// <summary>
/// Embeds the Phase 2 signature into an unsigned UBL invoice: the ext:UBLExtensions
/// block (ds:Signature + xades:QualifyingProperties) ZATCA's XML Implementation
/// Standard requires, plus the QR code and a top-level cac:Signature pointer.
///
/// Element names, namespaces and nesting mirror ZATCA's published sample invoices.
/// Two details are environment-dependent and worth re-checking against ZATCA's
/// current SDK sample before going live: (1) the exact XPath transform ZATCA's
/// validator expects for excluding UBLExtensions from the hashed content, and
/// (2) whether they require additional xades:SignaturePolicyIdentifier /
/// DataObjectFormat children — ZATCA's clearance API returns validationResults
/// with a precise error if either is wrong, so a failed submission is easy to
/// diagnose and patch here.
/// </summary>
public static class ZatcaXmlSigner
{
    private static readonly XNamespace Cac = "urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2";
    private static readonly XNamespace Cbc = "urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2";
    private static readonly XNamespace Ext = "urn:oasis:names:specification:ubl:schema:xsd:CommonExtensionComponents-2";
    private static readonly XNamespace Sig = "urn:oasis:names:specification:ubl:schema:xsd:CommonSignatureComponents-2";
    private static readonly XNamespace Sac = "urn:oasis:names:specification:ubl:schema:xsd:SignatureAggregateComponents-2";
    private static readonly XNamespace Sbc = "urn:oasis:names:specification:ubl:schema:xsd:SignatureBasicComponents-2";
    private static readonly XNamespace Ds = "http://www.w3.org/2000/09/xmldsig#";
    private static readonly XNamespace Xades = "http://uri.etsi.org/01903/v1.3.2#";

    public record SigningMaterial(byte[] InvoiceHash, byte[] Signature, byte[] PublicKeySpki, X509Certificate2? Certificate, string QrBase64);

    public static XDocument Embed(XDocument unsigned, SigningMaterial material)
    {
        var root = new XElement(unsigned.Root!); // clone so the caller's unsigned copy is untouched

        root.Add(
            new XAttribute(XNamespace.Xmlns + "ext", Ext),
            new XAttribute(XNamespace.Xmlns + "sig", Sig),
            new XAttribute(XNamespace.Xmlns + "sac", Sac),
            new XAttribute(XNamespace.Xmlns + "sbc", Sbc),
            new XAttribute(XNamespace.Xmlns + "ds", Ds),
            new XAttribute(XNamespace.Xmlns + "xades", Xades));

        var qrReference = new XElement(Cac + "AdditionalDocumentReference",
            new XElement(Cbc + "ID", "QR"),
            new XElement(Cac + "Attachment",
                new XElement(Cbc + "EmbeddedDocumentBinaryObject", new XAttribute("mimeCode", "text/plain"), material.QrBase64)));

        var lastAdditionalDocRef = root.Elements(Cac + "AdditionalDocumentReference").LastOrDefault();
        if (lastAdditionalDocRef is not null) lastAdditionalDocRef.AddAfterSelf(qrReference);
        else root.AddFirst(qrReference);

        var signaturePointer = new XElement(Cac + "Signature",
            new XElement(Cbc + "ID", "urn:oasis:names:specification:ubl:signature:Invoice"),
            new XElement(Cbc + "SignatureMethod", "urn:oasis:names:specification:ubl:dsig:enveloped:xades"));
        qrReference.AddAfterSelf(signaturePointer);

        root.AddFirst(BuildUblExtensions(material));

        return new XDocument(unsigned.Declaration is { } d ? new XDeclaration(d.Version, d.Encoding, d.Standalone) : null, root);
    }

    private static XElement BuildUblExtensions(SigningMaterial m)
    {
        var certBytes = m.Certificate?.RawData ?? m.PublicKeySpki;
        var certBase64 = Convert.ToBase64String(certBytes);
        var certDigest = Convert.ToBase64String(SHA256.HashData(certBytes));
        var issuerName = m.Certificate?.IssuerName.Name ?? "CN=ZATCA Demo Signing Key (no CSID onboarded yet)";
        var serialNumber = m.Certificate?.SerialNumber ?? "0";
        var signingTime = DateTime.UtcNow.ToString("yyyy-MM-ddTHH:mm:ssZ");

        var signedProperties = new XElement(Xades + "SignedProperties", new XAttribute("Id", "xadesSignedProperties"),
            new XElement(Xades + "SignedSignatureProperties",
                new XElement(Xades + "SigningTime", signingTime),
                new XElement(Xades + "SigningCertificate",
                    new XElement(Xades + "Cert",
                        new XElement(Xades + "CertDigest",
                            new XElement(Ds + "DigestMethod", new XAttribute("Algorithm", "http://www.w3.org/2001/04/xmlenc#sha256")),
                            new XElement(Ds + "DigestValue", certDigest)),
                        new XElement(Xades + "IssuerSerial",
                            new XElement(Ds + "X509IssuerName", issuerName),
                            new XElement(Ds + "X509SerialNumber", serialNumber))))));

        var signedPropertiesDigest = Convert.ToBase64String(
            SHA256.HashData(Encoding.UTF8.GetBytes(signedProperties.ToString(SaveOptions.DisableFormatting))));

        var signature = new XElement(Ds + "Signature", new XAttribute("Id", "signature"),
            new XElement(Ds + "SignedInfo",
                new XElement(Ds + "CanonicalizationMethod", new XAttribute("Algorithm", "http://www.w3.org/TR/2001/REC-xml-c14n-20010315")),
                new XElement(Ds + "SignatureMethod", new XAttribute("Algorithm", "http://www.w3.org/2001/04/xmldsig-more#ecdsa-sha256")),
                new XElement(Ds + "Reference", new XAttribute("Id", "invoiceSignedData"), new XAttribute("URI", ""),
                    new XElement(Ds + "Transforms",
                        new XElement(Ds + "Transform", new XAttribute("Algorithm", "http://www.w3.org/TR/1999/REC-xpath-19991116"),
                            new XElement(Ds + "XPath", "not(//ancestor-or-self::ext:UBLExtensions)")),
                        new XElement(Ds + "Transform", new XAttribute("Algorithm", "http://www.w3.org/TR/2001/REC-xml-c14n-20010315"))),
                    new XElement(Ds + "DigestMethod", new XAttribute("Algorithm", "http://www.w3.org/2001/04/xmlenc#sha256")),
                    new XElement(Ds + "DigestValue", Convert.ToBase64String(m.InvoiceHash))),
                new XElement(Ds + "Reference",
                    new XAttribute("Type", "http://www.w3.org/2000/09/xmldsig#SignatureProperties"),
                    new XAttribute("URI", "#xadesSignedProperties"),
                    new XElement(Ds + "DigestMethod", new XAttribute("Algorithm", "http://www.w3.org/2001/04/xmlenc#sha256")),
                    new XElement(Ds + "DigestValue", signedPropertiesDigest))),
            new XElement(Ds + "SignatureValue", Convert.ToBase64String(m.Signature)),
            new XElement(Ds + "KeyInfo",
                new XElement(Ds + "X509Data",
                    new XElement(Ds + "X509Certificate", certBase64))),
            new XElement(Ds + "Object",
                new XElement(Xades + "QualifyingProperties", new XAttribute("Target", "signature"), signedProperties)));

        return new XElement(Ext + "UBLExtensions",
            new XElement(Ext + "UBLExtension",
                new XElement(Ext + "ExtensionURI", "urn:oasis:names:specification:ubl:dsig:enveloped:xades"),
                new XElement(Ext + "ExtensionContent",
                    new XElement(Sig + "UBLDocumentSignatures",
                        new XElement(Sac + "SignatureInformation",
                            new XElement(Cbc + "ID", "urn:oasis:names:specification:ubl:signature:1"),
                            new XElement(Sbc + "ReferencedSignatureID", "urn:oasis:names:specification:ubl:signature:Invoice"),
                            signature)))));
    }
}
