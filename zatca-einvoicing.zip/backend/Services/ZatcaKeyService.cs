using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using Zatca.Api.Data;

namespace Zatca.Api.Services;

/// <summary>
/// Supplies the signing key/certificate for Phase 2. Once onboarding
/// (ZatcaOnboardingService) has produced a CSID, this uses that real
/// secp256k1 key + ZATCA-issued certificate. Before onboarding, it falls
/// back to a local demo P-256 key pair so the signing pipeline (hash -> sign
/// -> embed in the QR/XML) stays fully exercised end-to-end.
/// </summary>
public class ZatcaKeyService
{
    private readonly ZatcaConfigRepository _configRepo;
    private readonly string _demoKeyPath;

    public ZatcaKeyService(ZatcaConfigRepository configRepo)
    {
        _configRepo = configRepo;
        var dataDir = Path.Combine(AppContext.BaseDirectory, "App_Data");
        Directory.CreateDirectory(dataDir);
        _demoKeyPath = Path.Combine(dataDir, "demo-signing-key.pem");
    }

    /// <summary>True once a real CSID (compliance or production) has been onboarded.</summary>
    public bool IsOnboarded
    {
        get
        {
            var config = _configRepo.Get();
            return !string.IsNullOrWhiteSpace(config.ProductionCertificateBase64)
                || !string.IsNullOrWhiteSpace(config.ComplianceCertificateBase64);
        }
    }

    /// <summary>The ZATCA-issued certificate currently in force (production preferred over
    /// compliance), or null while still on the local demo key.</summary>
    public X509Certificate2? GetCurrentCertificate()
    {
        var config = _configRepo.Get();
        var base64 = config.ProductionCertificateBase64 ?? config.ComplianceCertificateBase64;
        if (string.IsNullOrWhiteSpace(base64)) return null;

        try
        {
            // ZATCA returns the certificate as base64 of the PEM/DER binary security token.
            var raw = Convert.FromBase64String(base64);
#pragma warning disable SYSLIB0057 // X509Certificate2(byte[]) ctor; X509CertificateLoader requires .NET 9+
            return new X509Certificate2(raw);
#pragma warning restore SYSLIB0057
        }
        catch
        {
            return null; // dummy/placeholder token that isn't a real DER cert yet
        }
    }

    private ECDsa LoadKey()
    {
        var config = _configRepo.Get();
        if (!string.IsNullOrWhiteSpace(config.PrivateKeyPem))
        {
            var ecdsa = ECDsa.Create();
            ecdsa.ImportFromPem(config.PrivateKeyPem);
            return ecdsa;
        }

        // Demo fallback: local P-256 key, generated once and reused.
        var demo = ECDsa.Create(ECCurve.NamedCurves.nistP256);
        if (File.Exists(_demoKeyPath))
        {
            demo.ImportFromPem(File.ReadAllText(_demoKeyPath));
        }
        else
        {
            File.WriteAllText(_demoKeyPath, demo.ExportECPrivateKeyPem());
        }
        return demo;
    }

    public byte[] SignHash(byte[] hash) => LoadKey().SignHash(hash, DSASignatureFormat.Rfc3279DerSequence);

    public byte[] ExportPublicKey() => LoadKey().ExportSubjectPublicKeyInfo();

    /// <summary>Tag 9 of the Phase 2 QR: the ECDSA signature ZATCA's own CA placed over this
    /// EGS's public key, extracted from the CSID certificate. Only available once a real CSID
    /// has been issued (parsed from the certificate's own Signature field).</summary>
    public byte[]? GetCertificateSignature()
    {
        var cert = GetCurrentCertificate();
        return cert?.GetRawCertData() is { } raw ? ExtractSignatureValue(raw) : null;
    }

    /// <summary>Pulls the outer `signatureValue` BIT STRING out of a DER-encoded X.509
    /// Certificate ::= SEQUENCE { tbsCertificate, signatureAlgorithm, signatureValue }.</summary>
    private static byte[]? ExtractSignatureValue(byte[] certDer)
    {
        try
        {
            var reader = new System.Formats.Asn1.AsnReader(certDer, System.Formats.Asn1.AsnEncodingRules.DER);
            var certSeq = reader.ReadSequence(); // Certificate ::= SEQUENCE { tbsCertificate, signatureAlgorithm, signatureValue }
            certSeq.ReadEncodedValue();          // tbsCertificate — skip
            certSeq.ReadEncodedValue();          // signatureAlgorithm — skip
            return certSeq.ReadBitString(out _); // signatureValue BIT STRING
        }
        catch
        {
            return null;
        }
    }
}
