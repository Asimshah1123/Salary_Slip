using System.Globalization;
using System.Text;
using System.Text.Encodings.Web;
using Zatca.Api.Models;

namespace Zatca.Api.Services;

/// <summary>
/// Renders a print-ready, self-contained HTML invoice (used for "Print / Save as PDF"
/// in the browser — no backend PDF library needed). The QR code image is drawn in the
/// viewer's own browser via a CDN QR library, decoding the exact TLV bytes ZATCA expects
/// (not the Base64 text) so the printed QR scans correctly.
/// </summary>
public static class InvoiceHtmlRenderer
{
    public static string Render(Invoice invoice)
    {
        var culture = CultureInfo.InvariantCulture;
        var qr = invoice.Phase2QrBase64 ?? invoice.Phase1QrBase64 ?? "";
        var rows = new StringBuilder();
        foreach (var li in invoice.LineItems)
        {
            rows.Append($@"
                <tr>
                    <td>{Enc(li.Description)}</td>
                    <td class=""num"">{li.Quantity.ToString(culture)}</td>
                    <td class=""num"">{li.UnitPrice.ToString("F2", culture)}</td>
                    <td class=""num"">{li.VatRate.ToString("F0", culture)}%</td>
                    <td class=""num"">{li.LineExtensionAmount.ToString("F2", culture)}</td>
                    <td class=""num"">{li.VatAmount.ToString("F2", culture)}</td>
                    <td class=""num"">{li.LineTotalWithVat.ToString("F2", culture)}</td>
                </tr>");
        }

        return $@"<!doctype html>
<html lang=""en"" dir=""ltr"">
<head>
<meta charset=""utf-8"">
<title>Invoice {Enc(invoice.InvoiceNumber)}</title>
<script src=""https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js""></script>
<style>
  body {{ font-family: Arial, Helvetica, sans-serif; color: #1a1a1a; margin: 32px; }}
  .header {{ display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 2px solid #0b5733; padding-bottom: 16px; }}
  h1 {{ margin: 0; color: #0b5733; }}
  .parties {{ display: flex; justify-content: space-between; gap: 24px; margin: 24px 0; }}
  .party {{ flex: 1; }}
  .party h3 {{ margin: 0 0 4px; font-size: 13px; text-transform: uppercase; color: #666; }}
  table {{ width: 100%; border-collapse: collapse; margin-top: 16px; }}
  th, td {{ border: 1px solid #ddd; padding: 8px; font-size: 13px; }}
  th {{ background: #0b5733; color: #fff; text-align: left; }}
  td.num, th.num {{ text-align: right; }}
  .totals {{ width: 320px; margin-left: auto; margin-top: 16px; }}
  .totals div {{ display: flex; justify-content: space-between; padding: 4px 0; }}
  .totals .grand {{ font-weight: bold; font-size: 16px; border-top: 2px solid #0b5733; padding-top: 8px; }}
  .qr-section {{ display: flex; align-items: center; gap: 16px; margin-top: 32px; }}
  #qrcode {{ width: 128px; height: 128px; }}
  .meta {{ font-size: 12px; color: #666; }}
  @media print {{ body {{ margin: 0; }} }}
</style>
</head>
<body>
  <div class=""header"">
    <div>
      <h1>{Enc(invoice.Seller.Name)}</h1>
      <div class=""meta"">VAT: {Enc(invoice.Seller.VatNumber)}</div>
    </div>
    <div style=""text-align:right"">
      <h2>Tax Invoice</h2>
      <div>{Enc(invoice.InvoiceNumber)}</div>
      <div class=""meta"">{invoice.IssueDateTimeUtc:yyyy-MM-dd HH:mm} UTC</div>
    </div>
  </div>

  <div class=""parties"">
    <div class=""party"">
      <h3>Seller</h3>
      {Enc(invoice.Seller.Name)}<br>
      {Enc(invoice.Seller.StreetName)} {Enc(invoice.Seller.BuildingNumber)}<br>
      {Enc(invoice.Seller.City)} {Enc(invoice.Seller.PostalCode)}<br>
      VAT No: {Enc(invoice.Seller.VatNumber)}
    </div>
    <div class=""party"">
      <h3>Buyer</h3>
      {Enc(invoice.Buyer.Name)}<br>
      {Enc(invoice.Buyer.StreetName)} {Enc(invoice.Buyer.BuildingNumber)}<br>
      {Enc(invoice.Buyer.City)} {Enc(invoice.Buyer.PostalCode)}<br>
      VAT No: {Enc(invoice.Buyer.VatNumber)}
    </div>
  </div>

  <table>
    <thead>
      <tr><th>Description</th><th class=""num"">Qty</th><th class=""num"">Unit Price</th><th class=""num"">VAT %</th><th class=""num"">Net</th><th class=""num"">VAT</th><th class=""num"">Total</th></tr>
    </thead>
    <tbody>{rows}</tbody>
  </table>

  <div class=""totals"">
    <div><span>Subtotal</span><span>{invoice.TaxExclusiveAmount.ToString("F2", culture)} {Enc(invoice.Currency)}</span></div>
    <div><span>VAT</span><span>{invoice.VatTotal.ToString("F2", culture)} {Enc(invoice.Currency)}</span></div>
    <div class=""grand""><span>Total</span><span>{invoice.TaxInclusiveAmount.ToString("F2", culture)} {Enc(invoice.Currency)}</span></div>
  </div>

  <div class=""qr-section"">
    <div id=""qrcode""></div>
    <div class=""meta"">
      ZATCA {(invoice.Phase2QrBase64 is not null ? "Phase 2 (signed)" : "Phase 1")} compliant QR<br>
      Scan to verify seller, VAT and totals.
    </div>
  </div>

  <script>
    // Decode the Base64 TLV payload back to its raw bytes and render those bytes
    // as the QR content (NOT the Base64 text) — this is what ZATCA's QR readers expect.
    var b64 = ""{qr}"";
    var binary = atob(b64);
    new QRCode(document.getElementById(""qrcode""), {{
      text: binary,
      width: 128,
      height: 128
    }});
  </script>
</body>
</html>";
    }

    private static string Enc(string? s) => HtmlEncoder.Default.Encode(s ?? string.Empty);
}
