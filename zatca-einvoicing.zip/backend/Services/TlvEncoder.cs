using System.Text;

namespace Zatca.Api.Services;

/// <summary>
/// ZATCA QR codes are encoded as a sequence of Tag-Length-Value (TLV) fields,
/// each: [1 byte tag][1 byte length][value bytes], concatenated and then Base64-encoded.
/// </summary>
public static class TlvEncoder
{
    public static byte[] Encode(byte tag, string value)
    {
        var valueBytes = Encoding.UTF8.GetBytes(value ?? string.Empty);
        if (valueBytes.Length > 255)
        {
            // Spec allows only a single length byte (max 255); callers should keep fields short.
            throw new ArgumentException($"TLV value for tag {tag} exceeds 255 bytes once UTF-8 encoded.");
        }

        var result = new byte[2 + valueBytes.Length];
        result[0] = tag;
        result[1] = (byte)valueBytes.Length;
        Buffer.BlockCopy(valueBytes, 0, result, 2, valueBytes.Length);
        return result;
    }

    public static byte[] Encode(byte tag, byte[] valueBytes)
    {
        if (valueBytes.Length > 255)
        {
            throw new ArgumentException($"TLV value for tag {tag} exceeds 255 bytes.");
        }

        var result = new byte[2 + valueBytes.Length];
        result[0] = tag;
        result[1] = (byte)valueBytes.Length;
        Buffer.BlockCopy(valueBytes, 0, result, 2, valueBytes.Length);
        return result;
    }

    /// <summary>Concatenates multiple already-encoded TLV chunks and Base64-encodes the result.</summary>
    public static string ToBase64(params byte[][] tlvChunks)
    {
        var totalLength = tlvChunks.Sum(c => c.Length);
        var buffer = new byte[totalLength];
        var offset = 0;
        foreach (var chunk in tlvChunks)
        {
            Buffer.BlockCopy(chunk, 0, buffer, offset, chunk.Length);
            offset += chunk.Length;
        }
        return Convert.ToBase64String(buffer);
    }
}
