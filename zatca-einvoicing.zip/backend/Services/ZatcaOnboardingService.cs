using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text;
using System.Text.Json;
using Microsoft.Extensions.Configuration;
using Zatca.Api.Data;
using Zatca.Api.Models;

namespace Zatca.Api.Services;

/// <summary>
/// Drives ZATCA's Fatoora onboarding pipeline against the real gateway (Sandbox,
/// Simulation or Production, depending on ZatcaConfig.Environment):
///
///   1. Generate a secp256k1 key + CSR (ZatcaCsrBuilder).
///   2. POST /compliance with the OTP -> Compliance CSID (cert + secret).
///   3. (Optional) POST /compliance/invoices with sample signed invoices to pass
///      the compliance checks ZATCA requires before issuing a Production CSID.
///   4. POST /production/csids, authenticated with the Compliance CSID, to get
///      the Production CSID that signs real, clearable/reportable invoices.
///
/// Every request below uses the exact ZATCA request/response shape from their
/// Fatoora integration guide. The config's OTP/VAT/EGS-serial are dummy values
/// by default (see ZatcaConfig), so calls against the public Sandbox will
/// return ZATCA's own validation errors until real values are supplied —
/// nothing about the plumbing needs to change when that happens.
/// </summary>
public class ZatcaOnboardingService
{
    private readonly HttpClient _http;
    private readonly ZatcaConfigRepository _configRepo;
    private readonly IConfiguration _appConfig;

    public ZatcaOnboardingService(HttpClient http, ZatcaConfigRepository configRepo, IConfiguration appConfig)
    {
        _http = http;
        _configRepo = configRepo;
        _appConfig = appConfig;
    }

    private string BaseUrl(ZatcaConfig config) =>
        _appConfig[$"Zatca:Environments:{config.Environment}"]
            ?? throw new InvalidOperationException($"No base URL configured for ZATCA environment '{config.Environment}'.");

    public ZatcaConfig GetConfig() => _configRepo.Get();

    public ZatcaConfig SaveConfig(ZatcaConfig config) => _configRepo.Save(config);

    /// <summary>Step 1+2: generate (or reuse) the key/CSR, then request the Compliance CSID.</summary>
    public async Task<ZatcaConfig> RequestComplianceCsidAsync()
    {
        var config = _configRepo.Get();
        try
        {
            if (string.IsNullOrWhiteSpace(config.PrivateKeyPem) || string.IsNullOrWhiteSpace(config.CsrPem))
            {
                var generated = ZatcaCsrBuilder.Generate(config);
                config.PrivateKeyPem = generated.PrivateKeyPem;
                config.CsrPem = generated.CsrPem;
                config.Stage = ZatcaOnboardingStage.CsrGenerated;
                _configRepo.Save(config);
            }

            var csrBase64 = Convert.ToBase64String(Encoding.UTF8.GetBytes(config.CsrPem!));

            using var request = new HttpRequestMessage(HttpMethod.Post, $"{BaseUrl(config)}/compliance")
            {
                Content = JsonContent.Create(new { csr = csrBase64 })
            };
            ApplyCommonHeaders(request);
            request.Headers.Authorization = new AuthenticationHeaderValue("Basic", BasicAuth(config.OtpCode, string.Empty));

            using var response = await _http.SendAsync(request);
            var body = await response.Content.ReadAsStringAsync();

            if (!response.IsSuccessStatusCode)
            {
                config.LastError = $"Compliance CSID request failed ({(int)response.StatusCode} {response.StatusCode}): {body}";
                _configRepo.Save(config);
                return config;
            }

            var parsed = JsonSerializer.Deserialize<ZatcaCsidResponse>(body, JsonOptions)
                ?? throw new InvalidOperationException("Empty response from ZATCA compliance endpoint.");

            config.ComplianceRequestId = parsed.RequestID;
            config.ComplianceCertificateBase64 = parsed.BinarySecurityToken;
            config.ComplianceSecret = parsed.Secret;
            config.Stage = ZatcaOnboardingStage.ComplianceCsidIssued;
            config.LastError = null;
        }
        catch (Exception ex)
        {
            config.LastError = $"Compliance CSID request threw: {ex.Message}";
        }

        return _configRepo.Save(config);
    }

    /// <summary>Submits one signed sample invoice to ZATCA's compliance-check endpoint —
    /// required (for several invoice types) before ZATCA will issue a Production CSID.</summary>
    public async Task<(bool Success, string ResponseBody)> CheckComplianceInvoiceAsync(string invoiceHash, string uuid, string signedInvoiceBase64)
    {
        var config = _configRepo.Get();
        if (config.Stage < ZatcaOnboardingStage.ComplianceCsidIssued)
        {
            return (false, "Request a Compliance CSID first.");
        }

        using var request = new HttpRequestMessage(HttpMethod.Post, $"{BaseUrl(config)}/compliance/invoices")
        {
            Content = JsonContent.Create(new { invoiceHash, uuid, invoice = signedInvoiceBase64 })
        };
        ApplyCommonHeaders(request);
        request.Headers.Authorization = new AuthenticationHeaderValue("Basic", BasicAuth(config.ComplianceRequestId!, config.ComplianceSecret!));

        using var response = await _http.SendAsync(request);
        var body = await response.Content.ReadAsStringAsync();
        return (response.IsSuccessStatusCode, body);
    }

    /// <summary>Step 4: exchange the Compliance CSID for a Production CSID.</summary>
    public async Task<ZatcaConfig> RequestProductionCsidAsync()
    {
        var config = _configRepo.Get();
        if (config.Stage < ZatcaOnboardingStage.ComplianceCsidIssued)
        {
            config.LastError = "Request a Compliance CSID before requesting the Production CSID.";
            return _configRepo.Save(config);
        }

        try
        {
            using var request = new HttpRequestMessage(HttpMethod.Post, $"{BaseUrl(config)}/production/csids")
            {
                Content = JsonContent.Create(new { compliance_request_id = config.ComplianceRequestId })
            };
            ApplyCommonHeaders(request);
            request.Headers.Authorization = new AuthenticationHeaderValue("Basic", BasicAuth(config.ComplianceRequestId!, config.ComplianceSecret!));

            using var response = await _http.SendAsync(request);
            var body = await response.Content.ReadAsStringAsync();

            if (!response.IsSuccessStatusCode)
            {
                config.LastError = $"Production CSID request failed ({(int)response.StatusCode} {response.StatusCode}): {body}";
                _configRepo.Save(config);
                return config;
            }

            var parsed = JsonSerializer.Deserialize<ZatcaCsidResponse>(body, JsonOptions)
                ?? throw new InvalidOperationException("Empty response from ZATCA production CSID endpoint.");

            config.ProductionRequestId = parsed.RequestID;
            config.ProductionCertificateBase64 = parsed.BinarySecurityToken;
            config.ProductionSecret = parsed.Secret;
            config.Stage = ZatcaOnboardingStage.ProductionCsidIssued;
            config.LastError = null;
        }
        catch (Exception ex)
        {
            config.LastError = $"Production CSID request threw: {ex.Message}";
        }

        return _configRepo.Save(config);
    }

    private static void ApplyCommonHeaders(HttpRequestMessage request)
    {
        request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
        request.Headers.Add("Accept-Version", "V2");
    }

    private static string BasicAuth(string username, string password) =>
        Convert.ToBase64String(Encoding.UTF8.GetBytes($"{username}:{password}"));

    private static readonly JsonSerializerOptions JsonOptions = new() { PropertyNameCaseInsensitive = true };

    private record ZatcaCsidResponse(string RequestID, string? DispositionMessage, string BinarySecurityToken, string Secret, string[]? Errors);
}
