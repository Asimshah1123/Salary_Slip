using System.Globalization;
using System.Security.Cryptography;
using System.Security.Cryptography.Xml;
using System.Text;
using System.Xml;
using System.Xml.Linq;
using Zatca.Api.Models;

namespace Zatca.Api.Services;

/// <summary>
/// ZATCA Phase 2 ("Integration Phase"): UBL XML + invoice hash chaining (ICV/PIH),
/// a real ECDSA signature (secp256k1, once a CSID has been onboarded — see
/// ZatcaKeyService/ZatcaOnboardingService), the signed ext:UBLExtensions block
/// (ZatcaXmlSigner), and the full 9-tag QR code.
///
/// The invoice hash is computed per ZATCA's rule: SHA-256 of the canonical
/// (W3C XML-C14N) form of the invoice content, computed BEFORE the
/// UBLExtensions/QR nodes are added — i.e. over the same "unsigned" document
/// ZATCA's own SDKs hash. Submitting this to the live Clearance/Reporting API
/// still needs a real CSID (see ZatcaOnboardingService); the hashing, signing
/// and XML-embedding pipeline itself is fully production-shaped already.
/// </summary>
public class ZatcaPhase2Service
{
    private readonly UblInvoiceXmlBuilder _xmlBuilder = new();
    private readonly ZatcaKeyService _keyService;

    public ZatcaPhase2Service(ZatcaKeyService keyService)
    {
        _keyService = keyService;
    }

    /// <summary>Base64(SHA-256("0")) — the required genesis hash for the very first invoice in the chain.</summary>
    public static string GenesisPreviousHash() =>
        Convert.ToBase64String(SHA256.HashData(Encoding.UTF8.GetBytes("0")));

    public void SignInvoice(Invoice invoice)
    {
        var unsignedXml = _xmlBuilder.Build(invoice);

        var invoiceHash = ComputeCanonicalHash(unsignedXml);
        var signature = _keyService.SignHash(invoiceHash);
        var publicKey = _keyService.ExportPublicKey();
        var certificate = _keyService.GetCurrentCertificate();
        var certificateSignature = _keyService.GetCertificateSignature();

        invoice.InvoiceHash = Convert.ToBase64String(invoiceHash);
        invoice.SignatureBase64 = Convert.ToBase64String(signature);
        invoice.PublicKeyBase64 = Convert.ToBase64String(publicKey);
        invoice.CertificateSignatureBase64 = certificateSignature is not null ? Convert.ToBase64String(certificateSignature) : null;

        invoice.Phase2QrBase64 = BuildQrBase64(invoice, invoiceHash, signature, publicKey, certificateSignature);

        var signed = ZatcaXmlSigner.Embed(unsignedXml, new ZatcaXmlSigner.SigningMaterial(
            invoiceHash, signature, publicKey, certificate, invoice.Phase2QrBase64));

        invoice.UblXml = signed.Declaration + "\n" + signed.ToString(SaveOptions.DisableFormatting);
        invoice.Status = InvoiceStatus.Signed;
    }

    /// <summary>SHA-256 over the W3C-canonical (XML-C14N) form of the unsigned invoice —
    /// the exact bytes ZATCA's own validator re-derives the invoice hash from.</summary>
    private static byte[] ComputeCanonicalHash(XDocument unsignedXml)
    {
        var xmlDoc = new XmlDocument { PreserveWhitespace = true };
        xmlDoc.LoadXml(unsignedXml.ToString(SaveOptions.DisableFormatting));

        var transform = new XmlDsigC14NTransform();
        transform.LoadInput(xmlDoc);
        using var canonicalStream = (MemoryStream)transform.GetOutput(typeof(Stream));

        return SHA256.HashData(canonicalStream.ToArray());
    }

    /// <summary>Phase 2 QR: the 5 Phase-1 tags plus hash (6), signature (7), public key (8)
    /// and — once a real CSID certificate has been onboarded — the ZATCA CA's signature
    /// over that certificate (9). Tag 9 is omitted while still on the local demo key,
    /// since there is no ZATCA-issued certificate yet to carry it.</summary>
    private static string BuildQrBase64(Invoice invoice, byte[] invoiceHash, byte[] signature, byte[] publicKey, byte[]? certificateSignature)
    {
        var timestamp = invoice.IssueDateTimeUtc.ToString("yyyy-MM-ddTHH:mm:ssZ", CultureInfo.InvariantCulture);
        var total = invoice.TaxInclusiveAmount.ToString("F2", CultureInfo.InvariantCulture);
        var vat = invoice.VatTotal.ToString("F2", CultureInfo.InvariantCulture);

        var chunks = new List<byte[]>
        {
            TlvEncoder.Encode(1, invoice.Seller.Name),
            TlvEncoder.Encode(2, invoice.Seller.VatNumber),
            TlvEncoder.Encode(3, timestamp),
            TlvEncoder.Encode(4, total),
            TlvEncoder.Encode(5, vat),
            TlvEncoder.Encode(6, Convert.ToBase64String(invoiceHash)),
            TlvEncoder.Encode(7, Convert.ToBase64String(signature)),
            TlvEncoder.Encode(8, Convert.ToBase64String(publicKey)),
        };

        if (certificateSignature is not null)
        {
            chunks.Add(TlvEncoder.Encode(9, Convert.ToBase64String(certificateSignature)));
        }

        return TlvEncoder.ToBase64(chunks.ToArray());
    }
}
