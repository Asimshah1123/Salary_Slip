using System.Globalization;
using System.Xml.Linq;
using Zatca.Api.Models;

namespace Zatca.Api.Services;

/// <summary>
/// Builds a UBL 2.1 Invoice XML document shaped after ZATCA's e-invoicing data
/// dictionary. This is a structural scaffold: field presence, nesting and the
/// core business data (parties, lines, totals, ICV/PIH, QR) are all here, but a
/// few constant values (CustomizationID, ProfileID strings) should be checked
/// against ZATCA's current XML Implementation Standard / SDK samples before
/// this is used to submit real invoices.
/// </summary>
public class UblInvoiceXmlBuilder
{
    private static readonly XNamespace Inv = "urn:oasis:names:specification:ubl:schema:xsd:Invoice-2";
    private static readonly XNamespace Cac = "urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2";
    private static readonly XNamespace Cbc = "urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2";

    public XDocument Build(Invoice invoice)
    {
        var subjectCode = invoice.Subject == InvoiceSubject.Simplified ? "02" : "01";
        // ZATCA's InvoiceTypeCode "name" attribute is a 7-digit transaction subtype flag
        // string (invoice subject + third-party/nominal/export/summary/self-billed flags).
        // "0100000" / "0200000" below are the plain (no special flags) standard/simplified cases.
        var typeCodeName = invoice.Subject == InvoiceSubject.Simplified ? "0200000" : "0100000";

        var invoiceEl = new XElement(Inv + "Invoice",
            new XAttribute(XNamespace.Xmlns + "cac", Cac),
            new XAttribute(XNamespace.Xmlns + "cbc", Cbc),
            new XElement(Cbc + "ProfileID", invoice.Subject == InvoiceSubject.Simplified ? "reporting:1.0" : "clearance:1.0"),
            new XElement(Cbc + "ID", invoice.InvoiceNumber),
            new XElement(Cbc + "UUID", invoice.Uuid),
            new XElement(Cbc + "IssueDate", invoice.IssueDateTimeUtc.ToString("yyyy-MM-dd")),
            new XElement(Cbc + "IssueTime", invoice.IssueDateTimeUtc.ToString("HH:mm:ss")),
            new XElement(Cbc + "InvoiceTypeCode", new XAttribute("name", typeCodeName), (int)invoice.DocumentType),
            new XElement(Cbc + "DocumentCurrencyCode", invoice.Currency),
            new XElement(Cbc + "TaxCurrencyCode", invoice.Currency),

            new XElement(Cac + "AdditionalDocumentReference",
                new XElement(Cbc + "ID", "ICV"),
                new XElement(Cbc + "UUID", invoice.Icv)),

            new XElement(Cac + "AdditionalDocumentReference",
                new XElement(Cbc + "ID", "PIH"),
                new XElement(Cac + "Attachment",
                    new XElement(Cbc + "EmbeddedDocumentBinaryObject",
                        new XAttribute("mimeCode", "text/plain"),
                        invoice.PreviousInvoiceHash))),

            BuildParty(Cac + "AccountingSupplierParty", invoice.Seller),
            BuildParty(Cac + "AccountingCustomerParty", invoice.Buyer),

            new XElement(Cac + "TaxTotal",
                new XElement(Cbc + "TaxAmount", new XAttribute("currencyID", invoice.Currency), invoice.VatTotal.ToString("F2", CultureInfo.InvariantCulture)),
                BuildTaxSubtotals(invoice)),

            new XElement(Cac + "LegalMonetaryTotal",
                new XElement(Cbc + "LineExtensionAmount", new XAttribute("currencyID", invoice.Currency), invoice.TaxExclusiveAmount.ToString("F2", CultureInfo.InvariantCulture)),
                new XElement(Cbc + "TaxExclusiveAmount", new XAttribute("currencyID", invoice.Currency), invoice.TaxExclusiveAmount.ToString("F2", CultureInfo.InvariantCulture)),
                new XElement(Cbc + "TaxInclusiveAmount", new XAttribute("currencyID", invoice.Currency), invoice.TaxInclusiveAmount.ToString("F2", CultureInfo.InvariantCulture)),
                new XElement(Cbc + "PayableAmount", new XAttribute("currencyID", invoice.Currency), invoice.TaxInclusiveAmount.ToString("F2", CultureInfo.InvariantCulture))),

            invoice.LineItems.Select((li, idx) => BuildInvoiceLine(li, idx + 1, invoice.Currency))
        );

        return new XDocument(new XDeclaration("1.0", "UTF-8", null), invoiceEl);
    }

    private XElement BuildParty(XName wrapperName, Party party) =>
        new(wrapperName,
            new XElement(Cac + "Party",
                new XElement(Cac + "PartyIdentification",
                    new XElement(Cbc + "ID", new XAttribute("schemeID", "CRN"), party.CrNumber ?? string.Empty)),
                new XElement(Cac + "PostalAddress",
                    new XElement(Cbc + "StreetName", party.StreetName),
                    new XElement(Cbc + "BuildingNumber", party.BuildingNumber),
                    new XElement(Cbc + "PlotIdentification", party.PlotIdentification),
                    new XElement(Cbc + "CitySubdivisionName", party.CitySubdivision),
                    new XElement(Cbc + "CityName", party.City),
                    new XElement(Cbc + "PostalZone", party.PostalCode),
                    new XElement(Cac + "Country", new XElement(Cbc + "IdentificationCode", party.Country))),
                new XElement(Cac + "PartyTaxScheme",
                    new XElement(Cbc + "CompanyID", party.VatNumber),
                    new XElement(Cac + "TaxScheme", new XElement(Cbc + "ID", "VAT"))),
                new XElement(Cac + "PartyLegalEntity",
                    new XElement(Cbc + "RegistrationName", party.Name))));

    private IEnumerable<XElement> BuildTaxSubtotals(Invoice invoice) =>
        invoice.LineItems
            .GroupBy(li => (li.VatRate, li.VatCategoryCode))
            .Select(g => new XElement(Cac + "TaxSubtotal",
                new XElement(Cbc + "TaxableAmount", new XAttribute("currencyID", invoice.Currency), g.Sum(li => li.LineExtensionAmount).ToString("F2", CultureInfo.InvariantCulture)),
                new XElement(Cbc + "TaxAmount", new XAttribute("currencyID", invoice.Currency), g.Sum(li => li.VatAmount).ToString("F2", CultureInfo.InvariantCulture)),
                new XElement(Cac + "TaxCategory",
                    new XElement(Cbc + "ID", g.Key.VatCategoryCode),
                    new XElement(Cbc + "Percent", g.Key.VatRate.ToString("F2", CultureInfo.InvariantCulture)),
                    new XElement(Cac + "TaxScheme", new XElement(Cbc + "ID", "VAT")))));

    private XElement BuildInvoiceLine(LineItem li, int lineNumber, string currency) =>
        new(Cac + "InvoiceLine",
            new XElement(Cbc + "ID", lineNumber),
            new XElement(Cbc + "InvoicedQuantity", li.Quantity.ToString(CultureInfo.InvariantCulture)),
            new XElement(Cbc + "LineExtensionAmount", new XAttribute("currencyID", currency), li.LineExtensionAmount.ToString("F2", CultureInfo.InvariantCulture)),
            new XElement(Cac + "TaxTotal",
                new XElement(Cbc + "TaxAmount", new XAttribute("currencyID", currency), li.VatAmount.ToString("F2", CultureInfo.InvariantCulture)),
                new XElement(Cbc + "RoundingAmount", new XAttribute("currencyID", currency), li.LineTotalWithVat.ToString("F2", CultureInfo.InvariantCulture))),
            new XElement(Cac + "Item",
                new XElement(Cbc + "Name", li.Description),
                new XElement(Cac + "ClassifiedTaxCategory",
                    new XElement(Cbc + "ID", li.VatCategoryCode),
                    new XElement(Cbc + "Percent", li.VatRate.ToString("F2", CultureInfo.InvariantCulture)),
                    new XElement(Cac + "TaxScheme", new XElement(Cbc + "ID", "VAT")))),
            new XElement(Cac + "Price",
                new XElement(Cbc + "PriceAmount", new XAttribute("currencyID", currency), li.UnitPrice.ToString("F2", CultureInfo.InvariantCulture))));
}
