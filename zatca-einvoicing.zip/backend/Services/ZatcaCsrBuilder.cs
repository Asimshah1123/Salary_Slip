using System.Formats.Asn1;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using Zatca.Api.Models;

namespace Zatca.Api.Services;

/// <summary>
/// Generates the secp256k1 key pair and PKCS#10 CSR exactly as ZATCA's onboarding
/// ("Compliance CSID") step requires — the same shape produced by ZATCA's own
/// `csr_config` + OpenSSL recipe in their Fatoora SDK docs:
///
///   Subject:    C=SA, OU=&lt;branch&gt;, O=&lt;organization&gt;, CN=&lt;common name&gt;
///   SAN (dirName): SN=&lt;EGS serial&gt;, UID=&lt;VAT number&gt;, title=&lt;invoice type&gt;,
///                  registeredAddress=&lt;location&gt;, businessCategory=&lt;industry&gt;
///   Key:        secp256k1 (OID 1.3.132.0.10), signed with SHA-256
///
/// Verified against `openssl req -text` to confirm the DER shape ZATCA's gateway
/// expects before this is wired to the live Compliance CSID endpoint.
/// </summary>
public static class ZatcaCsrBuilder
{
    public record Result(string PrivateKeyPem, string CsrPem);

    public static Result Generate(ZatcaConfig config)
    {
        using var ecdsa = ECDsa.Create(ECCurve.CreateFromValue("1.3.132.0.10")); // secp256k1
        var privateKeyPem = ecdsa.ExportECPrivateKeyPem();

        var subject = new X500DistinguishedNameBuilder();
        subject.AddCountryOrRegion(config.Country);
        subject.AddOrganizationalUnitName(config.OrganizationUnitName);
        subject.AddOrganizationName(config.OrganizationName);
        subject.AddCommonName(config.CommonName);

        var request = new CertificateRequest(subject.Build(), ecdsa, HashAlgorithmName.SHA256);
        request.CertificateExtensions.Add(new X509KeyUsageExtension(X509KeyUsageFlags.DigitalSignature, critical: true));
        request.CertificateExtensions.Add(new X509Extension("2.5.29.17", BuildZatcaSubjectAltName(config), critical: false));

        var csrPem = request.CreateSigningRequestPem();
        return new Result(privateKeyPem, csrPem);
    }

    /// <summary>
    /// Builds the SubjectAltName extension value: GeneralNames ::= SEQUENCE OF GeneralName,
    /// with a single GeneralName choice [4] directoryName carrying ZATCA's 5 custom attributes.
    /// </summary>
    private static byte[] BuildZatcaSubjectAltName(ZatcaConfig config)
    {
        var dirName = new X500DistinguishedNameBuilder();
        dirName.Add("2.5.4.4", config.EgsSerialNumber);                     // SN
        dirName.Add("0.9.2342.19200300.100.1.1", config.VatRegistrationNumber); // UID
        dirName.Add("2.5.4.12", config.InvoiceType);                        // title
        dirName.Add("2.5.4.26", config.Location);                           // registeredAddress
        dirName.Add("2.5.4.15", config.BusinessCategory);                   // businessCategory

        var writer = new AsnWriter(AsnEncodingRules.DER);
        using (writer.PushSequence())
        {
            WriteContextConstructed(writer, tagNumber: 4, content: dirName.Build().RawData);
        }
        return writer.Encode();
    }

    private static void WriteContextConstructed(AsnWriter writer, int tagNumber, byte[] content)
    {
        using (writer.PushSequence(new Asn1Tag(TagClass.ContextSpecific, tagNumber, isConstructed: true)))
        {
            writer.WriteEncodedValue(content);
        }
    }
}
