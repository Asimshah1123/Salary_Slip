using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text;
using System.Text.Json;
using Zatca.Api.Data;
using Zatca.Api.Models;

namespace Zatca.Api.Services;

/// <summary>
/// Submits a signed invoice to ZATCA's live Clearance (Standard/B2B, synchronous —
/// ZATCA stamps and returns the invoice) or Reporting (Simplified/B2C, asynchronous
/// acknowledgement) API, authenticated with the onboarded Production CSID.
/// </summary>
public class ZatcaApiClient
{
    private readonly HttpClient _http;
    private readonly ZatcaConfigRepository _configRepo;
    private readonly IConfiguration _appConfig;

    public ZatcaApiClient(HttpClient http, ZatcaConfigRepository configRepo, IConfiguration appConfig)
    {
        _http = http;
        _configRepo = configRepo;
        _appConfig = appConfig;
    }

    public record SubmissionResult(bool Success, InvoiceStatus ResultStatus, string ResponseJson, List<string> Warnings, List<string> Errors);

    public async Task<SubmissionResult> SubmitAsync(Invoice invoice)
    {
        var config = _configRepo.Get();

        if (string.IsNullOrWhiteSpace(config.ProductionRequestId) || string.IsNullOrWhiteSpace(config.ProductionSecret))
        {
            return new SubmissionResult(false, InvoiceStatus.Rejected,
                "{}", new(), new() { "No Production CSID onboarded yet — complete ZATCA onboarding (Compliance CSID, then Production CSID) first." });
        }

        if (invoice.UblXml is null || invoice.InvoiceHash is null)
        {
            return new SubmissionResult(false, InvoiceStatus.Rejected, "{}", new(), new() { "Invoice has not been Phase-2 signed yet." });
        }

        var isSimplified = invoice.Subject == InvoiceSubject.Simplified;
        var path = isSimplified ? "invoices/reporting/single" : "invoices/clearance/single";
        var baseUrl = _appConfig[$"Zatca:Environments:{config.Environment}"]
            ?? throw new InvalidOperationException($"No base URL configured for ZATCA environment '{config.Environment}'.");

        using var request = new HttpRequestMessage(HttpMethod.Post, $"{baseUrl}/{path}")
        {
            Content = JsonContent.Create(new
            {
                invoiceHash = invoice.InvoiceHash,
                uuid = invoice.Uuid,
                invoice = Convert.ToBase64String(Encoding.UTF8.GetBytes(invoice.UblXml))
            })
        };
        request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
        request.Headers.Add("Accept-Version", "V2");
        if (!isSimplified)
        {
            request.Headers.Add("Clearance-Status", "1");
        }
        request.Headers.Authorization = new AuthenticationHeaderValue("Basic",
            Convert.ToBase64String(Encoding.UTF8.GetBytes($"{config.ProductionRequestId}:{config.ProductionSecret}")));

        try
        {
            using var response = await _http.SendAsync(request);
            var body = await response.Content.ReadAsStringAsync();

            var (warnings, errors) = ParseValidationResults(body);

            if (!response.IsSuccessStatusCode)
            {
                errors.Insert(0, $"ZATCA returned {(int)response.StatusCode} {response.StatusCode}.");
                return new SubmissionResult(false, InvoiceStatus.Rejected, body, warnings, errors);
            }

            var resultStatus = isSimplified ? InvoiceStatus.Reported : InvoiceStatus.Cleared;
            return new SubmissionResult(true, resultStatus, body, warnings, errors);
        }
        catch (Exception ex)
        {
            return new SubmissionResult(false, InvoiceStatus.Rejected, "{}", new(), new() { $"Request to ZATCA failed: {ex.Message}" });
        }
    }

    private static (List<string> Warnings, List<string> Errors) ParseValidationResults(string body)
    {
        var warnings = new List<string>();
        var errors = new List<string>();
        try
        {
            using var doc = JsonDocument.Parse(body);
            if (doc.RootElement.TryGetProperty("validationResults", out var vr))
            {
                CollectMessages(vr, "warningMessages", warnings);
                CollectMessages(vr, "errorMessages", errors);
            }
        }
        catch (JsonException)
        {
            // Non-JSON or unexpected shape — caller still has the raw body to show.
        }
        return (warnings, errors);
    }

    private static void CollectMessages(JsonElement validationResults, string propertyName, List<string> target)
    {
        if (!validationResults.TryGetProperty(propertyName, out var arr) || arr.ValueKind != JsonValueKind.Array) return;
        foreach (var item in arr.EnumerateArray())
        {
            var message = item.TryGetProperty("message", out var m) ? m.GetString() : item.ToString();
            if (!string.IsNullOrWhiteSpace(message)) target.Add(message!);
        }
    }
}
