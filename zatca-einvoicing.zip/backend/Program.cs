using Zatca.Api.Data;
using Zatca.Api.Services;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers();

// NuGet access is unavailable in this environment (no Swashbuckle/EF Core), so this
// API is built entirely on the .NET base class library: System.Text.Json for data,
// System.Xml.Linq for UBL, System.Security.Cryptography for hashing/signing.
builder.Services.AddSingleton<InvoiceRepository>();
builder.Services.AddSingleton<SellerProfileRepository>();
builder.Services.AddSingleton<ZatcaConfigRepository>();
builder.Services.AddSingleton<ZatcaPhase1Service>();
builder.Services.AddSingleton<ZatcaKeyService>();
builder.Services.AddSingleton<ZatcaPhase2Service>();
builder.Services.AddSingleton<InvoiceService>();
builder.Services.AddHttpClient<ZatcaOnboardingService>();
builder.Services.AddHttpClient<ZatcaApiClient>();

builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowAngularDev", policy =>
    {
        policy.WithOrigins("http://localhost:4200")
              .AllowAnyHeader()
              .AllowAnyMethod();
    });
});

var app = builder.Build();

app.UseCors("AllowAngularDev");
app.UseAuthorization();
app.MapControllers();

app.Run();
