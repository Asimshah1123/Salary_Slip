namespace Zatca.Api.Models;

public class LineItem
{
    public string Id { get; set; } = Guid.NewGuid().ToString("N");
    public string Description { get; set; } = string.Empty;
    public decimal Quantity { get; set; } = 1;
    public decimal UnitPrice { get; set; }

    /// <summary>VAT rate as a percentage, e.g. 15 for standard rate, 0 for zero-rated/exempt.</summary>
    public decimal VatRate { get; set; } = 15m;

    /// <summary>ZATCA VAT category code: S = Standard, Z = Zero-rated, E = Exempt, O = Out of scope.</summary>
    public string VatCategoryCode { get; set; } = "S";

    public decimal LineExtensionAmount => Math.Round(Quantity * UnitPrice, 2, MidpointRounding.AwayFromZero);
    public decimal VatAmount => Math.Round(LineExtensionAmount * VatRate / 100m, 2, MidpointRounding.AwayFromZero);
    public decimal LineTotalWithVat => LineExtensionAmount + VatAmount;
}
