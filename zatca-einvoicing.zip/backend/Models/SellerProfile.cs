namespace Zatca.Api.Models;

/// <summary>Default seller (your company) details, reused to prefill every new invoice.</summary>
public class SellerProfile
{
    public Party Party { get; set; } = new()
    {
        Name = "My Company LLC",
        VatNumber = "300000000000003",
        StreetName = "King Fahd Road",
        BuildingNumber = "1234",
        CitySubdivision = "Al Olaya",
        City = "Riyadh",
        PostalCode = "12345",
        Country = "SA"
    };
}
