namespace Zatca.Api.Models;

public enum InvoiceStatus
{
    Draft,
    Generated,   // Phase 1 QR generated
    Signed,      // Phase 2 UBL XML + hash chain + signature produced
    Submitted,   // sent to ZATCA's Clearance/Reporting API
    Cleared,     // Standard (B2B) invoice: ZATCA cleared and stamped it
    Reported,    // Simplified (B2C) invoice: ZATCA accepted the report
    Rejected     // ZATCA returned validation errors
}

/// <summary>
/// ZATCA invoice subtype: Standard (B2B/B2G) invoices go through the Clearance model (01),
/// Simplified (B2C) invoices go through the Reporting model (02).
/// </summary>
public enum InvoiceSubject
{
    Standard = 1,
    Simplified = 2
}

public enum InvoiceDocumentType
{
    TaxInvoice = 388,
    DebitNote = 383,
    CreditNote = 381
}

public class Invoice
{
    public string Id { get; set; } = Guid.NewGuid().ToString("N");
    public string Uuid { get; set; } = Guid.NewGuid().ToString();

    /// <summary>Human-readable, sequential invoice number, e.g. INV-0001.</summary>
    public string InvoiceNumber { get; set; } = string.Empty;

    /// <summary>Invoice Counter Value — a strictly sequential integer required by ZATCA Phase 2.</summary>
    public long Icv { get; set; }

    /// <summary>Base64 SHA-256 hash of the previous invoice in the chain (genesis = hash of "0").</summary>
    public string PreviousInvoiceHash { get; set; } = string.Empty;

    /// <summary>Base64 SHA-256 hash of this invoice, computed once Phase 2 signing runs.</summary>
    public string? InvoiceHash { get; set; }

    public DateTime IssueDateTimeUtc { get; set; } = DateTime.UtcNow;

    public InvoiceDocumentType DocumentType { get; set; } = InvoiceDocumentType.TaxInvoice;
    public InvoiceSubject Subject { get; set; } = InvoiceSubject.Simplified;

    public string Currency { get; set; } = "SAR";

    public Party Seller { get; set; } = new();
    public Party Buyer { get; set; } = new();

    public List<LineItem> LineItems { get; set; } = new();

    public InvoiceStatus Status { get; set; } = InvoiceStatus.Draft;

    // Phase 1 output
    public string? Phase1QrBase64 { get; set; }

    // Phase 2 output
    public string? UblXml { get; set; }
    public string? Phase2QrBase64 { get; set; }
    public string? SignatureBase64 { get; set; }
    public string? PublicKeyBase64 { get; set; }
    public string? CertificateSignatureBase64 { get; set; }

    // ZATCA Clearance/Reporting submission result
    public string? ZatcaSubmissionResponseJson { get; set; }
    public List<string> ZatcaWarnings { get; set; } = new();
    public List<string> ZatcaErrors { get; set; } = new();

    /// <summary>For cleared (Standard/B2B) invoices: the XML ZATCA returned with its own
    /// cryptographic stamp added, which is what must actually be delivered to the buyer.</summary>
    public string? ClearedInvoiceXml { get; set; }

    public string? Notes { get; set; }

    // Computed totals
    public decimal TaxExclusiveAmount => LineItems.Sum(li => li.LineExtensionAmount);
    public decimal VatTotal => LineItems.Sum(li => li.VatAmount);
    public decimal TaxInclusiveAmount => TaxExclusiveAmount + VatTotal;
}
