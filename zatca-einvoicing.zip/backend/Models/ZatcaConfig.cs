namespace Zatca.Api.Models;

public enum ZatcaOnboardingStage
{
    NotStarted,
    CsrGenerated,
    ComplianceCsidIssued,
    ProductionCsidIssued
}

/// <summary>
/// ZATCA Fatoora onboarding configuration and state. Every value below is a
/// placeholder/dummy value so the full onboarding -> clearance pipeline can be
/// exercised end-to-end against ZATCA's own sandbox. To go live, replace the
/// "Replace with your real values" fields with the taxpayer's actual details
/// and a fresh OTP generated from the ZATCA Fatoora portal (Settings -> Email
/// & OTP for Solution Unit, or Fatoora Simulation Portal for the sandbox) —
/// nothing else in the pipeline needs to change.
/// </summary>
public class ZatcaConfig
{
    // ---------------- Replace with your real values ----------------

    /// <summary>Which ZATCA gateway to call. Sandbox = developer-portal (free testing,
    /// fake VAT numbers allowed). Simulation = pre-production, needs a real onboarded
    /// taxpayer. Production = core, live legal invoices.</summary>
    public string Environment { get; set; } = "Sandbox";

    /// <summary>One-time password from the Fatoora portal (Compliance CSID step only).
    /// Single use and short-lived — request a fresh one right before onboarding.</summary>
    public string OtpCode { get; set; } = "123345";

    /// <summary>EGS (device) identity: "1-&lt;solution name&gt;|2-&lt;unit/model&gt;|3-&lt;unique id&gt;".</summary>
    public string EgsSerialNumber { get; set; } = "1-TestSolution|2-TST-EGS-001|3-ed22f1d8-e6a2-1118-9b58-d9a8f11e445f";

    /// <summary>15-digit seller VAT registration number (must start and end with '3').</summary>
    public string VatRegistrationNumber { get; set; } = "300000000000003";

    public string OrganizationName { get; set; } = "My Company LLC";
    public string OrganizationUnitName { get; set; } = "Riyadh Branch";
    public string CommonName { get; set; } = "My Company LLC";
    public string Country { get; set; } = "SA";

    /// <summary>4-digit invoice-type subscription flags (Tax/Simplified/Debit/Credit), e.g. "1100".</summary>
    public string InvoiceType { get; set; } = "1100";
    public string Location { get; set; } = "Riyadh, Saudi Arabia";
    public string BusinessCategory { get; set; } = "Software Services";

    // ---------------- Populated automatically as onboarding progresses ----------------

    public ZatcaOnboardingStage Stage { get; set; } = ZatcaOnboardingStage.NotStarted;

    /// <summary>PEM-encoded secp256k1 private key generated locally for the CSR; never sent to ZATCA.</summary>
    public string? PrivateKeyPem { get; set; }
    public string? CsrPem { get; set; }

    public string? ComplianceRequestId { get; set; }
    public string? ComplianceCertificateBase64 { get; set; }
    public string? ComplianceSecret { get; set; }

    public string? ProductionRequestId { get; set; }
    public string? ProductionCertificateBase64 { get; set; }
    public string? ProductionSecret { get; set; }

    public string? LastError { get; set; }
    public DateTime? UpdatedAtUtc { get; set; }
}
