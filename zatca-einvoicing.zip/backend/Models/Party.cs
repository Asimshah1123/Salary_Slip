namespace Zatca.Api.Models;

/// <summary>
/// A trading party (Seller or Buyer) as required by the ZATCA e-invoicing spec.
/// </summary>
public class Party
{
    public string Name { get; set; } = string.Empty;

    /// <summary>15-digit Saudi VAT registration number (must start and end with '3').</summary>
    public string VatNumber { get; set; } = string.Empty;

    /// <summary>Commercial Registration number (optional for buyer).</summary>
    public string? CrNumber { get; set; }

    public string StreetName { get; set; } = string.Empty;
    public string BuildingNumber { get; set; } = string.Empty;
    public string PlotIdentification { get; set; } = string.Empty;
    public string CitySubdivision { get; set; } = string.Empty;
    public string City { get; set; } = string.Empty;
    public string PostalCode { get; set; } = string.Empty;

    /// <summary>ISO 3166-1 alpha-2 country code, e.g. "SA".</summary>
    public string Country { get; set; } = "SA";
}
