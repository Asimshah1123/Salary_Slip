namespace Zatca.Api.Models;

/// <summary>Shape the frontend posts to create an invoice; the server fills in ICV, UUID, hashes, QR, etc.</summary>
public class InvoiceCreateRequest
{
    public string? InvoiceNumber { get; set; }
    public InvoiceDocumentType DocumentType { get; set; } = InvoiceDocumentType.TaxInvoice;
    public InvoiceSubject Subject { get; set; } = InvoiceSubject.Simplified;
    public string Currency { get; set; } = "SAR";

    /// <summary>Optional — defaults to the saved seller profile when omitted.</summary>
    public Party? Seller { get; set; }

    public Party Buyer { get; set; } = new();

    public List<LineItem> LineItems { get; set; } = new();

    public string? Notes { get; set; }
}
