using Microsoft.AspNetCore.Mvc;
using Zatca.Api.Models;
using Zatca.Api.Services;

namespace Zatca.Api.Controllers;

/// <summary>
/// Drives ZATCA Fatoora onboarding: review/edit the taxpayer + EGS details,
/// then walk the Compliance CSID -> Production CSID steps against the real
/// ZATCA gateway (Sandbox by default). See ZatcaConfig for which fields are
/// dummy placeholders to replace with real values.
/// </summary>
[ApiController]
[Route("api/zatca")]
public class ZatcaOnboardingController : ControllerBase
{
    private readonly ZatcaOnboardingService _onboarding;

    public ZatcaOnboardingController(ZatcaOnboardingService onboarding)
    {
        _onboarding = onboarding;
    }

    public record ZatcaConfigView(
        string Environment, string OtpCode, string EgsSerialNumber, string VatRegistrationNumber,
        string OrganizationName, string OrganizationUnitName, string CommonName, string Country,
        string InvoiceType, string Location, string BusinessCategory,
        ZatcaOnboardingStage Stage, bool HasCsr, string? ComplianceRequestId, bool HasComplianceCsid,
        string? ProductionRequestId, bool HasProductionCsid, string? LastError, DateTime? UpdatedAtUtc);

    private static ZatcaConfigView ToView(ZatcaConfig c) => new(
        c.Environment, c.OtpCode, c.EgsSerialNumber, c.VatRegistrationNumber,
        c.OrganizationName, c.OrganizationUnitName, c.CommonName, c.Country,
        c.InvoiceType, c.Location, c.BusinessCategory,
        c.Stage, !string.IsNullOrWhiteSpace(c.CsrPem), c.ComplianceRequestId, !string.IsNullOrWhiteSpace(c.ComplianceCertificateBase64),
        c.ProductionRequestId, !string.IsNullOrWhiteSpace(c.ProductionCertificateBase64), c.LastError, c.UpdatedAtUtc);

    [HttpGet("config")]
    public ActionResult<ZatcaConfigView> GetConfig() => Ok(ToView(_onboarding.GetConfig()));

    public record UpdateConfigRequest(
        string Environment, string OtpCode, string EgsSerialNumber, string VatRegistrationNumber,
        string OrganizationName, string OrganizationUnitName, string CommonName, string Country,
        string InvoiceType, string Location, string BusinessCategory);

    [HttpPut("config")]
    public ActionResult<ZatcaConfigView> UpdateConfig([FromBody] UpdateConfigRequest request)
    {
        var config = _onboarding.GetConfig();
        config.Environment = request.Environment;
        config.OtpCode = request.OtpCode;
        config.EgsSerialNumber = request.EgsSerialNumber;
        config.VatRegistrationNumber = request.VatRegistrationNumber;
        config.OrganizationName = request.OrganizationName;
        config.OrganizationUnitName = request.OrganizationUnitName;
        config.CommonName = request.CommonName;
        config.Country = request.Country;
        config.InvoiceType = request.InvoiceType;
        config.Location = request.Location;
        config.BusinessCategory = request.BusinessCategory;
        return Ok(ToView(_onboarding.SaveConfig(config)));
    }

    /// <summary>Generates (or reuses) the CSR, then requests the Compliance CSID using the
    /// configured OTP. Against ZATCA's real sandbox, a dummy OTP/VAT number will come back
    /// with ZATCA's own validation error in `lastError` — that's expected until real values
    /// from the Fatoora portal are supplied.</summary>
    [HttpPost("onboarding/compliance")]
    public async Task<ActionResult<ZatcaConfigView>> RequestComplianceCsid()
        => Ok(ToView(await _onboarding.RequestComplianceCsidAsync()));

    [HttpPost("onboarding/production")]
    public async Task<ActionResult<ZatcaConfigView>> RequestProductionCsid()
        => Ok(ToView(await _onboarding.RequestProductionCsidAsync()));

    [HttpGet("onboarding/csr")]
    public IActionResult GetCsr()
    {
        var config = _onboarding.GetConfig();
        if (config.CsrPem is null) return NotFound(new { error = "No CSR generated yet." });
        return Content(config.CsrPem, "application/x-pem-file");
    }
}
