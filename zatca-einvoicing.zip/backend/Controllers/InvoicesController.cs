using Microsoft.AspNetCore.Mvc;
using Zatca.Api.Data;
using Zatca.Api.Models;
using Zatca.Api.Services;

namespace Zatca.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class InvoicesController : ControllerBase
{
    private readonly InvoiceService _service;
    private readonly ZatcaPhase1Service _phase1;
    private readonly ZatcaApiClient _zatcaApi;
    private readonly InvoiceRepository _repo;

    public InvoicesController(InvoiceService service, ZatcaPhase1Service phase1, ZatcaApiClient zatcaApi, InvoiceRepository repo)
    {
        _service = service;
        _phase1 = phase1;
        _zatcaApi = zatcaApi;
        _repo = repo;
    }

    [HttpGet]
    public ActionResult<List<Invoice>> GetAll() => Ok(_service.GetAll());

    [HttpGet("{id}")]
    public ActionResult<Invoice> GetById(string id)
    {
        var invoice = _service.GetById(id);
        return invoice is null ? NotFound() : Ok(invoice);
    }

    [HttpPost]
    public ActionResult<Invoice> Create([FromBody] InvoiceCreateRequest request)
    {
        if (request.LineItems.Count == 0)
        {
            return BadRequest(new { error = "At least one line item is required." });
        }

        var draft = new Invoice
        {
            InvoiceNumber = request.InvoiceNumber ?? string.Empty,
            DocumentType = request.DocumentType,
            Subject = request.Subject,
            Currency = request.Currency,
            Seller = request.Seller ?? new Party(),
            Buyer = request.Buyer,
            LineItems = request.LineItems,
            Notes = request.Notes
        };

        var created = _service.Create(draft);
        return CreatedAtAction(nameof(GetById), new { id = created.Id }, created);
    }

    [HttpDelete("{id}")]
    public IActionResult Delete(string id) => _service.Delete(id) ? NoContent() : NotFound();

    /// <summary>Raw Phase 1/2 QR Base64 TLV string plus its decoded tags, for display/verification.</summary>
    [HttpGet("{id}/qr")]
    public IActionResult GetQr(string id)
    {
        var invoice = _service.GetById(id);
        if (invoice is null) return NotFound();

        var base64 = invoice.Phase2QrBase64 ?? invoice.Phase1QrBase64;
        if (base64 is null) return NotFound(new { error = "QR not generated yet." });

        var decoded = _phase1.Decode(base64).Select(t => new { tag = t.Tag, value = t.Value });
        return Ok(new { base64, phase = invoice.Phase2QrBase64 is not null ? 2 : 1, tags = decoded });
    }

    [HttpGet("{id}/xml")]
    public IActionResult GetXml(string id)
    {
        var invoice = _service.GetById(id);
        if (invoice?.UblXml is null) return NotFound();
        return Content(invoice.UblXml, "application/xml");
    }

    /// <summary>Print-ready HTML invoice; the frontend opens this and uses the browser's print-to-PDF.</summary>
    [HttpGet("{id}/print")]
    public IActionResult GetPrintHtml(string id)
    {
        var invoice = _service.GetById(id);
        if (invoice is null) return NotFound();
        var html = InvoiceHtmlRenderer.Render(invoice);
        return Content(html, "text/html");
    }

    /// <summary>Submits this invoice to ZATCA's live Clearance (Standard) or Reporting
    /// (Simplified) API using the onboarded Production CSID. See ZatcaOnboardingController
    /// to complete onboarding first.</summary>
    [HttpPost("{id}/submit")]
    public async Task<IActionResult> Submit(string id)
    {
        var invoice = _service.GetById(id);
        if (invoice is null) return NotFound();

        var result = await _zatcaApi.SubmitAsync(invoice);

        invoice.Status = result.ResultStatus;
        invoice.ZatcaSubmissionResponseJson = result.ResponseJson;
        invoice.ZatcaWarnings = result.Warnings;
        invoice.ZatcaErrors = result.Errors;
        _repo.Update(invoice);

        return Ok(invoice);
    }
}
