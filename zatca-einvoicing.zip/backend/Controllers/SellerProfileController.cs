using Microsoft.AspNetCore.Mvc;
using Zatca.Api.Data;
using Zatca.Api.Models;

namespace Zatca.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class SellerProfileController : ControllerBase
{
    private readonly SellerProfileRepository _repo;

    public SellerProfileController(SellerProfileRepository repo)
    {
        _repo = repo;
    }

    [HttpGet]
    public ActionResult<SellerProfile> Get() => Ok(_repo.Get());

    [HttpPut]
    public ActionResult<SellerProfile> Save([FromBody] SellerProfile profile) => Ok(_repo.Save(profile));
}
