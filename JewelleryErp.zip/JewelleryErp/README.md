# Pakistani Jewellery Retail ERP

A multi-branch, role-based ERP for Pakistani jewellery retailers, built from the attached SRS (`Pakistani_Jewellery_Retail_ERP_SRS_...docx`). Backend: ASP.NET Core 10 Web API + SQL Server (EF Core). Frontend: Angular 22.

**This is a first implementation of the full SRS feature set. It has not run against a real database or been used by a business. Review it, run the UAT scenarios in SRS §13/§22, and get sign-off before going live with real money or stock.**

## What's here

```
backend/
  src/Erp.Domain/          entities, enums, pure business rules (pricing, reconciliation, journals, state machines)
  src/Erp.Infrastructure/  EF Core DbContext, all services (auth, sales, purchasing, inventory, job work, repairs, finance, reports, admin), file storage/scanning, CSV/XLSX/PDF export
  src/Erp.Api/             ASP.NET Core Web API: controllers, middleware, Program.cs, appsettings
  tools/Erp.SelfTest/      dependency-free console app that checks the business rules (pricing, reconciliation, RBAC, journals, image validation) — 75 assertions
  tools/Stubs/             API-shape stand-ins for EF Core / JwtBearer, used ONLY to compile-check this project where NuGet was unreachable; never used at runtime
  Dockerfile, JewelleryErp.sln
frontend/
  src/app/core/            API client, session (in-memory access token + HttpOnly refresh cookie), interceptors, guards, i18n
  src/app/shared/          dynamic form, data table, secure image viewer/uploader/gallery, charts, dialog
  src/app/features/        all screens: dashboard, POS, sales, products, purchases, inventory, job work, repairs, finance, reports, admin
  Dockerfile, nginx.conf
docker-compose.yml, .env.example
```

## Status — read before relying on this

**Backend compiles against real ASP.NET Core / EF Core / JwtBearer only if your build environment has NuGet access.** It was developed and compile-checked in a sandbox with no NuGet access, using hand-written stand-ins (`tools/Stubs`) that mimic the real packages' public API shape. `dotnet build -p:UseStubs=true` uses those stand-ins; a normal `dotnet build` (or `dotnet build src/Erp.Api/Erp.Api.csproj`) uses the real NuGet packages and is what you should use for anything beyond a first read-through. **The first real build may surface mismatches the stubs didn't catch.**

Verified in the sandbox:
- 75 self-tests of the business rules pass (`cd backend/tools/Erp.SelfTest && dotnet run`) — pricing, weight reconciliation, old-gold valuation, commission, journal balancing, job/repair/transfer state machines, RBAC role templates, image signature/metadata validation.
- The CSV/XLSX/PDF exporters were checked against openpyxl, Python's `csv` module, and `pdftotext`.
- All 12 API controllers resolve from dependency injection against the stubs; all 157 routes are registered with no ambiguous routes.
- A smoke test against the stub-built API confirmed: 401 + security headers on unauthenticated requests, rate limiting on login, CORS rejecting foreign origins, and that error responses keep the security headers.
- `ng build` (dev and production) succeeds with the real Angular 22 toolchain — no stubs were needed for the frontend.

**Not verified — do this before trusting the system:**
- Nothing has run against SQL Server or the real EF Core/JwtBearer packages.
- The global per-company/per-branch query filters, the auto-generated foreign keys, the atomic document-numbering (`UPDATE ... OUTPUT`), and the concurrency guard against double-selling one serialized item are all written but untested — they depend on real EF Core.
- None of the UAT scenarios in SRS §13 and §22 (sell a ring, run the worker reconciliation flows, branch isolation, etc.) have been executed end to end.
- No EF Core migrations exist yet (see below) — the app currently relies on `Database:AutoCreate` for a first local run.

## Running it locally

```bash
cp .env.example .env            # set SQL_SA_PASSWORD, JWT_KEY (openssl rand -base64 48), ADMIN_PASSWORD
docker compose up --build
```
- API: http://localhost:8080  (health: `/health/live`, `/health/ready`)
- Web: http://localhost:4200 (reverse-proxies `/api/*` to the API container)
- First run seeds: chart of accounts, metals/purities, units (gram approved; tola/ratti NOT approved — see Settings), payment methods, expense heads, a Head Office branch, and an administrator account (`Seed:AdminUser`, password from `ADMIN_PASSWORD`). Set `SEED_DEMO=true` for a couple of demo customers/products/rates to explore the POS.
- Sign in, then change the administrator password immediately (`mustChangePassword` forces this in the UI).

### Without Docker
Backend: `dotnet run --project backend/src/Erp.Api` with `ConnectionStrings:Default` and `Jwt:Key` set (via `dotnet user-secrets` or environment variables — never commit them).
Frontend: `cd frontend && npm install && npx ng serve` (proxy `/api` to your API port, e.g. via `proxy.conf.json`).

## Before production

1. **Run `dotnet build` for real** (not `-p:UseStubs=true`) and fix whatever the real packages' compiler surfaces.
2. **EF Core migrations.** No migrations are checked in. Generate them against your actual schema decisions:
   `dotnet tool install --global dotnet-ef && cd backend/src/Erp.Api && dotnet ef migrations add Initial --project ../Erp.Infrastructure`. Set `Database:AutoCreate=false` and apply migrations explicitly from then on.
3. **Approve the open decisions from SRS §15** — unit conversions (ratti etc. — currently blocked until approved in Settings → Units), tax rules, costing method, invoice numbering, backdating policy, approval limits per role — these are all configurable, not guessed, but they default to "off" or a conservative value and need a business decision.
4. **Secrets**: real `Jwt:Key`, DB credentials, and (if using encrypted SQL backups) a server certificate name — none of these belong in source control or `appsettings.json`.
5. **TLS** in front of both containers; set `Security:CookieSecure=true`.
6. **Run the SRS §13 / §22 UAT scenarios** against a staging environment with real data before go-live.
7. Review the generated role templates (`RoleTemplates` in `Erp.Domain`) and the default approval limits seeded in `DbSeeder` — they are a reasonable starting matrix, not the business's approved one (SRS §20 says the final matrix needs owner sign-off).

## Architecture notes worth knowing

- **Dual ledger**: every posted transaction writes both an immutable stock movement (never updated/deleted — corrections are reversing movements) and, where financial, a balanced double-entry journal. PKR and metal (fine-gram) balances for customers/suppliers/workers are kept in separate ledgers.
- **Branch isolation** is enforced by an EF Core global query filter based on the signed-in user's permitted branches (resolved server-side on every request, never trusted from the client) — not by hiding UI.
- **Rate snapshots**: every line that uses a gold rate stores the rate and its timestamp; later rate changes never alter a posted invoice.
- **Images**: validated by file signature (not client-reported MIME type), scanned, stripped of EXIF/GPS metadata, stored under random keys outside the web root, and served only through an authorized endpoint.
- **Idempotency**: every state-changing request from the Angular app carries an `Idempotency-Key` header; a retried request (e.g. a flaky connection) returns the original result instead of double-posting.

## Traceability

See `TRACEABILITY.md` for a section-by-section map from the SRS to where each requirement is implemented.
