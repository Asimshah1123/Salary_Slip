using Erp.Domain;
using Erp.Domain.Entities;
using Erp.Infrastructure.Contracts;
using Erp.Infrastructure.Exports;
using Erp.Infrastructure.Services;
using Microsoft.AspNetCore.Mvc;

namespace Erp.Api.Controllers;

public sealed record CancelRequest(string Reason);
public sealed record PayOutRequest(long? PayOutAccountId);
public sealed record VoidRequest(string Reason);
public sealed record StageRequest(JobStatus To, string? Note);
public sealed record DecisionRequest(bool Approve, string? Reason);
public sealed record ClaimRequest(IDictionary<long, decimal>? Overrides, List<long> EntryIds);
public sealed record PayCommissionRequest(decimal Amount, long AccountId, long? BranchId);
public sealed record ReversalRequest(string Kind, long Id, string Reason);
public sealed record OpeningRequest(long? BranchId, DateTime CutoverUtc);

public sealed class SalesController : ApiBase
{
    readonly SalesService _s;
    public SalesController(SalesService s) { _s = s; }
    [HttpPost("sales/quotes")] public async Task<IActionResult> Quote([FromBody] SaleInput i) => Ok(await _s.Quote(i));
    [HttpPost("sales")] public async Task<IActionResult> Create([FromBody] SaleInput i) { i.IdempotencyKey ??= IdemKey; return Ok(await _s.Create(i)); }
    [HttpGet("sales")] public async Task<IActionResult> List([FromQuery] SaleQuery q) => Ok(await _s.List(q));
    [HttpGet("sales/{id:long}")] public async Task<IActionResult> Get(long id) => Ok(await _s.Get(id));
    [HttpPost("sales/{id:long}/post")] public async Task<IActionResult> Post(long id) => Ok(await _s.Post(id));
    [HttpPost("sales/{id:long}/cancel")] public async Task<IActionResult> Cancel(long id, [FromBody] CancelRequest r) { await _s.Cancel(id, r.Reason); return NoContent(); }
    [HttpPost("sales/{id:long}/print")] public async Task<IActionResult> Print(long id) => Ok(await _s.RegisterPrint(id));
    [HttpPost("sales/{id:long}/returns")] public async Task<IActionResult> Return(long id, [FromBody] ReturnInput i) { i.IdempotencyKey ??= IdemKey; return Ok(await _s.Return(id, i)); }
    [HttpGet("sales/{id:long}/returns")] public async Task<IActionResult> Returns(long id) => Ok(await _s.ReturnsOf(id));
    [HttpPost("sales/returns/{id:long}/post")] public async Task<IActionResult> PostReturn(long id) => Ok(await _s.PostReturn(id));
    [HttpPost("sales/{id:long}/void")] public async Task<IActionResult> Void(long id, [FromBody] VoidRequest r) => Ok(await _s.Void(id, r.Reason, IdemKey));
    [HttpGet("sales/{id:long}/pdf")]
    public async Task<IActionResult> Pdf(long id)
    {
        var s = await _s.Get(id);
        var t = new ReportTable { Title = "Invoice " + s.Number, Scope = $"{s.Branch} | {s.DateUtc:yyyy-MM-dd HH:mm} | Customer: {s.Customer ?? "Walk-in"} | Salesman: {s.Salesman ?? "-"} | Rate policy: {s.RatePolicy}", GeneratedBy = User.FindFirst("uname")?.Value ?? "",
            Columns = new() { new("sku", "SKU"), new("d", "Item"), new("p", "Purity"), new("g", "Gross", "weight"), new("st", "Stone", "weight"), new("n", "Net", "weight"), new("r", "Rate", "money"), new("m", "Making", "money"), new("w", "Wastage", "money"), new("sv", "Stone val", "money"), new("dc", "Disc", "money"), new("t", "Total", "money") } };
        foreach (var l in s.Lines) t.Rows.Add(new object?[] { l.Sku, l.Description, l.Purity, l.Gross, l.Stone, l.Net, l.Rate, l.Making, l.Wastage, l.StoneValue, l.Discount, l.LineTotal });
        t.Totals["subtotal"] = s.Subtotal; t.Totals["discount"] = s.Discount; t.Totals["tax"] = s.Tax; t.Totals["old gold"] = s.OldGoldCredit; t.Totals["total"] = s.Total; t.Totals["paid"] = s.Paid; t.Totals["due"] = s.Due;
        t.Note = string.Join("; ", s.Payments.Select(p => $"{p.Method} {p.Amount:N2}"));
        return Export(t, "pdf");
    }
    [HttpPost("old-gold-transactions")] public async Task<IActionResult> OldGold([FromBody] OldGoldInput i) { i.IdempotencyKey ??= IdemKey; return Ok(await _s.CreateOldGold(i)); }
    [HttpGet("old-gold-transactions/{id:long}")] public async Task<IActionResult> GetOldGold(long id) => Ok(await _s.GetOldGold(id));
    [HttpPost("old-gold-transactions/{id:long}/post")] public async Task<IActionResult> PostOldGold(long id, [FromBody] PayOutRequest r) => Ok(await _s.PostOldGold(id, r.PayOutAccountId));
    [HttpGet("customers/{id:long}/old-gold")] public async Task<IActionResult> CustomerOldGold(long id, [FromQuery] bool unapplied = true) => Ok(await _s.OldGoldForCustomer(id, unapplied));
}

public sealed class PurchasesController : ApiBase
{
    readonly PurchaseService _p;
    public PurchasesController(PurchaseService p) { _p = p; }
    [HttpPost("purchases")] public async Task<IActionResult> Create([FromBody] PurchaseInput i) { i.IdempotencyKey ??= IdemKey; return Ok(await _p.Create(i)); }
    [HttpGet("purchases")] public async Task<IActionResult> List([FromQuery] PurchaseQuery q) => Ok(await _p.List(q));
    [HttpGet("purchases/{id:long}")] public async Task<IActionResult> Get(long id) => Ok(await _p.Get(id));
    [HttpPost("purchases/{id:long}/post")] public async Task<IActionResult> Post(long id) => Ok(await _p.Post(id));
    [HttpPost("purchases/{id:long}/receive")] public async Task<IActionResult> Receive(long id, [FromBody] List<ReceiveLineInput> lines) => Ok(await _p.Receive(id, lines));
    [HttpPost("purchases/{id:long}/supplier-return")] public async Task<IActionResult> SupplierReturn(long id, [FromBody] SupplierReturnInput i) { i.IdempotencyKey ??= IdemKey; return Ok(await _p.SupplierReturn(id, i)); }
    [HttpPost("supplier-payments")] public async Task<IActionResult> Pay([FromBody] SupplierPaymentInput i) { i.IdempotencyKey ??= IdemKey; return Ok(await _p.Pay(i)); }
    [HttpGet("suppliers/{id:long}/credit")] public async Task<IActionResult> Credit(long id) => Ok(new { credit = await _p.SupplierCredit(id) });
}

public sealed class InventoryController : ApiBase
{
    readonly InventoryService _i;
    public InventoryController(InventoryService i) { _i = i; }
    [HttpGet("inventory/stock")] public async Task<IActionResult> Stock([FromQuery] StockQuery q) => Ok(await _i.Stock(q));
    [HttpGet("inventory/movements")] public async Task<IActionResult> Movements([FromQuery] MovementQuery q) => Ok(await _i.Movements(q));
    [HttpGet("inventory/reconcile")] public async Task<IActionResult> Reconcile([FromQuery] long[]? branchIds) => Ok(await _i.Reconcile(branchIds));
    [HttpGet("inventory/transfers")] public async Task<IActionResult> Transfers([FromQuery] PageQuery q, [FromQuery] TransferStatus? status) => Ok(await _i.ListTransfers(q, status));
    [HttpPost("inventory/transfers")] public async Task<IActionResult> CreateTransfer([FromBody] TransferInput i) { i.IdempotencyKey ??= IdemKey; return Ok(await _i.CreateTransfer(i)); }
    [HttpGet("inventory/transfers/{id:long}")] public async Task<IActionResult> Transfer(long id) => Ok(await _i.GetTransfer(id));
    [HttpPost("inventory/transfers/{id:long}/dispatch")] public async Task<IActionResult> Dispatch(long id) => Ok(await _i.Dispatch(id));
    [HttpPost("inventory/transfers/{id:long}/receive")] public async Task<IActionResult> Receive(long id, [FromBody] TransferReceiveInput i) => Ok(await _i.Receive(id, i));
    [HttpPost("inventory/transfers/{id:long}/cancel")] public async Task<IActionResult> Cancel(long id, [FromBody] CancelRequest r) { await _i.CancelTransfer(id, r.Reason); return NoContent(); }
    [HttpGet("inventory/adjustments")] public async Task<IActionResult> Adjustments([FromQuery] PageQuery q) => Ok(await _i.ListAdjustments(q));
    [HttpPost("inventory/adjustments")] public async Task<IActionResult> Adjust([FromBody] AdjustInput i) { i.IdempotencyKey ??= IdemKey; return Ok(await _i.Adjust(i)); }
    [HttpPost("inventory/adjustments/{id:long}/post")] public async Task<IActionResult> PostAdjustment(long id) => Ok(await _i.PostAdjustment(id));
    [HttpGet("inventory/counts")] public async Task<IActionResult> Counts([FromQuery] PageQuery q) => Ok(await _i.ListCounts(q));
    [HttpPost("inventory/counts")] public async Task<IActionResult> CreateCount([FromBody] CountInput i) => Ok(await _i.CreateCount(i));
    [HttpGet("inventory/counts/{id:long}")] public async Task<IActionResult> Count(long id) => Ok(await _i.GetCount(id));
    [HttpPut("inventory/counts/{id:long}/entries")] public async Task<IActionResult> Enter(long id, [FromBody] List<CountEntry> e) => Ok(await _i.EnterCount(id, e));
    [HttpPost("inventory/counts/{id:long}/submit")] public async Task<IActionResult> Submit(long id) => Ok(await _i.SubmitCount(id));
    [HttpPost("inventory/counts/{id:long}/decision")] public async Task<IActionResult> Decide(long id, [FromBody] DecisionRequest r) => Ok(await _i.ApproveCount(id, r.Approve, r.Reason));
    [HttpGet("inventory/reservations")] public async Task<IActionResult> Reservations([FromQuery] bool activeOnly = true) => Ok(await _i.Reservations(activeOnly));
    [HttpPost("inventory/reservations")] public async Task<IActionResult> Reserve([FromBody] ReserveInput i) => Ok(await _i.Reserve(i));
    [HttpDelete("inventory/reservations/{id:long}")] public async Task<IActionResult> Release(long id) { await _i.Release(id); return NoContent(); }
}

public sealed class JobWorkController : ApiBase
{
    readonly JobWorkService _j;
    public JobWorkController(JobWorkService j) { _j = j; }
    [HttpGet("job-cards")] public async Task<IActionResult> List([FromQuery] JobQuery q) => Ok(await _j.List(q));
    [HttpGet("job-cards/{id:long}")] public async Task<IActionResult> Get(long id) => Ok(await _j.Get(id));
    [HttpPost("job-cards")] public async Task<IActionResult> Create([FromBody] JobInput i) { i.IdempotencyKey ??= IdemKey; return Ok(await _j.Create(i)); }
    [HttpPost("job-cards/{id:long}/approve")] public async Task<IActionResult> Approve(long id) => Ok(await _j.Approve(id));
    [HttpPost("job-cards/{id:long}/cancel")] public async Task<IActionResult> Cancel(long id, [FromBody] CancelRequest r) { await _j.Cancel(id, r.Reason); return NoContent(); }
    [HttpPost("job-cards/{id:long}/stage")] public async Task<IActionResult> Stage(long id, [FromBody] StageRequest r) => Ok(await _j.UpdateStage(id, r.To, r.Note));
    [HttpPost("job-cards/{id:long}/issue-material")] public async Task<IActionResult> Issue(long id, [FromBody] IssueInput i) { i.IdempotencyKey ??= IdemKey; return Ok(await _j.IssueMaterial(id, i)); }
    [HttpPost("job-cards/{id:long}/receipts")] public async Task<IActionResult> Receipt(long id, [FromBody] ReceiptInput i) { i.IdempotencyKey ??= IdemKey; return Ok(await _j.Receive(id, i)); }
    [HttpPost("job-cards/{id:long}/reconcile")] public async Task<IActionResult> Reconcile(long id, [FromBody] ReconcileInput i) => Ok(await _j.Reconcile(id, i));
    [HttpPost("job-cards/{id:long}/close")] public async Task<IActionResult> Close(long id) => Ok(await _j.Close(id));
    [HttpPost("worker-payments")] public async Task<IActionResult> Pay([FromBody] WorkerPaymentInput i) { i.IdempotencyKey ??= IdemKey; return Ok(await _j.PayWorker(i)); }
}

public sealed class RepairsController : ApiBase
{
    readonly RepairService _r;
    public RepairsController(RepairService r) { _r = r; }
    [HttpGet("repairs")] public async Task<IActionResult> List([FromQuery] RepairQuery q) => Ok(await _r.List(q));
    [HttpGet("repairs/{id:long}")] public async Task<IActionResult> Get(long id) => Ok(await _r.Get(id));
    [HttpPost("repairs")] public async Task<IActionResult> Intake([FromBody] RepairIntakeInput i) { i.IdempotencyKey ??= IdemKey; return Ok(await _r.Intake(i)); }
    [HttpPost("repairs/{id:long}/estimate")] public async Task<IActionResult> Estimate(long id, [FromBody] RepairEstimateInput i) => Ok(await _r.PrepareEstimate(id, i));
    [HttpPost("repairs/{id:long}/submit-approval")] public async Task<IActionResult> Submit(long id) => Ok(await _r.SubmitForApproval(id));
    [HttpPost("repairs/{id:long}/approve")] public async Task<IActionResult> Approve(long id, [FromBody] RepairApprovalInput i) => Ok(await _r.DecideEstimate(id, i));
    [HttpPatch("repairs/{id:long}/status")] public async Task<IActionResult> Status(long id, [FromBody] RepairStatusInput i) => Ok(await _r.UpdateStatus(id, i));
    [HttpPost("repairs/{id:long}/parts")] public async Task<IActionResult> Part(long id, [FromBody] RepairPartInput i) => Ok(await _r.AddPart(id, i));
    [HttpPost("repairs/{id:long}/link-job/{jobId:long}")] public async Task<IActionResult> Link(long id, long jobId) => Ok(await _r.LinkJob(id, jobId));
    [HttpPost("repairs/{id:long}/deliver")] public async Task<IActionResult> Deliver(long id, [FromBody] RepairDeliverInput i) => Ok(await _r.Deliver(id, i));
}

public sealed class FinanceController : ApiBase
{
    readonly FinanceService _f;
    public FinanceController(FinanceService f) { _f = f; }
    [HttpPost("expenses")] public async Task<IActionResult> Expense([FromBody] ExpenseInput i) { i.IdempotencyKey ??= IdemKey; return Ok(await _f.CreateExpense(i)); }
    [HttpGet("expenses")] public async Task<IActionResult> Expenses([FromQuery] PageQuery q, [FromQuery] long[]? branchIds, [FromQuery] DateTime? from, [FromQuery] DateTime? to, [FromQuery] long? headId) => Ok(await _f.ListExpenses(q, branchIds, from, to, headId));
    [HttpGet("expenses/{id:long}")] public async Task<IActionResult> GetExpense(long id) => Ok(await _f.GetExpense(id));
    [HttpPost("expenses/{id:long}/post")] public async Task<IActionResult> PostExpense(long id) => Ok(await _f.PostExpense(id));
    [HttpPost("cash-vouchers")] public async Task<IActionResult> CashVoucher([FromBody] VoucherInput i) { i.IdempotencyKey ??= IdemKey; return Ok(await _f.CreateVoucher(i)); }
    [HttpPost("bank-vouchers")] public async Task<IActionResult> BankVoucher([FromBody] VoucherInput i) { i.IdempotencyKey ??= IdemKey; return Ok(await _f.CreateVoucher(i)); }
    [HttpGet("vouchers")] public async Task<IActionResult> Vouchers([FromQuery] PageQuery q, [FromQuery] long[]? branchIds, [FromQuery] VoucherType? type, [FromQuery] DateTime? from, [FromQuery] DateTime? to) => Ok(await _f.ListVouchers(q, branchIds, type, from, to));
    [HttpGet("vouchers/{id:long}")] public async Task<IActionResult> Voucher(long id) => Ok(await _f.GetVoucher(id));
    [HttpPost("reversals")] public async Task<IActionResult> Reverse([FromBody] ReversalRequest r) { await _f.Reverse(r.Kind, r.Id, r.Reason); return NoContent(); }
    [HttpGet("registers")] public async Task<IActionResult> Registers([FromQuery] bool openOnly = false) => Ok(await _f.Registers(openOnly));
    [HttpPost("registers")] public async Task<IActionResult> Open([FromBody] RegisterOpenInput i) => Ok(await _f.OpenRegister(i));
    [HttpPost("registers/{id:long}/close")] public async Task<IActionResult> Close(long id, [FromBody] RegisterCloseInput i) => Ok(await _f.CloseRegister(id, i));
    [HttpGet("parties/{type}/{id:long}/statement")] public async Task<IActionResult> Statement(PartyType type, long id, [FromQuery] DateTime? from, [FromQuery] DateTime? to) => Ok(await _f.Statement(type, id, from ?? DateTime.UtcNow.AddMonths(-3), to ?? DateTime.UtcNow));
    [HttpGet("customers/{id:long}/ledger")] public async Task<IActionResult> CustomerLedger(long id, [FromQuery] DateTime? from, [FromQuery] DateTime? to) => Ok(await _f.Statement(PartyType.Customer, id, from ?? DateTime.UtcNow.AddMonths(-3), to ?? DateTime.UtcNow));
    [HttpGet("suppliers/{id:long}/ledger")] public async Task<IActionResult> SupplierLedger(long id, [FromQuery] DateTime? from, [FromQuery] DateTime? to) => Ok(await _f.Statement(PartyType.Supplier, id, from ?? DateTime.UtcNow.AddMonths(-3), to ?? DateTime.UtcNow));
    [HttpGet("workers/{id:long}/statement")] public async Task<IActionResult> WorkerStatement(long id, [FromQuery] DateTime? from, [FromQuery] DateTime? to) => Ok(await _f.Statement(PartyType.Worker, id, from ?? DateTime.UtcNow.AddMonths(-3), to ?? DateTime.UtcNow));
    [HttpPost("metal-ledger/entries")] public async Task<IActionResult> MetalEntry([FromBody] MetalEntryInput i) { await _f.MetalEntry(i); return NoContent(); }
    [HttpGet("commission")] public async Task<IActionResult> Commission([FromQuery] DateTime? from, [FromQuery] DateTime? to, [FromQuery] long[]? branchIds) => Ok(await _f.Commission(from, to, branchIds));
    [HttpGet("commission/{salesmanId:long}")] public async Task<IActionResult> CommissionDetail(long salesmanId, [FromQuery] DateTime? from, [FromQuery] DateTime? to) => Ok(await _f.CommissionDetails(salesmanId, from, to));
    [HttpPost("commission/approve")] public async Task<IActionResult> ApproveCommission([FromBody] ClaimRequest r) => Ok(new { approved = await _f.ApproveCommission(r.EntryIds, r.Overrides) });
    [HttpPost("commission/{salesmanId:long}/pay")] public async Task<IActionResult> PayCommission(long salesmanId, [FromBody] PayCommissionRequest r) { await _f.PayCommission(salesmanId, r.Amount, r.AccountId, r.BranchId); return NoContent(); }
    [HttpPost("opening-journal")] public async Task<IActionResult> Opening([FromBody] OpeningRequest r) => Ok(new { journal = await _f.PostOpeningJournal(r.BranchId, r.CutoverUtc) });
}

public sealed class ReportsController : ApiBase
{
    readonly ReportService _r;
    public ReportsController(ReportService r) { _r = r; }
    [HttpGet("reports/dashboard")] public async Task<IActionResult> Dashboard([FromQuery] ReportFilter f) => Ok(await _r.Dashboard(f));
    [HttpGet("reports/transactions")] public async Task<IActionResult> Register([FromQuery] RegisterQuery q) => Ok(await _r.Register(q));
    [HttpGet("reports/transactions/{type}/{docId:long}")] public async Task<IActionResult> Detail(TxnType type, long docId) => Ok(await _r.RegisterDetail(type, docId));
    [HttpGet("reports/transactions/export")] public async Task<IActionResult> RegisterExport([FromQuery] RegisterQuery q, [FromQuery] string format = "csv") => Export(await _r.RegisterTable(q), format);
    [HttpGet("reports/catalogue")] public IActionResult Catalogue() => Ok(ReportService.Catalogue.Select(c => new { key = c.Key, title = c.Value.Title, group = c.Value.Group }).GroupBy(x => x.group).Select(g => new { group = g.Key, reports = g.ToList() }));
    [HttpGet("reports/run/{key}")] public async Task<IActionResult> Run(string key, [FromQuery] ReportFilter f) => Ok(await _r.Run(key, f));
    [HttpGet("reports/run/{key}/export")] public async Task<IActionResult> RunExport(string key, [FromQuery] ReportFilter f, [FromQuery] string format = "csv") => Export(await _r.Run(key, f, forExport: true), format);
}

public sealed class AdminController : ApiBase
{
    readonly AdminService _a; readonly BackupService _b;
    public AdminController(AdminService a, BackupService b) { _a = a; _b = b; }
    public sealed record PasswordRequest(string Password);
    public sealed record SettingRequest(string Value, long? BranchId);
    public sealed record RestoreRequest(string Note);
    [HttpGet("users")] public async Task<IActionResult> Users([FromQuery] PageQuery q) => Ok(await _a.Users(q));
    [HttpPost("users")] public async Task<IActionResult> CreateUser([FromBody] UserInput i) => Ok(await _a.SaveUser(null, i));
    [HttpPut("users/{id:long}")] public async Task<IActionResult> UpdateUser(long id, [FromBody] UserInput i) => Ok(await _a.SaveUser(id, i));
    [HttpPost("users/{id:long}/reset-password")] public async Task<IActionResult> Reset(long id, [FromBody] PasswordRequest r) { await _a.ResetUserPassword(id, r.Password); return NoContent(); }
    [HttpPost("users/{id:long}/unlock")] public async Task<IActionResult> Unlock(long id) { await _a.Unlock(id); return NoContent(); }
    [HttpGet("users/{id:long}/logins")] public async Task<IActionResult> Logins(long id) => Ok(await _a.LoginHistory(id));
    [HttpGet("roles")] public async Task<IActionResult> Roles() => Ok(await _a.Roles());
    [HttpPost("roles")] public async Task<IActionResult> CreateRole([FromBody] RoleInput i) => Ok(await _a.SaveRole(null, i));
    [HttpPut("roles/{id:long}")] public async Task<IActionResult> UpdateRole(long id, [FromBody] RoleInput i) => Ok(await _a.SaveRole(id, i));
    [HttpGet("permissions")] public IActionResult Permissions() => Ok(_a.PermissionCatalogue());
    [HttpGet("branches")] public async Task<IActionResult> Branches() => Ok(await _a.Branches());
    [HttpGet("lookups/branches")] public async Task<IActionResult> BranchLookup() => Ok((await _a.Branches()).Where(b => b.IsActive).Select(b => new { id = b.Id, name = b.BranchName, code = b.BranchCode }));
    [HttpPost("branches")] public async Task<IActionResult> CreateBranch([FromBody] BranchInput i) => Ok(await _a.SaveBranch(null, i));
    [HttpPut("branches/{id:long}")] public async Task<IActionResult> UpdateBranch(long id, [FromBody] BranchInput i) => Ok(await _a.SaveBranch(id, i));
    [HttpGet("audit-logs")] public async Task<IActionResult> Audit([FromQuery] AuditQuery q) => Ok(await _a.AuditLogs(q));
    [HttpGet("audit-logs/export")] public async Task<IActionResult> AuditExport([FromQuery] AuditQuery q, [FromQuery] string format = "csv") => Export(await _a.AuditExport(q), format);
    [HttpGet("approvals")] public async Task<IActionResult> Approvals([FromQuery] PageQuery q, [FromQuery] ApprovalStatus? status, [FromQuery] bool mine = false) => Ok(await _a.Approvals(q, status, mine));
    [HttpPost("approvals/{id:long}/decision")] public async Task<IActionResult> Decide(long id, [FromBody] DecisionRequest r) { await _a.Decide(id, r.Approve, r.Reason); return NoContent(); }
    [HttpGet("settings")] public async Task<IActionResult> Settings([FromQuery] long? branchId) => Ok(await _a.Settings(branchId));
    [HttpPut("settings/{key}")] public async Task<IActionResult> SetSetting(string key, [FromBody] SettingRequest r) { await _a.SetSetting(key, r.Value, r.BranchId); return NoContent(); }
    [HttpGet("backups/status")] public async Task<IActionResult> Backups() => Ok(await _b.Status());
    [HttpPost("backups")] public async Task<IActionResult> RunBackup() => Ok(await _b.Run());
    [HttpPost("backups/{id:long}/restore-tested")] public async Task<IActionResult> Restored(long id, [FromBody] RestoreRequest r) { await _b.MarkRestoreTested(id, r.Note); return NoContent(); }
}
