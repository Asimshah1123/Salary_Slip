using System.Text.Json;
using Erp.Api.Infrastructure;
using Erp.Domain;
using Erp.Infrastructure;
using Erp.Infrastructure.Contracts;
using Erp.Infrastructure.Exports;
using Erp.Infrastructure.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;

namespace Erp.Api.Controllers;

[ApiController, Authorize, Route("api/v1")]
public abstract class ApiBase : ControllerBase
{
    protected string? IdemKey => Request.Headers["Idempotency-Key"].FirstOrDefault();
    protected IActionResult Export(ReportTable t, string format)
    {
        var safe = new string(t.Title.Where(char.IsLetterOrDigit).ToArray()); if (safe.Length == 0) safe = "report";
        var stamp = DateTime.UtcNow.ToString("yyyyMMdd-HHmm");
        Response.Headers["Cache-Control"] = "no-store";
        return (format ?? "csv").ToLowerInvariant() switch
        {
            "xlsx" => File(Exporters.Xlsx(t), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", $"{safe}-{stamp}.xlsx"),
            "pdf" => File(Exporters.Pdf(t), "application/pdf", $"{safe}-{stamp}.pdf"),
            "csv" => File(Exporters.Csv(t), "text/csv; charset=utf-8", $"{safe}-{stamp}.csv"),
            _ => throw new ValidationFailedException("format", "Use csv, xlsx or pdf.")
        };
    }
}

public sealed record LoginRequest(string UserName, string Password);
public sealed record ForgotRequest(string Email);
public sealed record ResetRequest(string Token, string NewPassword);
public sealed record ChangePasswordRequest(string CurrentPassword, string NewPassword);

public sealed class AuthController : ApiBase
{
    readonly AuthService _auth; readonly CurrentUser _cu; readonly IConfiguration _cfg;
    public AuthController(AuthService auth, CurrentUser cu, IConfiguration cfg) { _auth = auth; _cu = cu; _cfg = cfg; }
    const string Cookie = "erp_rt";

    void SetCookie(AuthResult r) => Response.Cookies.Append(Cookie, r.RefreshToken, new CookieOptions { HttpOnly = true, Secure = _cfg.GetValue("Security:CookieSecure", true), SameSite = SameSiteMode.Strict, Path = "/api/v1/auth", Expires = r.RefreshExpiresUtc });
    static object Body(AuthResult r) => new { accessToken = r.AccessToken, expiresUtc = r.ExpiresUtc, user = r.User };

    [AllowAnonymous, HttpPost("auth/login"), EnableRateLimiting("login")]
    public async Task<IActionResult> Login([FromBody] LoginRequest r)
    {
        var res = await _auth.Login(r.UserName, r.Password, HttpContext.Connection.RemoteIpAddress?.ToString(), Request.Headers.UserAgent.ToString());
        SetCookie(res); return Ok(Body(res));   // the refresh token travels only in the HttpOnly cookie, never in the body
    }

    [AllowAnonymous, HttpPost("auth/refresh"), EnableRateLimiting("login")]
    public async Task<IActionResult> Refresh()
    {
        if (Request.Headers["X-Requested-With"] != "erp-web") throw new ValidationFailedException("header", "Missing X-Requested-With header.");   // CSRF guard for the cookie-based endpoint
        var raw = Request.Cookies[Cookie] ?? throw new UnauthorizedException("Session expired.");
        var res = await _auth.Refresh(raw, HttpContext.Connection.RemoteIpAddress?.ToString(), Request.Headers.UserAgent.ToString());
        SetCookie(res); return Ok(Body(res));
    }

    [AllowAnonymous, HttpPost("auth/logout")]
    public async Task<IActionResult> Logout()
    {
        if (Request.Headers["X-Requested-With"] != "erp-web") throw new ValidationFailedException("header", "Missing X-Requested-With header.");
        await _auth.Logout(Request.Cookies[Cookie]); Response.Cookies.Delete(Cookie, new CookieOptions { Path = "/api/v1/auth" }); return NoContent();
    }

    [AllowAnonymous, HttpPost("auth/forgot-password"), EnableRateLimiting("reset")]
    public async Task<IActionResult> Forgot([FromBody] ForgotRequest r) { await _auth.ForgotPassword(r.Email); return Accepted(new { message = "If that email is registered, a reset code has been sent." }); }

    [AllowAnonymous, HttpPost("auth/reset-password"), EnableRateLimiting("reset")]
    public async Task<IActionResult> Reset([FromBody] ResetRequest r) { await _auth.ResetPassword(r.Token, r.NewPassword); return NoContent(); }

    [HttpPost("auth/change-password")]
    public async Task<IActionResult> Change([FromBody] ChangePasswordRequest r) { await _auth.ChangePassword(_cu.Ctx.UserId, r.CurrentPassword, r.NewPassword); Response.Cookies.Delete(Cookie, new CookieOptions { Path = "/api/v1/auth" }); return NoContent(); }

    [HttpGet("me")]
    public async Task<IActionResult> Me() => Ok(await _auth.Profile(_cu.Ctx.UserId));
}

public sealed class MastersController : ApiBase
{
    readonly MasterRegistry _reg; readonly AdminService _admin;
    public MastersController(MasterRegistry reg, AdminService admin) { _reg = reg; _admin = admin; }
    const string M = "{master:regex(^(customers|suppliers|employees|workers|salesman-profiles|categories|metals|purities|units|stone-types|expense-heads|payment-methods|locations|cash-bank-accounts|chart-accounts)$)}";

    [HttpGet(M)] public async Task<IActionResult> List(string master, [FromQuery] PageQuery q, [FromQuery] bool? active) => Ok(await _reg.Get(master).List(q, active));
    [HttpGet(M + "/{id:long}")] public async Task<IActionResult> Get(string master, long id) => Ok(await _reg.Get(master).Get(id));
    [HttpPost(M)] public async Task<IActionResult> Create(string master, [FromBody] JsonElement body) => Ok(await _reg.Get(master).Save(null, body));
    [HttpPut(M + "/{id:long}")] public async Task<IActionResult> Update(string master, long id, [FromBody] JsonElement body) => Ok(await _reg.Get(master).Save(id, body));
    [HttpPost(M + "/{id:long}/active")] public async Task<IActionResult> Active(string master, long id, [FromQuery] bool value) { await _reg.Get(master).SetActive(id, value); return NoContent(); }
    [HttpGet("lookups/{master}")] public async Task<IActionResult> Lookups(string master, [FromQuery] string? search, [FromQuery] int take = 50) => Ok(await _reg.Get(master).Lookups(search, take));
    public sealed record ConversionRequest(decimal FactorToGram, string ApprovalNote);
    [HttpPost("units/{id:long}/conversion")] public async Task<IActionResult> Conversion(long id, [FromBody] ConversionRequest r) => Ok(await _admin.ApproveUnitConversion(id, r.FactorToGram, r.ApprovalNote));
}

public sealed class ProductsController : ApiBase
{
    readonly ProductService _p; readonly FileService _f; readonly GoldRateService _g;
    public ProductsController(ProductService p, FileService f, GoldRateService g) { _p = p; _f = f; _g = g; }
    [HttpGet("products")] public async Task<IActionResult> List([FromQuery] ProductQuery q) => Ok(await _p.List(q));
    [HttpGet("products/{id:long}")] public async Task<IActionResult> Get(long id) => Ok(await _p.Get(id));
    [HttpGet("lookups/products")] public async Task<IActionResult> ProductLookup([FromQuery] string? search, [FromQuery] int take = 50) { var r = await _p.List(new ProductQuery { Search = search, PageSize = Math.Clamp(take, 1, 200), Active = true }); return Ok(r.Items.Select(p => new { id = p.Id, name = $"{p.Sku} - {p.Name}", code = p.Sku, extra = p.Purity })); }
    [HttpGet("products/scan")] public async Task<IActionResult> Scan([FromQuery] string code, [FromQuery] long? branchId) => Ok(await _p.Scan(code, branchId));
    [HttpGet("products/{id:long}/label")] public async Task<IActionResult> Label(long id) => Ok(await _p.Label(id));
    [HttpPost("products")] public async Task<IActionResult> Create([FromBody] ProductInput i) => Ok(await _p.Save(null, i));
    [HttpPut("products/{id:long}")] public async Task<IActionResult> Update(long id, [FromBody] ProductInput i) => Ok(await _p.Save(id, i));
    [HttpGet("product-gallery")] public async Task<IActionResult> Gallery([FromQuery] ProductQuery q) => Ok(await _p.Gallery(q));

    [HttpGet("gold-rates/current")] public async Task<IActionResult> Current([FromQuery] long? branchId) => Ok(await _g.Current(branchId));
    [HttpGet("gold-rates")] public async Task<IActionResult> Rates([FromQuery] long? branchId) => Ok(await _g.Current(branchId));
    [HttpPost("gold-rates")] public async Task<IActionResult> SetRates([FromBody] GoldRateInput i) => Ok(await _g.Set(i));
    [HttpGet("gold-rates/history")] public async Task<IActionResult> History([FromQuery] PageQuery q, [FromQuery] long? metalTypeId, [FromQuery] long? purityId, [FromQuery] long? branchId, [FromQuery] DateTime? from, [FromQuery] DateTime? to) => Ok(await _g.History(q, metalTypeId, purityId, branchId, from, to));
}

public sealed class UploadForm { public IFormFile File { get; set; } = default!; public FileKind Kind { get; set; } = FileKind.General; public string? Caption { get; set; } public bool MakePrimary { get; set; } }
public sealed record OrderRequest(List<long> Ids);
public sealed record ReasonRequest(string? Reason);

public sealed class FilesController : ApiBase
{
    readonly FileService _f;
    public FilesController(FileService f) { _f = f; }

    async Task<IActionResult> Up(FileOwnerType t, long id, UploadForm f)
    {
        if (f.File == null || f.File.Length == 0) throw new ValidationFailedException("file", "Choose an image to upload.");
        await using var s = f.File.OpenReadStream();
        return Ok(await _f.Upload(t, id, f.Kind, s, f.File.FileName, f.Caption, f.MakePrimary));
    }
    [HttpPost("files/{ownerType}/{ownerId:long}"), Consumes("multipart/form-data"), RequestSizeLimit(12 * 1024 * 1024), EnableRateLimiting("upload")] public Task<IActionResult> Upload(FileOwnerType ownerType, long ownerId, [FromForm] UploadForm f) => Up(ownerType, ownerId, f);
    [HttpPost("products/{id:long}/images"), Consumes("multipart/form-data"), RequestSizeLimit(12 * 1024 * 1024), EnableRateLimiting("upload")] public Task<IActionResult> ProductImage(long id, [FromForm] UploadForm f) => Up(FileOwnerType.Product, id, f);
    [HttpPost("repairs/{id:long}/images"), Consumes("multipart/form-data"), RequestSizeLimit(12 * 1024 * 1024), EnableRateLimiting("upload")] public Task<IActionResult> RepairImage(long id, [FromForm] UploadForm f) => Up(FileOwnerType.RepairTicket, id, f);
    [HttpPost("job-cards/{id:long}/images"), Consumes("multipart/form-data"), RequestSizeLimit(12 * 1024 * 1024), EnableRateLimiting("upload")] public Task<IActionResult> JobImage(long id, [FromForm] UploadForm f) => Up(FileOwnerType.JobCard, id, f);

    [HttpGet("files/{ownerType}/{ownerId:long}")] public async Task<IActionResult> List(FileOwnerType ownerType, long ownerId, [FromQuery] FileKind? kind) => Ok(await _f.List(ownerType, ownerId, kind));
    [HttpGet("products/{id:long}/images")] public async Task<IActionResult> ProductImages(long id) => Ok(await _f.List(FileOwnerType.Product, id));
    [HttpGet("repairs/{id:long}/images")] public async Task<IActionResult> RepairImages(long id, [FromQuery] FileKind? kind) => Ok(await _f.List(FileOwnerType.RepairTicket, id, kind));
    [HttpGet("job-cards/{id:long}/images")] public async Task<IActionResult> JobImages(long id) => Ok(await _f.List(FileOwnerType.JobCard, id));

    [HttpGet("files/{id:long}")]
    public async Task<IActionResult> Download(long id, [FromQuery] bool download = false)
    {
        var (stream, mime, name) = await _f.Open(id, download);
        var safe = new string(name.Where(c => char.IsLetterOrDigit(c) || c is '.' or '-' or '_').ToArray()); if (safe.Length == 0) safe = "file";
        Response.Headers["Cache-Control"] = "private, no-store"; Response.Headers["Content-Security-Policy"] = "default-src 'none'; img-src 'self'; sandbox";
        Response.Headers["Content-Disposition"] = $"{(download ? "attachment" : "inline")}; filename=\"{safe}\"";
        return File(stream, mime);
    }
    [HttpPost("files/{id:long}/primary")] public async Task<IActionResult> Primary(long id) { await _f.SetPrimary(id); return NoContent(); }
    [HttpPut("files/{ownerType}/{ownerId:long}/order")] public async Task<IActionResult> Order(FileOwnerType ownerType, long ownerId, [FromBody] OrderRequest r) { await _f.Reorder(ownerType, ownerId, r.Ids); return NoContent(); }
    [HttpDelete("files/{id:long}")] public async Task<IActionResult> Remove(long id, [FromQuery] string? reason) { await _f.Remove(id, reason); return NoContent(); }
    [HttpDelete("products/{id:long}/images/{imageId:long}")] public async Task<IActionResult> RemoveProductImage(long id, long imageId, [FromQuery] string? reason) { await _f.Remove(imageId, reason); return NoContent(); }
}
