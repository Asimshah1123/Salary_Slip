using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading.RateLimiting;
using Erp.Api.Infrastructure;
using Erp.Infrastructure;
using Erp.Infrastructure.Data;
using Erp.Infrastructure.Files;
using Erp.Infrastructure.Services;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.RateLimiting;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;

var builder = WebApplication.CreateBuilder(args);
var cfg = builder.Configuration; var isDev = builder.Environment.IsDevelopment();

// ---- secrets: never in source control. Development may use an ephemeral key; every other environment must supply one ----
var jwtKey = cfg["Jwt:Key"];
if (string.IsNullOrWhiteSpace(jwtKey))
{
    if (!isDev) throw new InvalidOperationException("Jwt:Key is required (base64, >= 32 bytes). Provide it via environment variable Jwt__Key or a secret store.");
    jwtKey = Convert.ToBase64String(System.Security.Cryptography.RandomNumberGenerator.GetBytes(48));
    Console.WriteLine("WARNING: using an ephemeral development JWT key - sessions end when the API restarts.");
}
if (Convert.FromBase64String(jwtKey).Length < 32) throw new InvalidOperationException("Jwt:Key must be at least 32 bytes.");
var conn = cfg.GetConnectionString("Default");
if (string.IsNullOrWhiteSpace(conn)) throw new InvalidOperationException("ConnectionStrings:Default is required.");

builder.Services.Configure<JwtOptions>(o => { cfg.GetSection("Jwt").Bind(o); o.Key = jwtKey; });
builder.Services.Configure<StorageOptions>(cfg.GetSection("Storage"));

builder.Services.AddDbContext<ErpDbContext>(o => o.UseSqlServer(conn).ConfigureWarnings(w => w.Ignore(CoreEventId.PossibleIncorrectRequiredNavigationWithQueryFilterInteractionWarning)));
builder.Services.AddMemoryCache(); builder.Services.AddHttpContextAccessor();
builder.Services.AddScoped<DbScope>(); builder.Services.AddScoped<CurrentUser>(); builder.Services.AddSingleton<IClock, SystemClock>();
builder.Services.AddSingleton<IFileStorage, LocalFileStorage>();
if (cfg.GetValue<bool>("Storage:ClamAvEnabled")) builder.Services.AddSingleton<IMalwareScanner, ClamAvScanner>(); else builder.Services.AddSingleton<IMalwareScanner, BasicMalwareScanner>();
builder.Services.AddSingleton<IEmailSender, LoggingEmailSender>();
foreach (var t in new[] { typeof(UserAccessLoader), typeof(AuthService), typeof(SettingsService), typeof(AuditService), typeof(NumberingService), typeof(RateService), typeof(ApprovalService), typeof(PostingEngine), typeof(AccessGuard), typeof(MasterRegistry),
    typeof(GoldRateService), typeof(ProductService), typeof(FileService), typeof(SalesService), typeof(PurchaseService), typeof(InventoryService), typeof(JobWorkService), typeof(RepairService), typeof(FinanceService), typeof(ReportService), typeof(AdminService), typeof(BackupService) })
    builder.Services.AddScoped(t);

builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme).AddJwtBearer(JwtBearerDefaults.AuthenticationScheme, o =>
{
    o.MapInboundClaims = false; o.RequireHttpsMetadata = !isDev;
    o.TokenValidationParameters = new TokenValidationParameters
    {
        ValidateIssuer = true, ValidIssuer = cfg["Jwt:Issuer"] ?? "jewellery-erp", ValidateAudience = true, ValidAudience = cfg["Jwt:Audience"] ?? "jewellery-erp-web",
        ValidateLifetime = true, ClockSkew = TimeSpan.FromSeconds(30), ValidateIssuerSigningKey = true, IssuerSigningKey = new SymmetricSecurityKey(Convert.FromBase64String(jwtKey))
    };
});
builder.Services.AddAuthorization(o => o.FallbackPolicy = new Microsoft.AspNetCore.Authorization.AuthorizationPolicyBuilder().RequireAuthenticatedUser().Build());   // everything needs a user unless [AllowAnonymous]

builder.Services.AddControllers().AddJsonOptions(o =>
{
    o.JsonSerializerOptions.Converters.Add(new JsonStringEnumConverter());
    o.JsonSerializerOptions.DefaultIgnoreCondition = JsonIgnoreCondition.Never; o.JsonSerializerOptions.PropertyNamingPolicy = JsonNamingPolicy.CamelCase;
}).ConfigureApiBehaviorOptions(o => o.InvalidModelStateResponseFactory = ctx =>
    new Microsoft.AspNetCore.Mvc.BadRequestObjectResult(new { title = "One or more validation errors occurred.", code = "validation", status = 400, errors = ctx.ModelState.Where(e => e.Value!.Errors.Count > 0).ToDictionary(e => e.Key, e => e.Value!.Errors.Select(x => x.ErrorMessage).ToArray()), correlationId = ctx.HttpContext.Items[CorrelationMiddleware.Header] }));

builder.Services.AddCors(o => o.AddDefaultPolicy(p => p.WithOrigins(cfg.GetSection("Cors:Origins").Get<string[]>() ?? Array.Empty<string>()).WithHeaders("Authorization", "Content-Type", "X-Branch-Id", "Idempotency-Key", "X-Correlation-Id", "X-Requested-With").WithMethods("GET", "POST", "PUT", "PATCH", "DELETE").AllowCredentials().WithExposedHeaders("X-Correlation-Id", "Content-Disposition")));

builder.Services.AddRateLimiter(o =>
{
    o.RejectionStatusCode = 429;
    static string Ip(HttpContext c) => c.Connection.RemoteIpAddress?.ToString() ?? "unknown";
    o.AddPolicy("login", c => RateLimitPartition.GetFixedWindowLimiter(Ip(c), _ => new FixedWindowRateLimiterOptions { PermitLimit = 10, Window = TimeSpan.FromMinutes(1), QueueLimit = 0 }));
    o.AddPolicy("reset", c => RateLimitPartition.GetFixedWindowLimiter(Ip(c), _ => new FixedWindowRateLimiterOptions { PermitLimit = 5, Window = TimeSpan.FromMinutes(10), QueueLimit = 0 }));
    o.AddPolicy("upload", c => RateLimitPartition.GetFixedWindowLimiter(c.User.FindFirst("sub")?.Value ?? Ip(c), _ => new FixedWindowRateLimiterOptions { PermitLimit = 60, Window = TimeSpan.FromMinutes(1), QueueLimit = 0 }));
    o.GlobalLimiter = PartitionedRateLimiter.Create<HttpContext, string>(c => RateLimitPartition.GetFixedWindowLimiter(c.User.FindFirst("sub")?.Value ?? Ip(c), _ => new FixedWindowRateLimiterOptions { PermitLimit = 600, Window = TimeSpan.FromMinutes(1), QueueLimit = 0 }));
});
builder.Services.AddHealthChecks().AddCheck<DbHealthCheck>("database");
builder.Services.AddOpenApi();
builder.Services.Configure<Microsoft.AspNetCore.Http.Features.FormOptions>(o => o.MultipartBodyLengthLimit = 12 * 1024 * 1024);

var app = builder.Build();
if (!isDev) { app.UseHsts(); app.UseHttpsRedirection(); }
app.UseMiddleware<CorrelationMiddleware>();
app.UseMiddleware<SecurityHeadersMiddleware>();
app.UseMiddleware<ErrorMiddleware>();
app.UseCors();
app.UseRateLimiter();
app.UseAuthentication();
app.UseMiddleware<UserContextMiddleware>();
app.UseAuthorization();
app.MapControllers();
app.MapHealthChecks("/health/live", new Microsoft.AspNetCore.Diagnostics.HealthChecks.HealthCheckOptions { Predicate = _ => false }).AllowAnonymous();
app.MapHealthChecks("/health/ready").AllowAnonymous();
if (isDev) app.MapOpenApi().AllowAnonymous();

// ---- diagnostics (no database needed): dotnet run -- --verify-di | --list-routes ----
if (args.Contains("--verify-di"))
{
    using var s = app.Services.CreateScope(); var bad = 0;
    foreach (var t in typeof(Program).Assembly.GetTypes().Where(t => typeof(Microsoft.AspNetCore.Mvc.ControllerBase).IsAssignableFrom(t) && !t.IsAbstract))
        try { Microsoft.Extensions.DependencyInjection.ActivatorUtilities.CreateInstance(s.ServiceProvider, t); Console.WriteLine("  ok   " + t.Name); }
        catch (Exception e) { bad++; Console.WriteLine("  FAIL " + t.Name + ": " + e.Message); }
    Console.WriteLine(bad == 0 ? "All controllers resolve." : bad + " controller(s) cannot be constructed."); return bad == 0 ? 0 : 1;
}
if (args.Contains("--list-routes"))
{
    foreach (var e in ((Microsoft.AspNetCore.Routing.IEndpointRouteBuilder)app).DataSources.SelectMany(d => d.Endpoints).OfType<Microsoft.AspNetCore.Routing.RouteEndpoint>().OrderBy(e => e.RoutePattern.RawText))
        Console.WriteLine($"{string.Join(",", e.Metadata.OfType<Microsoft.AspNetCore.Routing.HttpMethodMetadata>().FirstOrDefault()?.HttpMethods ?? new[] { "*" }),-7} /{e.RoutePattern.RawText}");
    return 0;
}
if (cfg.GetValue("Seed:Enabled", true)) await DbSeeder.RunAsync(app.Services, cfg, isDev, app.Logger);
app.Run();
return 0;
