using System.Security.Claims;
using System.Text.Json;
using Erp.Domain;
using Erp.Infrastructure;
using Erp.Infrastructure.Data;
using Erp.Infrastructure.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.EntityFrameworkCore;

namespace Erp.Api.Infrastructure;

/// <summary>Correlation id on every request/response and in every log line (SRS 9.1, 12).</summary>
public sealed class CorrelationMiddleware
{
    public const string Header = "X-Correlation-Id";
    readonly RequestDelegate _next; readonly ILogger<CorrelationMiddleware> _log;
    public CorrelationMiddleware(RequestDelegate next, ILogger<CorrelationMiddleware> log) { _next = next; _log = log; }
    public async Task Invoke(HttpContext ctx)
    {
        var id = ctx.Request.Headers[Header].FirstOrDefault();
        if (string.IsNullOrWhiteSpace(id) || id.Length > 64 || !id.All(c => char.IsLetterOrDigit(c) || c == '-')) id = Guid.NewGuid().ToString("N");
        ctx.Items[Header] = id; ctx.Response.Headers[Header] = id;
        using (_log.BeginScope(new Dictionary<string, object> { ["CorrelationId"] = id })) await _next(ctx);
    }
}

public sealed class SecurityHeadersMiddleware
{
    readonly RequestDelegate _next;
    public SecurityHeadersMiddleware(RequestDelegate next) { _next = next; }
    public Task Invoke(HttpContext ctx)
    {
        var h = ctx.Response.Headers;
        h["X-Content-Type-Options"] = "nosniff"; h["X-Frame-Options"] = "DENY"; h["Referrer-Policy"] = "no-referrer";
        h["Content-Security-Policy"] = "default-src 'none'; frame-ancestors 'none'";   // the API serves data only, never HTML
        h["Cache-Control"] = "no-store";
        return _next(ctx);
    }
}

/// <summary>
/// Resolves the signed-in user's roles, permissions and branch grants from the database on EVERY request (short server cache),
/// rejects tokens whose security stamp no longer matches, and validates the requested active branch (SRS 18.4, 21.2).
/// </summary>
public sealed class UserContextMiddleware
{
    readonly RequestDelegate _next;
    public UserContextMiddleware(RequestDelegate next) { _next = next; }

    public async Task Invoke(HttpContext http, UserAccessLoader loader, CurrentUser current, DbScope scope, IServiceProvider sp)
    {
        if (http.User.Identity?.IsAuthenticated == true)
        {
            long.TryParse(http.User.FindFirstValue("sub"), out var uid);
            var stamp = http.User.FindFirstValue("stamp");
            var ctx = uid == 0 ? null : await loader.Load(uid);
            if (ctx == null || ctx.Stamp != stamp)
            {
                http.Response.StatusCode = StatusCodes.Status401Unauthorized;
                await http.Response.WriteAsJsonAsync(new { title = "Session is no longer valid. Please sign in again.", code = "session_invalid", correlationId = http.Items[CorrelationMiddleware.Header] });
                return;
            }
            ctx.Ip = http.Connection.RemoteIpAddress?.ToString(); ctx.CorrelationId = http.Items[CorrelationMiddleware.Header] as string;
            var hdr = http.Request.Headers["X-Branch-Id"].FirstOrDefault();
            if (!string.IsNullOrWhiteSpace(hdr))
            {
                if (hdr.Equals("all", StringComparison.OrdinalIgnoreCase)) { if (!ctx.CanSeeAllBranches) { await Deny(http, sp, ctx, "All-branch view requires Branches.ViewAll or Reports.Consolidated.View.", null); return; } ctx.AllBranchesSelected = true; }
                else if (long.TryParse(hdr, out var bid) && ctx.BranchIds.Contains(bid)) ctx.ActiveBranchId = bid;
                else { long.TryParse(hdr, out var asked); await Deny(http, sp, ctx, "You are not assigned to that branch.", asked == 0 ? null : asked); return; }   // never trust the client's branch
            }
            ctx.ActiveBranchId ??= ctx.DefaultBranchId;
            current.Set(ctx);
            scope.CompanyId = ctx.CompanyId; scope.UserId = ctx.UserId; scope.AllowedBranchIds = ctx.BranchIds.ToArray();
        }
        await _next(http);
    }

    static async Task Deny(HttpContext http, IServiceProvider sp, UserContext ctx, string msg, long? target)
    {
        await ErrorMiddleware.AuditDenied(sp, ctx, "Branch.AccessDenied", msg, target);
        http.Response.StatusCode = StatusCodes.Status403Forbidden;
        await http.Response.WriteAsJsonAsync(new { title = msg, code = "branch_forbidden", correlationId = http.Items[CorrelationMiddleware.Header] });
    }
}

/// <summary>Maps exceptions to a consistent error shape with the correlation id; never leaks internals on 500.</summary>
public sealed class ErrorMiddleware
{
    readonly RequestDelegate _next; readonly ILogger<ErrorMiddleware> _log; readonly IServiceProvider _sp;
    public ErrorMiddleware(RequestDelegate next, ILogger<ErrorMiddleware> log, IServiceProvider sp) { _next = next; _log = log; _sp = sp; }

    public async Task Invoke(HttpContext http)
    {
        try { await _next(http); }
        catch (Exception ex) when (!http.Response.HasStarted)
        {
            var cid = http.Items[CorrelationMiddleware.Header] as string;
            var current = http.RequestServices.GetService<CurrentUser>();
            int status; string code, title; object? errors = null;
            switch (ex)
            {
                case ValidationFailedException v: status = 400; code = v.Code; title = v.Message; errors = v.Errors; break;
                case DomainException d: status = 422; code = d.Code; title = d.Message; break;
                case NotFoundException n: status = 404; code = n.Code; title = n.Message; break;
                case ForbiddenException f:
                    status = 403; code = f.Code; title = f.Message;
                    if (current?.Value != null) await AuditDenied(_sp, current.Value, "Access.Denied", f.Message, f.Target as long?);
                    break;
                case UnauthorizedException u: status = 401; code = u.Code; title = u.Message; break;
                case ConflictException c: status = 409; code = c.Code; title = c.Message; break;
                case DbUpdateConcurrencyException: status = 409; code = "concurrency"; title = "Another user changed this record at the same time. Reload and try again."; break;
                case JsonException or BadHttpRequestException: status = 400; code = "bad_request"; title = "The request could not be read."; break;
                default: status = 500; code = "server_error"; title = "Something went wrong. Quote the correlation id to support."; _log.LogError(ex, "Unhandled exception {CorrelationId}", cid); break;
            }
            // do NOT call Response.Clear(): it would also wipe the security headers and X-Correlation-Id set earlier in the pipeline
            http.Response.StatusCode = status; http.Response.ContentType = "application/json";
            await http.Response.WriteAsJsonAsync(new { title, code, status, errors, correlationId = cid });
        }
    }

    /// <summary>Written on a FRESH scope/context so a failed unit of work can never half-save while recording the denial.</summary>
    public static async Task AuditDenied(IServiceProvider sp, UserContext user, string action, string reason, long? targetBranch)
    {
        try
        {
            using var s = sp.CreateScope();
            var scope = s.ServiceProvider.GetRequiredService<DbScope>(); scope.CompanyId = user.CompanyId; scope.UserId = user.UserId; scope.AllowedBranchIds = user.BranchIds.ToArray();
            s.ServiceProvider.GetRequiredService<CurrentUser>().Set(user);
            await s.ServiceProvider.GetRequiredService<AuditService>().Save(action, "Security", user.UserId, reason: reason, targetBranchId: targetBranch, denied: true);
        }
        catch { /* auditing must never turn a denial into a 500 */ }
    }
}

/// <summary>Defence in depth: the action-level permission check (services also enforce it). Hiding a button in Angular is never the control.</summary>
[AttributeUsage(AttributeTargets.Class | AttributeTargets.Method, AllowMultiple = true)]
public sealed class RequirePermissionAttribute : Attribute, IAsyncAuthorizationFilter
{
    readonly string[] _any;
    public RequirePermissionAttribute(params string[] anyOf) { _any = anyOf; }
    public Task OnAuthorizationAsync(AuthorizationFilterContext c)
    {
        var cu = c.HttpContext.RequestServices.GetRequiredService<CurrentUser>();
        if (cu.Value == null) { c.Result = new UnauthorizedResult(); return Task.CompletedTask; }
        if (!_any.Any(cu.Value.Has)) throw new ForbiddenException("Missing permission " + string.Join(" or ", _any) + ".", _any[0]);
        return Task.CompletedTask;
    }
}

public sealed class DbHealthCheck : Microsoft.Extensions.Diagnostics.HealthChecks.IHealthCheck
{
    readonly IServiceProvider _sp;
    public DbHealthCheck(IServiceProvider sp) { _sp = sp; }
    public async Task<Microsoft.Extensions.Diagnostics.HealthChecks.HealthCheckResult> CheckHealthAsync(Microsoft.Extensions.Diagnostics.HealthChecks.HealthCheckContext context, CancellationToken ct = default)
    {
        using var s = _sp.CreateScope(); var db = s.ServiceProvider.GetRequiredService<ErpDbContext>();
        return await db.Database.CanConnectAsync(ct) ? Microsoft.Extensions.Diagnostics.HealthChecks.HealthCheckResult.Healthy() : Microsoft.Extensions.Diagnostics.HealthChecks.HealthCheckResult.Unhealthy("database unreachable");
    }
}
