namespace Erp.Domain.Calc;

/// <summary>decimal only - never float/double for money or weights (SRS 6.5, 8.1).</summary>
public static class Money
{
    public static decimal R2(decimal v) => Math.Round(v, 2, MidpointRounding.AwayFromZero);
    public static decimal R3(decimal v) => Math.Round(v, 3, MidpointRounding.AwayFromZero);
    public static decimal RoundTo(decimal v, decimal step) => step <= 0 ? R2(v) : Math.Round(v / step, 0, MidpointRounding.AwayFromZero) * step;
    public static bool Balanced(decimal debit, decimal credit) => R2(debit) == R2(credit);
}

public static class WeightCalc
{
    /// <summary>NetMetalWeight = Gross - Stone - other configured non-metal deductions.</summary>
    public static decimal NetMetal(decimal gross, decimal stone, decimal otherDeduction = 0m)
    {
        if (gross < 0 || stone < 0 || otherDeduction < 0) throw new DomainException("Weights cannot be negative.", "weight_negative");
        var net = gross - stone - otherDeduction;
        if (net < 0) throw new DomainException("Stone and other deductions exceed the gross weight.", "weight_deduction_exceeds_gross");
        return Money.R3(net);
    }

    /// <summary>FineGoldEquivalent = NetMetalWeight x PurityFactor (internal reconciliation only).</summary>
    public static decimal Fine(decimal netMetal, decimal purityFactor)
    {
        if (purityFactor <= 0 || purityFactor > 1) throw new DomainException("Purity factor must be between 0 and 1.", "purity_factor_invalid");
        return Money.R3(netMetal * purityFactor);
    }

    /// <summary>Conventional karat factor (e.g. 22K = 22/24). Only a default suggestion: the Purity master is the authority.</summary>
    public static decimal KaratFactor(decimal karat) => karat <= 0 || karat > 24 ? throw new DomainException("Karat must be 0-24.") : Math.Round(karat / 24m, 6);

    /// <summary>Unit conversion refuses units whose factor has not been approved in writing (SRS 2.1 - no hard-coded ratti).</summary>
    public static decimal ToGrams(decimal value, decimal? factorToGram, bool approved, string unitName)
    {
        if (!approved || factorToGram is null || factorToGram <= 0)
            throw new DomainException($"Unit '{unitName}' has no approved conversion to grams. Approve it in Settings > Units first.", "unit_not_approved");
        return Money.R3(value * factorToGram.Value);
    }
}
