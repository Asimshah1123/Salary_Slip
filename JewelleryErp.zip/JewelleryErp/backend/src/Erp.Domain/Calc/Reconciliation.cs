namespace Erp.Domain.Calc;

public record ReconInput(decimal IssuedFine, decimal AdditionalInputFine, decimal OutputFine, decimal ReturnedFine, decimal ScrapFine,
                         decimal ApprovedLossFine, decimal ToleranceFine, decimal WastageAllowancePercent);

public record ReconResult(decimal TotalInput, decimal Accounted, decimal Variance, decimal AllowedWastage, decimal ExcessLoss, decimal UnexpectedGain,
                          bool WithinTolerance, bool RequiresApproval, string Summary);

/// <summary>
/// SRS 6.5 - everything in fine (purity-adjusted) grams:
/// Variance = Issued + ApprovedAdditionalInput - (Output + Returned + Scrap + ApprovedLoss).
/// Positive variance = unaccounted loss, negative = unexpected weight gain. No silent auto write-off.
/// </summary>
public static class Reconciliation
{
    public static ReconResult Calculate(ReconInput r)
    {
        foreach (var v in new[] { r.IssuedFine, r.AdditionalInputFine, r.OutputFine, r.ReturnedFine, r.ScrapFine, r.ApprovedLossFine, r.ToleranceFine })
            if (v < 0) throw new DomainException("Reconciliation weights cannot be negative.", "recon_negative");
        var input = Money.R3(r.IssuedFine + r.AdditionalInputFine);
        var accounted = Money.R3(r.OutputFine + r.ReturnedFine + r.ScrapFine + r.ApprovedLossFine);
        var variance = Money.R3(input - accounted);
        var allowed = Money.R3(input * r.WastageAllowancePercent / 100m);   // wastage allowance is separate from physical loss
        var excessLoss = variance > 0 ? Math.Max(0, Money.R3(variance - allowed)) : 0m;
        var gain = variance < 0 ? Money.R3(-variance) : 0m;
        var within = variance >= 0 ? excessLoss <= r.ToleranceFine : gain <= r.ToleranceFine;
        var summary = variance == 0 ? "Balanced" : variance > 0
            ? (within ? $"Loss {variance}g within allowance/tolerance" : $"Excess loss {excessLoss}g beyond allowance + tolerance")
            : (within ? $"Gain {gain}g within tolerance" : $"Unexpected gain {gain}g beyond tolerance");
        return new ReconResult(input, accounted, variance, allowed, excessLoss, gain, within, !within, summary);
    }
}

public record OldGoldInput(decimal Gross, decimal Stone, decimal OtherDeduction, decimal MeltingDeduction, decimal PurityFactor, decimal AcceptedRate, string Method = "ByPurityRate", decimal? FineBaseRate = null);
public record OldGoldResult(decimal Net, decimal Fine, decimal Value, decimal DeductionPercent);

public static class OldGold
{
    /// <summary>SRS 2.4. Method ByPurityRate = net x accepted rate for the tested purity; ByFineEquivalent = fine x base (24K) rate. Shop documents which one it uses.</summary>
    public static OldGoldResult Value(OldGoldInput i)
    {
        var netBeforeMelt = WeightCalc.NetMetal(i.Gross, i.Stone, i.OtherDeduction);
        if (i.MeltingDeduction < 0 || i.MeltingDeduction > netBeforeMelt) throw new DomainException("Melting/testing deduction is invalid.", "melting_invalid");
        var net = Money.R3(netBeforeMelt - i.MeltingDeduction);
        var fine = WeightCalc.Fine(net, i.PurityFactor);
        decimal value = i.Method switch
        {
            "ByFineEquivalent" => Money.R2(fine * (i.FineBaseRate ?? throw new DomainException("A base fine rate is required for fine-equivalent valuation."))),
            _ => Money.R2(net * i.AcceptedRate)
        };
        var pct = netBeforeMelt == 0 ? 0 : Math.Round(i.MeltingDeduction / netBeforeMelt * 100m, 3);
        return new OldGoldResult(net, fine, value, pct);
    }
}

public static class CommissionCalc
{
    /// <summary>Fixed = per eligible invoice; Percent = % of eligible amount; None/Manual = 0 until manually approved.</summary>
    public static decimal Calculate(CommissionType type, decimal value, decimal eligibleAmount) => eligibleAmount <= 0 ? 0m : type switch
    {
        CommissionType.Percent or CommissionType.CategoryBased => Money.R2(eligibleAmount * value / 100m),
        CommissionType.Fixed => Money.R2(value),
        _ => 0m
    };

    /// <summary>Commission reversed on a return, proportional to the returned share of the original eligible amount.</summary>
    public static decimal ReverseShare(decimal originalCommission, decimal originalEligible, decimal returnedAmount) =>
        originalEligible <= 0 ? 0m : Money.R2(originalCommission * Math.Min(1m, returnedAmount / originalEligible));
}
