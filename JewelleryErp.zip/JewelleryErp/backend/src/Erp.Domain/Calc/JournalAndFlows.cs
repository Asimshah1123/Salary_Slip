namespace Erp.Domain.Calc;

public record JLine(string? AccountCode, long? AccountId, decimal Debit, decimal Credit, PartyType? PartyType = null, long? PartyId = null, string? Memo = null);

/// <summary>Collects journal lines and refuses to post an unbalanced entry (SRS 3.12).</summary>
public class JournalBuilder
{
    readonly List<JLine> _lines = new();
    public IReadOnlyList<JLine> Lines => _lines;
    public decimal TotalDebit => Money.R2(_lines.Sum(l => l.Debit));
    public decimal TotalCredit => Money.R2(_lines.Sum(l => l.Credit));

    public JournalBuilder Dr(string code, decimal amount, string? memo = null, PartyType? pt = null, long? pid = null) => Add(code, null, amount, 0, memo, pt, pid);
    public JournalBuilder Cr(string code, decimal amount, string? memo = null, PartyType? pt = null, long? pid = null) => Add(code, null, 0, amount, memo, pt, pid);
    public JournalBuilder DrAcc(long accountId, decimal amount, string? memo = null) => Add(null, accountId, amount, 0, memo, null, null);
    public JournalBuilder CrAcc(long accountId, decimal amount, string? memo = null) => Add(null, accountId, 0, amount, memo, null, null);

    JournalBuilder Add(string? code, long? id, decimal dr, decimal cr, string? memo, PartyType? pt, long? pid)
    {
        if (dr < 0 || cr < 0) throw new DomainException("Journal amounts must be positive; use the opposite side instead.", "journal_negative");
        if (dr == 0 && cr == 0) return this;
        _lines.Add(new JLine(code, id, Money.R2(dr), Money.R2(cr), pt, pid, memo));
        return this;
    }

    public void AssertBalanced()
    {
        if (_lines.Count == 0) throw new DomainException("Journal has no lines.", "journal_empty");
        if (!Money.Balanced(TotalDebit, TotalCredit))
            throw new DomainException($"Journal is not balanced (Dr {TotalDebit} vs Cr {TotalCredit}).", "journal_unbalanced");
    }

    /// <summary>Mirror image for reversal entries.</summary>
    public JournalBuilder Reversed()
    {
        var b = new JournalBuilder();
        foreach (var l in _lines) b._lines.Add(l with { Debit = l.Credit, Credit = l.Debit });
        return b;
    }
}

public static class JobFlow
{
    static readonly Dictionary<JobStatus, JobStatus[]> Map = new()
    {
        [JobStatus.Draft] = new[] { JobStatus.Approved, JobStatus.Cancelled },
        [JobStatus.Approved] = new[] { JobStatus.MaterialIssued, JobStatus.InProgress, JobStatus.Cancelled },
        [JobStatus.MaterialIssued] = new[] { JobStatus.MaterialIssued, JobStatus.InProgress, JobStatus.PartiallyReceived, JobStatus.Completed },
        [JobStatus.InProgress] = new[] { JobStatus.PartiallyReceived, JobStatus.Completed },
        [JobStatus.PartiallyReceived] = new[] { JobStatus.PartiallyReceived, JobStatus.Completed },
        [JobStatus.Completed] = new[] { JobStatus.Reconciled },
        [JobStatus.Reconciled] = new[] { JobStatus.Closed },
        [JobStatus.Closed] = Array.Empty<JobStatus>(),
        [JobStatus.Cancelled] = Array.Empty<JobStatus>(),
    };

    public static bool CanTransition(JobStatus from, JobStatus to, StockPostingMode mode)
    {
        if (to == JobStatus.MaterialIssued && mode == StockPostingMode.OnReceiptOnly) return false; // planning-only cards never issue stock
        return Map[from].Contains(to);
    }

    public static void Require(JobStatus from, JobStatus to, StockPostingMode mode)
    {
        if (!CanTransition(from, to, mode)) throw new DomainException($"Job card cannot move from {from} to {to} in {mode} mode.", "job_transition");
    }
}

public static class RepairFlow
{
    static readonly Dictionary<RepairStatus, RepairStatus[]> Map = new()
    {
        [RepairStatus.Received] = new[] { RepairStatus.Inspection, RepairStatus.Cancelled },
        [RepairStatus.Inspection] = new[] { RepairStatus.EstimatePrepared, RepairStatus.Unrepairable, RepairStatus.Rejected },
        [RepairStatus.EstimatePrepared] = new[] { RepairStatus.AwaitingApproval, RepairStatus.Approved, RepairStatus.Cancelled },
        [RepairStatus.AwaitingApproval] = new[] { RepairStatus.Approved, RepairStatus.Rejected, RepairStatus.EstimatePrepared },
        [RepairStatus.Approved] = new[] { RepairStatus.InRepair, RepairStatus.Cancelled },
        [RepairStatus.InRepair] = new[] { RepairStatus.QualityCheck, RepairStatus.Unrepairable },
        [RepairStatus.QualityCheck] = new[] { RepairStatus.Ready, RepairStatus.InRepair },
        [RepairStatus.Ready] = new[] { RepairStatus.Delivered },
        [RepairStatus.Delivered] = Array.Empty<RepairStatus>(),
        [RepairStatus.Rejected] = new[] { RepairStatus.Delivered },       // item returned unrepaired
        [RepairStatus.Cancelled] = new[] { RepairStatus.Delivered },
        [RepairStatus.Unrepairable] = new[] { RepairStatus.Delivered },
    };

    public static bool CanTransition(RepairStatus from, RepairStatus to, bool approvalRequired)
    {
        // when policy does not require customer approval an estimate may go straight to work
        if (from == RepairStatus.EstimatePrepared && to == RepairStatus.AwaitingApproval && !approvalRequired) return false;
        if (from == RepairStatus.EstimatePrepared && to == RepairStatus.Approved && approvalRequired) return false;
        return Map[from].Contains(to);
    }

    public static void Require(RepairStatus from, RepairStatus to, bool approvalRequired)
    {
        if (!CanTransition(from, to, approvalRequired)) throw new DomainException($"Repair cannot move from {from} to {to}.", "repair_transition");
    }
}

public static class TransferFlow
{
    public static void RequireDispatch(TransferStatus s) { if (s != TransferStatus.Draft) throw new DomainException("Only draft transfers can be dispatched.", "transfer_state"); }
    public static void RequireReceive(TransferStatus s) { if (s != TransferStatus.InTransit && s != TransferStatus.PartiallyReceived) throw new DomainException("Only in-transit transfers can be received.", "transfer_state"); }
}

public static class DocNumber
{
    /// <summary>e.g. INV-LHR-26-000123. Branch-scoped numbering embeds the branch prefix.</summary>
    public static string Format(string prefix, string? branchPrefix, int year, long n, int pad = 6) =>
        string.Join("-", new[] { prefix, branchPrefix, (year % 100).ToString("00"), n.ToString().PadLeft(pad, '0') }.Where(x => !string.IsNullOrWhiteSpace(x)));
}

public static class Aging
{
    public static string Bucket(int days) => days <= 30 ? "0-30" : days <= 60 ? "31-60" : days <= 90 ? "61-90" : "90+";
}
