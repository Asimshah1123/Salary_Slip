namespace Erp.Domain.Calc;

public record PricingInput(
    PricingMode Mode, decimal Quantity, decimal NetWeight, decimal RatePerGram, decimal TagPrice,
    ChargeType MakingType, decimal MakingValue, decimal WastagePercent, decimal WastageWeight,
    decimal StoneValue, decimal OtherCharges, decimal Discount, decimal? ManualPrice,
    bool TaxEnabled, decimal TaxPercent, RoundingPolicy Rounding = RoundingPolicy.PerLine, decimal RoundStep = 1m);

public record PricingResult(
    decimal MetalValue, decimal MakingCharge, decimal WastageCharge, decimal StoneValue, decimal OtherCharges,
    decimal GrossBeforeDiscount, decimal Discount, decimal Taxable, decimal Tax, decimal TotalUnrounded, decimal Total,
    bool RequiresApproval, decimal DiscountPercent);

/// <summary>
/// SRS 2.2: LineTotal = MetalValue + MakingCharge + WastageCharge + StoneValue + OtherCharges - Discount (+ tax if configured).
/// (a) Tagged price, (b) metal + making, (c) metal + stone + making/wastage, (d) manual approved price.
/// Unrounded inputs are preserved; rounding happens only at the configured boundary.
/// </summary>
public static class PricingCalculator
{
    public static PricingResult Price(PricingInput i)
    {
        if (i.Quantity <= 0) throw new DomainException("Quantity must be positive.", "qty_invalid");
        if (i.Discount < 0 || i.OtherCharges < 0 || i.StoneValue < 0 || i.MakingValue < 0) throw new DomainException("Charges and discount cannot be negative.", "charge_negative");
        decimal metal = Money.R2(i.NetWeight * i.RatePerGram), making = 0, wastage = 0, stone = 0, baseTotal;
        bool needsApproval = false;

        switch (i.Mode)
        {
            case PricingMode.Tagged:
                baseTotal = Money.R2(i.TagPrice * i.Quantity);
                metal = 0; // informational only for tagged items
                break;
            case PricingMode.MetalPlusMaking:
                making = Making(i, metal);
                baseTotal = metal + making + i.OtherCharges;
                break;
            case PricingMode.MetalStoneMakingWastage:
                making = Making(i, metal);
                wastage = i.WastageWeight > 0 ? Money.R2(i.WastageWeight * i.RatePerGram) : Money.R2(i.NetWeight * i.WastagePercent / 100m * i.RatePerGram);
                stone = Money.R2(i.StoneValue);
                baseTotal = metal + making + wastage + stone + i.OtherCharges;
                break;
            case PricingMode.ManualApproved:
                if (i.ManualPrice is null || i.ManualPrice < 0) throw new DomainException("A manual price is required for manually priced lines.", "manual_price_required");
                baseTotal = Money.R2(i.ManualPrice.Value);
                metal = 0; needsApproval = true;
                break;
            default: throw new DomainException("Unknown pricing mode.");
        }

        baseTotal = Money.R2(baseTotal);
        if (i.Discount > baseTotal) throw new DomainException("Discount cannot exceed the line amount.", "discount_exceeds_line");
        var taxable = baseTotal - i.Discount;
        var tax = i.TaxEnabled ? Money.R2(taxable * i.TaxPercent / 100m) : 0m;
        var unrounded = taxable + tax;
        var total = i.Rounding == RoundingPolicy.PerLine ? Money.RoundTo(unrounded, i.RoundStep) : Money.R2(unrounded);
        var discPct = baseTotal == 0 ? 0 : Math.Round(i.Discount / baseTotal * 100m, 3);
        return new PricingResult(metal, making, wastage, stone, i.OtherCharges, baseTotal, i.Discount, taxable, tax, unrounded, total, needsApproval, discPct);
    }

    static decimal Making(PricingInput i, decimal metalValue) => i.MakingType switch
    {
        ChargeType.None => 0m,
        ChargeType.Fixed => Money.R2(i.MakingValue),
        ChargeType.PerGram => Money.R2(i.MakingValue * i.NetWeight),
        ChargeType.Percent => Money.R2(metalValue * i.MakingValue / 100m),
        _ => 0m
    };
}

public record InvoiceTotals(decimal Subtotal, decimal Discount, decimal Tax, decimal OldGoldCredit, decimal Rounding, decimal Total, decimal Paid, decimal Due, decimal Change);

public static class InvoiceMath
{
    /// <summary>Totals from priced lines. Old-gold credit is applied before payments; excess payment is change/overpayment, never silently posted.</summary>
    public static InvoiceTotals Totals(IEnumerable<PricingResult> lines, decimal oldGoldCredit, decimal paid, RoundingPolicy policy, decimal step)
    {
        decimal sub = 0, disc = 0, tax = 0, unr = 0, lineTotals = 0;
        foreach (var l in lines) { sub += l.GrossBeforeDiscount; disc += l.Discount; tax += l.Tax; unr += l.TotalUnrounded; lineTotals += l.Total; }
        decimal gross, rounding = 0;
        if (policy == RoundingPolicy.PerInvoice) { gross = Money.RoundTo(unr, step); rounding = gross - Money.R2(unr); }
        else { gross = lineTotals; rounding = lineTotals - Money.R2(unr); }
        if (oldGoldCredit < 0) throw new DomainException("Old gold credit cannot be negative.");
        var total = Money.R2(gross - oldGoldCredit);
        if (total < 0) throw new DomainException("Old gold credit exceeds the invoice total. Pay the customer the difference through the old gold transaction.", "oldgold_exceeds_total");
        var due = Math.Max(0, total - paid);
        var change = Math.Max(0, paid - total);
        return new InvoiceTotals(Money.R2(sub), Money.R2(disc), Money.R2(tax), Money.R2(oldGoldCredit), Money.R2(rounding), total, Money.R2(paid), Money.R2(due), Money.R2(change));
    }
}
