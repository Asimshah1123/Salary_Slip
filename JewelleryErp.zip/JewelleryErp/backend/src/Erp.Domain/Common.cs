namespace Erp.Domain;

public abstract class Entity { public long Id { get; set; } }

public abstract class AuditedEntity : Entity
{
    public long? CreatedBy { get; set; }
    public DateTime CreatedAtUtc { get; set; }
    public long? ModifiedBy { get; set; }
    public DateTime? ModifiedAtUtc { get; set; }
    public byte[] RowVersion { get; set; } = Array.Empty<byte>();
}

public interface ICompanyScoped { long CompanyId { get; } }
public interface IBranchScoped { long BranchId { get; } }

public abstract class CompanyEntity : AuditedEntity, ICompanyScoped { public long CompanyId { get; set; } }

public abstract class BranchEntity : CompanyEntity, IBranchScoped { public long BranchId { get; set; } }

/// <summary>Base for every posted business document (sale, purchase, voucher, job receipt ...).</summary>
public abstract class PostableDocument : BranchEntity
{
    public string Number { get; set; } = "";
    public DateTime DocDateUtc { get; set; }
    public DocStatus Status { get; set; } = DocStatus.Draft;
    public long? PostedBy { get; set; }
    public DateTime? PostedAtUtc { get; set; }
    public long? ApprovedBy { get; set; }
    public DateTime? ApprovedAtUtc { get; set; }
    public string? Notes { get; set; }
    public string? IdempotencyKey { get; set; }
    public long? ReversalOfId { get; set; }
    public string? VoidReason { get; set; }
}

public class DomainException : Exception
{
    public string Code { get; }
    public DomainException(string message, string code = "domain_rule") : base(message) { Code = code; }
}
