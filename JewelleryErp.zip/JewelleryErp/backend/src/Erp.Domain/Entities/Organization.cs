namespace Erp.Domain.Entities;

public class Company : AuditedEntity
{
    public string Name { get; set; } = "";
    public string? LegalName { get; set; }
    public string? Ntn { get; set; }
    public string? Address { get; set; }
    public string? Phone { get; set; }
    public string BaseCurrency { get; set; } = "PKR";
    public string TimeZoneId { get; set; } = "Pakistan Standard Time";
    public bool IsActive { get; set; } = true;
}

public class Branch : CompanyEntity
{
    public string BranchCode { get; set; } = "";
    public string BranchName { get; set; } = "";
    public string? Address { get; set; }
    public string? City { get; set; }
    public string? Phone { get; set; }
    public bool IsActive { get; set; } = true;
    public bool IsHeadOffice { get; set; }
    public string BranchType { get; set; } = "Retail"; // Retail | Workshop | Warehouse | HeadOffice
    public string? TimeZoneId { get; set; }
    public string InvoicePrefix { get; set; } = "INV";
    public long? DefaultCashAccountId { get; set; }
    public string? ReceiptFooter { get; set; }
    public string? PrinterConfigJson { get; set; }
    public string? RatePolicy { get; set; } // null = company wide policy
}

public class StoreLocation : BranchEntity
{
    public string Code { get; set; } = "";
    public string Name { get; set; } = "";
    public string Kind { get; set; } = "Showroom"; // Showroom | Vault | Inspection | Workshop | Warehouse
    public bool IsDefault { get; set; }
    public bool IsActive { get; set; } = true;
}

public class AppSetting : CompanyEntity
{
    public long? BranchId { get; set; } // null = company-wide, set = explicit branch override
    public string Key { get; set; } = "";
    public string Value { get; set; } = "";
    public string? Description { get; set; }
}

/// <summary>Per branch / document-type / year numbering counter. RowVersion guards concurrent allocation.</summary>
public class InvoiceSequence : CompanyEntity
{
    public long? BranchId { get; set; }
    public string DocType { get; set; } = "";
    public int Year { get; set; }
    public long LastNumber { get; set; }
}
