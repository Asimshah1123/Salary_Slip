namespace Erp.Domain.Entities;

public class JobCard : PostableDocument
{
    public long WorkerId { get; set; }
    public JobStatus JobStatus { get; set; }
    public StockPostingMode StockPostingMode { get; set; }
    public Ownership MaterialOwnership { get; set; } = Ownership.Shop;  // who provides the metal
    public string? MaterialSourceNote { get; set; }
    public string DesignSpec { get; set; } = "";
    public DateTime? DueDateUtc { get; set; }
    public int TargetPieces { get; set; } = 1;
    public ChargeType MakingType { get; set; } = ChargeType.PerGram;
    public decimal MakingValue { get; set; }
    public decimal WastageAllowancePercent { get; set; }
    public decimal ToleranceFineGrams { get; set; }              // configured tolerance for reconciliation
    public long? WorkshopLocationId { get; set; }
    public long? RepairTicketId { get; set; }                    // job created from a repair stage
    // running totals (derived, refreshed on every posting)
    public decimal IssuedFine { get; set; }
    public decimal AdditionalInputFine { get; set; }
    public decimal ReceivedOutputFine { get; set; }
    public decimal ReturnedFine { get; set; }
    public decimal ScrapFine { get; set; }
    public decimal ApprovedLossFine { get; set; }
    public decimal VarianceFine { get; set; }
    public decimal MakingChargesAccrued { get; set; }
    public decimal MakingChargesPaid { get; set; }
    public string? VarianceApprovalReason { get; set; }
    public long? VarianceApprovedBy { get; set; }
    public bool StockModeLocked { get; set; }                    // true once any posting exists (SRS 6.4)
    public List<JobStage> Stages { get; set; } = new();
}

public class JobStage : Entity
{
    public long JobCardId { get; set; }
    public JobStatus FromStatus { get; set; }
    public JobStatus ToStatus { get; set; }
    public DateTime AtUtc { get; set; }
    public long UserId { get; set; }
    public string? Note { get; set; }
}

public class JobMaterialIssue : PostableDocument
{
    public long JobCardId { get; set; }
    public string? AcknowledgedBy { get; set; }
    public List<JobMaterialIssueLine> Lines { get; set; } = new();
}

public class JobMaterialIssueLine : Entity
{
    public long JobMaterialIssueId { get; set; }
    public long MetalTypeId { get; set; }
    public long PurityId { get; set; }
    public decimal GrossWeight { get; set; }
    public decimal NetWeight { get; set; }
    public decimal FineWeight { get; set; }
    public long? FromLocationId { get; set; }
    public bool IsAdditional { get; set; }
}

public class JobReceipt : PostableDocument
{
    public long JobCardId { get; set; }
    public Ownership InputOwnership { get; set; }
    public string? InputSourceNote { get; set; }
    public decimal MakingCharge { get; set; }
    public decimal OutputFine { get; set; }
    public decimal ReturnedFine { get; set; }
    public decimal ScrapFine { get; set; }
    public bool IsFinal { get; set; }
    public List<JobReceiptLine> Lines { get; set; } = new();
}

public class JobReceiptLine : Entity
{
    public long JobReceiptId { get; set; }
    public string Kind { get; set; } = "Output";      // Output | ReturnedMetal | Scrap
    public long? ProductId { get; set; }              // created for finished output pieces
    public string? Sku { get; set; }
    public string? Description { get; set; }
    public long? CategoryId { get; set; }
    public long MetalTypeId { get; set; }
    public long PurityId { get; set; }
    public decimal Quantity { get; set; } = 1;
    public decimal GrossWeight { get; set; }
    public decimal StoneWeight { get; set; }
    public decimal NetWeight { get; set; }
    public decimal FineWeight { get; set; }
    public decimal StoneValue { get; set; }
}

public class JobReconciliation : PostableDocument
{
    public long JobCardId { get; set; }
    public decimal IssuedFine { get; set; }
    public decimal AdditionalInputFine { get; set; }
    public decimal OutputFine { get; set; }
    public decimal ReturnedFine { get; set; }
    public decimal ScrapFine { get; set; }
    public decimal ApprovedLossFine { get; set; }
    public decimal VarianceFine { get; set; }
    public decimal ToleranceFine { get; set; }
    public bool WithinTolerance { get; set; }
    public string? ApprovalReason { get; set; }
    public decimal MakingCharges { get; set; }
}

public class WorkerPayment : PostableDocument
{
    public long WorkerId { get; set; }
    public long? JobCardId { get; set; }
    public long PaymentMethodId { get; set; }
    public long? AccountId { get; set; }
    public decimal Amount { get; set; }
    public string? Reference { get; set; }
}
