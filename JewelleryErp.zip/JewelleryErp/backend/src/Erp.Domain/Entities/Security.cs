namespace Erp.Domain.Entities;

public class AppUser : CompanyEntity
{
    public string UserName { get; set; } = "";
    public string Email { get; set; } = "";
    public string FullName { get; set; } = "";
    public string PasswordHash { get; set; } = "";
    public string PasswordSalt { get; set; } = "";
    public int HashIterations { get; set; }
    public bool IsActive { get; set; } = true;
    public bool IsSuperAdmin { get; set; }
    public long? DefaultBranchId { get; set; }
    public long? EmployeeId { get; set; }   // employee record and login are separate concepts
    public long? WorkerId { get; set; }     // karigar login -> assigned job cards only
    public int FailedLoginCount { get; set; }
    public DateTime? LockoutUntilUtc { get; set; }
    public DateTime? LastLoginUtc { get; set; }
    public string SecurityStamp { get; set; } = Guid.NewGuid().ToString("N"); // rotated on role/branch change
    public bool MustChangePassword { get; set; }
    public string PreferredLanguage { get; set; } = "en";
}

public class Role : CompanyEntity
{
    public string Name { get; set; } = "";
    public string? Description { get; set; }
    public bool IsSystem { get; set; }
    public bool IsActive { get; set; } = true;
}

public class Permission : Entity
{
    public string Code { get; set; } = "";       // Module.Action
    public string Module { get; set; } = "";
    public string Description { get; set; } = "";
}

public class RolePermission : Entity
{
    public long RoleId { get; set; }
    public long PermissionId { get; set; }
}

public class UserRole : Entity
{
    public long UserId { get; set; }
    public long RoleId { get; set; }
    public long? BranchId { get; set; } // optional branch scope of the assignment
}

public class UserBranchAccess : Entity
{
    public long UserId { get; set; }
    public long BranchId { get; set; }
    public bool IsDefault { get; set; }
    public bool IsActive { get; set; } = true;
}

public class RefreshToken : Entity
{
    public long UserId { get; set; }
    public string TokenHash { get; set; } = "";      // SHA-256 of the opaque token; never the token itself
    public string FamilyId { get; set; } = "";       // rotation family for reuse detection
    public DateTime CreatedUtc { get; set; }
    public DateTime ExpiresUtc { get; set; }
    public DateTime? RevokedUtc { get; set; }
    public string? ReplacedByHash { get; set; }
    public string? CreatedByIp { get; set; }
    public string? DeviceInfo { get; set; }
}

public class LoginAttempt : Entity
{
    public string UserNameOrEmail { get; set; } = "";
    public long? UserId { get; set; }
    public bool Succeeded { get; set; }
    public string? Ip { get; set; }
    public string? DeviceInfo { get; set; }
    public DateTime AtUtc { get; set; }
}

public class PasswordResetToken : Entity
{
    public long UserId { get; set; }
    public string TokenHash { get; set; } = "";
    public DateTime ExpiresUtc { get; set; }
    public DateTime? UsedUtc { get; set; }
}

public class AuditLog : Entity, ICompanyScoped
{
    public long CompanyId { get; set; }
    public DateTime AtUtc { get; set; }
    public long? UserId { get; set; }
    public string? UserName { get; set; }
    public long? ActiveBranchId { get; set; }
    public long? TargetBranchId { get; set; }
    public string Action { get; set; } = "";
    public string EntityType { get; set; } = "";
    public string? EntityId { get; set; }
    public string? BeforeJson { get; set; }
    public string? AfterJson { get; set; }
    public string? Reason { get; set; }
    public string? CorrelationId { get; set; }
    public string? Ip { get; set; }
    public bool Denied { get; set; }
}

/// <summary>SRS 19.3 - thresholds per role (and optionally branch). Above the limit a document becomes Pending Approval.</summary>
public class ApprovalLimit : CompanyEntity
{
    public long RoleId { get; set; }
    public long? BranchId { get; set; }
    public ApprovalType Type { get; set; }
    public decimal MaxValue { get; set; } // percentage for discounts, PKR for money, grams for metal
}

public class ApprovalRequest : BranchEntity
{
    public ApprovalType Type { get; set; }
    public string EntityType { get; set; } = "";
    public long EntityId { get; set; }
    public string? EntityNumber { get; set; }
    public decimal Value { get; set; }
    public decimal Limit { get; set; }
    public string? Reason { get; set; }
    public ApprovalStatus Status { get; set; }
    public long RequestedBy { get; set; }
    public DateTime RequestedAtUtc { get; set; }
    public long? DecidedBy { get; set; }
    public DateTime? DecidedAtUtc { get; set; }
    public string? DecisionReason { get; set; }
    public string? BeforeJson { get; set; }
    public string? AfterJson { get; set; }
}
