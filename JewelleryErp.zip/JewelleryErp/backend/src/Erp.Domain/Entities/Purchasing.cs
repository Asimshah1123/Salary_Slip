namespace Erp.Domain.Entities;

public class PurchaseOrder : PostableDocument
{
    public long SupplierId { get; set; }
    public DateTime? ExpectedDateUtc { get; set; }
    public decimal EstimatedTotal { get; set; }
    public List<PurchaseOrderLine> Lines { get; set; } = new();
}

public class PurchaseOrderLine : Entity
{
    public long PurchaseOrderId { get; set; }
    public string Description { get; set; } = "";
    public long? MetalTypeId { get; set; }
    public long? PurityId { get; set; }
    public decimal Quantity { get; set; }
    public decimal ExpectedWeight { get; set; }
    public decimal ExpectedRate { get; set; }
}

public class PurchaseInvoice : PostableDocument
{
    public long SupplierId { get; set; }
    public long? PurchaseOrderId { get; set; }
    public string SupplierInvoiceNo { get; set; } = "";
    public DateTime? ReceivedDateUtc { get; set; }
    public decimal Subtotal { get; set; }
    public decimal TaxTotal { get; set; }
    public decimal Total { get; set; }
    public decimal PaidTotal { get; set; }
    public decimal DueTotal { get; set; }
    public bool Received { get; set; }
    public long? InspectionLocationId { get; set; }
    public List<PurchaseInvoiceLine> Lines { get; set; } = new();
    public List<PurchasePayment> Payments { get; set; } = new();
}

public class PurchaseInvoiceLine : Entity
{
    public long PurchaseInvoiceId { get; set; }
    public int LineNo { get; set; }
    public long? ProductId { get; set; }          // created on posting when new piece details are supplied
    public bool IsLooseMetal { get; set; }        // raw metal bought by weight: stocked as metal+purity, no catalogue item
    public string Description { get; set; } = "";
    public string? NewSku { get; set; }
    public long? CategoryId { get; set; }
    public long MetalTypeId { get; set; }
    public long PurityId { get; set; }
    public decimal Quantity { get; set; } = 1;
    public decimal GrossWeight { get; set; }
    public decimal StoneWeight { get; set; }
    public decimal NetWeight { get; set; }
    public decimal FineWeight { get; set; }
    public decimal Rate { get; set; }
    public DateTime? RateTimestampUtc { get; set; }
    public decimal MetalValue { get; set; }
    public decimal MakingCharges { get; set; }
    public decimal StoneValue { get; set; }
    public decimal OtherCharges { get; set; }
    public decimal TaxAmount { get; set; }
    public decimal LineTotal { get; set; }
    // receiving / inspection (SRS 3.6)
    public decimal? ReceivedGrossWeight { get; set; }
    public decimal? ReceivedNetWeight { get; set; }
    public long? ReceivedPurityId { get; set; }
    public string? VarianceReason { get; set; }
    public decimal ReturnedQuantity { get; set; }
}

public class PurchasePayment : Entity
{
    public long PurchaseInvoiceId { get; set; }
    public long PaymentMethodId { get; set; }
    public long? AccountId { get; set; }
    public decimal Amount { get; set; }
    public string? Reference { get; set; }
}

public class SupplierReturn : PostableDocument
{
    public long SupplierId { get; set; }
    public long PurchaseInvoiceId { get; set; }
    public string Reason { get; set; } = "";
    public decimal Total { get; set; }
    public List<SupplierReturnLine> Lines { get; set; } = new();
}

public class SupplierReturnLine : Entity
{
    public long SupplierReturnId { get; set; }
    public long PurchaseInvoiceLineId { get; set; }
    public long? ProductId { get; set; }
    public decimal Quantity { get; set; }
    public decimal NetWeight { get; set; }
    public decimal Amount { get; set; }
}

public class SupplierPayment : PostableDocument
{
    public long SupplierId { get; set; }
    public long PaymentMethodId { get; set; }
    public long? AccountId { get; set; }
    public decimal Amount { get; set; }
    public decimal AllocatedAmount { get; set; }
    public decimal UnappliedAmount { get; set; }     // advance remains visible as supplier credit
    public string? Reference { get; set; }
    public List<PaymentAllocation> Allocations { get; set; } = new();
}

public class PaymentAllocation : Entity
{
    public long SupplierPaymentId { get; set; }
    public long PurchaseInvoiceId { get; set; }
    public decimal Amount { get; set; }
}
