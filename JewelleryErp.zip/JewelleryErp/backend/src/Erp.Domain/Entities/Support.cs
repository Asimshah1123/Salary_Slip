namespace Erp.Domain.Entities;

/// <summary>One row per transaction detail line, written at posting time (SRS 7.1). Drives the Comprehensive Transaction Register.</summary>
public class TransactionRegisterEntry : Entity, ICompanyScoped, IBranchScoped
{
    public long CompanyId { get; set; }
    public long BranchId { get; set; }
    public long? DestinationBranchId { get; set; }
    public DateTime PostedAtUtc { get; set; }
    public TxnType TxnType { get; set; }
    public long DocId { get; set; }
    public string DocNo { get; set; } = "";
    public int LineNo { get; set; }
    public DocStatus Status { get; set; }
    public PartyType? PartyType { get; set; }
    public long? PartyId { get; set; }
    public string? PartyName { get; set; }
    public long? ProductId { get; set; }
    public string? Sku { get; set; }
    public string? ItemName { get; set; }
    public string? CategoryName { get; set; }
    public long? MetalTypeId { get; set; }
    public long? PurityId { get; set; }
    public string? PurityLabel { get; set; }
    public decimal Gross { get; set; }
    public decimal Stone { get; set; }
    public decimal Net { get; set; }
    public decimal Fine { get; set; }
    public decimal Rate { get; set; }
    public decimal Making { get; set; }
    public decimal Wastage { get; set; }
    public decimal StoneValue { get; set; }
    public decimal PkrDebit { get; set; }
    public decimal PkrCredit { get; set; }
    public string? PaymentMethod { get; set; }
    public long? LinkedDocId { get; set; }
    public string? LinkedDocType { get; set; }
    public string? LinkedDocNo { get; set; }
    public long EnteredBy { get; set; }
    public string? EnteredByName { get; set; }
    public long? ApprovedBy { get; set; }
    public bool IsReversal { get; set; }
    public long? ReversedByDocId { get; set; }
}

public class CommissionEntry : BranchEntity
{
    public long SalesmanId { get; set; }          // Employee id
    public long? SalesInvoiceId { get; set; }
    public long? SalesReturnId { get; set; }
    public DateTime EntryDateUtc { get; set; }
    public decimal EligibleAmount { get; set; }
    public decimal Rate { get; set; }
    public decimal CalculatedAmount { get; set; }
    public decimal ApprovedAmount { get; set; }
    public decimal PaidAmount { get; set; }
    public bool IsApproved { get; set; }
    public bool IsReversal { get; set; }
    public string? Note { get; set; }
}

public class Notification : BranchEntity
{
    public string Type { get; set; } = "";       // LowStock, RepairOverdue, JobOverdue, ...
    public string Message { get; set; } = "";
    public string Severity { get; set; } = "Info";
    public string? RefType { get; set; }
    public long? RefId { get; set; }
    public bool IsRead { get; set; }
}

public class BackupHistory : Entity, ICompanyScoped
{
    public long CompanyId { get; set; }
    public DateTime StartedUtc { get; set; }
    public DateTime? FinishedUtc { get; set; }
    public string Status { get; set; } = "Pending"; // Pending | Succeeded | Failed | RestoreTested
    public string? Location { get; set; }
    public long? SizeBytes { get; set; }
    public bool Encrypted { get; set; }
    public string? Message { get; set; }
    public DateTime? RestoreTestedUtc { get; set; }
}
