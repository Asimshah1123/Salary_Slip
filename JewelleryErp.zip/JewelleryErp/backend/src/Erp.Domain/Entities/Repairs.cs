namespace Erp.Domain.Entities;

public class RepairTicket : PostableDocument
{
    public long CustomerId { get; set; }
    public RepairStatus RepairStatus { get; set; }
    public DateTime ReceivedDateUtc { get; set; }
    public DateTime? PromisedDateUtc { get; set; }
    public long? TechnicianId { get; set; }          // Employee id
    public long? WorkerId { get; set; }              // karigar stage (optional)
    public string ItemDescription { get; set; } = "";
    public string? Condition { get; set; }           // visible damage
    public string RequestedWork { get; set; } = "";
    public long? MetalTypeId { get; set; }
    public long? PurityId { get; set; }
    public decimal GrossWeight { get; set; }
    public decimal StoneWeight { get; set; }
    public decimal NetWeight { get; set; }
    public decimal FinalGrossWeight { get; set; }
    public string? StoneDetails { get; set; }
    public string? AccessoriesReceived { get; set; }
    public string? AcknowledgementName { get; set; }
    public bool CustomerAcknowledged { get; set; }
    public long? CustodyLocationId { get; set; }
    public decimal EstimateAmount { get; set; }
    public decimal ActualCharges { get; set; }
    public decimal AdvanceAmount { get; set; }
    public decimal PaidAmount { get; set; }
    public decimal BalanceAmount { get; set; }
    public bool ApprovalRequired { get; set; } = true;
    public bool EstimateApproved { get; set; }
    public string? WarrantyNote { get; set; }
    public string? RejectionReason { get; set; }
    public DateTime? ReadyNotifiedUtc { get; set; }
    public DateTime? DeliveredAtUtc { get; set; }
    public string? CollectorName { get; set; }
    public string? CollectorCnic { get; set; }
    public bool DeliveryOverride { get; set; }
    public string? DeliveryOverrideReason { get; set; }
    public List<RepairEstimate> Estimates { get; set; } = new();
    public List<RepairWorkLog> WorkLogs { get; set; } = new();
    public List<RepairPartUsage> Parts { get; set; } = new();
}

public class RepairEstimate : Entity
{
    public long RepairTicketId { get; set; }
    public int Version { get; set; }
    public decimal Amount { get; set; }
    public string? Description { get; set; }
    public long PreparedBy { get; set; }
    public DateTime PreparedAtUtc { get; set; }
    public ApprovalStatus ApprovalStatus { get; set; }
    public string? ApprovedByCustomer { get; set; }       // "approval" captured from the customer
    public DateTime? ApprovedAtUtc { get; set; }
    public string? ApprovalChannel { get; set; }           // Phone | InPerson | WhatsApp
}

public class RepairWorkLog : Entity
{
    public long RepairTicketId { get; set; }
    public RepairStatus FromStatus { get; set; }
    public RepairStatus ToStatus { get; set; }
    public DateTime AtUtc { get; set; }
    public long UserId { get; set; }
    public string? WorkPerformed { get; set; }
}

public class RepairPartUsage : Entity
{
    public long RepairTicketId { get; set; }
    public string Description { get; set; } = "";
    public long? ProductId { get; set; }
    public long? MetalTypeId { get; set; }
    public long? PurityId { get; set; }
    public decimal Quantity { get; set; } = 1;
    public decimal MetalAddedNet { get; set; }
    public decimal MetalRemovedNet { get; set; }
    public decimal Charge { get; set; }
    public decimal CostValue { get; set; }
    public bool Posted { get; set; }
}
