namespace Erp.Domain.Entities;

/// <summary>
/// Materialised balance derived from immutable StockMovement rows. Key = Branch/Location/Product/Metal/Purity/Status/Ownership/CustodyRef.
/// CustodyRefId = job card or repair ticket id for With-Worker / Repair-Intake custody, else 0.
/// RowVersion makes concurrent posting of the same serialized piece fail for the second user.
/// </summary>
public class StockBalance : CompanyEntity, IBranchScoped
{
    public long BranchId { get; set; }
    public long LocationId { get; set; }
    public long? ProductId { get; set; }
    public long? MetalTypeId { get; set; }
    public long? PurityId { get; set; }
    public StockStatus Status { get; set; }
    public Ownership Ownership { get; set; }
    public long CustodyRefId { get; set; }
    public decimal Quantity { get; set; }
    public decimal GrossWeight { get; set; }
    public decimal StoneWeight { get; set; }
    public decimal NetWeight { get; set; }
    public decimal FineWeight { get; set; }
    public decimal CostValue { get; set; }
}

/// <summary>Immutable ledger line. Never updated or deleted; corrections are reversing movements.</summary>
public class StockMovement : Entity, ICompanyScoped
{
    public long CompanyId { get; set; }
    public DateTime PostedAtUtc { get; set; }
    public long PostedBy { get; set; }
    public long? FromBranchId { get; set; }
    public long? FromLocationId { get; set; }
    public StockStatus? FromStatus { get; set; }
    public long? ToBranchId { get; set; }
    public long? ToLocationId { get; set; }
    public StockStatus? ToStatus { get; set; }
    public long? ProductId { get; set; }
    public long? MetalTypeId { get; set; }
    public long? PurityId { get; set; }
    public Ownership FromOwnership { get; set; }
    public long FromCustodyRefId { get; set; }
    public Ownership Ownership { get; set; }          // destination ownership
    public long CustodyRefId { get; set; }            // destination custody reference
    public decimal Quantity { get; set; }
    public decimal GrossWeight { get; set; }
    public decimal StoneWeight { get; set; }
    public decimal NetWeight { get; set; }
    public decimal FineWeight { get; set; }
    public decimal CostValue { get; set; }
    public TxnType RefType { get; set; }
    public long RefId { get; set; }
    public string RefNo { get; set; } = "";
    public string? Reason { get; set; }
    public long? ReversalOfId { get; set; }
    public string Kind { get; set; } = "Move"; // Opening | Receipt | Move | Issue | Adjustment | Reversal
}

public class StockTransfer : PostableDocument
{
    public long OriginBranchId { get; set; }
    public long DestinationBranchId { get; set; }
    public long? FromLocationId { get; set; }
    public long? ToLocationId { get; set; }
    public TransferStatus TransferStatus { get; set; }
    public DateTime? DispatchedAtUtc { get; set; }
    public long? DispatchedBy { get; set; }
    public DateTime? ReceivedAtUtc { get; set; }
    public long? ReceivedBy { get; set; }
    public string? VarianceReason { get; set; }
    public List<StockTransferLine> Lines { get; set; } = new();
}

public class StockTransferLine : Entity
{
    public long StockTransferId { get; set; }
    public long? ProductId { get; set; }
    public long? MetalTypeId { get; set; }
    public long? PurityId { get; set; }
    public decimal Quantity { get; set; }
    public decimal GrossWeight { get; set; }
    public decimal NetWeight { get; set; }
    public decimal ReceivedQuantity { get; set; }
    public decimal ReceivedGrossWeight { get; set; }
    public decimal ReceivedNetWeight { get; set; }
}

public class StockAdjustment : PostableDocument
{
    public string Reason { get; set; } = "";
    public string Kind { get; set; } = "Adjustment"; // Adjustment | Damage | Loss | Scrap | Reclassify
    public long? StockCountId { get; set; }
    public decimal TotalValue { get; set; }
    public List<StockAdjustmentLine> Lines { get; set; } = new();
}

public class StockAdjustmentLine : Entity
{
    public long StockAdjustmentId { get; set; }
    public long? ProductId { get; set; }
    public long? MetalTypeId { get; set; }
    public long? PurityId { get; set; }
    public long LocationId { get; set; }
    public StockStatus Status { get; set; } = StockStatus.Available;
    public decimal QuantityDelta { get; set; }
    public decimal GrossDelta { get; set; }
    public decimal NetDelta { get; set; }
    public decimal CostDelta { get; set; }
    public StockStatus? ToStatus { get; set; }         // damage / quarantine / scrap / reclassify
}

public class StockCount : PostableDocument
{
    public long? LocationId { get; set; }
    public string? ApprovalNote { get; set; }
    public List<StockCountLine> Lines { get; set; } = new();
}

public class StockCountLine : Entity
{
    public long StockCountId { get; set; }
    public long? ProductId { get; set; }
    public long? MetalTypeId { get; set; }
    public long? PurityId { get; set; }
    public long LocationId { get; set; }
    public decimal SystemQuantity { get; set; }
    public decimal SystemNetWeight { get; set; }
    public decimal? CountedQuantity { get; set; }
    public decimal? CountedNetWeight { get; set; }
    public string? VarianceNote { get; set; }
}

public class StockReservation : BranchEntity
{
    public long ProductId { get; set; }
    public long? CustomerId { get; set; }
    public DateTime ReservedUntilUtc { get; set; }
    public string? Note { get; set; }
    public bool IsActive { get; set; } = true;
}
