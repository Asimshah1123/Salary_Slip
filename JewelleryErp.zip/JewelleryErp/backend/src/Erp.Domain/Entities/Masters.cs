namespace Erp.Domain.Entities;

public class ProductCategory : CompanyEntity
{
    public string Name { get; set; } = "";
    public long? ParentId { get; set; }
    public string? NameUrdu { get; set; }
    public bool IsActive { get; set; } = true;
}

public class MetalType : CompanyEntity
{
    public string Code { get; set; } = "";   // GOLD, SILVER, PLATINUM
    public string Name { get; set; } = "";
    public string? NameUrdu { get; set; }
    public bool IsActive { get; set; } = true;
}

public class Purity : CompanyEntity
{
    public long MetalTypeId { get; set; }
    public string Label { get; set; } = "";       // 22K, 24K, 925
    public decimal Karat { get; set; }            // 22
    public decimal Factor { get; set; }           // fineness, 22K = 22/24 (configurable, not assumed)
    public bool IsActive { get; set; } = true;
}

public class Unit : CompanyEntity
{
    public string Code { get; set; } = "";
    public string Name { get; set; } = "";
    public bool IsMetalWeight { get; set; }
    public bool IsActive { get; set; } = true;
}

/// <summary>SRS 2.1: conversion to grams must be approved in writing; unapproved units are refused by the converter.</summary>
public class UnitConversion : CompanyEntity
{
    public long UnitId { get; set; }
    public decimal? FactorToGram { get; set; }
    public bool IsApproved { get; set; }
    public string? ApprovalNote { get; set; }
    public long? ApprovedBy { get; set; }
}

public class StoneType : CompanyEntity
{
    public string Name { get; set; } = "";
    public string? Notes { get; set; }
    public bool IsActive { get; set; } = true;
}

public class GoldRate : CompanyEntity
{
    public long MetalTypeId { get; set; }
    public long PurityId { get; set; }
    public long? BranchId { get; set; }            // optional branch-specific rate
    public decimal BuyRate { get; set; }           // PKR per gram
    public decimal SellRate { get; set; }
    public DateTime EffectiveFromUtc { get; set; }
    public string? Reason { get; set; }
    public bool IsOverride { get; set; }
    public string Source { get; set; } = "Manual";
}

public class ExpenseHead : CompanyEntity
{
    public string Name { get; set; } = "";
    public long? AccountId { get; set; }
    public bool IsActive { get; set; } = true;
}

public class PaymentMethod : CompanyEntity
{
    public string Name { get; set; } = "";
    public string Kind { get; set; } = "Cash"; // Cash | Bank | Card | Cheque | Digital | Credit
    public long? DefaultAccountId { get; set; }
    public bool IsActive { get; set; } = true;
}

/// <summary>Item master. A unique piece is one Product row (TrackingMode.Serialized); accessories/loose metal use quantity tracking.</summary>
public class Product : CompanyEntity
{
    public string Sku { get; set; } = "";
    public string? Barcode { get; set; }
    public string Name { get; set; } = "";
    public string? NameUrdu { get; set; }
    public long? CategoryId { get; set; }
    public long? SubCategoryId { get; set; }
    public TrackingMode Tracking { get; set; } = TrackingMode.Serialized;
    public long? MetalTypeId { get; set; }
    public long? PurityId { get; set; }
    public string? Design { get; set; }
    public string? Size { get; set; }
    public decimal GrossWeight { get; set; }       // grams, decimal(18,3)
    public decimal StoneWeight { get; set; }
    public decimal OtherDeduction { get; set; }
    public decimal NetMetalWeight { get; set; }    // calculated on save from the deduction policy
    public string? StoneDetails { get; set; }
    public decimal StoneValue { get; set; }
    public PricingMode PricingMode { get; set; } = PricingMode.MetalPlusMaking;
    public ChargeType MakingType { get; set; } = ChargeType.PerGram;
    public decimal MakingValue { get; set; }
    public decimal WastagePercent { get; set; }
    public decimal TagPrice { get; set; }
    public decimal CostPrice { get; set; }         // item-specific cost, gated by Reports.Cost.View
    public decimal MinStock { get; set; }
    public long? SupplierId { get; set; }
    public long? DefaultBranchId { get; set; }
    public long? UnitId { get; set; }
    public bool IsStockItem { get; set; } = true;
    public bool IsActive { get; set; } = true;
    public string? Notes { get; set; }
}

/// <summary>SRS 11 - image metadata only; bytes live in controlled storage addressed by a random StorageKey.</summary>
public class FileAsset : CompanyEntity
{
    public long? BranchId { get; set; }
    public FileOwnerType OwnerType { get; set; }
    public long OwnerId { get; set; }
    public FileKind Kind { get; set; }
    public string StorageKey { get; set; } = "";
    public string? ThumbKey { get; set; }
    public string OriginalName { get; set; } = "";
    public string MimeType { get; set; } = "";
    public long ByteSize { get; set; }
    public string Checksum { get; set; } = "";
    public int Width { get; set; }
    public int Height { get; set; }
    public string? Caption { get; set; }
    public bool IsPrimary { get; set; }
    public int SortOrder { get; set; }
    public bool IsArchived { get; set; }   // posted evidence is archived, never hard deleted
}
