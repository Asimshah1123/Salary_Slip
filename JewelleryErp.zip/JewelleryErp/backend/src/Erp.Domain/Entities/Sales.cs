namespace Erp.Domain.Entities;

public class SalesInvoice : PostableDocument
{
    public string InvoiceType { get; set; } = "Retail"; // Retail | Wholesale | Estimate
    public long? CustomerId { get; set; }
    public long? SalesmanId { get; set; }                // Employee id
    public decimal Subtotal { get; set; }
    public decimal DiscountTotal { get; set; }
    public decimal TaxTotal { get; set; }
    public decimal OldGoldCredit { get; set; }
    public decimal RoundingAdjustment { get; set; }
    public decimal Total { get; set; }
    public decimal PaidTotal { get; set; }
    public decimal DueTotal { get; set; }
    public decimal CostTotal { get; set; }
    public decimal CommissionAmount { get; set; }
    public int PrintCount { get; set; }
    public string? RateOverrideReason { get; set; }
    public string RatePolicy { get; set; } = "Company";  // which rate policy was active (SRS 18.1)
    public List<SalesInvoiceLine> Lines { get; set; } = new();
    public List<SalesPayment> Payments { get; set; } = new();
}

public class SalesInvoiceLine : Entity
{
    public long SalesInvoiceId { get; set; }
    public int LineNo { get; set; }
    public long ProductId { get; set; }
    public string Sku { get; set; } = "";
    public string Description { get; set; } = "";
    public decimal Quantity { get; set; } = 1;
    public long? MetalTypeId { get; set; }
    public long? PurityId { get; set; }
    public decimal GrossWeight { get; set; }
    public decimal StoneWeight { get; set; }
    public decimal NetWeight { get; set; }
    public decimal FineWeight { get; set; }
    public PricingMode PricingMode { get; set; }
    // rate snapshot (SRS 2.1 RateSnapshot)
    public decimal Rate { get; set; }
    public long? RateId { get; set; }
    public DateTime? RateTimestampUtc { get; set; }
    public decimal MetalValue { get; set; }
    public ChargeType MakingType { get; set; }
    public decimal MakingInput { get; set; }
    public decimal MakingCharge { get; set; }
    public decimal WastagePercent { get; set; }
    public decimal WastageCharge { get; set; }
    public decimal StoneValue { get; set; }
    public decimal OtherCharges { get; set; }
    public decimal Discount { get; set; }
    public decimal TaxAmount { get; set; }
    public decimal LineTotalUnrounded { get; set; }
    public decimal LineTotal { get; set; }
    public decimal CostSnapshot { get; set; }
    public decimal ReturnedQuantity { get; set; }
}

public class SalesPayment : Entity
{
    public long SalesInvoiceId { get; set; }
    public long PaymentMethodId { get; set; }
    public long? AccountId { get; set; }    // CashBankAccount
    public decimal Amount { get; set; }
    public string? Reference { get; set; }
    public bool IsRefund { get; set; }
}

public class SalesReturn : PostableDocument
{
    public long OriginalInvoiceId { get; set; }
    public long? CustomerId { get; set; }
    public string Reason { get; set; } = "";
    public bool IsExchange { get; set; }
    public decimal Subtotal { get; set; }
    public decimal TaxReversed { get; set; }
    public decimal RefundTotal { get; set; }
    public decimal CreditToLedger { get; set; }
    public decimal CommissionReversed { get; set; }
    public StockStatus ReturnToStatus { get; set; } = StockStatus.Available;
    public List<SalesReturnLine> Lines { get; set; } = new();
    public List<SalesReturnRefund> Refunds { get; set; } = new();
}

public class SalesReturnLine : Entity
{
    public long SalesReturnId { get; set; }
    public long OriginalLineId { get; set; }
    public long ProductId { get; set; }
    public decimal Quantity { get; set; }
    public decimal NetWeight { get; set; }
    public decimal Amount { get; set; }
    public decimal TaxAmount { get; set; }
}

public class SalesReturnRefund : Entity
{
    public long SalesReturnId { get; set; }
    public long PaymentMethodId { get; set; }
    public long? AccountId { get; set; }
    public decimal Amount { get; set; }
}

/// <summary>SRS 2.4 old gold / buy-back. Posted to unrefined-metal stock (status Quarantine) until tested/melted.</summary>
public class OldGoldTransaction : PostableDocument
{
    public long? CustomerId { get; set; }
    public long MetalTypeId { get; set; }
    public long PurityId { get; set; }           // tested purity accepted
    public decimal GrossWeight { get; set; }
    public decimal StoneWeight { get; set; }
    public decimal OtherDeduction { get; set; }
    public decimal MeltingDeductionWeight { get; set; }
    public decimal NetWeight { get; set; }
    public decimal FineWeight { get; set; }
    public decimal AcceptedRate { get; set; }
    public decimal Value { get; set; }
    public decimal DeductionPercent { get; set; }
    public long? AppliedToInvoiceId { get; set; }
    public decimal AppliedAmount { get; set; }
    public decimal PaidOutAmount { get; set; }
    public string? PaidOutMethod { get; set; }
    public string? ItemDescription { get; set; }
    public string? AssayNote { get; set; }
}
