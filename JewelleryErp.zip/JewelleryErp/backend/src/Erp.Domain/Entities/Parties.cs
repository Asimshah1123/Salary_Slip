namespace Erp.Domain.Entities;

public abstract class PartyBase : CompanyEntity
{
    public string Code { get; set; } = "";
    public string Name { get; set; } = "";
    public string? Phone { get; set; }
    public string? Phone2 { get; set; }
    public string? WhatsApp { get; set; }
    public string? Email { get; set; }
    public string? Address { get; set; }
    public string? City { get; set; }
    public string? Notes { get; set; }
    public decimal OpeningBalance { get; set; }       // PKR; positive = party owes us (customer) / we owe party (supplier)
    public decimal OpeningMetalFine { get; set; }     // grams fine
    public long? OpeningMetalTypeId { get; set; }
    public bool IsActive { get; set; } = true;
    public long? BranchId { get; set; }               // optional home branch; parties are company-wide by default
}

public class Customer : PartyBase
{
    public string? Cnic { get; set; }                 // sensitive: only returned with Customers.ViewSensitive
    public bool MarketingConsent { get; set; }
    public decimal CreditLimit { get; set; }
}

public class Supplier : PartyBase
{
    public string? Categories { get; set; }
    public string? PaymentTerms { get; set; }
    public int CreditDays { get; set; }
}

public class Employee : CompanyEntity
{
    public string Code { get; set; } = "";
    public string Name { get; set; } = "";
    public string? Phone { get; set; }
    public string? Email { get; set; }
    public string? JobTitle { get; set; }
    public long? BranchId { get; set; }
    public DateTime? HireDate { get; set; }
    public DateTime? ExitDate { get; set; }
    public decimal BaseSalary { get; set; }
    public bool IsActive { get; set; } = true;
}

public class SalesmanProfile : CompanyEntity
{
    public long EmployeeId { get; set; }
    public CommissionType CommissionType { get; set; }
    public decimal CommissionValue { get; set; }      // percent or fixed PKR per invoice
    public long? CategoryId { get; set; }             // for category based rules
    public bool IsActive { get; set; } = true;
}

public class Worker : CompanyEntity
{
    public string Code { get; set; } = "";
    public string Name { get; set; } = "";
    public string? Phone { get; set; }
    public string? Address { get; set; }
    public string? Skills { get; set; }
    public ChargeType RateType { get; set; } = ChargeType.PerGram;
    public decimal RateValue { get; set; }
    public decimal DefaultWastagePercent { get; set; }
    public decimal OpeningBalance { get; set; }       // PKR payable to the worker
    public decimal OpeningMetalFine { get; set; }     // metal in worker custody at cutover
    public long? BranchId { get; set; }
    public bool IsActive { get; set; } = true;
}
