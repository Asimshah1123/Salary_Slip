namespace Erp.Domain.Entities;

public class ChartAccount : CompanyEntity
{
    public string Code { get; set; } = "";
    public string Name { get; set; } = "";
    public AccountType Type { get; set; }
    public long? ParentId { get; set; }
    public bool IsControl { get; set; }       // control accounts (receivable/payable) are posted by the system only
    public bool IsActive { get; set; } = true;
}

public class CashBankAccount : CompanyEntity
{
    public long? BranchId { get; set; }
    public CashBankType Type { get; set; }
    public string Name { get; set; } = "";
    public string? BankName { get; set; }
    public string? AccountNumberMasked { get; set; }   // never the full number
    public long? ChartAccountId { get; set; }
    public decimal OpeningBalance { get; set; }
    public bool IsActive { get; set; } = true;
}

public class CashBankVoucher : PostableDocument
{
    public VoucherType VoucherType { get; set; }
    public long AccountId { get; set; }
    public long? ToAccountId { get; set; }
    public PartyType? PartyType { get; set; }
    public long? PartyId { get; set; }
    public long? CounterAccountId { get; set; }        // chart account for non-party vouchers
    public decimal Amount { get; set; }
    public string? Reference { get; set; }
    public string? ReconciliationRef { get; set; }
    public string? Description { get; set; }
}

public class ExpenseVoucher : PostableDocument
{
    public long ExpenseHeadId { get; set; }
    public string? Payee { get; set; }
    public string? Description { get; set; }
    public decimal Amount { get; set; }
    public decimal TaxAmount { get; set; }
    public long PaymentAccountId { get; set; }
    public long EnteredBy { get; set; }
}

public class CashRegisterSession : BranchEntity
{
    public long AccountId { get; set; }
    public DateTime OpenedAtUtc { get; set; }
    public long OpenedBy { get; set; }
    public decimal OpeningAmount { get; set; }
    public DateTime? ClosedAtUtc { get; set; }
    public long? ClosedBy { get; set; }
    public decimal? ExpectedClosing { get; set; }
    public decimal? CountedClosing { get; set; }
    public decimal? Variance { get; set; }
    public string? VarianceNote { get; set; }
}

public class JournalEntry : BranchEntity
{
    public string Number { get; set; } = "";
    public DateTime EntryDateUtc { get; set; }
    public TxnType DocType { get; set; }
    public long DocId { get; set; }
    public string DocNo { get; set; } = "";
    public string? Description { get; set; }
    public decimal TotalDebit { get; set; }
    public decimal TotalCredit { get; set; }
    public bool IsReversal { get; set; }
    public long? ReversalOfId { get; set; }
    public List<JournalLine> Lines { get; set; } = new();
}

public class JournalLine : Entity
{
    public long JournalEntryId { get; set; }
    public long AccountId { get; set; }
    public decimal Debit { get; set; }
    public decimal Credit { get; set; }
    public PartyType? PartyType { get; set; }
    public long? PartyId { get; set; }
    public string? Memo { get; set; }
}

/// <summary>PKR ledger per party. Customer: debit = receivable up. Supplier/Worker: credit = payable up.</summary>
public class PartyLedgerEntry : Entity, ICompanyScoped
{
    public long CompanyId { get; set; }
    public long? BranchId { get; set; }
    public PartyType PartyType { get; set; }
    public long PartyId { get; set; }
    public DateTime EntryDateUtc { get; set; }
    public TxnType DocType { get; set; }
    public long DocId { get; set; }
    public string DocNo { get; set; } = "";
    public string? Description { get; set; }
    public decimal Debit { get; set; }
    public decimal Credit { get; set; }
    public bool IsReversal { get; set; }
}

/// <summary>Metal ledger kept separate from PKR (SRS 3.12): a party may owe money and/or metal independently.</summary>
public class MetalLedgerEntry : Entity, ICompanyScoped
{
    public long CompanyId { get; set; }
    public long? BranchId { get; set; }
    public PartyType PartyType { get; set; }
    public long PartyId { get; set; }
    public long MetalTypeId { get; set; }
    public long? PurityId { get; set; }
    public DateTime EntryDateUtc { get; set; }
    public TxnType DocType { get; set; }
    public long DocId { get; set; }
    public string DocNo { get; set; } = "";
    public decimal NetIn { get; set; }     // metal received from the party
    public decimal NetOut { get; set; }    // metal given to the party
    public decimal FineIn { get; set; }
    public decimal FineOut { get; set; }
    public string? Description { get; set; }
}
