namespace Erp.Domain;

/// <summary>Module.Action permission codes (SRS 19.2). Enforced server-side via authorization policies.</summary>
public static class Perms
{
    public const string ProductsView = "Products.View", ProductsCreate = "Products.Create", ProductsEdit = "Products.Edit",
        ProductsImagesView = "Products.Images.View", ProductsImagesUpload = "Products.Images.Upload", ProductsImagesDelete = "Products.Images.Delete", ProductsImagesDownload = "Products.Images.Download";
    public const string CustomersView = "Customers.View", CustomersEdit = "Customers.Edit", CustomersSensitive = "Customers.ViewSensitive", CustomersLedger = "Customers.Ledger.View";
    public const string SuppliersView = "Suppliers.View", SuppliersEdit = "Suppliers.Edit", SuppliersLedger = "Suppliers.Ledger.View";
    public const string EmployeesView = "Employees.View", EmployeesManage = "Employees.Manage", WorkersView = "Workers.View", WorkersManage = "Workers.Manage";
    public const string SalesView = "Sales.View", SalesCreate = "Sales.Create", SalesPost = "Sales.Post", SalesReturn = "Sales.Return", SalesVoid = "Sales.Void", SalesDiscountOverride = "Sales.Discount.Override";
    public const string OldGoldCreate = "OldGold.Create", OldGoldView = "OldGold.View";
    public const string PurchasesView = "Purchases.View", PurchasesCreate = "Purchases.Create", PurchasesPost = "Purchases.Post", PurchasesReceive = "Purchases.Receive", PurchasesReturn = "Purchases.Return", PurchasesVarianceApprove = "Purchases.Variance.Approve";
    public const string InventoryView = "Inventory.View", InventoryTransfer = "Inventory.Transfer", InventoryTransferReceive = "Inventory.Transfer.Receive", InventoryAdjust = "Inventory.Adjust", InventoryCount = "Inventory.Count", InventoryCountApprove = "Inventory.Count.Approve", InventoryReserve = "Inventory.Reserve", InventoryNegativeOverride = "Inventory.NegativeStock.Override";
    public const string GoldRateView = "GoldRate.View", GoldRateEdit = "GoldRate.Edit", GoldRateOverride = "GoldRate.Override";
    public const string JobWorkView = "JobWork.View", JobWorkViewAssigned = "JobWork.ViewAssigned", JobWorkCreate = "JobWork.Create", JobWorkApprove = "JobWork.Approve", JobWorkMaterialIssue = "JobWork.MaterialIssue", JobWorkReceive = "JobWork.Receive", JobWorkReconcile = "JobWork.Reconcile", JobWorkVarianceApprove = "JobWork.Variance.Approve", JobWorkClose = "JobWork.Close", JobWorkUpdateStage = "JobWork.UpdateStage", JobWorkPay = "JobWork.Pay";
    public const string RepairsViewAssigned = "Repairs.ViewAssigned", RepairsViewBranch = "Repairs.ViewBranch", RepairsCreate = "Repairs.Create", RepairsEstimate = "Repairs.Estimate", RepairsEstimateApprove = "Repairs.Estimate.Approve", RepairsUpdateStatus = "Repairs.UpdateStatus", RepairsDeliver = "Repairs.Deliver", RepairsDeliveryOverride = "Repairs.Deliver.Override", RepairsImagesUpload = "Repairs.Images.Upload";
    public const string FinanceExpenseCreate = "Finance.Expense.Create", FinanceExpenseApprove = "Finance.Expense.Approve", FinancePaymentPost = "Finance.Payment.Post", FinanceView = "Finance.View", FinanceCashRegister = "Finance.CashRegister", FinanceAccountsManage = "Finance.Accounts.Manage", FinanceReverse = "Finance.Reverse", FinanceJournalView = "Finance.Journal.View", FinanceMetalLedger = "Finance.MetalLedger.Post", FinanceExport = "Finance.Export";
    public const string ReportsSales = "Reports.Sales.View", ReportsStock = "Reports.Stock.View", ReportsCost = "Reports.Cost.View", ReportsProfit = "Reports.Profit.View", ReportsExport = "Reports.Export", ReportsConsolidated = "Reports.Consolidated.View", ReportsTransactions = "Reports.Transactions.View", ReportsFinance = "Reports.Finance.View", ReportsCommission = "Reports.Commission.View", ReportsPurchase = "Reports.Purchase.View", ReportsWorkshop = "Reports.Workshop.View", ReportsDashboard = "Reports.Dashboard.View";
    public const string UsersManage = "Users.Manage", RolesManage = "Roles.Manage", BranchesManage = "Branches.Manage", BranchesViewAll = "Branches.ViewAll", AuditLogView = "AuditLog.View", AuditLogExport = "AuditLog.Export", SettingsManage = "Settings.Manage", BackupManage = "Backup.Manage", ApprovalsDecide = "Approvals.Decide", ApprovalsView = "Approvals.View", CommissionApprove = "Commission.Approve", MastersManage = "Masters.Manage";

    public static readonly IReadOnlyList<string> All = typeof(Perms)
        .GetFields(System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.Static | System.Reflection.BindingFlags.DeclaredOnly)
        .Where(f => f.IsLiteral && f.FieldType == typeof(string)).Select(f => (string)f.GetRawConstantValue()!).OrderBy(x => x, StringComparer.Ordinal).ToList();

    public static string ModuleOf(string code) => code.Contains('.') ? code[..code.IndexOf('.')] : code;
}

/// <summary>Default role templates derived from the SRS 19.1 / 20 matrix. Final grants are approved by the business owner.</summary>
public static class RoleTemplates
{
    public const string Owner = "System Owner", CompanyManager = "Company Manager", BranchManager = "Branch Manager", Accountant = "Accountant",
        Cashier = "Salesman / Cashier", Inventory = "Inventory Controller", Purchase = "Purchase Officer", KarigarSupervisor = "Karigar Supervisor",
        Worker = "Worker / Karigar", RepairTech = "Repair Technician", Auditor = "Auditor / Read-only", ReportViewer = "Report Viewer";

    static IEnumerable<string> Where(Func<string, bool> p) => Perms.All.Where(p);
    static bool V(string c) => c.EndsWith(".View") || c.EndsWith(".ViewAssigned") || c.EndsWith(".ViewBranch") || c.EndsWith(".Ledger.View") || c.EndsWith(".Images.View") || c.EndsWith(".Journal.View");

    public static IReadOnlyDictionary<string, string[]> Defaults() => new Dictionary<string, string[]>
    {
        [Owner] = Perms.All.ToArray(),
        [CompanyManager] = Where(c => c != Perms.UsersManage && c != Perms.RolesManage && c != Perms.SettingsManage && c != Perms.BackupManage && c != Perms.ReportsProfit && c != Perms.ReportsCost).ToArray(),
        [BranchManager] = Where(c => c != Perms.UsersManage && c != Perms.RolesManage && c != Perms.BranchesManage && c != Perms.BranchesViewAll && c != Perms.ReportsConsolidated
                                  && c != Perms.SettingsManage && c != Perms.BackupManage && c != Perms.ReportsProfit && c != Perms.ReportsCost && c != Perms.AuditLogExport && c != Perms.GoldRateOverride).ToArray(),
        [Accountant] = Where(c => V(c) || c.StartsWith("Finance.") && c != Perms.FinanceReverse || c == Perms.ReportsFinance || c == Perms.ReportsExport || c == Perms.ReportsTransactions || c == Perms.ReportsCommission
                               || c == Perms.CommissionApprove || c == Perms.ReportsSales || c == Perms.ReportsPurchase || c == Perms.ReportsDashboard || c == Perms.SalesView).ToArray(),
        [Cashier] = new[] { Perms.ProductsView, Perms.ProductsImagesView, Perms.CustomersView, Perms.CustomersEdit, Perms.SalesView, Perms.SalesCreate, Perms.SalesPost, Perms.OldGoldCreate, Perms.OldGoldView, Perms.GoldRateView, Perms.InventoryView, Perms.ReportsDashboard, Perms.RepairsCreate, Perms.RepairsViewBranch },
        [Inventory] = new[] { Perms.ProductsView, Perms.ProductsCreate, Perms.ProductsEdit, Perms.ProductsImagesView, Perms.ProductsImagesUpload, Perms.InventoryView, Perms.InventoryTransfer, Perms.InventoryTransferReceive, Perms.InventoryCount, Perms.InventoryReserve, Perms.PurchasesReceive, Perms.PurchasesView, Perms.ReportsStock, Perms.GoldRateView, Perms.ReportsDashboard },
        [Purchase] = new[] { Perms.PurchasesView, Perms.PurchasesCreate, Perms.PurchasesPost, Perms.PurchasesReturn, Perms.SuppliersView, Perms.SuppliersEdit, Perms.SuppliersLedger, Perms.ProductsView, Perms.ProductsImagesView, Perms.GoldRateView, Perms.ReportsPurchase, Perms.ReportsDashboard },
        [KarigarSupervisor] = new[] { Perms.JobWorkView, Perms.JobWorkCreate, Perms.JobWorkApprove, Perms.JobWorkMaterialIssue, Perms.JobWorkReceive, Perms.JobWorkReconcile, Perms.JobWorkVarianceApprove, Perms.JobWorkClose, Perms.JobWorkUpdateStage, Perms.WorkersView, Perms.InventoryView, Perms.ProductsView, Perms.ProductsImagesView, Perms.ReportsWorkshop, Perms.RepairsViewBranch, Perms.RepairsUpdateStatus, Perms.RepairsImagesUpload, Perms.GoldRateView },
        [Worker] = new[] { Perms.JobWorkViewAssigned, Perms.JobWorkUpdateStage },
        [RepairTech] = new[] { Perms.RepairsViewAssigned, Perms.RepairsUpdateStatus, Perms.RepairsImagesUpload, Perms.RepairsEstimate },
        [Auditor] = Where(c => V(c) || c == Perms.ReportsTransactions || c == Perms.ReportsSales || c == Perms.ReportsStock || c == Perms.ReportsFinance || c == Perms.ReportsPurchase || c == Perms.ReportsWorkshop || c == Perms.AuditLogView || c == Perms.ReportsDashboard).ToArray(),
        [ReportViewer] = new[] { Perms.ReportsDashboard, Perms.ReportsSales, Perms.ReportsStock, Perms.ReportsPurchase },
    };
}

/// <summary>Chart-of-accounts codes used by the posting engine. Mapped to ChartAccount rows at seed time and configurable by admin.</summary>
public static class Acc
{
    public const string Cash = "1000", Bank = "1010", Receivable = "1100", InvFinished = "1200", InvRawMetal = "1210", InvOldGold = "1220", MetalWithWorkers = "1230",
        Payable = "2000", WorkerPayable = "2100", CustomerAdvances = "2200", TaxPayable = "2300", CommissionPayable = "2400",
        Equity = "3000", RetainedEarnings = "3100", OpeningEquity = "3200",
        SalesRevenue = "4000", RepairIncome = "4100", SalesReturns = "4200", OtherIncome = "4900", RoundingAdj = "4950",
        Cogs = "5000", StockLoss = "5200", CommissionExpense = "5300", MetalLoss = "5400", CashShortage = "5500",
        ExpMisc = "6090";
}
