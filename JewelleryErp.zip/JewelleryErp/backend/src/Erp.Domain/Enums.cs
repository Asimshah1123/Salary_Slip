namespace Erp.Domain;

public enum DocStatus { Draft = 0, PendingApproval = 1, Approved = 2, Posted = 3, PartiallyPaid = 4, Closed = 5, Reversed = 6, Cancelled = 7, OnHold = 8 }

/// <summary>SRS 3.8 stock statuses.</summary>
public enum StockStatus { Available = 0, Reserved = 1, InTransit = 2, InInspection = 3, WithWorker = 4, RepairIntake = 5, Damaged = 6, Quarantine = 7, Sold = 8, Returned = 9, Scrapped = 10 }

public enum Ownership { Shop = 0, Customer = 1, Worker = 2, Supplier = 3 }

/// <summary>SRS 3.2 item kinds.</summary>
public enum TrackingMode { Serialized = 0, Quantity = 1, LooseMetal = 2, LooseStone = 3, RepairPart = 4, Service = 5 }

/// <summary>SRS 2.2 pricing models (a)-(d).</summary>
public enum PricingMode { Tagged = 0, MetalPlusMaking = 1, MetalStoneMakingWastage = 2, ManualApproved = 3 }

public enum ChargeType { None = 0, Fixed = 1, PerGram = 2, Percent = 3 }

public enum PartyType { Customer = 1, Supplier = 2, Worker = 3, Employee = 4, Other = 5 }

public enum TxnType
{
    Sale = 1, SaleReturn = 2, Purchase = 3, PurchaseReceipt = 4, SupplierReturn = 5, OldGold = 6,
    StockTransferOut = 7, StockTransferIn = 8, StockAdjustment = 9, StockCount = 10,
    JobIssue = 11, JobReceipt = 12, JobReconcile = 13, WorkerPayment = 14,
    RepairIntake = 15, RepairDelivery = 16, RepairPayment = 17,
    Expense = 18, CashReceipt = 19, CashPayment = 20, BankTransfer = 21, SupplierPayment = 22, CustomerReceipt = 23,
    Opening = 24, Reversal = 25, Commission = 26
}

public enum JobStatus { Draft = 0, Approved = 1, MaterialIssued = 2, InProgress = 3, PartiallyReceived = 4, Completed = 5, Reconciled = 6, Closed = 7, Cancelled = 8 }

/// <summary>SRS 6.4 explicit per-job configuration.</summary>
public enum StockPostingMode { OnIssue = 0, OnReceiptOnly = 1 }

public enum RepairStatus { Received = 0, Inspection = 1, EstimatePrepared = 2, AwaitingApproval = 3, Approved = 4, InRepair = 5, QualityCheck = 6, Ready = 7, Delivered = 8, Rejected = 9, Cancelled = 10, Unrepairable = 11 }

public enum TransferStatus { Draft = 0, InTransit = 1, PartiallyReceived = 2, Received = 3, Cancelled = 4 }

public enum VoucherType { Receipt = 1, Payment = 2, Transfer = 3, Deposit = 4, Withdrawal = 5 }

public enum AccountType { Asset = 1, Liability = 2, Equity = 3, Revenue = 4, Expense = 5 }

public enum CashBankType { Cash = 1, Bank = 2 }

public enum FileOwnerType { Product = 1, RepairTicket = 2, JobCard = 3, SupplierDocument = 4, ExpenseVoucher = 5, Customer = 6, Employee = 7, OldGold = 8, PurchaseInvoice = 9, CompanyLogo = 10 }

public enum FileKind { General = 0, Intake = 1, Before = 2, During = 3, After = 4, Reference = 5, Receipt = 6, Assay = 7, Delivery = 8, Document = 9 }

public enum ApprovalType { DiscountOverLimit = 1, ExpenseOverLimit = 2, StockAdjustment = 3, MetalLoss = 4, PurchaseVariance = 5, RefundOverLimit = 6, RateOverride = 7, OldGoldDeduction = 8, JobVariance = 9, TransferVariance = 10, Reversal = 11, ManualPrice = 12 }

public enum ApprovalStatus { Pending = 0, Approved = 1, Rejected = 2 }

public enum CommissionType { None = 0, Fixed = 1, Percent = 2, CategoryBased = 3, Manual = 4 }

public enum CostingMethod { ItemSpecific = 0, MovingAverage = 1, Fifo = 2 }

public enum RoundingPolicy { None = 0, PerLine = 1, PerInvoice = 2 }
