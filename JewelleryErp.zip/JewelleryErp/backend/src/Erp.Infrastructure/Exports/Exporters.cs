using System.Globalization;
using System.IO.Compression;
using System.Text;
using System.Xml;

namespace Erp.Infrastructure.Exports;

public sealed record ReportColumn(string Key, string Title, string Type = "text");   // text | number | money | weight | date | datetime | status

public sealed class ReportTable
{
    public string Title { get; set; } = "";
    public string Scope { get; set; } = "";                        // branch scope + filters shown in headings / export metadata (SRS 21.3)
    public string GeneratedBy { get; set; } = "";
    public DateTime GeneratedAtUtc { get; set; } = DateTime.UtcNow;
    public List<ReportColumn> Columns { get; set; } = new();
    public List<object?[]> Rows { get; set; } = new();
    public Dictionary<string, decimal> Totals { get; set; } = new();
    public string? Note { get; set; }
    public bool Truncated { get; set; }
}

public static class Exporters
{
    static string Fmt(object? v, string type)
    {
        if (v == null) return "";
        return v switch
        {
            DateTime d => type == "date" ? d.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture) : d.ToString("yyyy-MM-dd HH:mm", CultureInfo.InvariantCulture),
            decimal m => type == "weight" ? m.ToString("0.000", CultureInfo.InvariantCulture) : type == "money" ? m.ToString("0.00", CultureInfo.InvariantCulture) : m.ToString("0.####", CultureInfo.InvariantCulture),
            bool b => b ? "Yes" : "No",
            Enum e => e.ToString(),
            IFormattable f => f.ToString(null, CultureInfo.InvariantCulture),
            _ => v.ToString() ?? ""
        };
    }

    // ---------------- CSV (RFC 4180, with spreadsheet-formula injection guard) ----------------
    public static byte[] Csv(ReportTable t)
    {
        var sb = new StringBuilder();
        sb.Append('\uFEFF');   // BOM so Excel opens UTF-8 correctly
        sb.AppendLine(Esc("# " + t.Title)); sb.AppendLine(Esc("# Scope: " + t.Scope)); sb.AppendLine(Esc($"# Generated {t.GeneratedAtUtc:yyyy-MM-dd HH:mm} UTC by {t.GeneratedBy}"));
        sb.AppendLine(string.Join(",", t.Columns.Select(c => Esc(c.Title))));
        foreach (var r in t.Rows) sb.AppendLine(string.Join(",", t.Columns.Select((c, i) => Esc(Fmt(i < r.Length ? r[i] : null, c.Type), c.Type == "text"))));
        if (t.Totals.Count > 0) sb.AppendLine(Esc("Totals: " + string.Join("; ", t.Totals.Select(k => $"{k.Key}={k.Value.ToString("0.###", CultureInfo.InvariantCulture)}"))));
        return Encoding.UTF8.GetBytes(sb.ToString());
    }

    static string Esc(string s, bool guard = true)
    {
        if (guard && s.Length > 0 && (s[0] is '=' or '+' or '@' or '\t' or '\r' || (s[0] == '-' && !decimal.TryParse(s, NumberStyles.Any, CultureInfo.InvariantCulture, out _)))) s = "'" + s;
        return s.IndexOfAny(new[] { ',', '"', '\n', '\r' }) >= 0 ? "\"" + s.Replace("\"", "\"\"") + "\"" : s;
    }

    // ---------------- XLSX (minimal OOXML, no library) ----------------
    public static byte[] Xlsx(ReportTable t)
    {
        using var ms = new MemoryStream();
        using (var zip = new ZipArchive(ms, ZipArchiveMode.Create, true))
        {
            void Add(string path, string xml) { var e = zip.CreateEntry(path, CompressionLevel.Optimal); using var w = new StreamWriter(e.Open(), new UTF8Encoding(false)); w.Write(xml); }
            Add("[Content_Types].xml", "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\"><Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/><Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/><Override PartName=\"/xl/worksheets/sheet1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/><Override PartName=\"/xl/styles.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml\"/></Types>");
            Add("_rels/.rels", "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/></Relationships>");
            Add("xl/workbook.xml", "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\"><sheets><sheet name=\"Report\" sheetId=\"1\" r:id=\"rId1\"/></sheets></workbook>");
            Add("xl/_rels/workbook.xml.rels", "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet1.xml\"/><Relationship Id=\"rId2\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles\" Target=\"styles.xml\"/></Relationships>");
            // style ids: 0 normal, 1 bold, 2 money (#,##0.00), 3 weight (0.000)
            Add("xl/styles.xml", "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><styleSheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><numFmts count=\"2\"><numFmt numFmtId=\"164\" formatCode=\"#,##0.00\"/><numFmt numFmtId=\"165\" formatCode=\"0.000\"/></numFmts><fonts count=\"2\"><font><sz val=\"11\"/><name val=\"Calibri\"/></font><font><b/><sz val=\"11\"/><name val=\"Calibri\"/></font></fonts><fills count=\"2\"><fill><patternFill patternType=\"none\"/></fill><fill><patternFill patternType=\"gray125\"/></fill></fills><borders count=\"1\"><border><left/><right/><top/><bottom/><diagonal/></border></borders><cellStyleXfs count=\"1\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\"/></cellStyleXfs><cellXfs count=\"4\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\"/><xf numFmtId=\"0\" fontId=\"1\" fillId=\"0\" borderId=\"0\" xfId=\"0\" applyFont=\"1\"/><xf numFmtId=\"164\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\" applyNumberFormat=\"1\"/><xf numFmtId=\"165\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\" applyNumberFormat=\"1\"/></cellXfs><cellStyles count=\"1\"><cellStyle name=\"Normal\" xfId=\"0\" builtinId=\"0\"/></cellStyles></styleSheet>");

            var e2 = zip.CreateEntry("xl/worksheets/sheet1.xml", CompressionLevel.Optimal);
            using var xw = XmlWriter.Create(e2.Open(), new XmlWriterSettings { Encoding = new UTF8Encoding(false), CheckCharacters = false });
            xw.WriteStartDocument(true);
            xw.WriteStartElement("worksheet", "http://schemas.openxmlformats.org/spreadsheetml/2006/main");
            xw.WriteStartElement("sheetData");
            int row = 1;
            void Text(int r, string v, int style) { xw.WriteStartElement("row"); xw.WriteAttributeString("r", r.ToString()); xw.WriteStartElement("c"); xw.WriteAttributeString("r", "A" + r); xw.WriteAttributeString("t", "inlineStr"); xw.WriteAttributeString("s", style.ToString()); xw.WriteStartElement("is"); xw.WriteElementString("t", Clean(v)); xw.WriteEndElement(); xw.WriteEndElement(); xw.WriteEndElement(); }
            Text(row++, t.Title, 1); Text(row++, "Scope: " + t.Scope, 0); Text(row++, $"Generated {t.GeneratedAtUtc:yyyy-MM-dd HH:mm} UTC by {t.GeneratedBy}", 0); row++;
            xw.WriteStartElement("row"); xw.WriteAttributeString("r", row.ToString());
            for (int c = 0; c < t.Columns.Count; c++) { xw.WriteStartElement("c"); xw.WriteAttributeString("r", Col(c) + row); xw.WriteAttributeString("t", "inlineStr"); xw.WriteAttributeString("s", "1"); xw.WriteStartElement("is"); xw.WriteElementString("t", Clean(t.Columns[c].Title)); xw.WriteEndElement(); xw.WriteEndElement(); }
            xw.WriteEndElement(); row++;
            foreach (var r in t.Rows)
            {
                xw.WriteStartElement("row"); xw.WriteAttributeString("r", row.ToString());
                for (int c = 0; c < t.Columns.Count; c++)
                {
                    var v = c < r.Length ? r[c] : null; if (v == null) continue; var type = t.Columns[c].Type;
                    xw.WriteStartElement("c"); xw.WriteAttributeString("r", Col(c) + row);
                    if (v is decimal or int or long or double)
                    {
                        xw.WriteAttributeString("s", type == "money" ? "2" : type == "weight" ? "3" : "0");
                        xw.WriteElementString("v", Convert.ToDecimal(v, CultureInfo.InvariantCulture).ToString(CultureInfo.InvariantCulture));
                    }
                    else { xw.WriteAttributeString("t", "inlineStr"); xw.WriteStartElement("is"); var text = Fmt(v, type); if (text.Length > 0 && text[0] is '=' or '+' or '@') text = "'" + text; xw.WriteElementString("t", Clean(text)); xw.WriteEndElement(); }
                    xw.WriteEndElement();
                }
                xw.WriteEndElement(); row++;
            }
            if (t.Totals.Count > 0) Text(row + 1, "Totals: " + string.Join("; ", t.Totals.Select(k => $"{k.Key}={k.Value.ToString("0.###", CultureInfo.InvariantCulture)}")), 1);
            xw.WriteEndElement(); xw.WriteEndElement(); xw.WriteEndDocument();
        }
        return ms.ToArray();
    }
    static string Col(int i) { var s = ""; i++; while (i > 0) { i--; s = (char)('A' + i % 26) + s; i /= 26; } return s; }
    static string Clean(string s) => new string(s.Where(ch => ch == '\t' || ch == '\n' || ch == '\r' || ch >= 0x20).ToArray());

    // ---------------- PDF (minimal tabular PDF; Latin-1 text, A4 landscape, Helvetica) ----------------
    public static byte[] Pdf(ReportTable t)
    {
        const double W = 842, H = 595, M = 28, FS = 7.5, LH = 10;
        var colW = ColumnWidths(t, W - 2 * M, FS);
        var pages = new List<string>(); var cur = new StringBuilder(); double y = H - M;
        void NewPage() { if (cur.Length > 0) pages.Add(cur.ToString()); cur.Clear(); y = H - M; }
        void Line(double x, string s, bool bold = false, double size = FS) { cur.Append($"BT /{(bold ? "F2" : "F1")} {size.ToString("0.#", CultureInfo.InvariantCulture)} Tf {x.ToString("0.#", CultureInfo.InvariantCulture)} {y.ToString("0.#", CultureInfo.InvariantCulture)} Td ({PdfEsc(s)}) Tj ET\n"); }
        void Header()
        {
            Line(M, t.Title, true, 12); y -= 14; Line(M, "Scope: " + t.Scope, false, 8); y -= 10;
            Line(M, $"Generated {t.GeneratedAtUtc:yyyy-MM-dd HH:mm} UTC by {t.GeneratedBy}", false, 8); y -= 14;
            double x = M; for (int c = 0; c < t.Columns.Count; c++) { Line(x, Trunc(t.Columns[c].Title, colW[c], FS), true); x += colW[c]; }
            y -= 3; cur.Append($"{M} {y.ToString("0.#", CultureInfo.InvariantCulture)} m {(W - M).ToString("0.#", CultureInfo.InvariantCulture)} {y.ToString("0.#", CultureInfo.InvariantCulture)} l S\n"); y -= LH;
        }
        Header();
        foreach (var r in t.Rows)
        {
            if (y < M + LH) { NewPage(); Header(); }
            double x = M;
            for (int c = 0; c < t.Columns.Count; c++)
            {
                var txt = Trunc(Fmt(c < r.Length ? r[c] : null, t.Columns[c].Type), colW[c], FS);
                var right = t.Columns[c].Type is "money" or "number" or "weight";
                Line(right ? x + colW[c] - TextW(txt, FS) - 4 : x, txt); x += colW[c];
            }
            y -= LH;
        }
        if (t.Totals.Count > 0) { if (y < M + 2 * LH) { NewPage(); Header(); } y -= 4; Line(M, "Totals: " + string.Join("   ", t.Totals.Select(k => $"{k.Key}: {k.Value.ToString("N2", CultureInfo.InvariantCulture)}")), true, 8); }
        if (t.Truncated) { y -= LH; Line(M, "Result truncated - narrow the filters for the full set.", false, 8); }
        NewPage();

        var objs = new List<string>();   // 1 catalog, 2 pages, 3 F1, 4 F2, then (page, content) pairs
        var kids = new StringBuilder();
        for (int i = 0; i < pages.Count; i++) kids.Append($"{5 + i * 2} 0 R ");
        objs.Add("<< /Type /Catalog /Pages 2 0 R >>");
        objs.Add($"<< /Type /Pages /Kids [{kids}] /Count {pages.Count} >>");
        objs.Add("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>");
        objs.Add("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>");
        for (int i = 0; i < pages.Count; i++)
        {
            var content = pages[i] + $"BT /F1 7 Tf {M} 14 Td (Page {i + 1} of {pages.Count}) Tj ET\n";
            objs.Add($"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 {W} {H}] /Resources << /Font << /F1 3 0 R /F2 4 0 R >> >> /Contents {6 + i * 2} 0 R >>");
            objs.Add($"<< /Length {Encoding.Latin1.GetByteCount(content)} >>\nstream\n{content}endstream");
        }
        using var ms = new MemoryStream(); var offs = new List<int>();
        void Put(string s) { var b = Encoding.Latin1.GetBytes(s); ms.Write(b, 0, b.Length); }
        Put("%PDF-1.4\n");
        for (int i = 0; i < objs.Count; i++) { offs.Add((int)ms.Length); Put($"{i + 1} 0 obj\n{objs[i]}\nendobj\n"); }
        var xref = (int)ms.Length;
        Put($"xref\n0 {objs.Count + 1}\n0000000000 65535 f \n"); foreach (var o in offs) Put($"{o:D10} 00000 n \n");
        Put($"trailer\n<< /Size {objs.Count + 1} /Root 1 0 R >>\nstartxref\n{xref}\n%%EOF");
        return ms.ToArray();
    }

    static double TextW(string s, double fs) => s.Length * fs * 0.52;
    static string Trunc(string s, double width, double fs) { var max = Math.Max(1, (int)((width - 4) / (fs * 0.52))); return s.Length <= max ? s : s[..Math.Max(0, max - 1)] + "~"; }
    static double[] ColumnWidths(ReportTable t, double total, double fs)
    {
        var w = new double[t.Columns.Count];
        for (int c = 0; c < w.Length; c++)
        {
            var longest = Math.Max(t.Columns[c].Title.Length, t.Rows.Take(200).Select(r => c < r.Length ? Fmt(r[c], t.Columns[c].Type).Length : 0).DefaultIfEmpty(0).Max());
            w[c] = Math.Clamp(longest, 4, 28) * fs * 0.52 + 6;
        }
        var sum = w.Sum(); if (sum > total) for (int c = 0; c < w.Length; c++) w[c] *= total / sum;
        return w;
    }
    static string PdfEsc(string s)
    {
        var sb = new StringBuilder();
        foreach (var ch in s) { if (ch == '(' || ch == ')' || ch == '\\') sb.Append('\\').Append(ch); else if (ch < 32) sb.Append(' '); else if (ch > 255) sb.Append('?'); else sb.Append(ch); }
        return sb.ToString();
    }
}
