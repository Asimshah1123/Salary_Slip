using Erp.Domain;

namespace Erp.Infrastructure;

/// <summary>Per-request data scope read by the DbContext global query filters (company + permitted branches).</summary>
public sealed class DbScope
{
    public bool Bypass { get; set; }                       // system work only: seeding, background jobs
    public long CompanyId { get; set; }
    public long UserId { get; set; }
    public long[] AllowedBranchIds { get; set; } = Array.Empty<long>();
}

/// <summary>Everything the server knows about the signed-in user. Resolved server-side on every request, never trusted from the client.</summary>
public sealed class UserContext
{
    public long UserId { get; init; }
    public string UserName { get; init; } = "";
    public string FullName { get; init; } = "";
    public long CompanyId { get; init; }
    public long? EmployeeId { get; init; }
    public long? WorkerId { get; init; }
    public long? DefaultBranchId { get; init; }
    public HashSet<string> Permissions { get; init; } = new();
    public HashSet<long> RoleIds { get; init; } = new();
    public HashSet<long> BranchIds { get; init; } = new();
    public long? ActiveBranchId { get; set; }
    public bool AllBranchesSelected { get; set; }
    public string? Ip { get; set; }
    public string? CorrelationId { get; set; }
    public string Stamp { get; init; } = "";

    /// <summary>Owner/Manager labels never bypass: only explicit permissions count (SRS 18.4).</summary>
    public bool Has(string permission) => Permissions.Contains(permission);
    public bool CanSeeAllBranches => Has(Perms.BranchesViewAll) || Has(Perms.ReportsConsolidated);

    public void Require(string permission)
    {
        if (!Has(permission)) throw new ForbiddenException($"Missing permission {permission}.", permission);
    }
    public void RequireAny(params string[] permissions)
    {
        if (!permissions.Any(Has)) throw new ForbiddenException($"Missing permission {string.Join(" or ", permissions)}.", permissions[0]);
    }

    public void RequireBranch(long branchId)
    {
        if (!BranchIds.Contains(branchId)) throw new ForbiddenException("You do not have access to that branch.", "branch", branchId);
    }

    /// <summary>The branch a new document is posted to: the validated active branch (or the explicit one if permitted).</summary>
    public long PostingBranch(long? requested = null)
    {
        var b = requested ?? ActiveBranchId ?? DefaultBranchId ?? throw new DomainException("No active branch selected.", "no_branch");
        RequireBranch(b);
        return b;
    }

    /// <summary>Branch ids for list/report queries. Explicit ids must all be permitted; empty = active selection or all permitted when authorised.</summary>
    public long[] ResolveScope(IEnumerable<long>? requested = null)
    {
        var req = requested?.Distinct().ToArray() ?? Array.Empty<long>();
        if (req.Length > 0)
        {
            foreach (var b in req) RequireBranch(b);
            return req;
        }
        if (AllBranchesSelected && CanSeeAllBranches) return BranchIds.ToArray();
        if (ActiveBranchId is long a && BranchIds.Contains(a)) return new[] { a };
        return DefaultBranchId is long d && BranchIds.Contains(d) ? new[] { d } : BranchIds.Take(1).ToArray();
    }
}

/// <summary>Scoped holder populated by the authentication middleware.</summary>
public sealed class CurrentUser
{
    UserContext? _value;
    public UserContext? Value => _value;
    public UserContext Ctx => _value ?? throw new UnauthorizedException("Authentication required.");
    public bool IsAuthenticated => _value != null;
    public void Set(UserContext u) => _value = u;
}

public interface IClock { DateTime UtcNow { get; } }
public sealed class SystemClock : IClock { public DateTime UtcNow => DateTime.UtcNow; }

public interface IFileStorage
{
    Task<string> SaveAsync(Stream content, string extension, CancellationToken ct = default);   // returns random storage key
    Task<Stream?> OpenReadAsync(string key, CancellationToken ct = default);
    Task DeleteAsync(string key, CancellationToken ct = default);
}

public interface IMalwareScanner { Task<ScanResult> ScanAsync(byte[] content, CancellationToken ct = default); }
public sealed record ScanResult(bool Clean, string? Signature);

// ---- Exceptions mapped to HTTP statuses by the API error middleware ----
public class AppException : Exception { public string Code { get; } public AppException(string m, string code) : base(m) { Code = code; } }
public sealed class ForbiddenException : AppException
{
    public object? Target { get; }
    public ForbiddenException(string m, string code = "forbidden", object? target = null) : base(m, code) { Target = target; }
}
public sealed class UnauthorizedException : AppException { public UnauthorizedException(string m) : base(m, "unauthorized") { } }
public sealed class NotFoundException : AppException { public NotFoundException(string what) : base($"{what} was not found.", "not_found") { } }
public sealed class ConflictException : AppException { public ConflictException(string m, string code = "conflict") : base(m, code) { } }
public sealed class ValidationFailedException : AppException
{
    public IReadOnlyDictionary<string, string[]> Errors { get; }
    public ValidationFailedException(IDictionary<string, string[]> errors) : base("One or more validation errors occurred.", "validation") { Errors = new Dictionary<string, string[]>(errors); }
    public ValidationFailedException(string field, string message) : this(new Dictionary<string, string[]> { [field] = new[] { message } }) { }
}
