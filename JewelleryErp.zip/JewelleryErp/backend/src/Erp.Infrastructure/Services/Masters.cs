using System.Linq.Expressions;
using System.Reflection;
using System.Text.Json;
using Erp.Domain;
using Erp.Domain.Calc;
using Erp.Domain.Entities;
using Erp.Infrastructure.Contracts;
using Erp.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;

namespace Erp.Infrastructure.Services;

public static class QueryExt
{
    /// <summary>Sorting through an allow-list of property names only (SRS 9.1).</summary>
    public static IQueryable<T> OrderByProp<T>(this IQueryable<T> q, string? name, bool desc, IEnumerable<string> allowed, string fallback)
    {
        var pick = allowed.FirstOrDefault(a => string.Equals(a, name, StringComparison.OrdinalIgnoreCase)) ?? fallback;
        var p = Expression.Parameter(typeof(T), "x");
        var body = Expression.Convert(Expression.Property(p, pick), typeof(object));
        // EF cannot translate Convert(object) for ordering on all providers, so build a strongly typed key selector
        var prop = typeof(T).GetProperty(pick)!;
        var lambda = Expression.Lambda(Expression.Property(p, pick), p);
        var method = typeof(Queryable).GetMethods().First(m => m.Name == (desc ? "OrderByDescending" : "OrderBy") && m.GetParameters().Length == 2).MakeGenericMethod(typeof(T), prop.PropertyType);
        return (IQueryable<T>)method.Invoke(null, new object[] { q, lambda })!;
    }
}

public sealed class AccessGuard
{
    readonly ErpDbContext _db; readonly AuditService _audit;
    public AccessGuard(ErpDbContext db, AuditService audit) { _db = db; _audit = audit; }

    /// <summary>Scoped lookup by id. A record that exists but lies outside the user's company/branch scope returns the same 404 as a missing one, and the attempt is audited.</summary>
    public async Task<T> Find<T>(IQueryable<T> scoped, long id, string what) where T : Entity
    {
        var e = await scoped.FirstOrDefaultAsync(x => x.Id == id);
        if (e != null) return e;
        if (await _db.Set<T>().IgnoreQueryFilters().AnyAsync(x => x.Id == id))
            await _audit.Save("Access.Denied", typeof(T).Name, id, reason: "Out-of-scope record requested by id", denied: true);
        throw new NotFoundException(what);
    }
}

// ====================================================================================================
// Generic master data (customers, suppliers, units, ...) - whitelisted, permission-gated, projected to dictionaries (no entity leakage)
// ====================================================================================================
public interface IMasterHandler
{
    string Route { get; }
    Task<PagedResult<Dictionary<string, object?>>> List(PageQuery q, bool? active);
    Task<Dictionary<string, object?>> Get(long id);
    Task<Dictionary<string, object?>> Save(long? id, JsonElement body);
    Task SetActive(long id, bool active);
    Task<IReadOnlyList<Lookup>> Lookups(string? search, int take);
}

public sealed class MasterHandler<T> : IMasterHandler where T : CompanyEntity, new()
{
    public string Route { get; }
    readonly ErpDbContext _db; readonly CurrentUser _cu; readonly AuditService _audit; readonly AccessGuard _guard; readonly NumberingService _num;
    readonly string _viewPerm, _editPerm;
    readonly Func<string, Expression<Func<T, bool>>> _search;
    readonly Func<T, Lookup> _lookup;
    readonly string[] _sortable;
    readonly string _defaultSort;
    readonly HashSet<string> _hidden;
    readonly Func<T, bool, Task>? _before;
    readonly (string prop, string perm)[] _gated;
    static readonly HashSet<string> Protected = new() { "Id", "CompanyId", "CreatedBy", "CreatedAtUtc", "ModifiedBy", "ModifiedAtUtc", "RowVersion" };

    public MasterHandler(string route, ErpDbContext db, CurrentUser cu, AuditService audit, AccessGuard guard, NumberingService num, string viewPerm, string editPerm,
        Func<string, Expression<Func<T, bool>>> search, Func<T, Lookup> lookup, string defaultSort, string[] sortable,
        Func<T, bool, Task>? before = null, string[]? hidden = null, (string prop, string perm)[]? gated = null)
    {
        Route = route; _db = db; _cu = cu; _audit = audit; _guard = guard; _num = num; _viewPerm = viewPerm; _editPerm = editPerm; _search = search; _lookup = lookup;
        _defaultSort = defaultSort; _sortable = sortable; _before = before; _hidden = new HashSet<string>(hidden ?? Array.Empty<string>()); _gated = gated ?? Array.Empty<(string, string)>();
    }

    IQueryable<T> Q(bool? active)
    {
        IQueryable<T> q = _db.Set<T>();
        var ap = typeof(T).GetProperty("IsActive");
        if (active != null && ap != null && ap.PropertyType == typeof(bool))
        {
            var p = Expression.Parameter(typeof(T), "x");
            var eq = Expression.Equal(Expression.Property(p, "IsActive"), Expression.Constant(active.Value));
            q = q.Where(Expression.Lambda<Func<T, bool>>(eq, p));
        }
        return q;
    }

    public async Task<PagedResult<Dictionary<string, object?>>> List(PageQuery pq, bool? active)
    {
        var u = _cu.Ctx; u.Require(_viewPerm);
        var q = Q(active);
        if (!string.IsNullOrWhiteSpace(pq.Search)) q = q.Where(_search(pq.Search.Trim()));
        var total = await q.CountAsync();
        var items = await q.OrderByProp(pq.Sort, pq.Desc, _sortable, _defaultSort).Skip(pq.Skip).Take(pq.Take).AsNoTracking().ToListAsync();
        return new PagedResult<Dictionary<string, object?>>(items.Select(Project).ToList(), total, pq.Page, pq.Take);
    }

    public async Task<Dictionary<string, object?>> Get(long id)
    {
        _cu.Ctx.Require(_viewPerm);
        return Project(await _guard.Find(_db.Set<T>(), id, typeof(T).Name));
    }

    public async Task<IReadOnlyList<Lookup>> Lookups(string? search, int take)
    {
        _cu.Ctx.Require(_viewPerm);
        var q = Q(true);
        if (!string.IsNullOrWhiteSpace(search)) q = q.Where(_search(search.Trim()));
        var rows = await q.OrderByProp(null, false, _sortable, _defaultSort).Take(Math.Clamp(take, 1, 200)).AsNoTracking().ToListAsync();
        return rows.Select(_lookup).ToList();
    }

    public async Task<Dictionary<string, object?>> Save(long? id, JsonElement body)
    {
        var u = _cu.Ctx; u.Require(_editPerm);
        if (body.ValueKind != JsonValueKind.Object) throw new ValidationFailedException("body", "A JSON object is required.");
        T e; Dictionary<string, object?>? before = null; bool isNew = id == null;
        if (isNew) { e = new T { CompanyId = u.CompanyId }; _db.Set<T>().Add(e); }
        else { e = await _guard.Find(_db.Set<T>(), id!.Value, typeof(T).Name); before = Project(e); }

        var errors = new Dictionary<string, string[]>();
        foreach (var p in typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance))
        {
            if (!p.CanWrite || Protected.Contains(p.Name) || (p.PropertyType != typeof(string) && typeof(System.Collections.IEnumerable).IsAssignableFrom(p.PropertyType))) continue;
            var el = body.EnumerateObject().FirstOrDefault(o => string.Equals(o.Name, p.Name, StringComparison.OrdinalIgnoreCase));
            if (el.Value.ValueKind == JsonValueKind.Undefined) continue;
            var gate = _gated.FirstOrDefault(g => g.prop == p.Name);
            if (gate.prop != null && !u.Has(gate.perm)) continue;
            try { p.SetValue(e, JsonConvert.To(el.Value, p.PropertyType)); }
            catch (Exception ex) when (ex is FormatException or InvalidOperationException or OverflowException or ArgumentException) { errors[p.Name] = new[] { $"Invalid value for {p.Name}." }; }
        }
        if (errors.Count > 0) throw new ValidationFailedException(errors);
        if (e is IBranchScoped bs && bs.BranchId != 0) u.RequireBranch(bs.BranchId);
        if (_before != null) await _before(e, isNew);
        foreach (var p in typeof(T).GetProperties().Where(p => p.PropertyType == typeof(string) && p.Name is "Name" or "Code" or "Label"))
            if (p.GetValue(e) is string s && string.IsNullOrWhiteSpace(s) && p.Name != "Code") errors[p.Name] = new[] { $"{p.Name} is required." };
        if (errors.Count > 0) throw new ValidationFailedException(errors);

        try { await _db.SaveChangesAsync(); }
        catch (DbUpdateException ex) when (ex.ToString().Contains("duplicate", StringComparison.OrdinalIgnoreCase) || ex.ToString().Contains("UNIQUE", StringComparison.OrdinalIgnoreCase))
        { throw new ConflictException("A record with the same code/name already exists.", "duplicate"); }
        await _audit.Save(isNew ? $"{typeof(T).Name}.Created" : $"{typeof(T).Name}.Updated", typeof(T).Name, e.Id, before, Project(e));
        return Project(e);
    }

    public async Task SetActive(long id, bool active)
    {
        _cu.Ctx.Require(_editPerm);
        var e = await _guard.Find(_db.Set<T>(), id, typeof(T).Name);
        var p = typeof(T).GetProperty("IsActive") ?? throw new DomainException("This record cannot be deactivated.");
        p.SetValue(e, active);   // soft delete only; history stays intact
        await _audit.Save(active ? $"{typeof(T).Name}.Activated" : $"{typeof(T).Name}.Deactivated", typeof(T).Name, id);
    }

    Dictionary<string, object?> Project(T e)
    {
        var d = new Dictionary<string, object?>();
        var u = _cu.Ctx;
        foreach (var p in typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance))
        {
            if (p.Name is "CompanyId" or "CreatedBy" or "ModifiedBy" or "RowVersion" || _hidden.Contains(p.Name)) continue;
            if (p.PropertyType != typeof(string) && typeof(System.Collections.IEnumerable).IsAssignableFrom(p.PropertyType)) continue;
            var gate = _gated.FirstOrDefault(g => g.prop == p.Name);
            if (gate.prop != null && !u.Has(gate.perm)) continue;   // restricted fields are removed, not blanked
            d[char.ToLowerInvariant(p.Name[0]) + p.Name[1..]] = p.GetValue(e);
        }
        return d;
    }
}

static class JsonConvert
{
    public static object? To(JsonElement v, Type t)
    {
        var nullable = Nullable.GetUnderlyingType(t);
        var target = nullable ?? t;
        if (v.ValueKind == JsonValueKind.Null)
        {
            if (nullable != null || !target.IsValueType) return null;
            throw new FormatException("null not allowed");
        }
        if (target == typeof(string)) return v.ValueKind == JsonValueKind.String ? v.GetString()?.Trim() : v.ToString();
        if (target == typeof(bool)) return v.ValueKind == JsonValueKind.String ? bool.Parse(v.GetString()!) : v.GetBoolean();
        if (target == typeof(long)) return v.ValueKind == JsonValueKind.String ? long.Parse(v.GetString()!) : v.GetInt64();
        if (target == typeof(int)) return v.ValueKind == JsonValueKind.String ? int.Parse(v.GetString()!) : v.GetInt32();
        if (target == typeof(decimal)) return v.ValueKind == JsonValueKind.String ? decimal.Parse(v.GetString()!, System.Globalization.CultureInfo.InvariantCulture) : v.GetDecimal();
        if (target == typeof(DateTime)) return DateTime.Parse(v.GetString()!, System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.AdjustToUniversal | System.Globalization.DateTimeStyles.AssumeUniversal);
        if (target.IsEnum) return v.ValueKind == JsonValueKind.String ? Enum.Parse(target, v.GetString()!, true) : Enum.ToObject(target, v.GetInt32());
        throw new InvalidOperationException($"Unsupported type {target.Name}");
    }
}

public sealed class MasterRegistry
{
    readonly Dictionary<string, IMasterHandler> _h;
    public MasterRegistry(ErpDbContext db, CurrentUser cu, AuditService audit, AccessGuard guard, NumberingService num, PostingEngine posting)
    {
        async Task<string> Code(string prefix) => await num.Next(prefix, cu.Ctx.PostingBranch(), 5);
        var list = new List<IMasterHandler>
        {
            new MasterHandler<Customer>("customers", db, cu, audit, guard, num, Perms.CustomersView, Perms.CustomersEdit,
                s => x => x.Name.Contains(s) || (x.Phone != null && x.Phone.Contains(s)) || x.Code.Contains(s) || (x.WhatsApp != null && x.WhatsApp.Contains(s)),
                x => new Lookup(x.Id, x.Name, x.Code, x.Phone), "Name", new[] { "Name", "Code", "Phone", "City", "CreatedAtUtc" },
                before: async (e, isNew) => { if (isNew && string.IsNullOrWhiteSpace(e.Code)) e.Code = await Code("CUS"); },
                gated: new[] { ("Cnic", Perms.CustomersSensitive) }),
            new MasterHandler<Supplier>("suppliers", db, cu, audit, guard, num, Perms.SuppliersView, Perms.SuppliersEdit,
                s => x => x.Name.Contains(s) || (x.Phone != null && x.Phone.Contains(s)) || x.Code.Contains(s),
                x => new Lookup(x.Id, x.Name, x.Code, x.Phone), "Name", new[] { "Name", "Code", "Phone", "City" },
                before: async (e, isNew) => { if (isNew && string.IsNullOrWhiteSpace(e.Code)) e.Code = await Code("SUP"); }),
            new MasterHandler<Employee>("employees", db, cu, audit, guard, num, Perms.EmployeesView, Perms.EmployeesManage,
                s => x => x.Name.Contains(s) || x.Code.Contains(s) || (x.JobTitle != null && x.JobTitle.Contains(s)),
                x => new Lookup(x.Id, x.Name, x.Code, x.JobTitle), "Name", new[] { "Name", "Code", "JobTitle", "HireDate" },
                before: async (e, isNew) => { if (isNew && string.IsNullOrWhiteSpace(e.Code)) e.Code = await Code("EMP"); }, hidden: new[] { "BaseSalary" }, gated: new[] { ("BaseSalary", Perms.EmployeesManage) }),
            new MasterHandler<Worker>("workers", db, cu, audit, guard, num, Perms.WorkersView, Perms.WorkersManage,
                s => x => x.Name.Contains(s) || x.Code.Contains(s) || (x.Phone != null && x.Phone.Contains(s)),
                x => new Lookup(x.Id, x.Name, x.Code, x.Skills), "Name", new[] { "Name", "Code", "Phone" },
                before: async (e, isNew) => { if (isNew && string.IsNullOrWhiteSpace(e.Code)) e.Code = await Code("WRK"); }),
            new MasterHandler<SalesmanProfile>("salesman-profiles", db, cu, audit, guard, num, Perms.EmployeesView, Perms.EmployeesManage,
                s => x => x.EmployeeId.ToString() == s, x => new Lookup(x.Id, "Employee #" + x.EmployeeId, null, x.CommissionType.ToString()), "EmployeeId", new[] { "EmployeeId" }),
            new MasterHandler<ProductCategory>("categories", db, cu, audit, guard, num, Perms.ProductsView, Perms.MastersManage,
                s => x => x.Name.Contains(s), x => new Lookup(x.Id, x.Name), "Name", new[] { "Name" }),
            new MasterHandler<MetalType>("metals", db, cu, audit, guard, num, Perms.ProductsView, Perms.MastersManage,
                s => x => x.Name.Contains(s) || x.Code.Contains(s), x => new Lookup(x.Id, x.Name, x.Code), "Name", new[] { "Name", "Code" },
                before: (e, n) => { e.Code = (e.Code ?? "").Trim().ToUpperInvariant(); return Task.CompletedTask; }),
            new MasterHandler<Purity>("purities", db, cu, audit, guard, num, Perms.ProductsView, Perms.MastersManage,
                s => x => x.Label.Contains(s), x => new Lookup(x.Id, x.Label, x.MetalTypeId.ToString(), x.Factor.ToString("0.######")), "Label", new[] { "Label", "Karat", "Factor" },
                before: (e, n) =>
                {
                    if (e.MetalTypeId == 0) throw new ValidationFailedException("metalTypeId", "Metal type is required.");
                    if (e.Factor <= 0 && e.Karat > 0) e.Factor = WeightCalc.KaratFactor(e.Karat);   // conventional default; editable per shop assay rules
                    if (e.Factor <= 0 || e.Factor > 1) throw new ValidationFailedException("factor", "Purity factor must be between 0 and 1.");
                    if (string.IsNullOrWhiteSpace(e.Label)) e.Label = e.Karat > 0 ? $"{e.Karat:0.##}K" : "";
                    return Task.CompletedTask;
                }),
            new MasterHandler<Unit>("units", db, cu, audit, guard, num, Perms.ProductsView, Perms.SettingsManage, s => x => x.Name.Contains(s) || x.Code.Contains(s), x => new Lookup(x.Id, x.Name, x.Code), "Name", new[] { "Name", "Code" }),
            new MasterHandler<StoneType>("stone-types", db, cu, audit, guard, num, Perms.ProductsView, Perms.MastersManage, s => x => x.Name.Contains(s), x => new Lookup(x.Id, x.Name), "Name", new[] { "Name" }),
            new MasterHandler<ExpenseHead>("expense-heads", db, cu, audit, guard, num, Perms.FinanceView, Perms.FinanceAccountsManage, s => x => x.Name.Contains(s), x => new Lookup(x.Id, x.Name), "Name", new[] { "Name" }),
            new MasterHandler<PaymentMethod>("payment-methods", db, cu, audit, guard, num, Perms.SalesView, Perms.FinanceAccountsManage, s => x => x.Name.Contains(s), x => new Lookup(x.Id, x.Name, x.Kind, x.DefaultAccountId?.ToString()), "Name", new[] { "Name", "Kind" }),
            new MasterHandler<StoreLocation>("locations", db, cu, audit, guard, num, Perms.InventoryView, Perms.BranchesManage, s => x => x.Name.Contains(s) || x.Code.Contains(s), x => new Lookup(x.Id, x.Name, x.Code, x.BranchId.ToString()), "Name", new[] { "Name", "Code", "BranchId" }),
            new MasterHandler<CashBankAccount>("cash-bank-accounts", db, cu, audit, guard, num, Perms.FinanceView, Perms.FinanceAccountsManage, s => x => x.Name.Contains(s), x => new Lookup(x.Id, x.Name, x.Type.ToString(), x.BranchId?.ToString()), "Name", new[] { "Name", "Type" },
                before: async (e, isNew) =>
                {
                    if (!isNew || e.ChartAccountId != null) return;
                    var prefix = e.Type == CashBankType.Cash ? "100" : "101";
                    var n = await db.ChartAccounts.CountAsync(a => a.Code.StartsWith(prefix));
                    var ca = new ChartAccount { CompanyId = cu.Ctx.CompanyId, Code = prefix + n, Name = (e.Type == CashBankType.Cash ? "Cash - " : "Bank - ") + e.Name, Type = AccountType.Asset };
                    db.ChartAccounts.Add(ca); await db.SaveChangesAsync();
                    e.ChartAccountId = ca.Id;
                }),
            new MasterHandler<ChartAccount>("chart-accounts", db, cu, audit, guard, num, Perms.FinanceView, Perms.FinanceAccountsManage, s => x => x.Name.Contains(s) || x.Code.Contains(s), x => new Lookup(x.Id, x.Name, x.Code, x.Type.ToString()), "Code", new[] { "Code", "Name", "Type" },
                before: (e, n) => { if (!n && e.IsControl) throw new DomainException("Control accounts are posted by the system only.", "control_account"); return Task.CompletedTask; }),
        };
        _h = list.ToDictionary(h => h.Route);
    }
    public IMasterHandler Get(string route) => _h.TryGetValue(route, out var h) ? h : throw new NotFoundException("Master '" + route + "'");
    public IEnumerable<string> Routes => _h.Keys;
}

// ====================================================================================================
// Gold rates (SRS 2.3)
// ====================================================================================================
public sealed class GoldRateItem { public long PurityId { get; set; } public decimal BuyRate { get; set; } public decimal SellRate { get; set; } }
public sealed class GoldRateInput
{
    public long MetalTypeId { get; set; }
    public long? BranchId { get; set; }
    public DateTime? EffectiveFromUtc { get; set; }
    public List<GoldRateItem> Items { get; set; } = new();
    public string? Reason { get; set; }
    public bool IsOverride { get; set; }
}
public sealed record GoldRateDto(long Id, long MetalTypeId, string Metal, long PurityId, string Purity, long? BranchId, decimal BuyRate, decimal SellRate, DateTime EffectiveFromUtc, string? Reason, bool IsOverride, string? ChangedBy);

public sealed class GoldRateService
{
    readonly ErpDbContext _db; readonly CurrentUser _cu; readonly AuditService _audit; readonly RateService _rates;
    public GoldRateService(ErpDbContext db, CurrentUser cu, AuditService audit, RateService rates) { _db = db; _cu = cu; _audit = audit; _rates = rates; }

    public async Task<List<GoldRateDto>> Set(GoldRateInput i)
    {
        var u = _cu.Ctx; u.Require(Perms.GoldRateEdit);
        if (i.Items.Count == 0) throw new ValidationFailedException("items", "Add at least one purity rate.");
        if (i.BranchId != null) u.RequireBranch(i.BranchId.Value);
        var at = i.EffectiveFromUtc ?? DateTime.UtcNow;
        if (at < DateTime.UtcNow.AddMinutes(-5) || i.IsOverride) { u.Require(Perms.GoldRateOverride); if (string.IsNullOrWhiteSpace(i.Reason)) throw new ValidationFailedException("reason", "A reason is mandatory for backdated or override rates."); }
        if (at > DateTime.UtcNow.AddDays(1)) throw new ValidationFailedException("effectiveFromUtc", "Rates can be scheduled at most one day ahead.");
        var metal = await _db.MetalTypes.AsNoTracking().FirstOrDefaultAsync(m => m.Id == i.MetalTypeId) ?? throw new NotFoundException("Metal type");
        var purities = await _db.Purities.AsNoTracking().Where(p => p.MetalTypeId == metal.Id).ToDictionaryAsync(p => p.Id, p => p);
        var created = new List<GoldRate>();
        foreach (var it in i.Items)
        {
            if (!purities.ContainsKey(it.PurityId)) throw new ValidationFailedException("items", "Purity does not belong to the selected metal.");
            if (it.BuyRate <= 0 || it.SellRate <= 0) throw new ValidationFailedException("items", "Rates must be greater than zero.");
            if (it.SellRate < it.BuyRate) throw new ValidationFailedException("items", "Selling rate cannot be below the buying rate.");
            var r = new GoldRate { CompanyId = u.CompanyId, MetalTypeId = metal.Id, PurityId = it.PurityId, BranchId = i.BranchId, BuyRate = Money.R2(it.BuyRate), SellRate = Money.R2(it.SellRate), EffectiveFromUtc = at, Reason = i.Reason, IsOverride = i.IsOverride };
            _db.GoldRates.Add(r); created.Add(r);
        }
        _audit.Add(i.IsOverride ? "GoldRate.Override" : "GoldRate.Set", "GoldRate", string.Join(",", i.Items.Select(x => x.PurityId)), after: i, reason: i.Reason, targetBranchId: i.BranchId);
        await _db.SaveChangesAsync();
        return created.Select(r => new GoldRateDto(r.Id, r.MetalTypeId, metal.Name, r.PurityId, purities[r.PurityId].Label, r.BranchId, r.BuyRate, r.SellRate, r.EffectiveFromUtc, r.Reason, r.IsOverride, u.UserName)).ToList();
    }

    /// <summary>Rates currently in force for a branch (branch-specific wins when it is the more recent).</summary>
    public async Task<List<GoldRateDto>> Current(long? branchId)
    {
        var u = _cu.Ctx; u.Require(Perms.GoldRateView);
        var b = u.PostingBranch(branchId);
        var purities = await _db.Purities.AsNoTracking().Where(p => p.IsActive).ToListAsync();
        var metals = await _db.MetalTypes.AsNoTracking().ToDictionaryAsync(m => m.Id, m => m.Name);
        var res = new List<GoldRateDto>();
        foreach (var p in purities.OrderBy(p => p.MetalTypeId).ThenByDescending(p => p.Karat))
        {
            try
            {
                var sell = await _rates.Resolve(p.MetalTypeId, p.Id, b, true);
                var buy = await _rates.Resolve(p.MetalTypeId, p.Id, b, false);
                res.Add(new GoldRateDto(sell.RateId ?? 0, p.MetalTypeId, metals.GetValueOrDefault(p.MetalTypeId, ""), p.Id, p.Label, sell.Policy == "Branch" ? b : null, buy.Rate, sell.Rate, sell.AtUtc ?? DateTime.UtcNow, null, sell.IsOverride, null));
            }
            catch (DomainException) { /* no rate yet for this purity */ }
        }
        return res;
    }

    public async Task<PagedResult<GoldRateDto>> History(PageQuery pq, long? metalTypeId, long? purityId, long? branchId, DateTime? from, DateTime? to)
    {
        var u = _cu.Ctx; u.Require(Perms.GoldRateView);
        var q = _db.GoldRates.AsNoTracking().AsQueryable();
        if (metalTypeId != null) q = q.Where(r => r.MetalTypeId == metalTypeId);
        if (purityId != null) q = q.Where(r => r.PurityId == purityId);
        if (branchId != null) { u.RequireBranch(branchId.Value); q = q.Where(r => r.BranchId == branchId); }
        else { var allowed = u.BranchIds.ToArray(); q = q.Where(r => r.BranchId == null || allowed.Contains(r.BranchId.Value)); }
        if (from != null) q = q.Where(r => r.EffectiveFromUtc >= from);
        if (to != null) q = q.Where(r => r.EffectiveFromUtc <= to);
        var total = await q.CountAsync();
        var rows = await q.OrderByDescending(r => r.EffectiveFromUtc).Skip(pq.Skip).Take(pq.Take).ToListAsync();
        var pids = rows.Select(r => r.PurityId).Distinct().ToList(); var mids = rows.Select(r => r.MetalTypeId).Distinct().ToList();
        var pur = await _db.Purities.AsNoTracking().Where(p => pids.Contains(p.Id)).ToDictionaryAsync(p => p.Id, p => p.Label);
        var met = await _db.MetalTypes.AsNoTracking().Where(m => mids.Contains(m.Id)).ToDictionaryAsync(m => m.Id, m => m.Name);
        var uids = rows.Where(r => r.CreatedBy != null).Select(r => r.CreatedBy!.Value).Distinct().ToList();
        var names = await _db.Users.AsNoTracking().Where(x => uids.Contains(x.Id)).ToDictionaryAsync(x => x.Id, x => x.UserName);
        return new PagedResult<GoldRateDto>(rows.Select(r => new GoldRateDto(r.Id, r.MetalTypeId, met.GetValueOrDefault(r.MetalTypeId, ""), r.PurityId, pur.GetValueOrDefault(r.PurityId, ""), r.BranchId, r.BuyRate, r.SellRate, r.EffectiveFromUtc, r.Reason, r.IsOverride, r.CreatedBy != null ? names.GetValueOrDefault(r.CreatedBy.Value) : null)).ToList(), total, pq.Page, pq.Take);
    }
}
