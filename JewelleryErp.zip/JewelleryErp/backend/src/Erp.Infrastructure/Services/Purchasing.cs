using Erp.Domain;
using Erp.Domain.Calc;
using Erp.Domain.Entities;
using Erp.Infrastructure.Contracts;
using Erp.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;

namespace Erp.Infrastructure.Services;

public sealed class PurchaseLineInput
{
    public long? ProductId { get; set; }
    public bool IsLooseMetal { get; set; }
    public string Description { get; set; } = "";
    public string? NewSku { get; set; }
    public long? CategoryId { get; set; }
    public long MetalTypeId { get; set; }
    public long PurityId { get; set; }
    public decimal Quantity { get; set; } = 1;
    public decimal GrossWeight { get; set; }
    public decimal StoneWeight { get; set; }
    public decimal OtherDeduction { get; set; }
    public decimal? Rate { get; set; }
    public decimal MakingCharges { get; set; }
    public decimal StoneValue { get; set; }
    public decimal OtherCharges { get; set; }
    public decimal TaxAmount { get; set; }
}
public sealed class PurchaseInput
{
    public long SupplierId { get; set; }
    public long? BranchId { get; set; }
    public string SupplierInvoiceNo { get; set; } = "";
    public DateTime? DateUtc { get; set; }
    public DateTime? ReceivedDateUtc { get; set; }
    public List<PurchaseLineInput> Lines { get; set; } = new();
    public List<PaymentInput> Payments { get; set; } = new();
    public string? Notes { get; set; }
    public bool PostNow { get; set; } = true;
    public string? IdempotencyKey { get; set; }
}
public sealed class ReceiveLineInput
{
    public long LineId { get; set; }
    public decimal ReceivedGrossWeight { get; set; }
    public decimal ReceivedStoneWeight { get; set; }
    public decimal ReceivedOtherDeduction { get; set; }
    public long? ReceivedPurityId { get; set; }
    public string? VarianceReason { get; set; }
    public long? TargetLocationId { get; set; }
}
public sealed class SupplierReturnLineInput { public long PurchaseInvoiceLineId { get; set; } public decimal Quantity { get; set; } }
public sealed class SupplierReturnInput { public string Reason { get; set; } = ""; public List<SupplierReturnLineInput> Lines { get; set; } = new(); public string? IdempotencyKey { get; set; } }
public sealed class SupplierPaymentInput
{
    public long SupplierId { get; set; }
    public long? BranchId { get; set; }
    public long PaymentMethodId { get; set; }
    public long? AccountId { get; set; }
    public decimal Amount { get; set; }
    public string? Reference { get; set; }
    public List<AllocationInput> Allocations { get; set; } = new();
    public string? IdempotencyKey { get; set; }
}
public sealed class AllocationInput { public long PurchaseInvoiceId { get; set; } public decimal Amount { get; set; } }

public sealed record PurchaseLineDto(long Id, int LineNo, long? ProductId, string Description, string? Sku, long MetalTypeId, long PurityId, string Purity, decimal Quantity, decimal Gross, decimal Stone, decimal Net, decimal Fine, decimal Rate,
    decimal MetalValue, decimal Making, decimal StoneValue, decimal Other, decimal Tax, decimal LineTotal, decimal? ReceivedGross, decimal? ReceivedNet, string? VarianceReason, decimal ReturnedQuantity);
public sealed record PurchaseDto(long Id, string Number, string SupplierInvoiceNo, DateTime DateUtc, long BranchId, DocStatus Status, long SupplierId, string Supplier, decimal Subtotal, decimal Tax, decimal Total, decimal Paid, decimal Due, bool Received,
    IReadOnlyList<PurchaseLineDto> Lines, IReadOnlyList<PaymentDto> Payments, string? Notes);
public sealed record PurchaseRow(long Id, string Number, string SupplierInvoiceNo, DateTime DateUtc, string Supplier, DocStatus Status, decimal Total, decimal Paid, decimal Due, bool Received);
public sealed record SupplierPaymentDto(long Id, string Number, long SupplierId, decimal Amount, decimal Allocated, decimal Unapplied, DocStatus Status);
public sealed class PurchaseQuery : PageQuery { public DateTime? From { get; set; } public DateTime? To { get; set; } public long[]? BranchIds { get; set; } public long? SupplierId { get; set; } public DocStatus? Status { get; set; } public bool? Received { get; set; } }

public sealed class PurchaseService
{
    readonly ErpDbContext _db; readonly CurrentUser _cu; readonly AuditService _audit; readonly NumberingService _num; readonly PostingEngine _post; readonly SettingsService _settings;
    readonly RateService _rates; readonly AccessGuard _guard; readonly ApprovalService _approvals;
    public PurchaseService(ErpDbContext db, CurrentUser cu, AuditService audit, NumberingService num, PostingEngine post, SettingsService settings, RateService rates, AccessGuard guard, ApprovalService approvals)
    { _db = db; _cu = cu; _audit = audit; _num = num; _post = post; _settings = settings; _rates = rates; _guard = guard; _approvals = approvals; }

    public async Task<PurchaseDto> Create(PurchaseInput i)
    {
        var u = _cu.Ctx; u.Require(Perms.PurchasesCreate);
        var branch = await _post.PostingBranch(i.BranchId);
        if (!string.IsNullOrWhiteSpace(i.IdempotencyKey))
        {
            var dup = await _db.PurchaseInvoices.AsNoTracking().FirstOrDefaultAsync(x => x.IdempotencyKey == i.IdempotencyKey);
            if (dup != null) return await Get(dup.Id);
        }
        if (i.Lines.Count == 0) throw new ValidationFailedException("lines", "Add at least one line.");
        if (string.IsNullOrWhiteSpace(i.SupplierInvoiceNo)) throw new ValidationFailedException("supplierInvoiceNo", "Supplier invoice number is required.");
        var date = i.DateUtc ?? DateTime.UtcNow;
        await _post.EnsureBackdating(date, branch);
        long id = 0;
        await _post.InTransaction(async () =>
        {
            var sup = await _guard.Find(_db.Suppliers.AsNoTracking(), i.SupplierId, "Supplier");
            if (await _db.PurchaseInvoices.AnyAsync(p => p.SupplierId == sup.Id && p.SupplierInvoiceNo == i.SupplierInvoiceNo && p.Status != DocStatus.Cancelled))
                throw new ConflictException("This supplier invoice number was already entered.", "duplicate");
            var inv = new PurchaseInvoice { CompanyId = u.CompanyId, BranchId = branch, Number = await _num.Next("PUR", branch), DocDateUtc = date, SupplierId = sup.Id, SupplierInvoiceNo = i.SupplierInvoiceNo.Trim(), ReceivedDateUtc = i.ReceivedDateUtc, Notes = i.Notes, IdempotencyKey = i.IdempotencyKey, Status = DocStatus.Draft, InspectionLocationId = await _post.DefaultLocation(branch, "Inspection") };
            int no = 1; decimal sub = 0, tax = 0;
            foreach (var l in i.Lines)
            {
                var pur = await _db.Purities.AsNoTracking().FirstOrDefaultAsync(p => p.Id == l.PurityId && p.MetalTypeId == l.MetalTypeId) ?? throw new ValidationFailedException("lines", "Purity does not match the metal.");
                if (l.Quantity <= 0) throw new ValidationFailedException("lines", "Quantity must be positive.");
                var net = WeightCalc.NetMetal(l.GrossWeight, l.StoneWeight, l.OtherDeduction);
                var rate = l.Rate ?? (await _rates.Resolve(l.MetalTypeId, l.PurityId, branch, selling: false)).Rate;
                var snap = l.Rate == null ? DateTime.UtcNow : (DateTime?)null;
                var metal = Money.R2(net * rate);
                var total = Money.R2(metal + l.MakingCharges + l.StoneValue + l.OtherCharges + l.TaxAmount);
                inv.Lines.Add(new PurchaseInvoiceLine { LineNo = no++, ProductId = l.IsLooseMetal ? null : l.ProductId, IsLooseMetal = l.IsLooseMetal, Description = l.Description, NewSku = l.NewSku, CategoryId = l.CategoryId, MetalTypeId = l.MetalTypeId, PurityId = l.PurityId, Quantity = l.Quantity, GrossWeight = l.GrossWeight, StoneWeight = l.StoneWeight, NetWeight = net, FineWeight = WeightCalc.Fine(net, pur.Factor), Rate = rate, RateTimestampUtc = snap, MetalValue = metal, MakingCharges = l.MakingCharges, StoneValue = l.StoneValue, OtherCharges = l.OtherCharges, TaxAmount = l.TaxAmount, LineTotal = total });
                sub += total - l.TaxAmount; tax += l.TaxAmount;
            }
            inv.Subtotal = Money.R2(sub); inv.TaxTotal = Money.R2(tax); inv.Total = Money.R2(sub + tax);
            var paid = i.Payments.Sum(p => p.Amount);
            if (i.Payments.Any(p => p.Amount <= 0) || paid > inv.Total) throw new ValidationFailedException("payments", "Payments must be positive and cannot exceed the invoice total.");
            foreach (var p in i.Payments) inv.Payments.Add(new PurchasePayment { PaymentMethodId = p.PaymentMethodId, AccountId = p.AccountId, Amount = Money.R2(p.Amount), Reference = p.Reference });
            inv.PaidTotal = Money.R2(paid); inv.DueTotal = Money.R2(inv.Total - paid);
            _db.PurchaseInvoices.Add(inv);
            await _db.SaveChangesAsync();
            id = inv.Id;
            _audit.Add("Purchase.Created", nameof(PurchaseInvoice), inv.Id, after: new { inv.Number, inv.Total }, targetBranchId: branch);
            if (i.PostNow) { u.Require(Perms.PurchasesPost); await PostInternal(inv, sup); }
            return 0;
        });
        return await Get(id);
    }

    public async Task<PurchaseDto> Post(long id)
    {
        _cu.Ctx.Require(Perms.PurchasesPost);
        await _post.InTransaction(async () =>
        {
            var inv = await _guard.Find(_db.PurchaseInvoices.Include(x => x.Lines).Include(x => x.Payments), id, "Purchase invoice");
            if (inv.Status != DocStatus.Draft) throw new ConflictException("Only draft purchase invoices can be posted.");
            await _post.PostingBranch(inv.BranchId);
            var sup = await _db.Suppliers.AsNoTracking().FirstAsync(s => s.Id == inv.SupplierId);
            await PostInternal(inv, sup);
            return 0;
        });
        return await Get(id);
    }

    async Task PostInternal(PurchaseInvoice inv, Supplier sup)
    {
        var u = _cu.Ctx;
        if (inv.Lines.Count == 0) inv = await _db.PurchaseInvoices.Include(x => x.Lines).Include(x => x.Payments).FirstAsync(x => x.Id == inv.Id);
        inv.Status = inv.DueTotal > 0 && inv.PaidTotal > 0 ? DocStatus.PartiallyPaid : DocStatus.Posted; inv.PostedBy = u.UserId; inv.PostedAtUtc = DateTime.UtcNow;
        foreach (var l in inv.Lines)
        {
            Product? p = null;
            if (l.IsLooseMetal) { }
            else if (l.ProductId != null) p = await _db.Products.FirstOrDefaultAsync(x => x.Id == l.ProductId) ?? throw new NotFoundException("Item");
            else
            {
                p = new Product
                {
                    CompanyId = u.CompanyId, Sku = string.IsNullOrWhiteSpace(l.NewSku) ? await _num.Next("SKU", inv.BranchId) : l.NewSku.Trim().ToUpperInvariant(), Name = string.IsNullOrWhiteSpace(l.Description) ? "Purchased item" : l.Description, CategoryId = l.CategoryId,
                    Tracking = l.Quantity == 1 ? TrackingMode.Serialized : TrackingMode.Quantity, MetalTypeId = l.MetalTypeId, PurityId = l.PurityId, GrossWeight = Money.R3(l.GrossWeight / l.Quantity), StoneWeight = Money.R3(l.StoneWeight / l.Quantity),
                    NetMetalWeight = Money.R3(l.NetWeight / l.Quantity), StoneValue = Money.R2(l.StoneValue / l.Quantity), CostPrice = Money.R2(l.LineTotal / l.Quantity), SupplierId = sup.Id, DefaultBranchId = inv.BranchId, PricingMode = PricingMode.MetalPlusMaking, MakingType = ChargeType.PerGram
                };
                p.Barcode = p.Sku;
                _db.Products.Add(p);
                await _db.SaveChangesAsync();
                l.ProductId = p.Id;
            }
            await _post.Move(new StockMoveSpec
            {
                RefType = TxnType.Purchase, RefId = inv.Id, RefNo = inv.Number, To = new StockLoc(inv.BranchId, inv.InspectionLocationId ?? await _post.DefaultLocation(inv.BranchId), StockStatus.InInspection), ProductId = p?.Id, MetalTypeId = l.MetalTypeId, PurityId = l.PurityId,
                Qty = l.IsLooseMetal ? 0 : l.Quantity, Gross = l.GrossWeight, Stone = l.StoneWeight, Net = l.NetWeight, Fine = l.FineWeight, Cost = l.LineTotal, Kind = "Receipt"   // not available until authorised receipt
            });
            var e = _post.Reg(TxnType.Purchase, inv, l.LineNo, PartyType.Supplier, sup.Id, sup.Name);
            e.ProductId = p?.Id; e.Sku = p?.Sku; e.ItemName = p?.Name ?? (string.IsNullOrWhiteSpace(l.Description) ? "Loose metal" : l.Description); e.MetalTypeId = l.MetalTypeId; e.PurityId = l.PurityId; e.Gross = l.GrossWeight; e.Stone = l.StoneWeight; e.Net = l.NetWeight; e.Fine = l.FineWeight; e.Rate = l.Rate; e.Making = l.MakingCharges; e.StoneValue = l.StoneValue; e.PkrDebit = l.LineTotal;
        }
        _post.Party(PartyType.Supplier, sup.Id, inv.BranchId, inv.DocDateUtc, TxnType.Purchase, inv.Id, inv.Number, "Purchase " + inv.SupplierInvoiceNo, 0, inv.Total);
        foreach (var p in inv.Payments) _post.Party(PartyType.Supplier, sup.Id, inv.BranchId, inv.DocDateUtc, TxnType.SupplierPayment, inv.Id, inv.Number, "Payment at purchase", p.Amount, 0);
        var j = new JournalBuilder().Dr(Acc.InvFinished, inv.Total, "Purchased stock (in inspection)");
        foreach (var p in inv.Payments) j.CrAcc(await _post.LedgerAccountFor(p.AccountId), p.Amount, "Paid to supplier");
        j.Cr(Acc.Payable, inv.DueTotal, "Supplier payable", PartyType.Supplier, sup.Id);
        await _post.Journal(j, TxnType.Purchase, inv.Id, inv.Number, inv.BranchId, inv.DocDateUtc, "Purchase " + inv.Number);
        _audit.Add("Purchase.Posted", nameof(PurchaseInvoice), inv.Id, after: new { inv.Number, inv.Total, inv.PaidTotal }, targetBranchId: inv.BranchId);
    }

    /// <summary>Authorised receipt: measured weights/purity are compared with the supplier invoice; variance beyond tolerance needs a reason AND the variance-approve permission.</summary>
    public async Task<PurchaseDto> Receive(long id, List<ReceiveLineInput> lines)
    {
        var u = _cu.Ctx; u.Require(Perms.PurchasesReceive);
        if (lines.Count == 0) throw new ValidationFailedException("lines", "Enter the measured weights for at least one line.");
        await _post.InTransaction(async () =>
        {
            var inv = await _guard.Find(_db.PurchaseInvoices.Include(x => x.Lines), id, "Purchase invoice");
            if (inv.Status is DocStatus.Draft or DocStatus.Cancelled or DocStatus.Reversed) throw new ConflictException("Post the invoice before receiving stock.");
            u.RequireBranch(inv.BranchId);
            var tol = await _settings.Dec(SettingsService.Keys.PurchaseTolGrams, inv.BranchId);
            foreach (var r in lines)
            {
                var l = inv.Lines.FirstOrDefault(x => x.Id == r.LineId) ?? throw new ValidationFailedException("lines", "Line does not belong to this invoice.");
                if (l.ReceivedNetWeight != null) throw new ConflictException($"Line {l.LineNo} has already been received.");
                var purId = r.ReceivedPurityId ?? l.PurityId;
                var pur = await _db.Purities.AsNoTracking().FirstOrDefaultAsync(p => p.Id == purId && p.MetalTypeId == l.MetalTypeId) ?? throw new ValidationFailedException("lines", "Received purity does not match the metal.");
                var net = WeightCalc.NetMetal(r.ReceivedGrossWeight, r.ReceivedStoneWeight, r.ReceivedOtherDeduction);
                var diff = Money.R3(net - l.NetWeight);
                var purityDiff = purId != l.PurityId;
                if (Math.Abs(diff) > tol || purityDiff)
                {
                    if (string.IsNullOrWhiteSpace(r.VarianceReason)) throw new ValidationFailedException("lines", $"Line {l.LineNo}: a variance reason is mandatory ({(purityDiff ? "purity differs" : $"weight differs by {diff}g")}).");
                    u.Require(Perms.PurchasesVarianceApprove);
                    _audit.Add("Purchase.VarianceAccepted", nameof(PurchaseInvoice), inv.Id, before: new { l.NetWeight, l.PurityId }, after: new { net, purId }, reason: r.VarianceReason, targetBranchId: inv.BranchId);
                }
                l.ReceivedGrossWeight = r.ReceivedGrossWeight; l.ReceivedNetWeight = net; l.ReceivedPurityId = purId; l.VarianceReason = r.VarianceReason;
                var fine = WeightCalc.Fine(net, pur.Factor);
                var target = r.TargetLocationId ?? await _post.DefaultLocation(inv.BranchId);
                var insp = inv.InspectionLocationId ?? await _post.DefaultLocation(inv.BranchId, "Inspection");
                // move the invoiced quantity out of inspection; any measured difference is posted as an explicit variance adjustment
                await _post.Move(new StockMoveSpec
                {
                    RefType = TxnType.PurchaseReceipt, RefId = inv.Id, RefNo = inv.Number, From = new StockLoc(inv.BranchId, insp, StockStatus.InInspection), To = new StockLoc(inv.BranchId, target, StockStatus.Available), ProductId = l.ProductId, MetalTypeId = l.MetalTypeId, PurityId = l.PurityId,
                    Qty = l.IsLooseMetal ? 0 : l.Quantity, Gross = l.GrossWeight, Stone = l.StoneWeight, Net = l.NetWeight, Fine = l.FineWeight, Cost = l.LineTotal, Kind = "Move", Reason = "Authorised receipt"
                });
                if (l.ProductId != null)
                {
                    var p = await _db.Products.FirstAsync(x => x.Id == l.ProductId);
                    var per = l.Quantity == 0 ? 1 : l.Quantity;
                    var changed = p.NetMetalWeight != Money.R3(net / per) || p.PurityId != purId;
                    if (changed && (p.Tracking == TrackingMode.Serialized || await _db.StockMovements.CountAsync(m => m.ProductId == p.Id) <= 2))
                    { p.GrossWeight = Money.R3(r.ReceivedGrossWeight / per); p.StoneWeight = Money.R3(r.ReceivedStoneWeight / per); p.NetMetalWeight = Money.R3(net / per); p.PurityId = purId; }   // the tag follows the measured truth
                }
                var e = _post.Reg(TxnType.PurchaseReceipt, inv, l.LineNo, PartyType.Supplier, inv.SupplierId, await _post.PartyName(PartyType.Supplier, inv.SupplierId));
                e.ProductId = l.ProductId; e.MetalTypeId = l.MetalTypeId; e.PurityId = purId; e.Gross = r.ReceivedGrossWeight; e.Stone = r.ReceivedStoneWeight; e.Net = net; e.Fine = fine; e.ItemName = l.Description; e.LinkedDocId = inv.Id; e.LinkedDocType = "PurchaseInvoice"; e.LinkedDocNo = inv.Number;
            }
            inv.Received = inv.Lines.All(l => l.ReceivedNetWeight != null);
            if (inv.Received) inv.ReceivedDateUtc = DateTime.UtcNow;
            _audit.Add("Purchase.Received", nameof(PurchaseInvoice), inv.Id, after: new { lines = lines.Count, inv.Received }, targetBranchId: inv.BranchId);
            return 0;
        });
        return await Get(id);
    }

    public async Task<ReturnDto> SupplierReturn(long invoiceId, SupplierReturnInput i)
    {
        var u = _cu.Ctx; u.Require(Perms.PurchasesReturn);
        if (string.IsNullOrWhiteSpace(i.Reason)) throw new ValidationFailedException("reason", "A return reason is required.");
        if (!string.IsNullOrWhiteSpace(i.IdempotencyKey))
        {
            var dup = await _db.SupplierReturns.AsNoTracking().FirstOrDefaultAsync(x => x.IdempotencyKey == i.IdempotencyKey);
            if (dup != null) return new ReturnDto(dup.Id, dup.Number, dup.PurchaseInvoiceId, dup.Status, dup.Total, 0, 0, dup.Reason, null);
        }
        long rid = 0;
        await _post.InTransaction(async () =>
        {
            var inv = await _guard.Find(_db.PurchaseInvoices.Include(x => x.Lines), invoiceId, "Purchase invoice");
            if (inv.Status is DocStatus.Draft or DocStatus.Cancelled or DocStatus.Reversed) throw new ConflictException("Only posted purchases can be returned.");
            await _post.PostingBranch(inv.BranchId);
            var ret = new SupplierReturn { CompanyId = u.CompanyId, BranchId = inv.BranchId, Number = await _num.Next("SPR", inv.BranchId), DocDateUtc = DateTime.UtcNow, SupplierId = inv.SupplierId, PurchaseInvoiceId = inv.Id, Reason = i.Reason, IdempotencyKey = i.IdempotencyKey, Status = DocStatus.Posted, PostedBy = u.UserId, PostedAtUtc = DateTime.UtcNow };
            var supName = await _post.PartyName(PartyType.Supplier, inv.SupplierId);
            _db.SupplierReturns.Add(ret);
            await _db.SaveChangesAsync();   // the return needs its id before stock movements / register rows reference it
            decimal total = 0; int no = 1;
            foreach (var rl in i.Lines)
            {
                var l = inv.Lines.FirstOrDefault(x => x.Id == rl.PurchaseInvoiceLineId) ?? throw new ValidationFailedException("lines", "Line does not belong to this invoice.");
                if (rl.Quantity <= 0 || rl.Quantity + l.ReturnedQuantity > l.Quantity) throw new ValidationFailedException("lines", $"Line {l.LineNo}: only {l.Quantity - l.ReturnedQuantity} can be returned.");
                var share = rl.Quantity / l.Quantity; var amt = Money.R2(l.LineTotal * share);
                var status = l.ReceivedNetWeight == null ? StockStatus.InInspection : StockStatus.Available;
                var needNet = Money.R3(l.NetWeight * share);
                var bal = (l.IsLooseMetal
                              ? await _db.StockBalances.Where(b => b.BranchId == inv.BranchId && b.ProductId == null && b.MetalTypeId == l.MetalTypeId && b.PurityId == l.PurityId && b.Status == status && b.Ownership == Ownership.Shop && b.NetWeight >= needNet).FirstOrDefaultAsync()
                              : await _db.StockBalances.Where(b => b.BranchId == inv.BranchId && b.ProductId == l.ProductId && b.Status == status && b.Quantity >= rl.Quantity).FirstOrDefaultAsync())
                          ?? throw new DomainException($"Line {l.LineNo}: the item is no longer in stock (sold or moved) and cannot be returned to the supplier.", "return_stock_missing");
                await _post.Move(new StockMoveSpec { RefType = TxnType.SupplierReturn, RefId = ret.Id, RefNo = ret.Number, From = new StockLoc(inv.BranchId, bal.LocationId, status), ProductId = l.ProductId, MetalTypeId = l.MetalTypeId, PurityId = l.PurityId, Qty = l.IsLooseMetal ? 0 : rl.Quantity, Gross = Money.R3(l.GrossWeight * share), Stone = Money.R3(l.StoneWeight * share), Net = Money.R3(l.NetWeight * share), Fine = Money.R3(l.FineWeight * share), Cost = amt, Kind = "Issue", Reason = i.Reason });
                l.ReturnedQuantity += rl.Quantity; total += amt;
                ret.Lines.Add(new SupplierReturnLine { PurchaseInvoiceLineId = l.Id, ProductId = l.ProductId, Quantity = rl.Quantity, NetWeight = Money.R3(l.NetWeight * share), Amount = amt });
                var e = _post.Reg(TxnType.SupplierReturn, ret, no++, PartyType.Supplier, inv.SupplierId, supName);
                e.ProductId = l.ProductId; e.Net = Money.R3(l.NetWeight * share); e.MetalTypeId = l.MetalTypeId; e.PurityId = l.PurityId; e.ItemName = l.Description; e.PkrCredit = amt; e.LinkedDocId = inv.Id; e.LinkedDocType = "PurchaseInvoice"; e.LinkedDocNo = inv.Number;
            }
            ret.Total = Money.R2(total);
            await _db.SaveChangesAsync();
            _post.Party(PartyType.Supplier, inv.SupplierId, inv.BranchId, ret.DocDateUtc, TxnType.SupplierReturn, ret.Id, ret.Number, "Returned to supplier", ret.Total, 0, true);
            var dueDrop = Math.Min(ret.Total, inv.DueTotal);
            inv.DueTotal = Money.R2(inv.DueTotal - dueDrop);
            // value that was already paid becomes a supplier credit (advance) on the ledger
            var j = new JournalBuilder().Dr(Acc.Payable, ret.Total, "Supplier return", PartyType.Supplier, inv.SupplierId).Cr(Acc.InvFinished, ret.Total, "Stock returned to supplier");
            await _post.Journal(j, TxnType.SupplierReturn, ret.Id, ret.Number, inv.BranchId, ret.DocDateUtc, "Supplier return " + ret.Number, true);
            _audit.Add("Purchase.SupplierReturn", nameof(SupplierReturn), ret.Id, after: new { ret.Number, ret.Total }, reason: i.Reason, targetBranchId: inv.BranchId);
            rid = ret.Id;
            return 0;
        });
        var r2 = await _db.SupplierReturns.AsNoTracking().FirstAsync(x => x.Id == rid);
        return new ReturnDto(r2.Id, r2.Number, r2.PurchaseInvoiceId, r2.Status, r2.Total, 0, 0, r2.Reason, null);
    }

    /// <summary>Supplier payment that can settle one or several invoices; whatever is not allocated stays visible as supplier credit (advance).</summary>
    public async Task<SupplierPaymentDto> Pay(SupplierPaymentInput i)
    {
        var u = _cu.Ctx; u.Require(Perms.FinancePaymentPost);
        var branch = await _post.PostingBranch(i.BranchId);
        if (i.Amount <= 0) throw new ValidationFailedException("amount", "Amount must be positive.");
        if (!string.IsNullOrWhiteSpace(i.IdempotencyKey))
        {
            var dup = await _db.SupplierPayments.AsNoTracking().FirstOrDefaultAsync(x => x.IdempotencyKey == i.IdempotencyKey);
            if (dup != null) return new SupplierPaymentDto(dup.Id, dup.Number, dup.SupplierId, dup.Amount, dup.AllocatedAmount, dup.UnappliedAmount, dup.Status);
        }
        long pid = 0;
        await _post.InTransaction(async () =>
        {
            var sup = await _guard.Find(_db.Suppliers.AsNoTracking(), i.SupplierId, "Supplier");
            var alloc = i.Allocations.Sum(a => a.Amount);
            if (alloc > i.Amount || i.Allocations.Any(a => a.Amount <= 0)) throw new ValidationFailedException("allocations", "Allocations must be positive and cannot exceed the payment.");
            var pay = new SupplierPayment { CompanyId = u.CompanyId, BranchId = branch, Number = await _num.Next("SPY", branch), DocDateUtc = DateTime.UtcNow, SupplierId = sup.Id, PaymentMethodId = i.PaymentMethodId, AccountId = i.AccountId, Amount = Money.R2(i.Amount), Reference = i.Reference, IdempotencyKey = i.IdempotencyKey, Status = DocStatus.Posted, PostedBy = u.UserId, PostedAtUtc = DateTime.UtcNow };
            foreach (var a in i.Allocations)
            {
                var inv = await _db.PurchaseInvoices.FirstOrDefaultAsync(p => p.Id == a.PurchaseInvoiceId && p.SupplierId == sup.Id) ?? throw new ValidationFailedException("allocations", "Invoice not found for this supplier.");
                if (a.Amount > inv.DueTotal) throw new ValidationFailedException("allocations", $"{inv.Number}: allocation exceeds the outstanding {inv.DueTotal:N2}.");
                inv.PaidTotal = Money.R2(inv.PaidTotal + a.Amount); inv.DueTotal = Money.R2(inv.DueTotal - a.Amount);
                inv.Status = inv.DueTotal == 0 ? DocStatus.Posted : DocStatus.PartiallyPaid;
                pay.Allocations.Add(new PaymentAllocation { PurchaseInvoiceId = inv.Id, Amount = Money.R2(a.Amount) });
            }
            pay.AllocatedAmount = Money.R2(alloc); pay.UnappliedAmount = Money.R2(i.Amount - alloc);
            _db.SupplierPayments.Add(pay);
            await _db.SaveChangesAsync();
            _post.Party(PartyType.Supplier, sup.Id, branch, pay.DocDateUtc, TxnType.SupplierPayment, pay.Id, pay.Number, "Payment" + (pay.UnappliedAmount > 0 ? " (incl. advance)" : ""), pay.Amount, 0);
            var j = new JournalBuilder().Dr(Acc.Payable, pay.Amount, "Supplier payment", PartyType.Supplier, sup.Id).CrAcc(await _post.LedgerAccountFor(i.AccountId), pay.Amount, "Paid");
            await _post.Journal(j, TxnType.SupplierPayment, pay.Id, pay.Number, branch, pay.DocDateUtc, "Supplier payment " + pay.Number);
            var e = _post.Reg(TxnType.SupplierPayment, pay, 1, PartyType.Supplier, sup.Id, sup.Name); e.PkrDebit = pay.Amount; e.ItemName = "Supplier payment";
            _audit.Add("SupplierPayment.Posted", nameof(SupplierPayment), pay.Id, after: new { pay.Number, pay.Amount, pay.UnappliedAmount }, targetBranchId: branch);
            pid = pay.Id;
            return 0;
        });
        var p2 = await _db.SupplierPayments.AsNoTracking().FirstAsync(x => x.Id == pid);
        return new SupplierPaymentDto(p2.Id, p2.Number, p2.SupplierId, p2.Amount, p2.AllocatedAmount, p2.UnappliedAmount, p2.Status);
    }

    public async Task<PagedResult<PurchaseRow>> List(PurchaseQuery q)
    {
        var u = _cu.Ctx; u.Require(Perms.PurchasesView);
        var branches = u.ResolveScope(q.BranchIds);
        var s = _db.PurchaseInvoices.AsNoTracking().Where(x => branches.Contains(x.BranchId));
        if (q.From != null) s = s.Where(x => x.DocDateUtc >= q.From);
        if (q.To != null) s = s.Where(x => x.DocDateUtc < q.To.Value.AddDays(1));
        if (q.SupplierId != null) s = s.Where(x => x.SupplierId == q.SupplierId);
        if (q.Status != null) s = s.Where(x => x.Status == q.Status);
        if (q.Received != null) s = s.Where(x => x.Received == q.Received);
        if (!string.IsNullOrWhiteSpace(q.Search)) { var t = q.Search.Trim(); s = s.Where(x => x.Number.Contains(t) || x.SupplierInvoiceNo.Contains(t)); }
        var total = await s.CountAsync();
        var rows = await s.OrderByProp(q.Sort, q.Desc || q.Sort == null, new[] { "DocDateUtc", "Number", "Total", "Status" }, "DocDateUtc").Skip(q.Skip).Take(q.Take).ToListAsync();
        var sids = rows.Select(r => r.SupplierId).Distinct().ToList();
        var names = await _db.Suppliers.AsNoTracking().Where(x => sids.Contains(x.Id)).ToDictionaryAsync(x => x.Id, x => x.Name);
        return new PagedResult<PurchaseRow>(rows.Select(r => new PurchaseRow(r.Id, r.Number, r.SupplierInvoiceNo, r.DocDateUtc, names.GetValueOrDefault(r.SupplierId, ""), r.Status, r.Total, r.PaidTotal, r.DueTotal, r.Received)).ToList(), total, q.Page, q.Take,
            new Dictionary<string, decimal> { ["total"] = await s.SumAsync(x => x.Total), ["due"] = await s.SumAsync(x => x.DueTotal) });
    }

    public async Task<PurchaseDto> Get(long id)
    {
        _cu.Ctx.Require(Perms.PurchasesView);
        var inv = await _guard.Find(_db.PurchaseInvoices.AsNoTracking().Include(x => x.Lines).Include(x => x.Payments), id, "Purchase invoice");
        var sup = await _db.Suppliers.AsNoTracking().Where(s => s.Id == inv.SupplierId).Select(s => s.Name).FirstOrDefaultAsync() ?? "";
        var pur = await _db.Purities.AsNoTracking().ToDictionaryAsync(p => p.Id, p => p.Label);
        var pm = await _db.PaymentMethods.AsNoTracking().ToDictionaryAsync(m => m.Id, m => m.Name);
        var pids = inv.Lines.Where(l => l.ProductId != null).Select(l => l.ProductId!.Value).ToList();
        var skus = await _db.Products.AsNoTracking().Where(p => pids.Contains(p.Id)).ToDictionaryAsync(p => p.Id, p => p.Sku);
        return new PurchaseDto(inv.Id, inv.Number, inv.SupplierInvoiceNo, inv.DocDateUtc, inv.BranchId, inv.Status, inv.SupplierId, sup, inv.Subtotal, inv.TaxTotal, inv.Total, inv.PaidTotal, inv.DueTotal, inv.Received,
            inv.Lines.OrderBy(l => l.LineNo).Select(l => new PurchaseLineDto(l.Id, l.LineNo, l.ProductId, l.Description, l.ProductId != null ? skus.GetValueOrDefault(l.ProductId.Value) : null, l.MetalTypeId, l.PurityId, pur.GetValueOrDefault(l.PurityId, ""), l.Quantity, l.GrossWeight, l.StoneWeight, l.NetWeight, l.FineWeight, l.Rate, l.MetalValue, l.MakingCharges, l.StoneValue, l.OtherCharges, l.TaxAmount, l.LineTotal, l.ReceivedGrossWeight, l.ReceivedNetWeight, l.VarianceReason, l.ReturnedQuantity)).ToList(),
            inv.Payments.Select(p => new PaymentDto(p.PaymentMethodId, pm.GetValueOrDefault(p.PaymentMethodId, ""), p.AccountId, p.Amount, p.Reference)).ToList(), inv.Notes);
    }

    /// <summary>Supplier credit = payments (and returns) not yet matched to invoices.</summary>
    public async Task<decimal> SupplierCredit(long supplierId)
    {
        _cu.Ctx.RequireAny(Perms.SuppliersLedger, Perms.PurchasesView);
        await _guard.Find(_db.Suppliers.AsNoTracking(), supplierId, "Supplier");
        return await _db.SupplierPayments.AsNoTracking().Where(p => p.SupplierId == supplierId && p.Status == DocStatus.Posted).SumAsync(p => p.UnappliedAmount);
    }
}
