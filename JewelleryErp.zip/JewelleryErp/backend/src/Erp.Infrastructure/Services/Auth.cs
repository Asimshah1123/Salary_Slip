using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using System.IdentityModel.Tokens.Jwt;
using Erp.Domain;
using Erp.Domain.Entities;
using Erp.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;

namespace Erp.Infrastructure.Services;

public sealed class JwtOptions
{
    public string Issuer { get; set; } = "jewellery-erp";
    public string Audience { get; set; } = "jewellery-erp-web";
    public string Key { get; set; } = "";               // base64, >= 32 bytes; from secret store / environment, never source control
    public int AccessMinutes { get; set; } = 15;
    public int RefreshDays { get; set; } = 14;
    public int MaxFailedLogins { get; set; } = 5;
    public int LockoutMinutes { get; set; } = 15;
}

/// <summary>PBKDF2-HMAC-SHA256 with a per-user random salt (never reversible encryption).</summary>
public static class PasswordHasher
{
    public const int DefaultIterations = 600_000;
    public static (string hash, string salt, int iterations) Hash(string password, int iterations = DefaultIterations)
    {
        var salt = RandomNumberGenerator.GetBytes(16);
        var h = Rfc2898DeriveBytes.Pbkdf2(Encoding.UTF8.GetBytes(password), salt, iterations, HashAlgorithmName.SHA256, 32);
        return (Convert.ToBase64String(h), Convert.ToBase64String(salt), iterations);
    }
    public static bool Verify(string password, string hash, string salt, int iterations)
    {
        var expected = Convert.FromBase64String(hash);
        var actual = Rfc2898DeriveBytes.Pbkdf2(Encoding.UTF8.GetBytes(password), Convert.FromBase64String(salt), iterations, HashAlgorithmName.SHA256, expected.Length);
        return CryptographicOperations.FixedTimeEquals(expected, actual);
    }
    public static void Validate(string password)
    {
        var errs = new List<string>();
        if (password.Length < 10) errs.Add("at least 10 characters");
        if (!password.Any(char.IsLetter)) errs.Add("a letter");
        if (!password.Any(char.IsDigit)) errs.Add("a digit");
        if (errs.Count > 0) throw new ValidationFailedException("password", "Password needs " + string.Join(", ", errs) + ".");
    }
}

public interface IEmailSender { Task SendAsync(string to, string subject, string body, CancellationToken ct = default); }

/// <summary>Default sender: logs only the fact of sending (never the token). Replace with SMTP/SMS in production.</summary>
public sealed class LoggingEmailSender : IEmailSender
{
    readonly ILogger<LoggingEmailSender> _log;
    public LoggingEmailSender(ILogger<LoggingEmailSender> log) { _log = log; }
    public Task SendAsync(string to, string subject, string body, CancellationToken ct = default)
    {
        _log.LogInformation("Email queued to {To}: {Subject}", to, subject);
        return Task.CompletedTask;
    }
}

public sealed record UserProfile(long Id, string UserName, string FullName, string Email, string Language, long? DefaultBranchId, long? EmployeeId, long? WorkerId,
                                 IReadOnlyList<BranchRef> Branches, IReadOnlyList<string> Permissions, IReadOnlyList<string> Roles, bool MustChangePassword);
public sealed record BranchRef(long Id, string Code, string Name, bool IsActive);
public sealed record AuthResult(string AccessToken, DateTime ExpiresUtc, string RefreshToken, DateTime RefreshExpiresUtc, UserProfile User);

public sealed class UserAccessLoader
{
    readonly ErpDbContext _db; readonly IMemoryCache _cache;
    public UserAccessLoader(ErpDbContext db, IMemoryCache cache) { _db = db; _cache = cache; }
    public static string Key(long userId) => $"uctx:{userId}";
    public void Invalidate(long userId) => _cache.Remove(Key(userId));

    /// <summary>Loads roles, permissions and branch grants from the DB (short server-side cache). Returns null if the user is inactive.</summary>
    public async Task<UserContext?> Load(long userId)
    {
        if (_cache.TryGetValue(Key(userId), out UserContext? hit) && hit != null) return Clone(hit);
        var u = await _db.Users.AsNoTracking().IgnoreQueryFilters().FirstOrDefaultAsync(x => x.Id == userId);
        if (u == null || !u.IsActive) return null;
        var roleIds = await _db.UserRoles.AsNoTracking().Where(r => r.UserId == userId).Select(r => r.RoleId).Distinct().ToListAsync();
        var activeRoles = await _db.Roles.AsNoTracking().IgnoreQueryFilters().Where(r => roleIds.Contains(r.Id) && r.IsActive).Select(r => r.Id).ToListAsync();
        var perms = await (from rp in _db.RolePermissions.AsNoTracking() join p in _db.Permissions.AsNoTracking() on rp.PermissionId equals p.Id where activeRoles.Contains(rp.RoleId) select p.Code).Distinct().ToListAsync();
        var grants = await _db.UserBranchAccess.AsNoTracking().Where(b => b.UserId == userId && b.IsActive).Select(b => new { b.BranchId, b.IsDefault }).ToListAsync();
        var branchIds = grants.Select(g => g.BranchId).ToHashSet();
        var def = grants.FirstOrDefault(g => g.IsDefault)?.BranchId ?? u.DefaultBranchId ?? grants.FirstOrDefault()?.BranchId;
        var ctx = new UserContext
        {
            UserId = u.Id, UserName = u.UserName, FullName = u.FullName, CompanyId = u.CompanyId, EmployeeId = u.EmployeeId, WorkerId = u.WorkerId, DefaultBranchId = def,
            Permissions = perms.ToHashSet(), RoleIds = activeRoles.ToHashSet(), BranchIds = branchIds, Stamp = u.SecurityStamp
        };
        _cache.Set(Key(userId), ctx, TimeSpan.FromSeconds(30));
        return Clone(ctx);
    }

    static UserContext Clone(UserContext c) => new()
    {
        UserId = c.UserId, UserName = c.UserName, FullName = c.FullName, CompanyId = c.CompanyId, EmployeeId = c.EmployeeId, WorkerId = c.WorkerId, DefaultBranchId = c.DefaultBranchId,
        Permissions = c.Permissions, RoleIds = c.RoleIds, BranchIds = c.BranchIds, Stamp = c.Stamp
    };
}

public sealed class AuthService
{
    readonly ErpDbContext _db; readonly JwtOptions _jwt; readonly IClock _clock; readonly UserAccessLoader _access; readonly IEmailSender _email; readonly ILogger<AuthService> _log;
    static readonly (string h, string s, int i) Dummy = PasswordHasher.Hash("dummy-password-for-timing", 100_000);

    public AuthService(ErpDbContext db, IOptions<JwtOptions> jwt, IClock clock, UserAccessLoader access, IEmailSender email, ILogger<AuthService> log)
    { _db = db; _jwt = jwt.Value; _clock = clock; _access = access; _email = email; _log = log; }

    public async Task<AuthResult> Login(string userOrEmail, string password, string? ip, string? device)
    {
        var key = (userOrEmail ?? "").Trim().ToLowerInvariant();
        var user = string.IsNullOrEmpty(key) ? null : await _db.Users.IgnoreQueryFilters().FirstOrDefaultAsync(u => u.UserName.ToLower() == key || u.Email.ToLower() == key);
        var now = _clock.UtcNow;
        const string generic = "Invalid username or password.";   // never reveals which part was wrong

        if (user == null)
        {
            PasswordHasher.Verify(password ?? "", Dummy.h, Dummy.s, Dummy.i);   // equalise timing
            _db.LoginAttempts.Add(new LoginAttempt { UserNameOrEmail = key, Succeeded = false, Ip = ip, DeviceInfo = device, AtUtc = now });
            await _db.SaveChangesAsync();
            throw new UnauthorizedException(generic);
        }
        if (user.LockoutUntilUtc != null && user.LockoutUntilUtc > now)
        {
            _db.LoginAttempts.Add(new LoginAttempt { UserNameOrEmail = key, UserId = user.Id, Succeeded = false, Ip = ip, DeviceInfo = device, AtUtc = now });
            await _db.SaveChangesAsync();
            throw new UnauthorizedException(generic);
        }
        var ok = user.IsActive && PasswordHasher.Verify(password ?? "", user.PasswordHash, user.PasswordSalt, user.HashIterations);
        _db.LoginAttempts.Add(new LoginAttempt { UserNameOrEmail = key, UserId = user.Id, Succeeded = ok, Ip = ip, DeviceInfo = device, AtUtc = now });
        if (!ok)
        {
            user.FailedLoginCount++;
            if (user.FailedLoginCount >= _jwt.MaxFailedLogins) { user.LockoutUntilUtc = now.AddMinutes(_jwt.LockoutMinutes); user.FailedLoginCount = 0; }
            await _db.SaveChangesAsync();
            throw new UnauthorizedException(generic);
        }
        user.FailedLoginCount = 0; user.LockoutUntilUtc = null; user.LastLoginUtc = now;
        // opportunistic hash upgrade when iteration policy increases
        if (user.HashIterations < PasswordHasher.DefaultIterations)
        { var (h, s, i) = PasswordHasher.Hash(password!); user.PasswordHash = h; user.PasswordSalt = s; user.HashIterations = i; }
        var result = await Issue(user, Guid.NewGuid().ToString("N"), ip, device);
        await _db.SaveChangesAsync();
        return result;
    }

    async Task<AuthResult> Issue(AppUser user, string familyId, string? ip, string? device)
    {
        var now = _clock.UtcNow;
        var (token, exp) = CreateAccessToken(user, now);
        var raw = Convert.ToBase64String(RandomNumberGenerator.GetBytes(48)).Replace('+', '-').Replace('/', '_').TrimEnd('=');
        var rt = new RefreshToken { UserId = user.Id, TokenHash = Hash(raw), FamilyId = familyId, CreatedUtc = now, ExpiresUtc = now.AddDays(_jwt.RefreshDays), CreatedByIp = ip, DeviceInfo = device };
        _db.RefreshTokens.Add(rt);
        var profile = await Profile(user.Id) ?? throw new UnauthorizedException("User is not available.");
        return new AuthResult(token, exp, raw, rt.ExpiresUtc, profile);
    }

    (string token, DateTime exp) CreateAccessToken(AppUser u, DateTime now)
    {
        if (string.IsNullOrWhiteSpace(_jwt.Key)) throw new InvalidOperationException("Jwt:Key is not configured.");
        var key = new SymmetricSecurityKey(Convert.FromBase64String(_jwt.Key));
        var exp = now.AddMinutes(_jwt.AccessMinutes);
        var claims = new List<Claim>
        {
            new(JwtRegisteredClaimNames.Sub, u.Id.ToString()), new(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString("N")),
            new("uname", u.UserName), new("cid", u.CompanyId.ToString()), new("stamp", u.SecurityStamp)
        };
        var jwt = new JwtSecurityToken(_jwt.Issuer, _jwt.Audience, claims, now, exp, new SigningCredentials(key, SecurityAlgorithms.HmacSha256));
        return (new JwtSecurityTokenHandler().WriteToken(jwt), exp);
    }

    public async Task<AuthResult> Refresh(string rawToken, string? ip, string? device)
    {
        var h = Hash(rawToken ?? "");
        var rt = await _db.RefreshTokens.FirstOrDefaultAsync(r => r.TokenHash == h) ?? throw new UnauthorizedException("Session expired.");
        var now = _clock.UtcNow;
        if (rt.RevokedUtc != null)
        {
            // a rotated token was replayed: treat as theft and revoke the whole family
            var family = await _db.RefreshTokens.Where(r => r.FamilyId == rt.FamilyId && r.RevokedUtc == null).ToListAsync();
            foreach (var f in family) f.RevokedUtc = now;
            await _db.SaveChangesAsync();
            _log.LogWarning("Refresh token reuse detected for user {UserId}", rt.UserId);
            throw new UnauthorizedException("Session expired.");
        }
        if (rt.ExpiresUtc <= now) throw new UnauthorizedException("Session expired.");
        var user = await _db.Users.IgnoreQueryFilters().FirstOrDefaultAsync(u => u.Id == rt.UserId);
        if (user == null || !user.IsActive) throw new UnauthorizedException("Session expired.");
        var result = await Issue(user, rt.FamilyId, ip, device);
        rt.RevokedUtc = now; rt.ReplacedByHash = Hash(result.RefreshToken);
        await _db.SaveChangesAsync();
        return result;
    }

    public async Task Logout(string? rawToken)
    {
        if (string.IsNullOrEmpty(rawToken)) return;
        var h = Hash(rawToken);
        var rt = await _db.RefreshTokens.FirstOrDefaultAsync(r => r.TokenHash == h);
        if (rt == null) return;
        var family = await _db.RefreshTokens.Where(r => r.FamilyId == rt.FamilyId && r.RevokedUtc == null).ToListAsync();
        foreach (var f in family) f.RevokedUtc = _clock.UtcNow;
        await _db.SaveChangesAsync();
    }

    public async Task ForgotPassword(string email)
    {
        var e = (email ?? "").Trim().ToLowerInvariant();
        var user = await _db.Users.IgnoreQueryFilters().FirstOrDefaultAsync(u => u.Email.ToLower() == e && u.IsActive);
        if (user == null) return;   // same response either way
        var raw = Convert.ToHexString(RandomNumberGenerator.GetBytes(32)).ToLowerInvariant();
        _db.PasswordResetTokens.Add(new PasswordResetToken { UserId = user.Id, TokenHash = Hash(raw), ExpiresUtc = _clock.UtcNow.AddMinutes(30) });
        await _db.SaveChangesAsync();
        await _email.SendAsync(user.Email, "Password reset", $"Use this one-time code within 30 minutes: {raw}");
    }

    public async Task ResetPassword(string token, string newPassword)
    {
        PasswordHasher.Validate(newPassword);
        var h = Hash(token ?? "");
        var t = await _db.PasswordResetTokens.FirstOrDefaultAsync(x => x.TokenHash == h && x.UsedUtc == null && x.ExpiresUtc > _clock.UtcNow) ?? throw new ValidationFailedException("token", "The reset code is invalid or expired.");
        var user = await _db.Users.IgnoreQueryFilters().FirstAsync(u => u.Id == t.UserId);
        SetPassword(user, newPassword);
        t.UsedUtc = _clock.UtcNow;
        var live = await _db.RefreshTokens.Where(r => r.UserId == user.Id && r.RevokedUtc == null).ToListAsync();
        foreach (var r in live) r.RevokedUtc = _clock.UtcNow;
        await _db.SaveChangesAsync();
        _access.Invalidate(user.Id);
    }

    public async Task ChangePassword(long userId, string current, string next)
    {
        PasswordHasher.Validate(next);
        var user = await _db.Users.IgnoreQueryFilters().FirstAsync(u => u.Id == userId);
        if (!PasswordHasher.Verify(current ?? "", user.PasswordHash, user.PasswordSalt, user.HashIterations)) throw new ValidationFailedException("currentPassword", "Current password is incorrect.");
        SetPassword(user, next);
        await _db.SaveChangesAsync();
        _access.Invalidate(userId);
    }

    public static void SetPassword(AppUser user, string password)
    {
        var (h, s, i) = PasswordHasher.Hash(password);
        user.PasswordHash = h; user.PasswordSalt = s; user.HashIterations = i; user.MustChangePassword = false;
        user.SecurityStamp = Guid.NewGuid().ToString("N");   // invalidates outstanding access tokens
    }

    public async Task<UserProfile?> Profile(long userId)
    {
        var u = await _db.Users.AsNoTracking().IgnoreQueryFilters().FirstOrDefaultAsync(x => x.Id == userId);
        if (u == null) return null;
        var ctx = await _access.Load(userId);
        if (ctx == null) return null;
        var branches = await _db.Branches.AsNoTracking().IgnoreQueryFilters().Where(b => ctx.BranchIds.Contains(b.Id)).OrderBy(b => b.BranchName)
            .Select(b => new BranchRef(b.Id, b.BranchCode, b.BranchName, b.IsActive)).ToListAsync();
        var roles = await _db.Roles.AsNoTracking().IgnoreQueryFilters().Where(r => ctx.RoleIds.Contains(r.Id)).Select(r => r.Name).ToListAsync();
        return new UserProfile(u.Id, u.UserName, u.FullName, u.Email, u.PreferredLanguage, ctx.DefaultBranchId, u.EmployeeId, u.WorkerId, branches, ctx.Permissions.OrderBy(p => p).ToList(), roles, u.MustChangePassword);
    }

    static string Hash(string raw) => Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(raw)));
}
