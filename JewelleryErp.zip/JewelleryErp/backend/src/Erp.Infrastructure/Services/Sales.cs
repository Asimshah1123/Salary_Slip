using Erp.Domain;
using Erp.Domain.Calc;
using Erp.Domain.Entities;
using Erp.Infrastructure.Contracts;
using Erp.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;

namespace Erp.Infrastructure.Services;

public sealed class SaleLineInput
{
    public long ProductId { get; set; }
    public decimal Quantity { get; set; } = 1;
    public PricingMode? PricingMode { get; set; }
    public decimal? RateOverride { get; set; }
    public string? RateOverrideReason { get; set; }
    public ChargeType? MakingType { get; set; }
    public decimal? MakingValue { get; set; }
    public decimal? WastagePercent { get; set; }
    public decimal? WastageWeight { get; set; }
    public decimal? StoneValue { get; set; }
    public decimal OtherCharges { get; set; }
    public decimal Discount { get; set; }
    public decimal? ManualPrice { get; set; }
}
public sealed class PaymentInput { public long PaymentMethodId { get; set; } public long? AccountId { get; set; } public decimal Amount { get; set; } public string? Reference { get; set; } }
public sealed class SaleInput
{
    public long? BranchId { get; set; }
    public long? CustomerId { get; set; }
    public long? SalesmanId { get; set; }
    public DateTime? DateUtc { get; set; }
    public List<SaleLineInput> Lines { get; set; } = new();
    public List<PaymentInput> Payments { get; set; } = new();
    public List<long> OldGoldIds { get; set; } = new();
    public string? Notes { get; set; }
    public bool PostNow { get; set; } = true;
    public bool Hold { get; set; }
    public string? IdempotencyKey { get; set; }
}

public sealed record SaleLineDto(long Id, int LineNo, long ProductId, string Sku, string Description, decimal Quantity, string? Purity, decimal Gross, decimal Stone, decimal Net, decimal Fine, PricingMode PricingMode,
    decimal Rate, DateTime? RateAt, decimal MetalValue, decimal Making, decimal Wastage, decimal StoneValue, decimal Other, decimal Discount, decimal Tax, decimal LineTotal, decimal ReturnedQuantity, long? ImageId, decimal? Cost);
public sealed record PaymentDto(long MethodId, string Method, long? AccountId, decimal Amount, string? Reference);
public sealed record SaleDto(long Id, string Number, DateTime DateUtc, long BranchId, string Branch, DocStatus Status, long? CustomerId, string? Customer, long? SalesmanId, string? Salesman,
    decimal Subtotal, decimal Discount, decimal Tax, decimal OldGoldCredit, decimal Rounding, decimal Total, decimal Paid, decimal Due, string RatePolicy, int PrintCount, string? Notes, string? PendingReason,
    IReadOnlyList<SaleLineDto> Lines, IReadOnlyList<PaymentDto> Payments, decimal? CostTotal);
public sealed record SaleRow(long Id, string Number, DateTime DateUtc, string Branch, string? Customer, string? Salesman, DocStatus Status, decimal Total, decimal Paid, decimal Due);
public sealed record QuoteLine(long ProductId, string Sku, string Description, decimal Net, decimal Rate, PricingResult Price);
public sealed record QuoteResult(IReadOnlyList<QuoteLine> Lines, InvoiceTotals Totals, string RatePolicy);

public sealed class SaleQuery : PageQuery
{
    public DateTime? From { get; set; }
    public DateTime? To { get; set; }
    public long[]? BranchIds { get; set; }
    public long? CustomerId { get; set; }
    public long? SalesmanId { get; set; }
    public DocStatus? Status { get; set; }
}

public sealed class ReturnLineInput { public long OriginalLineId { get; set; } public decimal Quantity { get; set; } }
public sealed class ReturnInput
{
    public string Reason { get; set; } = "";
    public List<ReturnLineInput> Lines { get; set; } = new();
    public List<PaymentInput> Refunds { get; set; } = new();
    public StockStatus ReturnToStatus { get; set; } = StockStatus.Available;
    public bool IsExchange { get; set; }
    public string? IdempotencyKey { get; set; }
}
public sealed record ReturnDto(long Id, string Number, long OriginalInvoiceId, DocStatus Status, decimal Subtotal, decimal Refunded, decimal CreditToLedger, string Reason, string? PendingReason);

public sealed class OldGoldInput
{
    public long? BranchId { get; set; }
    public long? CustomerId { get; set; }
    public long MetalTypeId { get; set; }
    public long PurityId { get; set; }
    public decimal GrossWeight { get; set; }
    public decimal StoneWeight { get; set; }
    public decimal OtherDeduction { get; set; }
    public decimal MeltingDeductionWeight { get; set; }
    public decimal? AcceptedRate { get; set; }
    public string? RateReason { get; set; }
    public string? ItemDescription { get; set; }
    public string? AssayNote { get; set; }
    public decimal PayOutNow { get; set; }
    public long? PayOutAccountId { get; set; }
    public string? IdempotencyKey { get; set; }
}
public sealed record OldGoldDto(long Id, string Number, DocStatus Status, long? CustomerId, string? Customer, string Purity, decimal Gross, decimal Stone, decimal Net, decimal Fine, decimal Rate, decimal Value, decimal DeductionPercent, decimal PaidOut, long? AppliedToInvoiceId, string? PendingReason);

public sealed class SalesService
{
    readonly ErpDbContext _db; readonly CurrentUser _cu; readonly AuditService _audit; readonly NumberingService _num; readonly PostingEngine _post; readonly SettingsService _settings;
    readonly RateService _rates; readonly ApprovalService _approvals; readonly AccessGuard _guard;
    public SalesService(ErpDbContext db, CurrentUser cu, AuditService audit, NumberingService num, PostingEngine post, SettingsService settings, RateService rates, ApprovalService approvals, AccessGuard guard)
    { _db = db; _cu = cu; _audit = audit; _num = num; _post = post; _settings = settings; _rates = rates; _approvals = approvals; _guard = guard; }

    // ============================ pricing ============================
    sealed record PricedLine(Product P, SaleLineInput In, PricingResult R, RateSnapshot? Rate, decimal Qty, decimal Gross, decimal Stone, decimal Net, decimal Fine, PricingMode Mode, ChargeType MakingType, decimal MakingValue, decimal WastagePct, decimal StoneValue, Purity? Pur, bool RateOverridden);

    async Task<List<PricedLine>> PriceLines(IEnumerable<SaleLineInput> lines, long branchId)
    {
        var u = _cu.Ctx;
        var taxOn = await _settings.Bool(SettingsService.Keys.TaxEnabled, branchId);
        var taxPct = await _settings.Dec(SettingsService.Keys.TaxPercent, branchId);
        var policy = await _settings.Enum<RoundingPolicy>(SettingsService.Keys.Rounding, branchId);
        var step = await _settings.Dec(SettingsService.Keys.RoundStep, branchId);
        var result = new List<PricedLine>();
        foreach (var l in lines)
        {
            var p = await _db.Products.AsNoTracking().FirstOrDefaultAsync(x => x.Id == l.ProductId) ?? throw new NotFoundException("Item");
            if (!p.IsActive) throw new DomainException($"{p.Sku} is inactive.", "product_inactive");
            if (l.Quantity <= 0) throw new ValidationFailedException("quantity", "Quantity must be positive.");
            if (p.Tracking == TrackingMode.Serialized && l.Quantity != 1) throw new ValidationFailedException("quantity", $"{p.Sku} is a unique piece; quantity must be 1.");
            var qty = l.Quantity;
            Purity? pur = p.PurityId != null ? await _db.Purities.AsNoTracking().FirstOrDefaultAsync(x => x.Id == p.PurityId) : null;
            decimal gross = Money.R3(p.GrossWeight * qty), stone = Money.R3(p.StoneWeight * qty), net = Money.R3(p.NetMetalWeight * qty);
            if (p.Tracking == TrackingMode.LooseMetal) { gross = net = qty; stone = 0; }   // loose metal is sold by weight: quantity = grams
            var mode = l.PricingMode ?? p.PricingMode;
            RateSnapshot? rate = null; bool overridden = false;
            if (p.MetalTypeId != null && p.PurityId != null && mode != PricingMode.Tagged && mode != PricingMode.ManualApproved)
            {
                rate = await _rates.Resolve(p.MetalTypeId.Value, p.PurityId.Value, branchId, selling: true);
                if (l.RateOverride != null && l.RateOverride != rate.Rate)
                {
                    u.Require(Perms.GoldRateOverride);
                    if (string.IsNullOrWhiteSpace(l.RateOverrideReason)) throw new ValidationFailedException("rateOverrideReason", "A reason is mandatory when overriding the gold rate.");
                    if (l.RateOverride <= 0) throw new ValidationFailedException("rateOverride", "Rate must be positive.");
                    rate = rate with { Rate = Money.R2(l.RateOverride.Value), IsOverride = true }; overridden = true;
                }
            }
            if (mode == PricingMode.ManualApproved && l.ManualPrice == null) throw new ValidationFailedException("manualPrice", "A manual price is required for manually priced lines.");
            var making = l.MakingType ?? p.MakingType; var makingVal = l.MakingValue ?? p.MakingValue;
            var wastePct = l.WastagePercent ?? p.WastagePercent; var stoneVal = (l.StoneValue ?? p.StoneValue) * (p.Tracking == TrackingMode.Serialized ? 1 : qty);
            var r = PricingCalculator.Price(new PricingInput(mode, qty, net, rate?.Rate ?? 0m, p.TagPrice, making, makingVal, wastePct, l.WastageWeight ?? 0m, stoneVal, l.OtherCharges, l.Discount, l.ManualPrice, taxOn, taxPct, policy, step <= 0 ? 1m : step));
            result.Add(new PricedLine(p, l, r, rate, qty, gross, stone, net, pur != null ? WeightCalc.Fine(net, pur.Factor) : 0m, mode, making, makingVal, wastePct, stoneVal, pur, overridden));
        }
        return result;
    }

    /// <summary>POS "quote": priced preview with current rate snapshot; nothing is saved (SRS API /sales/quotes).</summary>
    public async Task<QuoteResult> Quote(SaleInput i)
    {
        var u = _cu.Ctx; u.RequireAny(Perms.SalesCreate, Perms.SalesView);
        var branch = u.PostingBranch(i.BranchId);
        if (i.Lines.Count == 0) throw new ValidationFailedException("lines", "Add at least one item.");
        var priced = await PriceLines(i.Lines, branch);
        var policy = await _settings.Enum<RoundingPolicy>(SettingsService.Keys.Rounding, branch);
        var step = await _settings.Dec(SettingsService.Keys.RoundStep, branch);
        var og = i.OldGoldIds.Count == 0 ? 0m : await _db.OldGoldTransactions.AsNoTracking().Where(o => i.OldGoldIds.Contains(o.Id) && o.AppliedToInvoiceId == null).SumAsync(o => o.Value);
        var totals = InvoiceMath.Totals(priced.Select(x => x.R), og, i.Payments.Sum(x => x.Amount), policy, step <= 0 ? 1m : step);
        return new QuoteResult(priced.Select(x => new QuoteLine(x.P.Id, x.P.Sku, x.P.Name, x.Net, x.Rate?.Rate ?? 0, x.R)).ToList(), totals, priced.FirstOrDefault(x => x.Rate != null)?.Rate?.Policy ?? "Company");
    }

    // ============================ create / post ============================
    public async Task<SaleDto> Create(SaleInput i)
    {
        var u = _cu.Ctx; u.Require(Perms.SalesCreate);
        var branch = await _post.PostingBranch(i.BranchId);
        if (!string.IsNullOrWhiteSpace(i.IdempotencyKey))
        {
            var dup = await _db.SalesInvoices.AsNoTracking().FirstOrDefaultAsync(x => x.IdempotencyKey == i.IdempotencyKey);
            if (dup != null) return await Get(dup.Id);   // a retried request never duplicates a sale
        }
        if (i.Lines.Count == 0) throw new ValidationFailedException("lines", "Add at least one item.");
        if (i.Lines.GroupBy(l => l.ProductId).Any(g => g.Count() > 1 && g.Key != 0)) throw new ValidationFailedException("lines", "The same item appears twice on the invoice.");
        var date = i.DateUtc ?? DateTime.UtcNow;
        await _post.EnsureBackdating(date, branch);
        var id = await _post.InTransaction(async () =>
        {
            var priced = await PriceLines(i.Lines, branch);
            var policy = await _settings.Enum<RoundingPolicy>(SettingsService.Keys.Rounding, branch);
            var step = await _settings.Dec(SettingsService.Keys.RoundStep, branch);

            Customer? cust = i.CustomerId != null ? await _guard.Find(_db.Customers.AsNoTracking(), i.CustomerId.Value, "Customer") : null;
            if (i.SalesmanId != null && !await _db.Employees.AnyAsync(e => e.Id == i.SalesmanId && e.IsActive)) throw new ValidationFailedException("salesmanId", "Salesman not found or inactive.");

            var og = new List<OldGoldTransaction>();
            if (i.OldGoldIds.Count > 0)
            {
                if (cust == null) throw new ValidationFailedException("customerId", "Select the customer to apply an old gold credit.");
                og = await _db.OldGoldTransactions.Where(o => i.OldGoldIds.Contains(o.Id)).ToListAsync();
                if (og.Count != i.OldGoldIds.Distinct().Count()) throw new NotFoundException("Old gold transaction");
                foreach (var o in og)
                    if (o.Status != DocStatus.Posted || o.AppliedToInvoiceId != null || o.CustomerId != cust.Id) throw new ValidationFailedException("oldGoldIds", $"Old gold {o.Number} is not available for this customer.");
            }
            var ogCredit = og.Sum(o => Money.R2(o.Value - o.PaidOutAmount));
            var paid = i.Payments.Sum(p => p.Amount);
            if (i.Payments.Any(p => p.Amount <= 0)) throw new ValidationFailedException("payments", "Payment amounts must be positive.");
            var totals = InvoiceMath.Totals(priced.Select(x => x.R), ogCredit, paid, policy, step <= 0 ? 1m : step);
            if (paid > totals.Total) throw new ValidationFailedException("payments", $"Payments ({paid:N2}) exceed the invoice total ({totals.Total:N2}). Enter only the amount received.");
            if (totals.Due > 0 && cust == null) throw new ValidationFailedException("customerId", "A customer is required for credit (udhaar) or part-paid sales.");
            await ValidatePayments(i.Payments, branch);

            var inv = new SalesInvoice
            {
                CompanyId = u.CompanyId, BranchId = branch, Number = await _num.Next("INV", branch), DocDateUtc = date, Status = i.Hold ? DocStatus.OnHold : DocStatus.Draft, CustomerId = cust?.Id, SalesmanId = i.SalesmanId,
                Subtotal = totals.Subtotal, DiscountTotal = totals.Discount, TaxTotal = totals.Tax, OldGoldCredit = totals.OldGoldCredit, RoundingAdjustment = totals.Rounding, Total = totals.Total, PaidTotal = totals.Paid, DueTotal = totals.Due,
                Notes = i.Notes, IdempotencyKey = i.IdempotencyKey, RatePolicy = priced.FirstOrDefault(x => x.Rate != null)?.Rate?.Policy ?? "Company"
            };
            int no = 1; decimal cost = 0;
            foreach (var x in priced)
            {
                var lineCost = Money.R2(x.P.CostPrice * (x.P.Tracking == TrackingMode.Serialized ? 1 : x.Qty)); cost += lineCost;
                inv.Lines.Add(new SalesInvoiceLine
                {
                    LineNo = no++, ProductId = x.P.Id, Sku = x.P.Sku, Description = x.P.Name, Quantity = x.Qty, MetalTypeId = x.P.MetalTypeId, PurityId = x.P.PurityId, GrossWeight = x.Gross, StoneWeight = x.Stone, NetWeight = x.Net, FineWeight = x.Fine,
                    PricingMode = x.Mode, Rate = x.Rate?.Rate ?? 0, RateId = x.Rate?.RateId, RateTimestampUtc = x.Rate?.AtUtc, MetalValue = x.R.MetalValue, MakingType = x.MakingType, MakingInput = x.MakingValue, MakingCharge = x.R.MakingCharge,
                    WastagePercent = x.WastagePct, WastageCharge = x.R.WastageCharge, StoneValue = x.R.StoneValue, OtherCharges = x.R.OtherCharges, Discount = x.R.Discount, TaxAmount = x.R.Tax, LineTotalUnrounded = x.R.TotalUnrounded, LineTotal = x.R.Total, CostSnapshot = lineCost
                });
                if (x.RateOverridden) inv.RateOverrideReason = x.In.RateOverrideReason;
            }
            inv.CostTotal = Money.R2(cost);
            foreach (var p in i.Payments) inv.Payments.Add(new SalesPayment { PaymentMethodId = p.PaymentMethodId, AccountId = p.AccountId, Amount = Money.R2(p.Amount), Reference = p.Reference });
            _db.SalesInvoices.Add(inv);
            await _db.SaveChangesAsync();
            foreach (var o in og) { o.AppliedToInvoiceId = inv.Id; o.AppliedAmount = Money.R2(o.Value - o.PaidOutAmount); }

            // approval gates (SRS 19.3): discount, manual price, rate override
            var pending = await NeedsApproval(inv, priced, branch);
            if (pending != null && !i.Hold) { inv.Status = DocStatus.PendingApproval; await _db.SaveChangesAsync(); }
            _audit.Add("Sale.Created", "SalesInvoice", inv.Id, after: new { inv.Number, inv.Total, lines = inv.Lines.Count, status = inv.Status.ToString() }, targetBranchId: branch);
            if (i.PostNow && !i.Hold && inv.Status == DocStatus.Draft) { u.Require(Perms.SalesPost); await PostInternal(inv, priced.ToDictionary(x => x.P.Id, x => x.P)); }
            return inv.Id;
        });
        return await Get(id);
    }

    async Task<string?> NeedsApproval(SalesInvoice inv, List<PricedLine> priced, long branch)
    {
        var u = _cu.Ctx;
        string? reason = null;
        if (!u.Has(Perms.SalesDiscountOverride))
        {
            var maxPct = priced.Count == 0 ? 0 : Math.Max(priced.Max(x => x.R.DiscountPercent), inv.Subtotal == 0 ? 0 : Math.Round(inv.DiscountTotal / inv.Subtotal * 100m, 3));
            var chk = await _approvals.Check(ApprovalType.DiscountOverLimit, maxPct, branch);
            if (chk.NeedsApproval) { _approvals.Request(ApprovalType.DiscountOverLimit, nameof(SalesInvoice), inv.Id, inv.Number, maxPct, chk.Limit ?? 0, branch, "Discount above your limit"); reason = $"Discount {maxPct}% exceeds your limit of {chk.Limit}%."; }
        }
        if (priced.Any(x => x.R.RequiresApproval))
        {
            _approvals.Request(ApprovalType.ManualPrice, nameof(SalesInvoice), inv.Id, inv.Number, inv.Total, 0, branch, "Manually priced line");
            reason ??= "Manually priced line needs approval.";
        }
        if (priced.Any(x => x.RateOverridden))
        {
            // deviation from the card rate against the user's override limit (if configured)
            foreach (var x in priced.Where(y => y.RateOverridden))
            {
                var card = await _rates.Resolve(x.P.MetalTypeId!.Value, x.P.PurityId!.Value, branch, true);
                var dev = card.Rate == 0 ? 0 : Math.Round(Math.Abs(x.Rate!.Rate - card.Rate) / card.Rate * 100m, 3);
                var chk = await _approvals.Check(ApprovalType.RateOverride, dev, branch);
                if (chk.NeedsApproval) { _approvals.Request(ApprovalType.RateOverride, nameof(SalesInvoice), inv.Id, inv.Number, dev, chk.Limit ?? 0, branch, x.In.RateOverrideReason); reason ??= $"Rate override of {dev}% exceeds your limit."; }
                _audit.Add("GoldRate.OverrideOnSale", nameof(SalesInvoice), inv.Id, before: new { card.Rate }, after: new { x.Rate!.Rate, dev }, reason: x.In.RateOverrideReason, targetBranchId: branch);
            }
        }
        return reason;
    }

    async Task ValidatePayments(IEnumerable<PaymentInput> payments, long branch)
    {
        var ids = payments.Select(p => p.PaymentMethodId).Distinct().ToList();
        if (ids.Count == 0) return;
        var ok = await _db.PaymentMethods.AsNoTracking().Where(m => ids.Contains(m.Id) && m.IsActive).CountAsync();
        if (ok != ids.Count) throw new ValidationFailedException("payments", "A payment method is invalid or inactive.");
        foreach (var a in payments.Where(p => p.AccountId != null).Select(p => p.AccountId!.Value).Distinct())
        {
            var acc = await _db.CashBankAccounts.AsNoTracking().FirstOrDefaultAsync(x => x.Id == a && x.IsActive) ?? throw new ValidationFailedException("payments", "Cash/bank account not found.");
            if (acc.BranchId != null && acc.BranchId != branch) throw new ValidationFailedException("payments", "That cash/bank account belongs to another branch.");
        }
    }

    public async Task<SaleDto> Post(long id)
    {
        var u = _cu.Ctx; u.Require(Perms.SalesPost);
        await _post.InTransaction(async () =>
        {
            var inv = await _guard.Find(_db.SalesInvoices.Include(x => x.Lines).Include(x => x.Payments), id, "Invoice");
            if (inv.Status is DocStatus.Posted or DocStatus.PartiallyPaid or DocStatus.Closed) throw new ConflictException("This invoice is already posted.", "already_posted");
            if (inv.Status is DocStatus.Reversed or DocStatus.Cancelled) throw new ConflictException("This invoice is " + inv.Status + ".");
            if (inv.Status == DocStatus.PendingApproval) throw new ConflictException("This invoice is waiting for approval.", "pending_approval");
            await _post.PostingBranch(inv.BranchId);
            var products = await _db.Products.AsNoTracking().Where(p => inv.Lines.Select(l => l.ProductId).Contains(p.Id)).ToDictionaryAsync(p => p.Id, p => p);
            await PostInternal(inv, products);
            return 0;
        });
        return await Get(id);
    }

    async Task PostInternal(SalesInvoice inv, Dictionary<long, Product> products)
    {
        var u = _cu.Ctx;
        inv.Status = inv.DueTotal > 0 && inv.PaidTotal > 0 ? DocStatus.PartiallyPaid : DocStatus.Posted;
        inv.PostedBy = u.UserId; inv.PostedAtUtc = DateTime.UtcNow;
        var customerName = await _post.PartyName(PartyType.Customer, inv.CustomerId);
        var pmNames = await _db.PaymentMethods.AsNoTracking().ToDictionaryAsync(m => m.Id, m => m.Name);
        var paySummary = string.Join("; ", inv.Payments.Select(p => $"{pmNames.GetValueOrDefault(p.PaymentMethodId, "?")} {p.Amount:N0}"));
        var defLoc = new Dictionary<long, long>();

        foreach (var l in inv.Lines)
        {
            var p = products[l.ProductId];
            if (p.IsStockItem)
            {
                var bal = await _post.FindAvailable(inv.BranchId, p.Id, l.Quantity, p.Sku);   // concurrent buyers: second post hits the rowversion/unique guard
                await _post.Move(new StockMoveSpec
                {
                    RefType = TxnType.Sale, RefId = inv.Id, RefNo = inv.Number, From = new StockLoc(inv.BranchId, bal.LocationId, StockStatus.Available), To = new StockLoc(inv.BranchId, bal.LocationId, StockStatus.Sold),
                    ProductId = p.Id, MetalTypeId = l.MetalTypeId, PurityId = l.PurityId, Qty = l.Quantity, Gross = l.GrossWeight, Stone = l.StoneWeight, Net = l.NetWeight, Fine = l.FineWeight, Cost = l.CostSnapshot, Kind = "Issue"
                });
            }
            var e = _post.Reg(TxnType.Sale, inv, l.LineNo, customerName == null ? null : PartyType.Customer, inv.CustomerId, customerName);
            e.ProductId = p.Id; e.Sku = l.Sku; e.ItemName = l.Description; e.MetalTypeId = l.MetalTypeId; e.PurityId = l.PurityId; e.Gross = l.GrossWeight; e.Stone = l.StoneWeight; e.Net = l.NetWeight; e.Fine = l.FineWeight;
            e.Rate = l.Rate; e.Making = l.MakingCharge; e.Wastage = l.WastageCharge; e.StoneValue = l.StoneValue; e.PkrCredit = l.LineTotal; e.PaymentMethod = paySummary;
        }

        // PKR ledger of the customer
        if (inv.CustomerId != null)
        {
            var gross = Money.R2(inv.Total + inv.OldGoldCredit);
            _post.Party(PartyType.Customer, inv.CustomerId.Value, inv.BranchId, inv.DocDateUtc, TxnType.Sale, inv.Id, inv.Number, "Sale invoice", gross, 0);
            if (inv.OldGoldCredit > 0) _post.Party(PartyType.Customer, inv.CustomerId.Value, inv.BranchId, inv.DocDateUtc, TxnType.OldGold, inv.Id, inv.Number, "Old gold credit applied", 0, inv.OldGoldCredit);
            foreach (var p in inv.Payments) _post.Party(PartyType.Customer, inv.CustomerId.Value, inv.BranchId, inv.DocDateUtc, TxnType.CustomerReceipt, inv.Id, inv.Number, "Payment at sale (" + pmNames.GetValueOrDefault(p.PaymentMethodId, "") + ")", 0, p.Amount);
        }

        // balanced journal
        var j = new JournalBuilder();
        foreach (var p in inv.Payments) j.DrAcc(await _post.LedgerAccountFor(p.AccountId), p.Amount, "Sale receipt");
        if (inv.OldGoldCredit > 0) j.Dr(Acc.CustomerAdvances, inv.OldGoldCredit, "Old gold credit applied", PartyType.Customer, inv.CustomerId);
        if (inv.DueTotal > 0) j.Dr(Acc.Receivable, inv.DueTotal, "Credit sale", PartyType.Customer, inv.CustomerId);
        var revenue = Money.R2(inv.Lines.Sum(l => l.LineTotalUnrounded - l.TaxAmount));
        j.Cr(Acc.SalesRevenue, revenue, "Sales revenue");
        j.Cr(Acc.TaxPayable, inv.TaxTotal, "Sales tax");
        if (inv.RoundingAdjustment > 0) j.Cr(Acc.RoundingAdj, inv.RoundingAdjustment); else if (inv.RoundingAdjustment < 0) j.Dr(Acc.RoundingAdj, -inv.RoundingAdjustment);
        if (await _settings.Bool(SettingsService.Keys.PostCostJournal, inv.BranchId) && inv.CostTotal > 0) { j.Dr(Acc.Cogs, inv.CostTotal, "Cost of goods sold").Cr(Acc.InvFinished, inv.CostTotal, "Finished goods issued"); }
        await _post.Journal(j, TxnType.Sale, inv.Id, inv.Number, inv.BranchId, inv.DocDateUtc, "Sale " + inv.Number);

        await AccrueCommission(inv, products);
        _audit.Add("Sale.Posted", "SalesInvoice", inv.Id, after: new { inv.Number, inv.Total, inv.PaidTotal, inv.DueTotal }, targetBranchId: inv.BranchId);
    }

    async Task AccrueCommission(SalesInvoice inv, Dictionary<long, Product> products)
    {
        if (inv.SalesmanId == null) return;
        var prof = await _db.SalesmanProfiles.AsNoTracking().FirstOrDefaultAsync(s => s.EmployeeId == inv.SalesmanId && s.IsActive);
        if (prof == null || prof.CommissionType == CommissionType.None) return;
        var eligible = inv.Lines.Where(l => prof.CommissionType != CommissionType.CategoryBased || products[l.ProductId].CategoryId == prof.CategoryId).Sum(l => l.LineTotalUnrounded - l.TaxAmount);
        var amt = CommissionCalc.Calculate(prof.CommissionType, prof.CommissionValue, eligible);
        inv.CommissionAmount = amt;
        if (amt != 0 || prof.CommissionType == CommissionType.Manual)
            _db.CommissionEntries.Add(new CommissionEntry { CompanyId = inv.CompanyId, BranchId = inv.BranchId, SalesmanId = inv.SalesmanId.Value, SalesInvoiceId = inv.Id, EntryDateUtc = inv.DocDateUtc, EligibleAmount = Money.R2(eligible), Rate = prof.CommissionValue, CalculatedAmount = amt, IsApproved = false });
    }

    // ============================ hold / cancel ============================
    public async Task Cancel(long id, string reason)
    {
        var u = _cu.Ctx; u.RequireAny(Perms.SalesCreate, Perms.SalesVoid);
        if (string.IsNullOrWhiteSpace(reason)) throw new ValidationFailedException("reason", "A reason is required.");
        await _post.InTransaction(async () =>
        {
            var inv = await _guard.Find(_db.SalesInvoices, id, "Invoice");
            if (inv.Status is not (DocStatus.Draft or DocStatus.OnHold or DocStatus.PendingApproval)) throw new ConflictException("Only unposted invoices can be cancelled; use a return/void for posted invoices.");
            inv.Status = DocStatus.Cancelled; inv.VoidReason = reason;
            var linked = await _db.OldGoldTransactions.Where(o => o.AppliedToInvoiceId == inv.Id).ToListAsync();
            foreach (var o in linked) { o.AppliedToInvoiceId = null; o.AppliedAmount = 0; }   // release the credit
            _audit.Add("Sale.Cancelled", "SalesInvoice", inv.Id, reason: reason, targetBranchId: inv.BranchId);
            return 0;
        });
    }

    // ============================ queries ============================
    public async Task<PagedResult<SaleRow>> List(SaleQuery q)
    {
        var u = _cu.Ctx; u.Require(Perms.SalesView);
        var branches = u.ResolveScope(q.BranchIds);
        IQueryable<SalesInvoice> s = _db.SalesInvoices.AsNoTracking().Where(x => branches.Contains(x.BranchId));
        if (q.From != null) s = s.Where(x => x.DocDateUtc >= q.From);
        if (q.To != null) s = s.Where(x => x.DocDateUtc < q.To.Value.AddDays(1));
        if (q.CustomerId != null) s = s.Where(x => x.CustomerId == q.CustomerId);
        if (q.SalesmanId != null) s = s.Where(x => x.SalesmanId == q.SalesmanId);
        if (q.Status != null) s = s.Where(x => x.Status == q.Status);
        if (!string.IsNullOrWhiteSpace(q.Search)) { var t = q.Search.Trim(); s = s.Where(x => x.Number.Contains(t)); }
        var total = await s.CountAsync();
        var rows = await s.OrderByProp(q.Sort, q.Desc || q.Sort == null, new[] { "DocDateUtc", "Number", "Total", "Status" }, "DocDateUtc").Skip(q.Skip).Take(q.Take).ToListAsync();
        var cids = rows.Where(r => r.CustomerId != null).Select(r => r.CustomerId!.Value).Distinct().ToList();
        var sids = rows.Where(r => r.SalesmanId != null).Select(r => r.SalesmanId!.Value).Distinct().ToList();
        var cn = await _db.Customers.AsNoTracking().Where(c => cids.Contains(c.Id)).ToDictionaryAsync(c => c.Id, c => c.Name);
        var sn = await _db.Employees.AsNoTracking().Where(c => sids.Contains(c.Id)).ToDictionaryAsync(c => c.Id, c => c.Name);
        var bn = await _db.Branches.AsNoTracking().IgnoreQueryFilters().ToDictionaryAsync(b => b.Id, b => b.BranchName);
        var items = rows.Select(r => new SaleRow(r.Id, r.Number, r.DocDateUtc, bn.GetValueOrDefault(r.BranchId, ""), r.CustomerId != null ? cn.GetValueOrDefault(r.CustomerId.Value) : null, r.SalesmanId != null ? sn.GetValueOrDefault(r.SalesmanId.Value) : null, r.Status, r.Total, r.PaidTotal, r.DueTotal)).ToList();
        return new PagedResult<SaleRow>(items, total, q.Page, q.Take, new Dictionary<string, decimal> { ["total"] = await s.SumAsync(x => x.Total), ["paid"] = await s.SumAsync(x => x.PaidTotal), ["due"] = await s.SumAsync(x => x.DueTotal) });
    }

    public async Task<SaleDto> Get(long id)
    {
        var u = _cu.Ctx; u.Require(Perms.SalesView);
        var inv = await _guard.Find(_db.SalesInvoices.AsNoTracking().Include(x => x.Lines).Include(x => x.Payments), id, "Invoice");
        var cust = inv.CustomerId != null ? await _db.Customers.AsNoTracking().Where(c => c.Id == inv.CustomerId).Select(c => c.Name).FirstOrDefaultAsync() : null;
        var sm = inv.SalesmanId != null ? await _db.Employees.AsNoTracking().Where(c => c.Id == inv.SalesmanId).Select(c => c.Name).FirstOrDefaultAsync() : null;
        var br = await _db.Branches.AsNoTracking().IgnoreQueryFilters().Where(b => b.Id == inv.BranchId).Select(b => b.BranchName).FirstOrDefaultAsync() ?? "";
        var pur = await _db.Purities.AsNoTracking().ToDictionaryAsync(p => p.Id, p => p.Label);
        var pm = await _db.PaymentMethods.AsNoTracking().ToDictionaryAsync(m => m.Id, m => m.Name);
        var pids = inv.Lines.Select(l => l.ProductId).ToList();
        var img = await _db.Files.AsNoTracking().Where(f => f.OwnerType == FileOwnerType.Product && pids.Contains(f.OwnerId) && f.IsPrimary && !f.IsArchived).ToDictionaryAsync(f => f.OwnerId, f => f.Id);
        var seeCost = u.Has(Perms.ReportsCost);
        string? pending = null;
        if (inv.Status == DocStatus.PendingApproval) pending = await _db.ApprovalRequests.AsNoTracking().Where(a => a.EntityType == nameof(SalesInvoice) && a.EntityId == inv.Id && a.Status == ApprovalStatus.Pending).Select(a => a.Reason).FirstOrDefaultAsync();
        return new SaleDto(inv.Id, inv.Number, inv.DocDateUtc, inv.BranchId, br, inv.Status, inv.CustomerId, cust, inv.SalesmanId, sm, inv.Subtotal, inv.DiscountTotal, inv.TaxTotal, inv.OldGoldCredit, inv.RoundingAdjustment, inv.Total, inv.PaidTotal, inv.DueTotal, inv.RatePolicy, inv.PrintCount, inv.Notes, pending,
            inv.Lines.OrderBy(l => l.LineNo).Select(l => new SaleLineDto(l.Id, l.LineNo, l.ProductId, l.Sku, l.Description, l.Quantity, l.PurityId != null ? pur.GetValueOrDefault(l.PurityId.Value) : null, l.GrossWeight, l.StoneWeight, l.NetWeight, l.FineWeight, l.PricingMode, l.Rate, l.RateTimestampUtc,
                l.MetalValue, l.MakingCharge, l.WastageCharge, l.StoneValue, l.OtherCharges, l.Discount, l.TaxAmount, l.LineTotal, l.ReturnedQuantity, img.TryGetValue(l.ProductId, out var iid) ? iid : null, seeCost ? l.CostSnapshot : null)).ToList(),
            inv.Payments.Select(p => new PaymentDto(p.PaymentMethodId, pm.GetValueOrDefault(p.PaymentMethodId, ""), p.AccountId, p.Amount, p.Reference)).ToList(), seeCost ? inv.CostTotal : null);
    }

    /// <summary>Records a print. Re-prints are logged (SRS 3.7) and counted on the invoice.</summary>
    public async Task<SaleDto> RegisterPrint(long id)
    {
        _cu.Ctx.Require(Perms.SalesView);
        var inv = await _guard.Find(_db.SalesInvoices, id, "Invoice");
        if (inv.Status is DocStatus.Draft or DocStatus.OnHold or DocStatus.PendingApproval) throw new ConflictException("Post the invoice before printing the final copy.");
        if (inv.PrintCount > 0 && await _settings.Bool(SettingsService.Keys.LogDuplicatePrint, inv.BranchId)) _audit.Add("Sale.DuplicatePrint", "SalesInvoice", inv.Id, after: new { copy = inv.PrintCount + 1 }, targetBranchId: inv.BranchId);
        inv.PrintCount++;
        await _db.SaveChangesAsync();
        return await Get(id);
    }

    // ============================ returns / exchanges / void ============================
    public async Task<ReturnDto> Return(long invoiceId, ReturnInput i)
    {
        var u = _cu.Ctx; u.Require(Perms.SalesReturn);
        if (string.IsNullOrWhiteSpace(i.Reason)) throw new ValidationFailedException("reason", "A return reason is required.");
        if (!string.IsNullOrWhiteSpace(i.IdempotencyKey))
        {
            var dup = await _db.SalesReturns.AsNoTracking().FirstOrDefaultAsync(x => x.IdempotencyKey == i.IdempotencyKey);
            if (dup != null) return ToDto(dup, null);
        }
        long retId = 0;
        await _post.InTransaction(async () =>
        {
            var inv = await _guard.Find(_db.SalesInvoices.Include(x => x.Lines).Include(x => x.Payments), invoiceId, "Invoice");
            if (inv.Status is not (DocStatus.Posted or DocStatus.PartiallyPaid or DocStatus.Closed)) throw new ConflictException("Only posted invoices can be returned.");
            await _post.PostingBranch(inv.BranchId);
            if (i.Lines.Count == 0) throw new ValidationFailedException("lines", "Select at least one item to return.");
            var ret = new SalesReturn { CompanyId = u.CompanyId, BranchId = inv.BranchId, Number = await _num.Next("SRT", inv.BranchId), DocDateUtc = DateTime.UtcNow, OriginalInvoiceId = inv.Id, CustomerId = inv.CustomerId, Reason = i.Reason, IsExchange = i.IsExchange, ReturnToStatus = i.ReturnToStatus, IdempotencyKey = i.IdempotencyKey, Status = DocStatus.Draft };
            decimal amount = 0, tax = 0;
            foreach (var rl in i.Lines)
            {
                var ol = inv.Lines.FirstOrDefault(x => x.Id == rl.OriginalLineId) ?? throw new ValidationFailedException("lines", "Line does not belong to this invoice.");
                if (rl.Quantity <= 0) throw new ValidationFailedException("lines", "Return quantity must be positive.");
                if (rl.Quantity + ol.ReturnedQuantity > ol.Quantity) throw new ValidationFailedException("lines", $"{ol.Sku}: only {ol.Quantity - ol.ReturnedQuantity} left to return.");
                var share = rl.Quantity / ol.Quantity;
                var a = Money.R2(ol.LineTotal * share); var t = Money.R2(ol.TaxAmount * share);
                ret.Lines.Add(new SalesReturnLine { OriginalLineId = ol.Id, ProductId = ol.ProductId, Quantity = rl.Quantity, NetWeight = Money.R3(ol.NetWeight * share), Amount = a, TaxAmount = t });
                amount += a; tax += t;
            }
            ret.Subtotal = Money.R2(amount); ret.TaxReversed = Money.R2(tax);
            var dueReduction = Math.Min(ret.Subtotal, inv.DueTotal);
            var refundable = Money.R2(ret.Subtotal - dueReduction);
            var refunds = i.Refunds.Sum(r => r.Amount);
            if (refunds < 0 || refunds > refundable) throw new ValidationFailedException("refunds", $"Refunds ({refunds:N2}) cannot exceed the refundable amount ({refundable:N2}).");
            if (refundable - refunds > 0 && inv.CustomerId == null) throw new ValidationFailedException("refunds", "Walk-in customers must be refunded in full; there is no ledger to hold a credit.");
            await ValidatePayments(i.Refunds, inv.BranchId);
            foreach (var r in i.Refunds) ret.Refunds.Add(new SalesReturnRefund { PaymentMethodId = r.PaymentMethodId, AccountId = r.AccountId, Amount = Money.R2(r.Amount) });
            ret.RefundTotal = Money.R2(refunds); ret.CreditToLedger = Money.R2(refundable - refunds);
            _db.SalesReturns.Add(ret);
            await _db.SaveChangesAsync();
            retId = ret.Id;

            var chk = await _approvals.Check(ApprovalType.RefundOverLimit, ret.RefundTotal, inv.BranchId);
            if (chk.NeedsApproval) { ret.Status = DocStatus.PendingApproval; _approvals.Request(ApprovalType.RefundOverLimit, nameof(SalesReturn), ret.Id, ret.Number, ret.RefundTotal, chk.Limit ?? 0, inv.BranchId, i.Reason); }
            else await PostReturnInternal(ret, inv);
            return 0;
        });
        var r2 = await _db.SalesReturns.AsNoTracking().FirstAsync(x => x.Id == retId);
        return ToDto(r2, null);
    }

    public async Task<ReturnDto> PostReturn(long returnId)
    {
        var u = _cu.Ctx; u.Require(Perms.SalesReturn);
        await _post.InTransaction(async () =>
        {
            var ret = await _guard.Find(_db.SalesReturns.Include(x => x.Lines).Include(x => x.Refunds), returnId, "Return");
            if (ret.Status != DocStatus.Approved) throw new ConflictException("Only approved returns can be posted.");
            var inv = await _db.SalesInvoices.Include(x => x.Lines).Include(x => x.Payments).FirstAsync(x => x.Id == ret.OriginalInvoiceId);
            await PostReturnInternal(ret, inv);
            return 0;
        });
        return ToDto(await _db.SalesReturns.AsNoTracking().FirstAsync(x => x.Id == returnId), null);
    }

    async Task PostReturnInternal(SalesReturn ret, SalesInvoice inv)
    {
        var u = _cu.Ctx;
        if (ret.Lines.Count == 0) ret = await _db.SalesReturns.Include(x => x.Lines).Include(x => x.Refunds).FirstAsync(x => x.Id == ret.Id);
        ret.Status = DocStatus.Posted; ret.PostedBy = u.UserId; ret.PostedAtUtc = DateTime.UtcNow;
        var products = await _db.Products.AsNoTracking().Where(p => ret.Lines.Select(l => l.ProductId).Contains(p.Id)).ToDictionaryAsync(p => p.Id, p => p);
        var customerName = await _post.PartyName(PartyType.Customer, inv.CustomerId);
        decimal costBack = 0; int no = 1;
        foreach (var rl in ret.Lines)
        {
            var ol = inv.Lines.First(x => x.Id == rl.OriginalLineId);
            var share = rl.Quantity / ol.Quantity;
            var cost = Money.R2(ol.CostSnapshot * share); costBack += cost;
            ol.ReturnedQuantity += rl.Quantity;
            var p = products[rl.ProductId];
            if (p.IsStockItem)
            {
                var sold = await _db.StockBalances.FirstOrDefaultAsync(b => b.BranchId == inv.BranchId && b.ProductId == p.Id && b.Status == StockStatus.Sold && b.Ownership == Ownership.Shop && b.Quantity >= rl.Quantity)
                           ?? throw new DomainException($"{p.Sku}: sold stock record not found; cannot return.", "return_stock_missing");
                await _post.Move(new StockMoveSpec
                {
                    RefType = TxnType.SaleReturn, RefId = ret.Id, RefNo = ret.Number, From = new StockLoc(inv.BranchId, sold.LocationId, StockStatus.Sold), To = new StockLoc(inv.BranchId, sold.LocationId, ret.ReturnToStatus),
                    ProductId = p.Id, MetalTypeId = ol.MetalTypeId, PurityId = ol.PurityId, Qty = rl.Quantity, Gross = Money.R3(ol.GrossWeight * share), Stone = Money.R3(ol.StoneWeight * share), Net = rl.NetWeight, Fine = Money.R3(ol.FineWeight * share), Cost = cost, Kind = "Reversal", Reason = ret.Reason
                });
            }
            var e = _post.Reg(TxnType.SaleReturn, ret, no++, customerName == null ? null : PartyType.Customer, inv.CustomerId, customerName);
            e.ProductId = p.Id; e.Sku = ol.Sku; e.ItemName = ol.Description; e.MetalTypeId = ol.MetalTypeId; e.PurityId = ol.PurityId; e.Net = rl.NetWeight; e.PkrDebit = rl.Amount; e.LinkedDocId = inv.Id; e.LinkedDocType = "SalesInvoice"; e.LinkedDocNo = inv.Number;
        }
        var dueReduction = Math.Min(ret.Subtotal, inv.DueTotal);
        inv.DueTotal = Money.R2(inv.DueTotal - dueReduction);
        if (inv.DueTotal == 0 && inv.Status == DocStatus.PartiallyPaid) inv.Status = DocStatus.Posted;

        if (inv.CustomerId != null)
        {
            _post.Party(PartyType.Customer, inv.CustomerId.Value, inv.BranchId, DateTime.UtcNow, TxnType.SaleReturn, ret.Id, ret.Number, "Sales return of " + inv.Number, 0, ret.Subtotal, true);
            foreach (var rf in ret.Refunds) _post.Party(PartyType.Customer, inv.CustomerId.Value, inv.BranchId, DateTime.UtcNow, TxnType.SaleReturn, ret.Id, ret.Number, "Refund paid", rf.Amount, 0, true);
        }
        var j = new JournalBuilder();
        j.Dr(Acc.SalesReturns, Money.R2(ret.Subtotal - ret.TaxReversed), "Sales returned");
        j.Dr(Acc.TaxPayable, ret.TaxReversed, "Tax reversed");
        foreach (var rf in ret.Refunds) j.CrAcc(await _post.LedgerAccountFor(rf.AccountId), rf.Amount, "Refund");
        j.Cr(Acc.Receivable, dueReduction, "Receivable reduced", PartyType.Customer, inv.CustomerId);
        j.Cr(Acc.CustomerAdvances, ret.CreditToLedger, "Credit held for customer", PartyType.Customer, inv.CustomerId);
        if (await _settings.Bool(SettingsService.Keys.PostCostJournal, inv.BranchId) && costBack > 0) j.Dr(Acc.InvFinished, costBack, "Stock returned").Cr(Acc.Cogs, costBack, "Cost reversed");
        await _post.Journal(j, TxnType.SaleReturn, ret.Id, ret.Number, inv.BranchId, DateTime.UtcNow, "Return " + ret.Number, true);

        if (inv.CommissionAmount != 0 && await _settings.Bool(SettingsService.Keys.CommissionOnReturn, inv.BranchId) && inv.SalesmanId != null)
        {
            var eligible = inv.Lines.Sum(l => l.LineTotalUnrounded - l.TaxAmount);
            var back = CommissionCalc.ReverseShare(inv.CommissionAmount, Money.R2(eligible), Money.R2(ret.Subtotal - ret.TaxReversed));
            if (back != 0) _db.CommissionEntries.Add(new CommissionEntry { CompanyId = inv.CompanyId, BranchId = inv.BranchId, SalesmanId = inv.SalesmanId.Value, SalesReturnId = ret.Id, EntryDateUtc = DateTime.UtcNow, EligibleAmount = -Money.R2(ret.Subtotal - ret.TaxReversed), CalculatedAmount = -back, IsReversal = true, Note = "Return " + ret.Number });
            ret.CommissionReversed = back;
        }
        _audit.Add("Sale.Returned", nameof(SalesReturn), ret.Id, after: new { ret.Number, ret.Subtotal, ret.RefundTotal }, reason: ret.Reason, targetBranchId: inv.BranchId);
    }

    /// <summary>Full reversal of a posted invoice: every remaining quantity is returned and refunded through the original payment methods.</summary>
    public async Task<ReturnDto> Void(long invoiceId, string reason, string? idempotencyKey)
    {
        var u = _cu.Ctx; u.Require(Perms.SalesVoid);
        var inv = await _guard.Find(_db.SalesInvoices.AsNoTracking().Include(x => x.Lines).Include(x => x.Payments), invoiceId, "Invoice");
        var refundable = Money.R2(inv.Lines.Sum(l => Money.R2(l.LineTotal * (l.Quantity - l.ReturnedQuantity) / l.Quantity)) - Math.Min(inv.Lines.Sum(l => Money.R2(l.LineTotal * (l.Quantity - l.ReturnedQuantity) / l.Quantity)), inv.DueTotal));
        var left = refundable; var refunds = new List<PaymentInput>();
        foreach (var p in inv.Payments.OrderByDescending(p => p.Amount)) { var a = Math.Min(left, p.Amount); if (a > 0) { refunds.Add(new PaymentInput { PaymentMethodId = p.PaymentMethodId, AccountId = p.AccountId, Amount = a }); left -= a; } }
        var dto = await Return(invoiceId, new ReturnInput { Reason = "VOID: " + reason, Lines = inv.Lines.Where(l => l.Quantity > l.ReturnedQuantity).Select(l => new ReturnLineInput { OriginalLineId = l.Id, Quantity = l.Quantity - l.ReturnedQuantity }).ToList(), Refunds = refunds, IdempotencyKey = idempotencyKey });
        if (dto.Status == DocStatus.Posted)
        {
            var i2 = await _db.SalesInvoices.FirstAsync(x => x.Id == invoiceId);
            i2.Status = DocStatus.Reversed; i2.VoidReason = reason;
            await _post.MarkRegisterReversed(TxnType.Sale, invoiceId, dto.Id);
            await _audit.Save("Sale.Voided", "SalesInvoice", invoiceId, reason: reason, targetBranchId: i2.BranchId);
        }
        return dto;
    }

    public async Task<List<ReturnDto>> ReturnsOf(long invoiceId)
    {
        _cu.Ctx.Require(Perms.SalesView);
        var inv = await _guard.Find(_db.SalesInvoices.AsNoTracking(), invoiceId, "Invoice");
        var rows = await _db.SalesReturns.AsNoTracking().Where(r => r.OriginalInvoiceId == inv.Id).OrderByDescending(r => r.Id).ToListAsync();
        return rows.Select(r => ToDto(r, null)).ToList();
    }

    static ReturnDto ToDto(SalesReturn r, string? pending) => new(r.Id, r.Number, r.OriginalInvoiceId, r.Status, r.Subtotal, r.RefundTotal, r.CreditToLedger, r.Reason, pending);

    // ============================ old gold / buy-back ============================
    public async Task<OldGoldDto> CreateOldGold(OldGoldInput i)
    {
        var u = _cu.Ctx; u.Require(Perms.OldGoldCreate);
        var branch = await _post.PostingBranch(i.BranchId);
        if (!string.IsNullOrWhiteSpace(i.IdempotencyKey))
        {
            var dup = await _db.OldGoldTransactions.AsNoTracking().FirstOrDefaultAsync(x => x.IdempotencyKey == i.IdempotencyKey);
            if (dup != null) return await GetOldGold(dup.Id);
        }
        long id = 0;
        await _post.InTransaction(async () =>
        {
            var pur = await _db.Purities.AsNoTracking().FirstOrDefaultAsync(p => p.Id == i.PurityId && p.MetalTypeId == i.MetalTypeId) ?? throw new ValidationFailedException("purityId", "Tested purity not found for this metal.");
            var card = await _rates.Resolve(i.MetalTypeId, i.PurityId, branch, selling: false);
            var rate = card.Rate;
            if (i.AcceptedRate != null && i.AcceptedRate != card.Rate)
            {
                u.Require(Perms.GoldRateOverride);
                if (string.IsNullOrWhiteSpace(i.RateReason)) throw new ValidationFailedException("rateReason", "A reason is mandatory when the accepted rate differs from the card rate.");
                rate = Money.R2(i.AcceptedRate.Value);
                _audit.Add("GoldRate.OverrideOnOldGold", "OldGoldTransaction", "new", before: new { card.Rate }, after: new { rate }, reason: i.RateReason, targetBranchId: branch);
            }
            var method = await _settings.Get(SettingsService.Keys.OldGoldMethod, branch);
            var v = OldGold.Value(new OldGoldInput_(i, pur.Factor, rate, method).ToCalc());
            if (i.CustomerId == null && Money.R2(i.PayOutNow) != v.Value) throw new ValidationFailedException("payOutNow", "Walk-in buy-back must be paid out in full (no customer ledger to hold a credit).");
            if (i.PayOutNow < 0 || i.PayOutNow > v.Value) throw new ValidationFailedException("payOutNow", "Pay-out cannot be negative or exceed the valuation.");
            if (i.CustomerId != null) await _guard.Find(_db.Customers.AsNoTracking(), i.CustomerId.Value, "Customer");
            var og = new OldGoldTransaction
            {
                CompanyId = u.CompanyId, BranchId = branch, Number = await _num.Next("OGT", branch), DocDateUtc = DateTime.UtcNow, CustomerId = i.CustomerId, MetalTypeId = i.MetalTypeId, PurityId = i.PurityId, GrossWeight = i.GrossWeight, StoneWeight = i.StoneWeight,
                OtherDeduction = i.OtherDeduction, MeltingDeductionWeight = i.MeltingDeductionWeight, NetWeight = v.Net, FineWeight = v.Fine, AcceptedRate = rate, Value = v.Value, DeductionPercent = v.DeductionPercent, PaidOutAmount = Money.R2(i.PayOutNow),
                ItemDescription = i.ItemDescription, AssayNote = i.AssayNote, IdempotencyKey = i.IdempotencyKey, Status = DocStatus.Draft
            };
            _db.OldGoldTransactions.Add(og);
            await _db.SaveChangesAsync();
            id = og.Id;
            var thr = await _settings.Dec(SettingsService.Keys.OldGoldDeductionPct, branch);
            if (og.DeductionPercent > thr && !u.Has(Perms.ApprovalsDecide))
            {
                og.Status = DocStatus.PendingApproval;
                _approvals.Request(ApprovalType.OldGoldDeduction, nameof(OldGoldTransaction), og.Id, og.Number, og.DeductionPercent, thr, branch, "Melting/testing deduction above threshold");
            }
            else await PostOldGoldInternal(og, i.PayOutAccountId);
            return 0;
        });
        return await GetOldGold(id);
    }

    sealed record OldGoldInput_(OldGoldInput I, decimal Factor, decimal Rate, string Method)
    {
        public Domain.Calc.OldGoldInput ToCalc() => new(I.GrossWeight, I.StoneWeight, I.OtherDeduction, I.MeltingDeductionWeight, Factor, Rate, Method, Factor > 0 ? Rate / Factor : null);
    }

    public async Task<OldGoldDto> PostOldGold(long id, long? payOutAccountId)
    {
        _cu.Ctx.Require(Perms.OldGoldCreate);
        await _post.InTransaction(async () =>
        {
            var og = await _guard.Find(_db.OldGoldTransactions, id, "Old gold transaction");
            if (og.Status != DocStatus.Approved) throw new ConflictException("Only approved old gold transactions can be posted.");
            await PostOldGoldInternal(og, payOutAccountId);
            return 0;
        });
        return await GetOldGold(id);
    }

    async Task PostOldGoldInternal(OldGoldTransaction og, long? payOutAccountId)
    {
        var u = _cu.Ctx;
        og.Status = DocStatus.Posted; og.PostedBy = u.UserId; og.PostedAtUtc = DateTime.UtcNow;
        var loc = await _post.DefaultLocation(og.BranchId);
        // old gold sits in a separate unrefined-metal category (Quarantine) until tested / melted / reclassified (SRS 2.4)
        await _post.Move(new StockMoveSpec { RefType = TxnType.OldGold, RefId = og.Id, RefNo = og.Number, To = new StockLoc(og.BranchId, loc, StockStatus.Quarantine), MetalTypeId = og.MetalTypeId, PurityId = og.PurityId, Gross = og.GrossWeight, Stone = og.StoneWeight, Net = og.NetWeight, Fine = og.FineWeight, Cost = og.Value, Kind = "Receipt", Reason = "Old gold received" });
        var name = await _post.PartyName(PartyType.Customer, og.CustomerId);
        var credit = Money.R2(og.Value - og.PaidOutAmount);
        if (og.CustomerId != null)
        {
            _post.Party(PartyType.Customer, og.CustomerId.Value, og.BranchId, og.DocDateUtc, TxnType.OldGold, og.Id, og.Number, "Old gold received", 0, og.Value);
            if (og.PaidOutAmount > 0) _post.Party(PartyType.Customer, og.CustomerId.Value, og.BranchId, og.DocDateUtc, TxnType.OldGold, og.Id, og.Number, "Paid out for old gold", og.PaidOutAmount, 0);
        }
        var j = new JournalBuilder().Dr(Acc.InvOldGold, og.Value, "Old gold stock");
        if (credit > 0) j.Cr(Acc.CustomerAdvances, credit, "Customer credit for old gold", PartyType.Customer, og.CustomerId);
        if (og.PaidOutAmount > 0) j.CrAcc(await _post.LedgerAccountFor(payOutAccountId), og.PaidOutAmount, "Paid to customer");
        await _post.Journal(j, TxnType.OldGold, og.Id, og.Number, og.BranchId, og.DocDateUtc, "Old gold " + og.Number);
        var e = _post.Reg(TxnType.OldGold, og, 1, name == null ? null : PartyType.Customer, og.CustomerId, name);
        e.MetalTypeId = og.MetalTypeId; e.PurityId = og.PurityId; e.Gross = og.GrossWeight; e.Stone = og.StoneWeight; e.Net = og.NetWeight; e.Fine = og.FineWeight; e.Rate = og.AcceptedRate; e.PkrDebit = og.Value; e.ItemName = og.ItemDescription ?? "Old gold";
        _audit.Add("OldGold.Posted", nameof(OldGoldTransaction), og.Id, after: new { og.Number, og.Value, og.DeductionPercent }, targetBranchId: og.BranchId);
    }

    public async Task<OldGoldDto> GetOldGold(long id)
    {
        _cu.Ctx.RequireAny(Perms.OldGoldView, Perms.OldGoldCreate, Perms.SalesView);
        var o = await _guard.Find(_db.OldGoldTransactions.AsNoTracking(), id, "Old gold transaction");
        var cust = o.CustomerId != null ? await _db.Customers.AsNoTracking().Where(c => c.Id == o.CustomerId).Select(c => c.Name).FirstOrDefaultAsync() : null;
        var pur = await _db.Purities.AsNoTracking().Where(p => p.Id == o.PurityId).Select(p => p.Label).FirstOrDefaultAsync() ?? "";
        var pend = o.Status == DocStatus.PendingApproval ? "Deduction above threshold - waiting for approval." : null;
        return new OldGoldDto(o.Id, o.Number, o.Status, o.CustomerId, cust, pur, o.GrossWeight, o.StoneWeight, o.NetWeight, o.FineWeight, o.AcceptedRate, o.Value, o.DeductionPercent, o.PaidOutAmount, o.AppliedToInvoiceId, pend);
    }

    public async Task<List<OldGoldDto>> OldGoldForCustomer(long customerId, bool unappliedOnly)
    {
        _cu.Ctx.RequireAny(Perms.OldGoldView, Perms.OldGoldCreate, Perms.SalesCreate);
        var q = _db.OldGoldTransactions.AsNoTracking().Where(o => o.CustomerId == customerId && o.Status == DocStatus.Posted);
        if (unappliedOnly) q = q.Where(o => o.AppliedToInvoiceId == null && o.Value > o.PaidOutAmount);
        var ids = await q.OrderByDescending(o => o.Id).Take(50).Select(o => o.Id).ToListAsync();
        var res = new List<OldGoldDto>(); foreach (var id in ids) res.Add(await GetOldGold(id));
        return res;
    }
}
