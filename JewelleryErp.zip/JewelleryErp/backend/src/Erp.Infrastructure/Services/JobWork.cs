using Erp.Domain;
using Erp.Domain.Calc;
using Erp.Domain.Entities;
using Erp.Infrastructure.Contracts;
using Erp.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;

namespace Erp.Infrastructure.Services;

public sealed class JobInput
{
    public long WorkerId { get; set; }
    public long? BranchId { get; set; }
    public StockPostingMode Mode { get; set; } = StockPostingMode.OnIssue;
    public Ownership MaterialOwnership { get; set; } = Ownership.Shop;
    public string? MaterialSourceNote { get; set; }
    public string DesignSpec { get; set; } = "";
    public DateTime? DueDateUtc { get; set; }
    public int TargetPieces { get; set; } = 1;
    public ChargeType MakingType { get; set; } = ChargeType.PerGram;
    public decimal MakingValue { get; set; }
    public decimal WastageAllowancePercent { get; set; }
    public decimal? ToleranceFineGrams { get; set; }
    public long? WorkshopLocationId { get; set; }
    public string? Notes { get; set; }
    public string? IdempotencyKey { get; set; }
}
public sealed class IssueLineInput { public long MetalTypeId { get; set; } public long PurityId { get; set; } public decimal GrossWeight { get; set; } public decimal NetWeight { get; set; } public long? FromLocationId { get; set; } public bool IsAdditional { get; set; } }
public sealed class IssueInput { public List<IssueLineInput> Lines { get; set; } = new(); public string? AcknowledgedBy { get; set; } public string? IdempotencyKey { get; set; } }
public sealed class ReceiptLineInput
{
    public string Kind { get; set; } = "Output";           // Output | ReturnedMetal | Scrap
    public string? Sku { get; set; }
    public string? Description { get; set; }
    public long? CategoryId { get; set; }
    public long MetalTypeId { get; set; }
    public long PurityId { get; set; }
    public decimal Quantity { get; set; } = 1;
    public decimal GrossWeight { get; set; }
    public decimal StoneWeight { get; set; }
    public decimal StoneValue { get; set; }
}
public sealed class ReceiptInput
{
    public List<ReceiptLineInput> Lines { get; set; } = new();
    public List<IssueLineInput> InputMaterial { get; set; } = new();   // OnReceiptOnly: metal the worker/customer supplied
    public bool IsFinal { get; set; }
    public decimal? MakingChargeOverride { get; set; }                  // needs JobWork.Variance.Approve
    public string? InputSourceNote { get; set; }
    public string? IdempotencyKey { get; set; }
}
public sealed class ReconcileInput { public decimal ApprovedLossFine { get; set; } public string? Reason { get; set; } }
public sealed class WorkerPaymentInput { public long WorkerId { get; set; } public long? JobCardId { get; set; } public long? BranchId { get; set; } public long PaymentMethodId { get; set; } public long? AccountId { get; set; } public decimal Amount { get; set; } public string? Reference { get; set; } public string? IdempotencyKey { get; set; } }
public sealed class JobQuery : PageQuery { public JobStatus? Status { get; set; } public long? WorkerId { get; set; } public bool? Overdue { get; set; } public long[]? BranchIds { get; set; } }

public sealed record CustodyRow(long LocationId, string? Metal, string? Purity, decimal Gross, decimal Net, decimal Fine);
public sealed record JobDocRow(long Id, string Number, DateTime DateUtc, string Summary, decimal Fine, decimal Amount);
public sealed record ReconPreview(decimal TotalInput, decimal Accounted, decimal Variance, decimal AllowedWastage, decimal ExcessLoss, decimal UnexpectedGain, bool WithinTolerance, bool RequiresApproval, string Summary);
public sealed record JobDto(long Id, string Number, long BranchId, long WorkerId, string Worker, JobStatus JobStatus, StockPostingMode Mode, Ownership MaterialOwnership, string? MaterialSourceNote, string DesignSpec, DateTime? DueDateUtc, bool Overdue,
    int TargetPieces, ChargeType MakingType, decimal MakingValue, decimal WastageAllowancePercent, decimal ToleranceFine, decimal IssuedFine, decimal AdditionalInputFine, decimal OutputFine, decimal ReturnedFine, decimal ScrapFine, decimal ApprovedLossFine,
    decimal VarianceFine, decimal MakingAccrued, decimal MakingPaid, bool ModeLocked, string MaterialStatus, IReadOnlyList<CustodyRow> Custody, IReadOnlyList<JobDocRow> Issues, IReadOnlyList<JobDocRow> Receipts,
    IReadOnlyList<(JobStatus From, JobStatus To, DateTime At, string? Note)> Stages, ReconPreview Reconciliation, string? Notes);
public sealed record JobRow(long Id, string Number, string Worker, JobStatus JobStatus, StockPostingMode Mode, DateTime? DueDateUtc, bool Overdue, decimal IssuedFine, decimal OutputFine, decimal VarianceFine, decimal Payable);

public sealed class JobWorkService
{
    readonly ErpDbContext _db; readonly CurrentUser _cu; readonly AuditService _audit; readonly NumberingService _num; readonly PostingEngine _post; readonly SettingsService _settings; readonly RateService _rates; readonly AccessGuard _guard;
    public JobWorkService(ErpDbContext db, CurrentUser cu, AuditService audit, NumberingService num, PostingEngine post, SettingsService settings, RateService rates, AccessGuard guard)
    { _db = db; _cu = cu; _audit = audit; _num = num; _post = post; _settings = settings; _rates = rates; _guard = guard; }

    // ---------------- helpers ----------------
    void Transition(JobCard j, JobStatus to, string? note)
    {
        if (j.JobStatus == to && to is not (JobStatus.PartiallyReceived or JobStatus.MaterialIssued)) return;
        JobFlow.Require(j.JobStatus, to, j.StockPostingMode);
        j.Stages.Add(new JobStage { FromStatus = j.JobStatus, ToStatus = to, AtUtc = DateTime.UtcNow, UserId = _cu.Ctx.UserId, Note = note });
        j.JobStatus = to;
    }

    async Task<JobCard> Load(long id, bool forWrite = true)
    {
        var u = _cu.Ctx;
        var j = await _guard.Find(_db.JobCards.Include(x => x.Stages), id, "Job card");
        if (!u.Has(Perms.JobWorkView) && !(u.Has(Perms.JobWorkViewAssigned) && u.WorkerId == j.WorkerId)) throw new NotFoundException("Job card");   // karigars only ever see their own jobs
        return j;
    }

    static decimal[] Allocate(decimal total, IList<decimal> weights)
    {
        var sum = weights.Sum(); var res = new decimal[weights.Count];
        if (weights.Count == 0) return res;
        decimal given = 0;
        for (int i = 0; i < weights.Count; i++) { res[i] = sum == 0 ? 0 : Money.R2(total * weights[i] / sum); given += res[i]; }
        res[^1] += Money.R2(total) - given;   // the rounding remainder goes to the last line so journals always balance
        return res;
    }

    // ---------------- create / approve / cancel ----------------
    public async Task<JobDto> Create(JobInput i)
    {
        var u = _cu.Ctx; u.Require(Perms.JobWorkCreate);
        var branch = await _post.PostingBranch(i.BranchId);
        if (!string.IsNullOrWhiteSpace(i.IdempotencyKey)) { var d = await _db.JobCards.AsNoTracking().FirstOrDefaultAsync(x => x.IdempotencyKey == i.IdempotencyKey); if (d != null) return await Get(d.Id); }
        if (string.IsNullOrWhiteSpace(i.DesignSpec)) throw new ValidationFailedException("designSpec", "Describe the design / specification.");
        if (i.Mode == StockPostingMode.OnIssue && i.MaterialOwnership != Ownership.Shop) throw new ValidationFailedException("materialOwnership", "OnIssue mode moves shop stock to the worker. For worker- or customer-owned metal use OnReceiptOnly.");
        if (i.Mode == StockPostingMode.OnReceiptOnly && i.MaterialOwnership == Ownership.Shop) throw new ValidationFailedException("materialOwnership", "If the shop's own metal is handed over, use OnIssue mode - otherwise the stock ledger would be wrong.");
        if (i.Mode == StockPostingMode.OnReceiptOnly && string.IsNullOrWhiteSpace(i.MaterialSourceNote)) throw new ValidationFailedException("materialSourceNote", "State who provides the material (planning-only card).");
        var w = await _db.Workers.AsNoTracking().FirstOrDefaultAsync(x => x.Id == i.WorkerId && x.IsActive) ?? throw new ValidationFailedException("workerId", "Worker not found or inactive.");
        var tol = i.ToleranceFineGrams ?? await _settings.Dec(SettingsService.Keys.JobToleranceFine, branch);
        var j = new JobCard
        {
            CompanyId = u.CompanyId, BranchId = branch, Number = await _num.Next("JOB", branch), DocDateUtc = DateTime.UtcNow, WorkerId = w.Id, JobStatus = JobStatus.Draft, StockPostingMode = i.Mode, MaterialOwnership = i.MaterialOwnership,
            MaterialSourceNote = i.MaterialSourceNote, DesignSpec = i.DesignSpec, DueDateUtc = i.DueDateUtc, TargetPieces = Math.Max(1, i.TargetPieces), MakingType = i.MakingType == ChargeType.None ? w.RateType : i.MakingType,
            MakingValue = i.MakingValue > 0 ? i.MakingValue : w.RateValue, WastageAllowancePercent = i.WastageAllowancePercent > 0 ? i.WastageAllowancePercent : w.DefaultWastagePercent, ToleranceFineGrams = tol,
            WorkshopLocationId = i.WorkshopLocationId, Notes = i.Notes, IdempotencyKey = i.IdempotencyKey, Status = DocStatus.Draft
        };
        j.Stages.Add(new JobStage { FromStatus = JobStatus.Draft, ToStatus = JobStatus.Draft, AtUtc = DateTime.UtcNow, UserId = u.UserId, Note = "Created" });
        _db.JobCards.Add(j);
        _audit.Add("Job.Created", nameof(JobCard), "new", after: new { j.Number, w.Name, j.StockPostingMode }, targetBranchId: branch);
        await _db.SaveChangesAsync();
        return await Get(j.Id);
    }

    public async Task<JobDto> Approve(long id)
    {
        _cu.Ctx.Require(Perms.JobWorkApprove);
        var j = await Load(id);
        Transition(j, JobStatus.Approved, "Approved"); j.Status = DocStatus.Approved; j.ApprovedBy = _cu.Ctx.UserId; j.ApprovedAtUtc = DateTime.UtcNow;
        await _audit.Save("Job.Approved", nameof(JobCard), j.Id, targetBranchId: j.BranchId);
        return await Get(id);
    }

    public async Task Cancel(long id, string reason)
    {
        _cu.Ctx.Require(Perms.JobWorkApprove);
        var j = await Load(id);
        if (j.StockModeLocked) throw new ConflictException("Stock has already moved on this job; it cannot be cancelled - reconcile and close it instead.");
        Transition(j, JobStatus.Cancelled, reason); j.Status = DocStatus.Cancelled; j.VoidReason = reason;
        await _audit.Save("Job.Cancelled", nameof(JobCard), id, reason: reason, targetBranchId: j.BranchId);
    }

    /// <summary>Worker/supervisor stage update. Karigars may only move their own jobs between work stages.</summary>
    public async Task<JobDto> UpdateStage(long id, JobStatus to, string? note)
    {
        var u = _cu.Ctx; u.Require(Perms.JobWorkUpdateStage);
        var j = await Load(id);
        if (to is not (JobStatus.InProgress or JobStatus.Completed)) throw new ForbiddenException("Only the In Progress / Completed work stages can be set here; other stages are posted through issue, receipt, reconcile and close.");
        if (to == JobStatus.Completed && j.ReceivedOutputFine == 0 && j.StockPostingMode == StockPostingMode.OnIssue && j.JobStatus != JobStatus.PartiallyReceived) throw new ConflictException("Completed work must be received (weighed in) by the supervisor first.");
        Transition(j, to, note);
        await _audit.Save("Job.Stage", nameof(JobCard), id, after: new { to = to.ToString(), note }, targetBranchId: j.BranchId);
        return await Get(id);
    }

    // ---------------- material issue (mode A) ----------------
    public async Task<JobDto> IssueMaterial(long id, IssueInput i)
    {
        var u = _cu.Ctx; u.Require(Perms.JobWorkMaterialIssue);
        if (i.Lines.Count == 0) throw new ValidationFailedException("lines", "Add the metal to issue.");
        await _post.InTransaction(async () =>
        {
            var j = await Load(id);
            await _post.PostingBranch(j.BranchId);
            if (j.StockPostingMode != StockPostingMode.OnIssue) throw new ConflictException("This job is Not Issued / Planning Only; shop stock cannot be issued against it.", "planning_only");
            if (j.JobStatus is not (JobStatus.Approved or JobStatus.MaterialIssued or JobStatus.InProgress or JobStatus.PartiallyReceived)) throw new ConflictException("Approve the job card before issuing material.");
            var issue = new JobMaterialIssue { CompanyId = u.CompanyId, BranchId = j.BranchId, Number = await _num.Next("MIS", j.BranchId), DocDateUtc = DateTime.UtcNow, JobCardId = j.Id, AcknowledgedBy = i.AcknowledgedBy, IdempotencyKey = i.IdempotencyKey, Status = DocStatus.Posted, PostedBy = u.UserId, PostedAtUtc = DateTime.UtcNow };
            _db.JobMaterialIssues.Add(issue);
            await _db.SaveChangesAsync();   // the voucher needs its id before ledger rows reference it
            var wLoc = j.WorkshopLocationId ?? await _post.DefaultLocation(j.BranchId, "Workshop");
            decimal cost = 0, fineTotal = 0, addFine = 0;
            foreach (var l in i.Lines)
            {
                var pur = await _db.Purities.AsNoTracking().FirstOrDefaultAsync(p => p.Id == l.PurityId && p.MetalTypeId == l.MetalTypeId) ?? throw new ValidationFailedException("lines", "Purity does not match the metal.");
                var net = l.NetWeight > 0 ? l.NetWeight : l.GrossWeight;
                if (net <= 0) throw new ValidationFailedException("lines", "Weight must be positive.");
                var gross = l.GrossWeight > 0 ? l.GrossWeight : net;
                var fine = WeightCalc.Fine(net, pur.Factor);
                var bal = await _db.StockBalances.FirstOrDefaultAsync(b => b.BranchId == j.BranchId && b.ProductId == null && b.MetalTypeId == l.MetalTypeId && b.PurityId == l.PurityId && b.Status == StockStatus.Available && b.Ownership == Ownership.Shop && b.NetWeight >= net && (l.FromLocationId == null || b.LocationId == l.FromLocationId))
                          ?? throw new DomainException("Not enough loose metal of that purity is available to issue (negative stock is blocked).", "negative_stock");
                var c = bal.NetWeight == 0 ? 0m : Money.R2(bal.CostValue * Math.Min(1m, net / bal.NetWeight)); cost += c;
                await _post.Move(new StockMoveSpec { RefType = TxnType.JobIssue, RefId = issue.Id, RefNo = issue.Number, From = new StockLoc(j.BranchId, bal.LocationId, StockStatus.Available), To = new StockLoc(j.BranchId, wLoc, StockStatus.WithWorker), ToCustodyRefId = j.Id,
                    MetalTypeId = l.MetalTypeId, PurityId = l.PurityId, Gross = gross, Net = net, Fine = fine, Cost = c, Kind = "Issue", Reason = "Issued to worker for " + j.Number });
                issue.Lines.Add(new JobMaterialIssueLine { MetalTypeId = l.MetalTypeId, PurityId = l.PurityId, GrossWeight = gross, NetWeight = net, FineWeight = fine, FromLocationId = bal.LocationId, IsAdditional = l.IsAdditional });
                _post.Metal(PartyType.Worker, j.WorkerId, j.BranchId, l.MetalTypeId, l.PurityId, issue.DocDateUtc, TxnType.JobIssue, issue.Id, issue.Number, 0, net, 0, fine, "Issued for " + j.Number);
                fineTotal += fine; if (l.IsAdditional) addFine += fine;
            }
            j.IssuedFine = Money.R3(j.IssuedFine + fineTotal - addFine); j.AdditionalInputFine = Money.R3(j.AdditionalInputFine + addFine); j.StockModeLocked = true;
            if (j.Status == DocStatus.Approved) j.Status = DocStatus.Posted;
            Transition(j, JobStatus.MaterialIssued, "Material issued " + issue.Number);
            var wName = await _post.PartyName(PartyType.Worker, j.WorkerId);
            var e = _post.Reg(TxnType.JobIssue, issue, 1, PartyType.Worker, j.WorkerId, wName); e.Fine = fineTotal; e.Net = issue.Lines.Sum(x => x.NetWeight); e.Gross = issue.Lines.Sum(x => x.GrossWeight); e.ItemName = "Metal issued"; e.LinkedDocId = j.Id; e.LinkedDocType = "JobCard"; e.LinkedDocNo = j.Number; e.PkrDebit = cost;
            await _post.Journal(new JournalBuilder().Dr(Acc.MetalWithWorkers, cost, "Metal in worker custody", PartyType.Worker, j.WorkerId).Cr(Acc.InvRawMetal, cost, "Raw metal issued"), TxnType.JobIssue, issue.Id, issue.Number, j.BranchId, issue.DocDateUtc, "Issue " + issue.Number);
            _audit.Add("Job.MaterialIssued", nameof(JobCard), j.Id, after: new { issue.Number, fine = fineTotal }, targetBranchId: j.BranchId);
            return 0;
        });
        return await Get(id);
    }

    // ---------------- receipt of finished work (both modes) ----------------
    public async Task<JobDto> Receive(long id, ReceiptInput i)
    {
        var u = _cu.Ctx; u.Require(Perms.JobWorkReceive);
        if (i.Lines.Count == 0) throw new ValidationFailedException("lines", "Add the finished pieces / returned metal / scrap.");
        if (i.MakingChargeOverride != null) u.Require(Perms.JobWorkVarianceApprove);
        if (!string.IsNullOrWhiteSpace(i.IdempotencyKey)) { var d = await _db.JobReceipts.AsNoTracking().FirstOrDefaultAsync(x => x.IdempotencyKey == i.IdempotencyKey); if (d != null) return await Get(d.JobCardId); }
        await _post.InTransaction(async () =>
        {
            var j = await Load(id);
            await _post.PostingBranch(j.BranchId);
            if (j.JobStatus is not (JobStatus.Approved or JobStatus.MaterialIssued or JobStatus.InProgress or JobStatus.PartiallyReceived)) throw new ConflictException($"Cannot receive work while the job is {j.JobStatus}.");
            var onIssue = j.StockPostingMode == StockPostingMode.OnIssue;
            if (onIssue && j.IssuedFine <= 0) throw new ConflictException("No material has been issued on this job yet.");
            if (!onIssue && i.Lines.Any(l => l.Kind != "Output")) throw new ValidationFailedException("lines", "Worker/customer-owned jobs only receive finished output; returned metal and scrap stay with the owner.");
            if (!onIssue && i.InputMaterial.Count == 0) throw new ValidationFailedException("inputMaterial", "Record the metal the worker/customer supplied so the job can be reconciled.");

            var purities = await _db.Purities.AsNoTracking().ToDictionaryAsync(p => p.Id, p => p);
            var rl = new List<(ReceiptLineInput In, decimal Net, decimal Fine)>();
            foreach (var l in i.Lines)
            {
                if (l.Kind is not ("Output" or "ReturnedMetal" or "Scrap")) throw new ValidationFailedException("lines", "Line kind must be Output, ReturnedMetal or Scrap.");
                if (!purities.TryGetValue(l.PurityId, out var pur) || pur.MetalTypeId != l.MetalTypeId) throw new ValidationFailedException("lines", "Purity does not match the metal.");
                if (l.Quantity <= 0) throw new ValidationFailedException("lines", "Quantity must be positive.");
                var net = WeightCalc.NetMetal(l.GrossWeight, l.Kind == "Output" ? l.StoneWeight : 0m);
                if (net <= 0) throw new ValidationFailedException("lines", "A line has no metal weight.");
                rl.Add((l, net, WeightCalc.Fine(net, pur.Factor)));
            }
            var receipt = new JobReceipt { CompanyId = u.CompanyId, BranchId = j.BranchId, Number = await _num.Next("JRC", j.BranchId), DocDateUtc = DateTime.UtcNow, JobCardId = j.Id, InputOwnership = j.MaterialOwnership, InputSourceNote = i.InputSourceNote ?? j.MaterialSourceNote, IsFinal = i.IsFinal, IdempotencyKey = i.IdempotencyKey, Status = DocStatus.Posted, PostedBy = u.UserId, PostedAtUtc = DateTime.UtcNow };
            _db.JobReceipts.Add(receipt);
            await _db.SaveChangesAsync();   // id needed by ledger rows

            decimal outFine = rl.Where(x => x.In.Kind == "Output").Sum(x => x.Fine), retFine = rl.Where(x => x.In.Kind == "ReturnedMetal").Sum(x => x.Fine), scrFine = rl.Where(x => x.In.Kind == "Scrap").Sum(x => x.Fine);
            var consume = outFine + retFine + scrFine;
            decimal costRelieved = 0;
            var wLoc = j.WorkshopLocationId ?? await _post.DefaultLocation(j.BranchId, "Workshop");
            var defLoc = await _post.DefaultLocation(j.BranchId);

            // 1) relieve worker custody proportionally across the issued purities (fine-weight basis)
            if (onIssue)
            {
                var rows = await _db.StockBalances.Where(b => b.BranchId == j.BranchId && b.Status == StockStatus.WithWorker && b.CustodyRefId == j.Id && b.NetWeight > 0).ToListAsync();
                var fTot = rows.Sum(r => r.FineWeight);
                var frac = fTot <= 0 ? 0m : Math.Min(1m, consume / fTot);
                foreach (var r in rows)
                {
                    var n = Money.R3(r.NetWeight * frac); var g = Money.R3(r.GrossWeight * frac); var f = Money.R3(r.FineWeight * frac); var c = Money.R2(r.CostValue * frac);
                    if (n <= 0 && g <= 0) continue;
                    await _post.Move(new StockMoveSpec { RefType = TxnType.JobReceipt, RefId = receipt.Id, RefNo = receipt.Number, From = new StockLoc(j.BranchId, r.LocationId, StockStatus.WithWorker), FromCustodyRefId = j.Id, MetalTypeId = r.MetalTypeId, PurityId = r.PurityId, Gross = g, Net = n, Fine = f, Cost = c, Kind = "Issue", Reason = "Worker custody relieved by receipt" });
                    costRelieved += c;
                }
            }

            // 2) making charge (policy, or supervisor-approved override)
            var outNet = rl.Where(x => x.In.Kind == "Output").Sum(x => x.Net);
            decimal metalValueOut = 0; RateSnapshot? buy = null;
            if (!onIssue) { foreach (var x in rl) { buy = await _rates.Resolve(x.In.MetalTypeId, x.In.PurityId, j.BranchId, selling: false); metalValueOut += Money.R2(x.Net * buy.Rate); } }
            decimal making = i.MakingChargeOverride ?? j.MakingType switch
            {
                ChargeType.PerGram => Money.R2(j.MakingValue * outNet),
                ChargeType.Percent => Money.R2(j.MakingValue / 100m * (onIssue ? (consume == 0 ? 0 : costRelieved * outFine / consume) : metalValueOut)),
                ChargeType.Fixed => (i.IsFinal && j.MakingChargesAccrued == 0) ? Money.R2(j.MakingValue) : 0m,
                _ => 0m
            };
            if (making < 0) throw new ValidationFailedException("makingChargeOverride", "Making charge cannot be negative.");

            // 3) post each received line
            var lineCosts = onIssue ? Allocate(costRelieved, rl.Select(x => x.Fine).ToList()) : rl.Select(x => Money.R2(x.Net * (buy == null ? 0 : (_rates.Resolve(x.In.MetalTypeId, x.In.PurityId, j.BranchId, false).Result.Rate)))).ToArray();
            var outIdx = rl.Select((x, k) => (x, k)).Where(t => t.x.In.Kind == "Output").Select(t => t.k).ToList();
            var makingShare = Allocate(making, outIdx.Select(k => rl[k].Net).ToList());
            var customerOwned = j.MaterialOwnership == Ownership.Customer;
            decimal finishedCost = 0, rawCost = 0, stoneTotal = 0; int no = 1, outPos = 0;
            var wName = await _post.PartyName(PartyType.Worker, j.WorkerId);
            for (int k = 0; k < rl.Count; k++)
            {
                var (l, net, fine) = rl[k]; var metalCost = customerOwned ? 0m : lineCosts[k];
                var lr = new JobReceiptLine { JobReceiptId = receipt.Id, Kind = l.Kind, Description = l.Description, CategoryId = l.CategoryId, MetalTypeId = l.MetalTypeId, PurityId = l.PurityId, Quantity = l.Quantity, GrossWeight = l.GrossWeight, StoneWeight = l.Kind == "Output" ? l.StoneWeight : 0, NetWeight = net, FineWeight = fine, StoneValue = l.StoneValue };
                if (l.Kind == "Output")
                {
                    var cost = Money.R2(metalCost + makingShare[outPos++] + l.StoneValue); finishedCost += cost; stoneTotal += l.StoneValue;
                    if (j.RepairTicketId != null)
                    {
                        // repair job: the repaired piece stays CUSTOMER property in the ticket's custody; the shop's metal + making is a repair cost
                        await _post.Move(new StockMoveSpec { RefType = TxnType.JobReceipt, RefId = receipt.Id, RefNo = receipt.Number, To = new StockLoc(j.BranchId, defLoc, StockStatus.RepairIntake), ToOwnership = Ownership.Customer, ToCustodyRefId = j.RepairTicketId.Value, MetalTypeId = l.MetalTypeId, PurityId = l.PurityId, Qty = 0, Gross = l.GrossWeight, Stone = l.StoneWeight, Net = net, Fine = fine, Cost = 0, Kind = "Receipt", Reason = "Repaired piece back from karigar " + j.Number });
                        var er = _post.Reg(TxnType.JobReceipt, receipt, no++, PartyType.Worker, j.WorkerId, wName); er.MetalTypeId = l.MetalTypeId; er.PurityId = l.PurityId; er.Gross = l.GrossWeight; er.Stone = l.StoneWeight; er.Net = net; er.Fine = fine; er.Making = makingShare[outPos - 1]; er.ItemName = "Repaired piece"; er.PkrDebit = cost; er.LinkedDocId = j.Id; er.LinkedDocType = "JobCard"; er.LinkedDocNo = j.Number;
                        receipt.Lines.Add(lr);
                        if (onIssue) _post.Metal(PartyType.Worker, j.WorkerId, j.BranchId, l.MetalTypeId, l.PurityId, receipt.DocDateUtc, TxnType.JobReceipt, receipt.Id, receipt.Number, net, 0, fine, 0, "Repaired piece received");
                        continue;
                    }
                    var p = new Product { CompanyId = u.CompanyId, Sku = string.IsNullOrWhiteSpace(l.Sku) ? await _num.Next("SKU", j.BranchId) : l.Sku.Trim().ToUpperInvariant(), Name = string.IsNullOrWhiteSpace(l.Description) ? "Job " + j.Number + " piece" : l.Description, CategoryId = l.CategoryId, Tracking = l.Quantity == 1 ? TrackingMode.Serialized : TrackingMode.Quantity,
                        MetalTypeId = l.MetalTypeId, PurityId = l.PurityId, GrossWeight = Money.R3(l.GrossWeight / l.Quantity), StoneWeight = Money.R3(l.StoneWeight / l.Quantity), NetMetalWeight = Money.R3(net / l.Quantity), StoneValue = Money.R2(l.StoneValue / l.Quantity), CostPrice = Money.R2(cost / l.Quantity),
                        MakingType = ChargeType.PerGram, MakingValue = 0, PricingMode = PricingMode.MetalPlusMaking, DefaultBranchId = j.BranchId, Design = j.DesignSpec.Length > 200 ? j.DesignSpec[..200] : j.DesignSpec };
                    p.Barcode = p.Sku;
                    _db.Products.Add(p); await _db.SaveChangesAsync();
                    lr.ProductId = p.Id; lr.Sku = p.Sku;
                    var to = customerOwned ? new StockLoc(j.BranchId, defLoc, StockStatus.Quarantine) : new StockLoc(j.BranchId, defLoc, StockStatus.Available);
                    await _post.Move(new StockMoveSpec { RefType = TxnType.JobReceipt, RefId = receipt.Id, RefNo = receipt.Number, To = to, ToOwnership = customerOwned ? Ownership.Customer : Ownership.Shop, ToCustodyRefId = customerOwned ? j.Id : 0, ProductId = p.Id, MetalTypeId = l.MetalTypeId, PurityId = l.PurityId, Qty = l.Quantity, Gross = l.GrossWeight, Stone = l.StoneWeight, Net = net, Fine = fine, Cost = cost, Kind = "Receipt", Reason = "Finished work " + j.Number });
                    var e = _post.Reg(TxnType.JobReceipt, receipt, no++, PartyType.Worker, j.WorkerId, wName); e.ProductId = p.Id; e.Sku = p.Sku; e.ItemName = p.Name; e.MetalTypeId = l.MetalTypeId; e.PurityId = l.PurityId; e.Gross = l.GrossWeight; e.Stone = l.StoneWeight; e.Net = net; e.Fine = fine; e.Making = makingShare[outPos - 1]; e.StoneValue = l.StoneValue; e.PkrDebit = cost; e.LinkedDocId = j.Id; e.LinkedDocType = "JobCard"; e.LinkedDocNo = j.Number;
                }
                else
                {
                    rawCost += metalCost;
                    var st = l.Kind == "Scrap" ? StockStatus.Quarantine : StockStatus.Available;   // scrap is segregated until refined
                    await _post.Move(new StockMoveSpec { RefType = TxnType.JobReceipt, RefId = receipt.Id, RefNo = receipt.Number, To = new StockLoc(j.BranchId, defLoc, st), MetalTypeId = l.MetalTypeId, PurityId = l.PurityId, Gross = l.GrossWeight, Net = net, Fine = fine, Cost = metalCost, Kind = "Receipt", Reason = l.Kind + " from " + j.Number });
                    var e = _post.Reg(TxnType.JobReceipt, receipt, no++, PartyType.Worker, j.WorkerId, wName); e.MetalTypeId = l.MetalTypeId; e.PurityId = l.PurityId; e.Gross = l.GrossWeight; e.Net = net; e.Fine = fine; e.ItemName = l.Kind; e.PkrDebit = metalCost; e.LinkedDocId = j.Id; e.LinkedDocType = "JobCard"; e.LinkedDocNo = j.Number;
                }
                receipt.Lines.Add(lr);
                if (onIssue) _post.Metal(PartyType.Worker, j.WorkerId, j.BranchId, l.MetalTypeId, l.PurityId, receipt.DocDateUtc, TxnType.JobReceipt, receipt.Id, receipt.Number, net, 0, fine, 0, l.Kind + " received");
            }

            // 4) worker payable + journal
            decimal payable = Money.R2(making + stoneTotal + (onIssue || customerOwned ? 0m : finishedCost - making - stoneTotal));
            var jb = new JournalBuilder();
            if (onIssue) { jb.Dr(j.RepairTicketId != null ? Acc.Cogs : Acc.InvFinished, finishedCost, "Finished goods from karigar").Dr(Acc.InvRawMetal, rawCost, "Returned metal / scrap").Cr(Acc.MetalWithWorkers, costRelieved, "Custody relieved").Cr(Acc.WorkerPayable, payable, "Making + stones payable", PartyType.Worker, j.WorkerId); }
            else { jb.Dr(j.RepairTicketId != null ? Acc.Cogs : Acc.InvFinished, finishedCost, "Finished goods from karigar").Cr(Acc.WorkerPayable, finishedCost, "Metal + making payable", PartyType.Worker, j.WorkerId); payable = finishedCost; }
            if (customerOwned && !onIssue) { jb = new JournalBuilder(); if (payable > 0) jb.Dr(Acc.InvFinished, payable).Cr(Acc.WorkerPayable, payable, null, PartyType.Worker, j.WorkerId); }
            if (jb.Lines.Count > 0) await _post.Journal(jb, TxnType.JobReceipt, receipt.Id, receipt.Number, j.BranchId, receipt.DocDateUtc, "Receipt " + receipt.Number);
            if (payable > 0) _post.Party(PartyType.Worker, j.WorkerId, j.BranchId, receipt.DocDateUtc, TxnType.JobReceipt, receipt.Id, receipt.Number, "Work received on " + j.Number, 0, payable);

            // 5) job totals / status
            foreach (var x in i.InputMaterial) { var pu = purities[x.PurityId]; var n = x.NetWeight > 0 ? x.NetWeight : x.GrossWeight; j.AdditionalInputFine = Money.R3(j.AdditionalInputFine + WeightCalc.Fine(n, pu.Factor)); }
            j.ReceivedOutputFine = Money.R3(j.ReceivedOutputFine + outFine); j.ReturnedFine = Money.R3(j.ReturnedFine + retFine); j.ScrapFine = Money.R3(j.ScrapFine + scrFine);
            j.MakingChargesAccrued = Money.R2(j.MakingChargesAccrued + payable); j.StockModeLocked = true;
            receipt.MakingCharge = making; receipt.OutputFine = outFine; receipt.ReturnedFine = retFine; receipt.ScrapFine = scrFine;
            if (j.Status == DocStatus.Approved) j.Status = DocStatus.Posted;
            if (j.JobStatus == JobStatus.Approved) Transition(j, JobStatus.InProgress, "Work started");
            Transition(j, i.IsFinal ? JobStatus.Completed : JobStatus.PartiallyReceived, "Receipt " + receipt.Number);
            _audit.Add("Job.Received", nameof(JobCard), j.Id, after: new { receipt.Number, outFine, retFine, scrFine, making }, targetBranchId: j.BranchId);
            return 0;
        });
        return await Get(id);
    }

    // ---------------- reconcile & close (SRS 6.5) ----------------
    ReconResult Calc(JobCard j, decimal loss) => Reconciliation.Calculate(new ReconInput(j.IssuedFine, j.AdditionalInputFine, j.ReceivedOutputFine, j.ReturnedFine, j.ScrapFine, loss, j.ToleranceFineGrams, j.WastageAllowancePercent));

    public async Task<JobDto> Reconcile(long id, ReconcileInput i)
    {
        var u = _cu.Ctx; u.Require(Perms.JobWorkReconcile);
        await _post.InTransaction(async () =>
        {
            var j = await Load(id);
            if (j.JobStatus != JobStatus.Completed) throw new ConflictException("Reconcile after the final receipt has been posted (job must be Completed).");
            await _post.PostingBranch(j.BranchId);
            var baseRes = Calc(j, 0);
            var res = Calc(j, i.ApprovedLossFine);
            if (i.ApprovedLossFine < 0 || (baseRes.Variance > 0 && i.ApprovedLossFine > baseRes.Variance)) throw new ValidationFailedException("approvedLossFine", "Approved loss cannot be negative or exceed the unaccounted weight.");
            var needsApproval = !baseRes.WithinTolerance || i.ApprovedLossFine > 0;
            if (needsApproval)
            {
                u.Require(Perms.JobWorkVarianceApprove);
                if (string.IsNullOrWhiteSpace(i.Reason)) throw new ValidationFailedException("reason", "A reason is mandatory to approve a variance or loss (no silent write-off).");
                if (!res.WithinTolerance) throw new ValidationFailedException("approvedLossFine", $"After the approved loss, {res.Summary}. Approve the full variance with a reason.");
            }
            var rec = new JobReconciliation { CompanyId = u.CompanyId, BranchId = j.BranchId, Number = await _num.Next("JRE", j.BranchId), DocDateUtc = DateTime.UtcNow, JobCardId = j.Id, IssuedFine = j.IssuedFine, AdditionalInputFine = j.AdditionalInputFine, OutputFine = j.ReceivedOutputFine, ReturnedFine = j.ReturnedFine, ScrapFine = j.ScrapFine,
                ApprovedLossFine = i.ApprovedLossFine, VarianceFine = res.Variance, ToleranceFine = j.ToleranceFineGrams, WithinTolerance = baseRes.WithinTolerance, ApprovalReason = i.Reason, MakingCharges = j.MakingChargesAccrued, Status = DocStatus.Posted, PostedBy = u.UserId, PostedAtUtc = DateTime.UtcNow, ApprovedBy = needsApproval ? u.UserId : null, ApprovedAtUtc = needsApproval ? DateTime.UtcNow : null };
            _db.JobReconciliations.Add(rec);
            await _db.SaveChangesAsync();

            // write off the explicitly approved loss (+ the tolerated residual) from remaining custody
            var writeFine = Money.R3(i.ApprovedLossFine + Math.Max(0, res.Variance));
            if (j.StockPostingMode == StockPostingMode.OnIssue && writeFine > 0)
            {
                var rows = await _db.StockBalances.Where(b => b.BranchId == j.BranchId && b.Status == StockStatus.WithWorker && b.CustodyRefId == j.Id && b.NetWeight > 0).ToListAsync();
                var fTot = rows.Sum(r => r.FineWeight); var frac = fTot <= 0 ? 0m : Math.Min(1m, writeFine / fTot); decimal cost = 0;
                foreach (var r in rows)
                {
                    var n = Money.R3(r.NetWeight * frac); var f = Money.R3(r.FineWeight * frac); var c = Money.R2(r.CostValue * frac); if (n <= 0) continue; cost += c;
                    await _post.Move(new StockMoveSpec { RefType = TxnType.JobReconcile, RefId = rec.Id, RefNo = rec.Number, From = new StockLoc(j.BranchId, r.LocationId, StockStatus.WithWorker), FromCustodyRefId = j.Id, MetalTypeId = r.MetalTypeId, PurityId = r.PurityId, Gross = Money.R3(r.GrossWeight * frac), Net = n, Fine = f, Cost = c, Kind = "Adjustment", Reason = "Approved process loss: " + (i.Reason ?? "within tolerance") });
                    _post.Metal(PartyType.Worker, j.WorkerId, j.BranchId, r.MetalTypeId ?? 0, r.PurityId, rec.DocDateUtc, TxnType.JobReconcile, rec.Id, rec.Number, n, 0, f, 0, "Loss written off");
                }
                if (cost > 0) await _post.Journal(new JournalBuilder().Dr(Acc.MetalLoss, cost, "Process loss").Cr(Acc.MetalWithWorkers, cost, "Custody written off", PartyType.Worker, j.WorkerId), TxnType.JobReconcile, rec.Id, rec.Number, j.BranchId, rec.DocDateUtc, "Reconciliation " + rec.Number);
            }
            j.ApprovedLossFine = i.ApprovedLossFine; j.VarianceFine = res.Variance; j.VarianceApprovalReason = i.Reason; j.VarianceApprovedBy = needsApproval ? u.UserId : null;
            Transition(j, JobStatus.Reconciled, res.Summary);
            var e = _post.Reg(TxnType.JobReconcile, rec, 1, PartyType.Worker, j.WorkerId, await _post.PartyName(PartyType.Worker, j.WorkerId)); e.Fine = res.Variance; e.ItemName = "Reconciliation: " + res.Summary; e.LinkedDocId = j.Id; e.LinkedDocType = "JobCard"; e.LinkedDocNo = j.Number;
            _audit.Add("Job.Reconciled", nameof(JobCard), j.Id, after: new { rec.Number, res.Variance, res.Summary, i.ApprovedLossFine }, reason: i.Reason, targetBranchId: j.BranchId);
            return 0;
        });
        return await Get(id);
    }

    public async Task<JobDto> Close(long id)
    {
        _cu.Ctx.Require(Perms.JobWorkClose);
        var j = await Load(id);
        if (j.JobStatus != JobStatus.Reconciled) throw new ConflictException("Only reconciled jobs can be closed.");
        var left = await _db.StockBalances.Where(b => b.BranchId == j.BranchId && b.Status == StockStatus.WithWorker && b.CustodyRefId == j.Id).SumAsync(b => b.NetWeight);
        if (left > 0.0005m) throw new ConflictException($"{left:0.###}g is still in the worker's custody. Reconcile it before closing.");
        Transition(j, JobStatus.Closed, "Closed"); j.Status = DocStatus.Closed;
        await _audit.Save("Job.Closed", nameof(JobCard), id, targetBranchId: j.BranchId);
        return await Get(id);
    }

    // ---------------- worker payments ----------------
    public async Task<JobDocRow> PayWorker(WorkerPaymentInput i)
    {
        var u = _cu.Ctx; u.RequireAny(Perms.JobWorkPay, Perms.FinancePaymentPost);
        var branch = await _post.PostingBranch(i.BranchId);
        if (i.Amount <= 0) throw new ValidationFailedException("amount", "Amount must be positive.");
        if (!string.IsNullOrWhiteSpace(i.IdempotencyKey)) { var d = await _db.WorkerPayments.AsNoTracking().FirstOrDefaultAsync(x => x.IdempotencyKey == i.IdempotencyKey); if (d != null) return new JobDocRow(d.Id, d.Number, d.DocDateUtc, "Worker payment", 0, d.Amount); }
        long pid = 0;
        await _post.InTransaction(async () =>
        {
            var w = await _db.Workers.AsNoTracking().FirstOrDefaultAsync(x => x.Id == i.WorkerId) ?? throw new NotFoundException("Worker");
            JobCard? j = null; if (i.JobCardId != null) j = await Load(i.JobCardId.Value);
            var p = new WorkerPayment { CompanyId = u.CompanyId, BranchId = branch, Number = await _num.Next("WPY", branch), DocDateUtc = DateTime.UtcNow, WorkerId = w.Id, JobCardId = j?.Id, PaymentMethodId = i.PaymentMethodId, AccountId = i.AccountId, Amount = Money.R2(i.Amount), Reference = i.Reference, IdempotencyKey = i.IdempotencyKey, Status = DocStatus.Posted, PostedBy = u.UserId, PostedAtUtc = DateTime.UtcNow };
            _db.WorkerPayments.Add(p); await _db.SaveChangesAsync();
            if (j != null) j.MakingChargesPaid = Money.R2(j.MakingChargesPaid + p.Amount);
            _post.Party(PartyType.Worker, w.Id, branch, p.DocDateUtc, TxnType.WorkerPayment, p.Id, p.Number, "Payment to worker", p.Amount, 0);
            await _post.Journal(new JournalBuilder().Dr(Acc.WorkerPayable, p.Amount, "Worker payment", PartyType.Worker, w.Id).CrAcc(await _post.LedgerAccountFor(i.AccountId), p.Amount, "Paid"), TxnType.WorkerPayment, p.Id, p.Number, branch, p.DocDateUtc, "Worker payment " + p.Number);
            var e = _post.Reg(TxnType.WorkerPayment, p, 1, PartyType.Worker, w.Id, w.Name); e.PkrDebit = p.Amount; e.ItemName = "Worker payment";
            _audit.Add("Worker.Paid", nameof(WorkerPayment), p.Id, after: new { p.Number, p.Amount }, targetBranchId: branch);
            pid = p.Id; return 0;
        });
        var r = await _db.WorkerPayments.AsNoTracking().FirstAsync(x => x.Id == pid);
        return new JobDocRow(r.Id, r.Number, r.DocDateUtc, "Worker payment", 0, r.Amount);
    }

    // ---------------- queries ----------------
    public async Task<PagedResult<JobRow>> List(JobQuery q)
    {
        var u = _cu.Ctx; u.RequireAny(Perms.JobWorkView, Perms.JobWorkViewAssigned);
        var s = _db.JobCards.AsNoTracking().AsQueryable();
        if (!u.Has(Perms.JobWorkView)) { var wid = u.WorkerId ?? -1; s = s.Where(x => x.WorkerId == wid); }
        else { var br = u.ResolveScope(q.BranchIds); s = s.Where(x => br.Contains(x.BranchId)); }
        if (q.Status != null) s = s.Where(x => x.JobStatus == q.Status);
        if (q.WorkerId != null) s = s.Where(x => x.WorkerId == q.WorkerId);
        var now = DateTime.UtcNow;
        if (q.Overdue == true) s = s.Where(x => x.DueDateUtc != null && x.DueDateUtc < now && x.JobStatus != JobStatus.Closed && x.JobStatus != JobStatus.Cancelled && x.JobStatus != JobStatus.Reconciled);
        if (!string.IsNullOrWhiteSpace(q.Search)) { var t = q.Search.Trim(); s = s.Where(x => x.Number.Contains(t) || x.DesignSpec.Contains(t)); }
        var total = await s.CountAsync();
        var rows = await s.OrderByDescending(x => x.Id).Skip(q.Skip).Take(q.Take).ToListAsync();
        var wids = rows.Select(r => r.WorkerId).Distinct().ToList();
        var names = await _db.Workers.AsNoTracking().Where(w => wids.Contains(w.Id)).ToDictionaryAsync(w => w.Id, w => w.Name);
        return new PagedResult<JobRow>(rows.Select(r => new JobRow(r.Id, r.Number, names.GetValueOrDefault(r.WorkerId, ""), r.JobStatus, r.StockPostingMode, r.DueDateUtc, IsOverdue(r), r.IssuedFine, r.ReceivedOutputFine, r.VarianceFine, Money.R2(r.MakingChargesAccrued - r.MakingChargesPaid))).ToList(), total, q.Page, q.Take);
    }

    static bool IsOverdue(JobCard j) => j.DueDateUtc != null && j.DueDateUtc < DateTime.UtcNow && j.JobStatus is not (JobStatus.Closed or JobStatus.Cancelled or JobStatus.Reconciled);

    public async Task<JobDto> Get(long id)
    {
        var j = await Load(id, false);
        var w = await _db.Workers.AsNoTracking().Where(x => x.Id == j.WorkerId).Select(x => x.Name).FirstOrDefaultAsync() ?? "";
        var pur = await _db.Purities.AsNoTracking().ToDictionaryAsync(p => p.Id, p => p.Label);
        var met = await _db.MetalTypes.AsNoTracking().ToDictionaryAsync(m => m.Id, m => m.Name);
        var cust = await _db.StockBalances.AsNoTracking().Where(b => b.Status == StockStatus.WithWorker && b.CustodyRefId == j.Id && (b.NetWeight != 0 || b.GrossWeight != 0)).ToListAsync();
        var issues = await _db.JobMaterialIssues.AsNoTracking().Include(x => x.Lines).Where(x => x.JobCardId == j.Id).OrderBy(x => x.Id).ToListAsync();
        var receipts = await _db.JobReceipts.AsNoTracking().Include(x => x.Lines).Where(x => x.JobCardId == j.Id).OrderBy(x => x.Id).ToListAsync();
        var rec = Calc(j, j.ApprovedLossFine);
        var status = j.StockPostingMode == StockPostingMode.OnReceiptOnly ? "Not Issued / Planning Only" : j.IssuedFine > 0 ? "Issued" : "Awaiting issue";
        return new JobDto(j.Id, j.Number, j.BranchId, j.WorkerId, w, j.JobStatus, j.StockPostingMode, j.MaterialOwnership, j.MaterialSourceNote, j.DesignSpec, j.DueDateUtc, IsOverdue(j), j.TargetPieces, j.MakingType, j.MakingValue, j.WastageAllowancePercent, j.ToleranceFineGrams,
            j.IssuedFine, j.AdditionalInputFine, j.ReceivedOutputFine, j.ReturnedFine, j.ScrapFine, j.ApprovedLossFine, j.VarianceFine, j.MakingChargesAccrued, j.MakingChargesPaid, j.StockModeLocked, status,
            cust.Select(c => new CustodyRow(c.LocationId, c.MetalTypeId != null ? met.GetValueOrDefault(c.MetalTypeId.Value) : null, c.PurityId != null ? pur.GetValueOrDefault(c.PurityId.Value) : null, c.GrossWeight, c.NetWeight, c.FineWeight)).ToList(),
            issues.Select(x => new JobDocRow(x.Id, x.Number, x.DocDateUtc, string.Join(", ", x.Lines.Select(l => $"{l.NetWeight:0.###}g {pur.GetValueOrDefault(l.PurityId)}")), x.Lines.Sum(l => l.FineWeight), 0)).ToList(),
            receipts.Select(x => new JobDocRow(x.Id, x.Number, x.DocDateUtc, string.Join(", ", x.Lines.Select(l => $"{l.Kind} {l.NetWeight:0.###}g {pur.GetValueOrDefault(l.PurityId)}")), x.OutputFine + x.ReturnedFine + x.ScrapFine, x.MakingCharge)).ToList(),
            j.Stages.OrderBy(s => s.AtUtc).Select(s => (s.FromStatus, s.ToStatus, s.AtUtc, s.Note)).ToList(),
            new ReconPreview(rec.TotalInput, rec.Accounted, rec.Variance, rec.AllowedWastage, rec.ExcessLoss, rec.UnexpectedGain, rec.WithinTolerance, rec.RequiresApproval, rec.Summary), j.Notes);
    }
}
