using System.Security.Cryptography;
using Erp.Domain;
using Erp.Domain.Calc;
using Erp.Domain.Entities;
using Erp.Infrastructure.Contracts;
using Erp.Infrastructure.Data;
using Erp.Infrastructure.Files;
using Microsoft.EntityFrameworkCore;

namespace Erp.Infrastructure.Services;

public sealed class ProductInput
{
    public string? Sku { get; set; }
    public string? Barcode { get; set; }
    public string Name { get; set; } = "";
    public string? NameUrdu { get; set; }
    public long? CategoryId { get; set; }
    public long? SubCategoryId { get; set; }
    public TrackingMode Tracking { get; set; } = TrackingMode.Serialized;
    public long? MetalTypeId { get; set; }
    public long? PurityId { get; set; }
    public string? Design { get; set; }
    public string? Size { get; set; }
    public decimal GrossWeight { get; set; }
    public decimal StoneWeight { get; set; }
    public decimal OtherDeduction { get; set; }
    public string? StoneDetails { get; set; }
    public decimal StoneValue { get; set; }
    public PricingMode PricingMode { get; set; } = PricingMode.MetalPlusMaking;
    public ChargeType MakingType { get; set; } = ChargeType.PerGram;
    public decimal MakingValue { get; set; }
    public decimal WastagePercent { get; set; }
    public decimal TagPrice { get; set; }
    public decimal? CostPrice { get; set; }
    public decimal MinStock { get; set; }
    public long? SupplierId { get; set; }
    public long? DefaultBranchId { get; set; }
    public long? UnitId { get; set; }
    public bool IsStockItem { get; set; } = true;
    public bool IsActive { get; set; } = true;
    public string? Notes { get; set; }
}

public sealed class ProductQuery : PageQuery
{
    public long? CategoryId { get; set; }
    public long? PurityId { get; set; }
    public long? MetalTypeId { get; set; }
    public decimal? MinWeight { get; set; }
    public decimal? MaxWeight { get; set; }
    public long[]? BranchIds { get; set; }
    public string? StockFilter { get; set; }     // instock | outofstock | all
    public TrackingMode? Tracking { get; set; }
    public bool? Active { get; set; }
}

public sealed record ProductDto(long Id, string Sku, string? Barcode, string Name, string? NameUrdu, long? CategoryId, string? Category, TrackingMode Tracking, long? MetalTypeId, string? Metal, long? PurityId, string? Purity, decimal? PurityFactor,
    string? Design, string? Size, decimal GrossWeight, decimal StoneWeight, decimal OtherDeduction, decimal NetMetalWeight, decimal FineWeight, string? StoneDetails, decimal StoneValue, PricingMode PricingMode, ChargeType MakingType, decimal MakingValue,
    decimal WastagePercent, decimal TagPrice, decimal? CostPrice, decimal MinStock, long? SupplierId, long? DefaultBranchId, bool IsStockItem, bool IsActive, string? Notes,
    long? PrimaryImageId, int ImageCount, decimal AvailableQty);

public sealed record ImageDto(long Id, string Kind, string? Caption, bool IsPrimary, int SortOrder, int Width, int Height, long ByteSize, string MimeType, DateTime UploadedAtUtc);
public sealed record GalleryItem(ProductDto Product, IReadOnlyList<ImageDto> Images);

public sealed class ProductService
{
    readonly ErpDbContext _db; readonly CurrentUser _cu; readonly AuditService _audit; readonly NumberingService _num; readonly AccessGuard _guard;
    public ProductService(ErpDbContext db, CurrentUser cu, AuditService audit, NumberingService num, AccessGuard guard) { _db = db; _cu = cu; _audit = audit; _num = num; _guard = guard; }

    static readonly string[] Sortable = { "Sku", "Name", "NetMetalWeight", "GrossWeight", "TagPrice", "CreatedAtUtc" };

    public async Task<PagedResult<ProductDto>> List(ProductQuery pq)
    {
        var u = _cu.Ctx; u.Require(Perms.ProductsView);
        var branches = u.ResolveScope(pq.BranchIds);
        IQueryable<Product> q = _db.Products.AsNoTracking();
        if (pq.Active != null) q = q.Where(p => p.IsActive == pq.Active);
        if (pq.CategoryId != null) q = q.Where(p => p.CategoryId == pq.CategoryId || p.SubCategoryId == pq.CategoryId);
        if (pq.PurityId != null) q = q.Where(p => p.PurityId == pq.PurityId);
        if (pq.MetalTypeId != null) q = q.Where(p => p.MetalTypeId == pq.MetalTypeId);
        if (pq.Tracking != null) q = q.Where(p => p.Tracking == pq.Tracking);
        if (pq.MinWeight != null) q = q.Where(p => p.NetMetalWeight >= pq.MinWeight);
        if (pq.MaxWeight != null) q = q.Where(p => p.NetMetalWeight <= pq.MaxWeight);
        if (!string.IsNullOrWhiteSpace(pq.Search))
        {
            var s = pq.Search.Trim();
            q = q.Where(p => p.Sku.Contains(s) || p.Name.Contains(s) || (p.Barcode != null && p.Barcode == s) || (p.Design != null && p.Design.Contains(s)));
        }
        if (pq.StockFilter == "instock") q = q.Where(p => _db.StockBalances.Any(b => b.ProductId == p.Id && b.Status == StockStatus.Available && b.Quantity > 0 && branches.Contains(b.BranchId)));
        else if (pq.StockFilter == "outofstock") q = q.Where(p => !_db.StockBalances.Any(b => b.ProductId == p.Id && b.Status == StockStatus.Available && b.Quantity > 0 && branches.Contains(b.BranchId)));
        var total = await q.CountAsync();
        var rows = await q.OrderByProp(pq.Sort, pq.Desc, Sortable, "Sku").Skip(pq.Skip).Take(pq.Take).ToListAsync();
        return new PagedResult<ProductDto>(await Project(rows, branches), total, pq.Page, pq.Take);
    }

    public async Task<ProductDto> Get(long id)
    {
        var u = _cu.Ctx; u.Require(Perms.ProductsView);
        var p = await _guard.Find(_db.Products.AsNoTracking(), id, "Product");
        return (await Project(new List<Product> { p }, u.ResolveScope()))[0];
    }

    /// <summary>POS scan: exact barcode or SKU. Returns the item plus availability in the selected branch.</summary>
    public async Task<ProductDto> Scan(string code, long? branchId)
    {
        var u = _cu.Ctx; u.RequireAny(Perms.ProductsView, Perms.SalesCreate);
        var c = (code ?? "").Trim();
        var p = await _db.Products.AsNoTracking().FirstOrDefaultAsync(x => x.IsActive && (x.Barcode == c || x.Sku == c)) ?? throw new NotFoundException("Item");
        return (await Project(new List<Product> { p }, new[] { u.PostingBranch(branchId) }))[0];
    }

    async Task<List<ProductDto>> Project(List<Product> rows, long[] branches)
    {
        var u = _cu.Ctx;
        var ids = rows.Select(r => r.Id).ToList();
        var stock = await _db.StockBalances.AsNoTracking().Where(b => ids.Contains(b.ProductId ?? 0) && b.Status == StockStatus.Available && branches.Contains(b.BranchId))
            .GroupBy(b => b.ProductId).Select(g => new { Id = g.Key, Qty = g.Sum(x => x.Quantity) }).ToListAsync();
        var imgs = await _db.Files.AsNoTracking().Where(f => f.OwnerType == FileOwnerType.Product && ids.Contains(f.OwnerId) && !f.IsArchived).Select(f => new { f.OwnerId, f.Id, f.IsPrimary, f.SortOrder }).ToListAsync();
        var cats = await _db.ProductCategories.AsNoTracking().ToDictionaryAsync(c => c.Id, c => c.Name);
        var metals = await _db.MetalTypes.AsNoTracking().ToDictionaryAsync(m => m.Id, m => m.Name);
        var pur = await _db.Purities.AsNoTracking().ToDictionaryAsync(x => x.Id, x => x);
        var seeCost = u.Has(Perms.ReportsCost);
        return rows.Select(p =>
        {
            var my = imgs.Where(i => i.OwnerId == p.Id).OrderByDescending(i => i.IsPrimary).ThenBy(i => i.SortOrder).ToList();
            pur.TryGetValue(p.PurityId ?? 0, out var pr);
            return new ProductDto(p.Id, p.Sku, p.Barcode, p.Name, p.NameUrdu, p.CategoryId, p.CategoryId != null ? cats.GetValueOrDefault(p.CategoryId.Value) : null, p.Tracking, p.MetalTypeId, p.MetalTypeId != null ? metals.GetValueOrDefault(p.MetalTypeId.Value) : null,
                p.PurityId, pr?.Label, pr?.Factor, p.Design, p.Size, p.GrossWeight, p.StoneWeight, p.OtherDeduction, p.NetMetalWeight, pr != null ? WeightCalc.Fine(p.NetMetalWeight, pr.Factor) : 0m, p.StoneDetails, p.StoneValue, p.PricingMode, p.MakingType, p.MakingValue,
                p.WastagePercent, p.TagPrice, seeCost ? p.CostPrice : null, p.MinStock, p.SupplierId, p.DefaultBranchId, p.IsStockItem, p.IsActive, p.Notes, my.FirstOrDefault()?.Id, my.Count, stock.FirstOrDefault(s => s.Id == p.Id)?.Qty ?? 0m);
        }).ToList();
    }

    public async Task<ProductDto> Save(long? id, ProductInput i)
    {
        var u = _cu.Ctx; u.Require(id == null ? Perms.ProductsCreate : Perms.ProductsEdit);
        var errors = new Dictionary<string, string[]>();
        if (string.IsNullOrWhiteSpace(i.Name)) errors["name"] = new[] { "Name is required." };
        if (i.Tracking is TrackingMode.Serialized or TrackingMode.LooseMetal && (i.MetalTypeId == null || i.PurityId == null)) errors["purityId"] = new[] { "Metal and purity/karat are required for metal items." };
        if (i.MakingValue < 0 || i.TagPrice < 0 || i.StoneValue < 0 || i.WastagePercent < 0 || i.WastagePercent > 100) errors["pricing"] = new[] { "Pricing values must be zero or positive (wastage 0-100%)." };
        decimal net;
        try { net = WeightCalc.NetMetal(i.GrossWeight, i.StoneWeight, i.OtherDeduction); }
        catch (DomainException ex) { errors["weights"] = new[] { ex.Message }; net = 0; }
        if (errors.Count > 0) throw new ValidationFailedException(errors);
        if (i.PurityId != null)
        {
            var pu = await _db.Purities.AsNoTracking().FirstOrDefaultAsync(x => x.Id == i.PurityId) ?? throw new ValidationFailedException("purityId", "Purity not found.");
            if (i.MetalTypeId != null && pu.MetalTypeId != i.MetalTypeId) throw new ValidationFailedException("purityId", "Purity does not belong to the selected metal.");
            i.MetalTypeId ??= pu.MetalTypeId;
        }

        Product p; object? before = null;
        if (id == null)
        {
            p = new Product { CompanyId = u.CompanyId };
            _db.Products.Add(p);
            p.Sku = string.IsNullOrWhiteSpace(i.Sku) ? await _num.Next("SKU", u.PostingBranch(i.DefaultBranchId), 6) : i.Sku.Trim().ToUpperInvariant();
        }
        else
        {
            p = await _guard.Find(_db.Products, id.Value, "Product");
            before = new { p.Sku, p.Name, p.GrossWeight, p.StoneWeight, p.NetMetalWeight, p.PurityId, p.TagPrice, p.MakingValue };
            var hasStock = await _db.StockMovements.AnyAsync(m => m.ProductId == p.Id);
            if (hasStock && (p.Tracking != i.Tracking || p.PurityId != i.PurityId || p.MetalTypeId != i.MetalTypeId))
                throw new ConflictException("Metal, purity and tracking mode cannot change once the item has stock history. Adjust through a stock reclassification.", "product_locked");
            if (!string.IsNullOrWhiteSpace(i.Sku) && !string.Equals(p.Sku, i.Sku.Trim(), StringComparison.OrdinalIgnoreCase))
            {
                if (hasStock) throw new ConflictException("SKU cannot change once the item has stock history.", "product_locked");
                p.Sku = i.Sku.Trim().ToUpperInvariant();
            }
        }
        var bc = string.IsNullOrWhiteSpace(i.Barcode) ? null : i.Barcode.Trim();
        if (bc != null && await _db.Products.AnyAsync(x => x.Barcode == bc && x.Id != p.Id)) throw new ConflictException("Another item already uses this barcode.", "duplicate");
        if (await _db.Products.AnyAsync(x => x.Sku == p.Sku && x.Id != p.Id)) throw new ConflictException("Another item already uses this SKU.", "duplicate");

        p.Barcode = bc ?? p.Barcode ?? p.Sku; p.Name = i.Name.Trim(); p.NameUrdu = i.NameUrdu; p.CategoryId = i.CategoryId; p.SubCategoryId = i.SubCategoryId; p.Tracking = i.Tracking;
        p.MetalTypeId = i.MetalTypeId; p.PurityId = i.PurityId; p.Design = i.Design; p.Size = i.Size; p.GrossWeight = i.GrossWeight; p.StoneWeight = i.StoneWeight; p.OtherDeduction = i.OtherDeduction;
        p.NetMetalWeight = net; p.StoneDetails = i.StoneDetails; p.StoneValue = i.StoneValue; p.PricingMode = i.PricingMode; p.MakingType = i.MakingType; p.MakingValue = i.MakingValue;
        p.WastagePercent = i.WastagePercent; p.TagPrice = i.TagPrice; p.MinStock = i.MinStock; p.SupplierId = i.SupplierId; p.DefaultBranchId = i.DefaultBranchId; p.UnitId = i.UnitId;
        p.IsStockItem = i.IsStockItem && i.Tracking != TrackingMode.Service; p.IsActive = i.IsActive; p.Notes = i.Notes;
        if (i.CostPrice != null && u.Has(Perms.ReportsCost)) p.CostPrice = i.CostPrice.Value;   // cost is only writable by users who may see it
        await _db.SaveChangesAsync();
        await _audit.Save(id == null ? "Product.Created" : "Product.Updated", "Product", p.Id, before, new { p.Sku, p.Name, p.GrossWeight, p.StoneWeight, p.NetMetalWeight, p.PurityId, p.TagPrice, p.MakingValue });
        return await Get(p.Id);
    }

    public async Task<PagedResult<GalleryItem>> Gallery(ProductQuery pq)
    {
        _cu.Ctx.Require(Perms.ProductsImagesView);
        var page = await List(pq);
        var ids = page.Items.Select(x => x.Id).ToList();
        var files = await _db.Files.AsNoTracking().Where(f => f.OwnerType == FileOwnerType.Product && ids.Contains(f.OwnerId) && !f.IsArchived).OrderByDescending(f => f.IsPrimary).ThenBy(f => f.SortOrder).ToListAsync();
        var items = page.Items.Select(p => new GalleryItem(p, files.Where(f => f.OwnerId == p.Id).Select(FileService.ToDto).ToList())).ToList();
        return new PagedResult<GalleryItem>(items, page.Total, page.Page, page.PageSize);
    }

    /// <summary>Label data for barcode/QR printing (SKU, short description, karat, weight, price).</summary>
    public async Task<object> Label(long id)
    {
        var p = await Get(id);
        return new { p.Sku, p.Barcode, Description = p.Name, Karat = p.Purity, NetWeight = p.NetMetalWeight, Price = p.TagPrice };
    }
}

// ====================================================================================================
// Secure image/document upload & authorised delivery (SRS 10, 11)
// ====================================================================================================
public sealed class FileService
{
    readonly ErpDbContext _db; readonly CurrentUser _cu; readonly AuditService _audit; readonly IFileStorage _store; readonly IMalwareScanner _scan; readonly SettingsService _settings; readonly AccessGuard _guard;
    public FileService(ErpDbContext db, CurrentUser cu, AuditService audit, IFileStorage store, IMalwareScanner scan, SettingsService settings, AccessGuard guard)
    { _db = db; _cu = cu; _audit = audit; _store = store; _scan = scan; _settings = settings; _guard = guard; }

    public static ImageDto ToDto(FileAsset f) => new(f.Id, f.Kind.ToString(), f.Caption, f.IsPrimary, f.SortOrder, f.Width, f.Height, f.ByteSize, f.MimeType, f.CreatedAtUtc);

    /// <summary>The owner must be visible to the user (company + branch scope) and the matching permission must be held.</summary>
    async Task<long?> AuthoriseOwner(FileOwnerType type, long ownerId, bool write)
    {
        var u = _cu.Ctx;
        switch (type)
        {
            case FileOwnerType.Product:
                u.Require(write ? Perms.ProductsImagesUpload : Perms.ProductsImagesView);
                await _guard.Find(_db.Products.AsNoTracking(), ownerId, "Product"); return null;
            case FileOwnerType.RepairTicket:
                u.RequireAny(write ? new[] { Perms.RepairsImagesUpload, Perms.RepairsCreate } : new[] { Perms.RepairsViewBranch, Perms.RepairsViewAssigned });
                var r = await _guard.Find(_db.RepairTickets.AsNoTracking(), ownerId, "Repair ticket");
                if (!u.Has(Perms.RepairsViewBranch) && !(u.Has(Perms.RepairsViewAssigned) && r.TechnicianId != null && r.TechnicianId == u.EmployeeId)) throw new NotFoundException("Repair ticket");
                return r.BranchId;
            case FileOwnerType.JobCard:
                u.RequireAny(write ? new[] { Perms.JobWorkUpdateStage, Perms.JobWorkCreate } : new[] { Perms.JobWorkView, Perms.JobWorkViewAssigned });
                var j = await _guard.Find(_db.JobCards.AsNoTracking(), ownerId, "Job card");
                if (!u.Has(Perms.JobWorkView) && !(u.Has(Perms.JobWorkViewAssigned) && u.WorkerId == j.WorkerId)) throw new NotFoundException("Job card");
                return j.BranchId;
            case FileOwnerType.Customer: u.Require(Perms.CustomersView); await _guard.Find(_db.Customers.AsNoTracking(), ownerId, "Customer"); return null;
            case FileOwnerType.SupplierDocument: u.Require(Perms.SuppliersView); await _guard.Find(_db.Suppliers.AsNoTracking(), ownerId, "Supplier"); return null;
            case FileOwnerType.PurchaseInvoice: u.Require(Perms.PurchasesView); return (await _guard.Find(_db.PurchaseInvoices.AsNoTracking(), ownerId, "Purchase invoice")).BranchId;
            case FileOwnerType.ExpenseVoucher: u.RequireAny(Perms.FinanceView, Perms.FinanceExpenseCreate); return (await _guard.Find(_db.ExpenseVouchers.AsNoTracking(), ownerId, "Expense voucher")).BranchId;
            case FileOwnerType.OldGold: u.Require(Perms.OldGoldView); return (await _guard.Find(_db.OldGoldTransactions.AsNoTracking(), ownerId, "Old gold transaction")).BranchId;
            case FileOwnerType.Employee: u.Require(Perms.EmployeesView); await _guard.Find(_db.Employees.AsNoTracking(), ownerId, "Employee"); return null;
            default: throw new ForbiddenException("Unsupported owner type.");
        }
    }

    public async Task<ImageDto> Upload(FileOwnerType type, long ownerId, FileKind kind, Stream content, string fileName, string? caption, bool makePrimary)
    {
        var u = _cu.Ctx;
        var branchId = await AuthoriseOwner(type, ownerId, write: true);
        var maxMb = await _settings.Dec(SettingsService.Keys.MaxImageMb);
        var max = (long)(Math.Max(1, maxMb) * 1024 * 1024);
        using var ms = new MemoryStream();
        var buf = new byte[81920]; int n;
        while ((n = await content.ReadAsync(buf)) > 0) { ms.Write(buf, 0, n); if (ms.Length > max) throw new DomainException($"The image is larger than the {maxMb:0.#} MB limit.", "image_too_large"); }
        var bytes = ms.ToArray();

        var info = ImageInspector.Inspect(bytes, fileName);                     // signature + dimensions + extension match
        var scan = await _scan.ScanAsync(bytes);
        if (!scan.Clean) { await _audit.Save("File.Rejected", type.ToString(), ownerId, after: new { signature = scan.Signature }, reason: "Malware scan failed", denied: true); throw new DomainException("The file was rejected by the security scan.", "image_malware"); }
        var clean = ImageInspector.StripMetadata(bytes, info.Mime);             // remove EXIF/GPS/comments
        var checksum = Convert.ToHexString(SHA256.HashData(clean)).ToLowerInvariant();

        string key;
        using (var s = new MemoryStream(clean)) key = await _store.SaveAsync(s, info.Extension);
        try
        {
            var existing = await _db.Files.Where(f => f.OwnerType == type && f.OwnerId == ownerId && !f.IsArchived).ToListAsync();
            var first = existing.Count == 0;
            var asset = new FileAsset
            {
                CompanyId = u.CompanyId, BranchId = branchId, OwnerType = type, OwnerId = ownerId, Kind = kind, StorageKey = key, OriginalName = Path.GetFileName(fileName ?? "image"),
                MimeType = info.Mime, ByteSize = clean.Length, Checksum = checksum, Width = info.Width, Height = info.Height, Caption = caption,
                SortOrder = existing.Count == 0 ? 0 : existing.Max(f => f.SortOrder) + 1, IsPrimary = first || (makePrimary && type == FileOwnerType.Product)
            };
            if (asset.IsPrimary) foreach (var f in existing) f.IsPrimary = false;
            _db.Files.Add(asset);
            _audit.Add("File.Uploaded", type.ToString(), ownerId, after: new { asset.OriginalName, asset.ByteSize, asset.Kind });
            await _db.SaveChangesAsync();
            return ToDto(asset);
        }
        catch
        {
            await _store.DeleteAsync(key);      // a failed upload must never leave an orphan or broken reference
            throw;
        }
    }

    public async Task<List<ImageDto>> List(FileOwnerType type, long ownerId, FileKind? kind = null)
    {
        await AuthoriseOwner(type, ownerId, write: false);
        var q = _db.Files.AsNoTracking().Where(f => f.OwnerType == type && f.OwnerId == ownerId && !f.IsArchived);
        if (kind != null) q = q.Where(f => f.Kind == kind);
        return (await q.OrderByDescending(f => f.IsPrimary).ThenBy(f => f.SortOrder).ToListAsync()).Select(ToDto).ToList();
    }

    public async Task SetPrimary(long fileId)
    {
        var f = await _guard.Find(_db.Files, fileId, "File");
        await AuthoriseOwner(f.OwnerType, f.OwnerId, write: true);
        var all = await _db.Files.Where(x => x.OwnerType == f.OwnerType && x.OwnerId == f.OwnerId && !x.IsArchived).ToListAsync();
        foreach (var x in all) x.IsPrimary = x.Id == f.Id;
        await _audit.Save("File.SetPrimary", f.OwnerType.ToString(), f.OwnerId, after: new { fileId });
    }

    public async Task Reorder(FileOwnerType type, long ownerId, IList<long> orderedIds)
    {
        await AuthoriseOwner(type, ownerId, write: true);
        var all = await _db.Files.Where(x => x.OwnerType == type && x.OwnerId == ownerId && !x.IsArchived).ToListAsync();
        for (int i = 0; i < orderedIds.Count; i++) { var f = all.FirstOrDefault(x => x.Id == orderedIds[i]); if (f != null) f.SortOrder = i; }
        await _audit.Save("File.Reordered", type.ToString(), ownerId);
    }

    /// <summary>Soft removal: the stored bytes are retained as archived evidence; hard deletion never happens from the UI/API.</summary>
    public async Task Remove(long fileId, string? reason)
    {
        var u = _cu.Ctx;
        var f = await _guard.Find(_db.Files, fileId, "File");
        await AuthoriseOwner(f.OwnerType, f.OwnerId, write: true);
        if (f.OwnerType == FileOwnerType.Product) u.Require(Perms.ProductsImagesDelete);
        f.IsArchived = true; f.IsPrimary = false;
        var next = await _db.Files.Where(x => x.OwnerType == f.OwnerType && x.OwnerId == f.OwnerId && !x.IsArchived && x.Id != f.Id).OrderBy(x => x.SortOrder).FirstOrDefaultAsync();
        if (f.OwnerType == FileOwnerType.Product && next != null && !await _db.Files.AnyAsync(x => x.OwnerType == f.OwnerType && x.OwnerId == f.OwnerId && x.IsPrimary && !x.IsArchived)) next.IsPrimary = true;
        await _audit.Save("File.Archived", f.OwnerType.ToString(), f.OwnerId, before: new { f.OriginalName, f.Checksum }, reason: reason);
    }

    public async Task<(Stream stream, string mime, string name)> Open(long fileId, bool download)
    {
        var f = await _guard.Find(_db.Files.AsNoTracking(), fileId, "File");
        await AuthoriseOwner(f.OwnerType, f.OwnerId, write: false);
        if (download) _cu.Ctx.Require(Perms.ProductsImagesDownload);
        if (f.OwnerType != FileOwnerType.Product || download) await _audit.Save(download ? "File.Downloaded" : "File.Viewed", f.OwnerType.ToString(), f.OwnerId, after: new { f.Id });   // restricted evidence is audited
        var s = await _store.OpenReadAsync(f.StorageKey) ?? throw new NotFoundException("File");
        return (s, f.MimeType, f.OriginalName);
    }
}
