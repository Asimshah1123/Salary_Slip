using System.Diagnostics;
using Erp.Domain;
using Erp.Domain.Entities;
using Erp.Infrastructure.Contracts;
using Erp.Infrastructure.Data;
using Erp.Infrastructure.Exports;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace Erp.Infrastructure.Services;

public sealed class UserInput
{
    public string UserName { get; set; } = "";
    public string Email { get; set; } = "";
    public string FullName { get; set; } = "";
    public string? Password { get; set; }
    public bool IsActive { get; set; } = true;
    public List<long> RoleIds { get; set; } = new();
    public List<long> BranchIds { get; set; } = new();
    public long? DefaultBranchId { get; set; }
    public long? EmployeeId { get; set; }
    public long? WorkerId { get; set; }
    public string PreferredLanguage { get; set; } = "en";
}
public sealed record UserDto(long Id, string UserName, string Email, string FullName, bool IsActive, bool Locked, DateTime? LastLoginUtc, long? DefaultBranchId, long? EmployeeId, long? WorkerId, IReadOnlyList<long> RoleIds, IReadOnlyList<string> Roles, IReadOnlyList<long> BranchIds, string PreferredLanguage);
public sealed class LimitInput { public ApprovalType Type { get; set; } public decimal MaxValue { get; set; } public long? BranchId { get; set; } }
public sealed class RoleInput { public string Name { get; set; } = ""; public string? Description { get; set; } public List<string> Permissions { get; set; } = new(); public List<LimitInput> Limits { get; set; } = new(); public bool IsActive { get; set; } = true; }
public sealed record RoleDto(long Id, string Name, string? Description, bool IsSystem, bool IsActive, IReadOnlyList<string> Permissions, IReadOnlyList<LimitInput> Limits, int Users);
public sealed class BranchInput { public string BranchCode { get; set; } = ""; public string BranchName { get; set; } = ""; public string? Address { get; set; } public string? City { get; set; } public string? Phone { get; set; } public string BranchType { get; set; } = "Retail"; public string InvoicePrefix { get; set; } = ""; public bool IsActive { get; set; } = true; public string? ReceiptFooter { get; set; } public long? DefaultCashAccountId { get; set; } public string? RatePolicy { get; set; } }
public sealed record AuditRow(long Id, DateTime AtUtc, string? User, string Action, string EntityType, string? EntityId, long? ActiveBranchId, long? TargetBranchId, string? Reason, bool Denied, string? CorrelationId, string? BeforeJson, string? AfterJson, string? Ip);
public sealed class AuditQuery : PageQuery { public DateTime? From { get; set; } public DateTime? To { get; set; } public long? UserId { get; set; } public string? Action { get; set; } public string? EntityType { get; set; } public string? EntityId { get; set; } public bool? Denied { get; set; } }
public sealed record ApprovalDto(long Id, ApprovalType Type, string EntityType, long EntityId, string? Number, decimal Value, decimal Limit, string? Reason, ApprovalStatus Status, string RequestedBy, DateTime RequestedAtUtc, string? DecidedBy, string? DecisionReason, long BranchId);
public sealed record BranchDto(long Id, string BranchCode, string BranchName, string? City, string? Address, string? Phone, bool IsActive, bool IsHeadOffice, string BranchType, string InvoicePrefix, string? ReceiptFooter, long? DefaultCashAccountId, string? RatePolicy);
public sealed record SettingDto(string Key, string Value, string Default, long? BranchId, bool IsOverride);
public sealed record BackupDto(long Id, DateTime StartedUtc, DateTime? FinishedUtc, string Status, bool Encrypted, long? SizeBytes, string? Message, DateTime? RestoreTestedUtc);

public sealed class AdminService
{
    readonly ErpDbContext _db; readonly CurrentUser _cu; readonly AuditService _audit; readonly UserAccessLoader _access; readonly AccessGuard _guard; readonly SettingsService _settings; readonly ApprovalService _approvals;
    public AdminService(ErpDbContext db, CurrentUser cu, AuditService audit, UserAccessLoader access, AccessGuard guard, SettingsService settings, ApprovalService approvals) { _db = db; _cu = cu; _audit = audit; _access = access; _guard = guard; _settings = settings; _approvals = approvals; }

    // ================= users =================
    public async Task<PagedResult<UserDto>> Users(PageQuery q)
    {
        _cu.Ctx.Require(Perms.UsersManage);
        var s = _db.Users.AsNoTracking().AsQueryable();
        if (!string.IsNullOrWhiteSpace(q.Search)) { var t = q.Search.Trim(); s = s.Where(u => u.UserName.Contains(t) || u.FullName.Contains(t) || u.Email.Contains(t)); }
        var total = await s.CountAsync();
        var ids = await s.OrderBy(u => u.UserName).Skip(q.Skip).Take(q.Take).Select(u => u.Id).ToListAsync();
        var items = new List<UserDto>(); foreach (var id in ids) items.Add(await UserDto_(id));
        return new PagedResult<UserDto>(items, total, q.Page, q.Take);
    }

    async Task<UserDto> UserDto_(long id)
    {
        var u = await _guard.Find(_db.Users.AsNoTracking(), id, "User");
        var rid = await _db.UserRoles.AsNoTracking().Where(r => r.UserId == id).Select(r => r.RoleId).Distinct().ToListAsync();
        var roles = await _db.Roles.AsNoTracking().Where(r => rid.Contains(r.Id)).Select(r => r.Name).ToListAsync();
        var bids = await _db.UserBranchAccess.AsNoTracking().Where(b => b.UserId == id && b.IsActive).Select(b => b.BranchId).ToListAsync();
        return new UserDto(u.Id, u.UserName, u.Email, u.FullName, u.IsActive, u.LockoutUntilUtc > DateTime.UtcNow, u.LastLoginUtc, u.DefaultBranchId, u.EmployeeId, u.WorkerId, rid, roles, bids, u.PreferredLanguage);
    }

    /// <summary>Nobody can hand out more than they hold: roles are only assignable if their permissions are a subset of the actor's own.</summary>
    async Task EnforceNoEscalation(IEnumerable<long> roleIds, IEnumerable<long> branchIds)
    {
        var me = _cu.Ctx;
        foreach (var b in branchIds) me.RequireBranch(b);
        var perms = await (from rp in _db.RolePermissions.AsNoTracking() join p in _db.Permissions.AsNoTracking() on rp.PermissionId equals p.Id where roleIds.Contains(rp.RoleId) select p.Code).Distinct().ToListAsync();
        var missing = perms.Where(p => !me.Has(p)).ToList();
        if (missing.Count > 0) throw new ForbiddenException($"You cannot assign roles carrying permissions you do not hold ({string.Join(", ", missing.Take(5))}{(missing.Count > 5 ? ", ..." : "")}).", "privilege_escalation");
    }

    public async Task<UserDto> SaveUser(long? id, UserInput i)
    {
        var me = _cu.Ctx; me.Require(Perms.UsersManage);
        var errs = new Dictionary<string, string[]>();
        if (string.IsNullOrWhiteSpace(i.UserName) || i.UserName.Trim().Length < 3 || i.UserName.Any(char.IsWhiteSpace)) errs["userName"] = new[] { "User name must be at least 3 characters with no spaces." };
        if (string.IsNullOrWhiteSpace(i.Email) || !i.Email.Contains('@')) errs["email"] = new[] { "A valid email is required." };
        if (string.IsNullOrWhiteSpace(i.FullName)) errs["fullName"] = new[] { "Full name is required." };
        if (i.RoleIds.Count == 0) errs["roleIds"] = new[] { "Assign at least one role." };
        if (i.BranchIds.Count == 0) errs["branchIds"] = new[] { "Assign at least one branch." };
        if (i.DefaultBranchId != null && !i.BranchIds.Contains(i.DefaultBranchId.Value)) errs["defaultBranchId"] = new[] { "The default branch must be one of the assigned branches." };
        if (id == null) { if (string.IsNullOrWhiteSpace(i.Password)) errs["password"] = new[] { "A temporary password is required." }; else try { PasswordHasher.Validate(i.Password); } catch (ValidationFailedException e) { errs["password"] = e.Errors["password"]; } }
        if (errs.Count > 0) throw new ValidationFailedException(errs);
        await EnforceNoEscalation(i.RoleIds, i.BranchIds);
        var roles = await _db.Roles.AsNoTracking().Where(r => i.RoleIds.Contains(r.Id) && r.IsActive).Select(r => r.Id).ToListAsync();
        if (roles.Count != i.RoleIds.Distinct().Count()) throw new ValidationFailedException("roleIds", "A role was not found or is inactive.");

        long uid = 0;
        await using (var tx = await _db.Database.BeginTransactionAsync())
        {
            AppUser u; bool isNew = id == null; object? before = null; var rotate = false;
            if (isNew) { u = new AppUser { CompanyId = me.CompanyId }; _db.Users.Add(u); }
            else
            {
                u = await _db.Users.FirstOrDefaultAsync(x => x.Id == id) ?? throw new NotFoundException("User");
                if (u.Id == me.UserId && !i.IsActive) throw new ConflictException("You cannot deactivate your own account.");
                before = new { u.UserName, u.IsActive, u.Email };
                var oldRoles = (await _db.UserRoles.Where(r => r.UserId == u.Id).Select(r => r.RoleId).ToListAsync()).OrderBy(x => x).ToList();
                var oldBr = (await _db.UserBranchAccess.Where(b => b.UserId == u.Id && b.IsActive).Select(b => b.BranchId).ToListAsync()).OrderBy(x => x).ToList();
                rotate = !oldRoles.SequenceEqual(i.RoleIds.Distinct().OrderBy(x => x)) || !oldBr.SequenceEqual(i.BranchIds.Distinct().OrderBy(x => x)) || u.IsActive != i.IsActive;
            }
            var uname = i.UserName.Trim(); var mail = i.Email.Trim();
            if (await _db.Users.IgnoreQueryFilters().AnyAsync(x => x.Id != u.Id && (x.UserName.ToLower() == uname.ToLower() || x.Email.ToLower() == mail.ToLower()))) throw new ConflictException("That user name or email is already in use.", "duplicate");
            u.UserName = uname; u.Email = mail; u.FullName = i.FullName.Trim(); u.IsActive = i.IsActive; u.EmployeeId = i.EmployeeId; u.WorkerId = i.WorkerId; u.PreferredLanguage = i.PreferredLanguage; u.DefaultBranchId = i.DefaultBranchId ?? i.BranchIds.First();
            if (isNew) { AuthService.SetPassword(u, i.Password!); u.MustChangePassword = true; }
            await _db.SaveChangesAsync();
            _db.UserRoles.RemoveRange(await _db.UserRoles.Where(r => r.UserId == u.Id).ToListAsync());
            foreach (var r in i.RoleIds.Distinct()) _db.UserRoles.Add(new UserRole { UserId = u.Id, RoleId = r });
            var existing = await _db.UserBranchAccess.Where(b => b.UserId == u.Id).ToListAsync();
            foreach (var e in existing) { e.IsActive = i.BranchIds.Contains(e.BranchId); e.IsDefault = e.BranchId == u.DefaultBranchId; }
            foreach (var b in i.BranchIds.Distinct().Where(b => existing.All(e => e.BranchId != b))) _db.UserBranchAccess.Add(new UserBranchAccess { UserId = u.Id, BranchId = b, IsDefault = b == u.DefaultBranchId });
            if (rotate) { u.SecurityStamp = Guid.NewGuid().ToString("N"); foreach (var t in await _db.RefreshTokens.Where(t => t.UserId == u.Id && t.RevokedUtc == null).ToListAsync()) t.RevokedUtc = DateTime.UtcNow; }   // sessions must re-authenticate after access changes
            _audit.Add(isNew ? "User.Created" : "User.Updated", nameof(AppUser), u.Id, before, new { u.UserName, u.IsActive, roles = i.RoleIds, branches = i.BranchIds });
            await _db.SaveChangesAsync(); await tx.CommitAsync(); uid = u.Id;
        }
        _access.Invalidate(uid);
        return await UserDto_(uid);
    }

    public async Task ResetUserPassword(long id, string tempPassword)
    {
        _cu.Ctx.Require(Perms.UsersManage); PasswordHasher.Validate(tempPassword);
        var u = await _db.Users.FirstOrDefaultAsync(x => x.Id == id) ?? throw new NotFoundException("User");
        AuthService.SetPassword(u, tempPassword); u.MustChangePassword = true; u.FailedLoginCount = 0; u.LockoutUntilUtc = null;
        foreach (var t in await _db.RefreshTokens.Where(t => t.UserId == id && t.RevokedUtc == null).ToListAsync()) t.RevokedUtc = DateTime.UtcNow;
        await _audit.Save("User.PasswordReset", nameof(AppUser), id);   // the password itself is never logged
        _access.Invalidate(id);
    }

    public async Task Unlock(long id)
    {
        _cu.Ctx.Require(Perms.UsersManage);
        var u = await _db.Users.FirstOrDefaultAsync(x => x.Id == id) ?? throw new NotFoundException("User");
        u.FailedLoginCount = 0; u.LockoutUntilUtc = null; await _audit.Save("User.Unlocked", nameof(AppUser), id);
    }

    public async Task<List<object>> LoginHistory(long userId)
    {
        _cu.Ctx.Require(Perms.UsersManage);
        return (await _db.LoginAttempts.AsNoTracking().Where(l => l.UserId == userId).OrderByDescending(l => l.AtUtc).Take(50).ToListAsync()).Select(l => (object)new { l.AtUtc, l.Succeeded, l.Ip, l.DeviceInfo }).ToList();
    }

    // ================= roles =================
    public async Task<List<RoleDto>> Roles()
    {
        _cu.Ctx.RequireAny(Perms.RolesManage, Perms.UsersManage);
        var roles = await _db.Roles.AsNoTracking().OrderBy(r => r.Name).ToListAsync();
        var res = new List<RoleDto>(); foreach (var r in roles) res.Add(await RoleDto_(r)); return res;
    }
    async Task<RoleDto> RoleDto_(Role r)
    {
        var perms = await (from rp in _db.RolePermissions.AsNoTracking() join p in _db.Permissions.AsNoTracking() on rp.PermissionId equals p.Id where rp.RoleId == r.Id select p.Code).OrderBy(x => x).ToListAsync();
        var lim = await _db.ApprovalLimits.AsNoTracking().Where(l => l.RoleId == r.Id).Select(l => new LimitInput { Type = l.Type, MaxValue = l.MaxValue, BranchId = l.BranchId }).ToListAsync();
        return new RoleDto(r.Id, r.Name, r.Description, r.IsSystem, r.IsActive, perms, lim, await _db.UserRoles.CountAsync(x => x.RoleId == r.Id));
    }

    public IEnumerable<object> PermissionCatalogue() => Perms.All.GroupBy(Perms.ModuleOf).OrderBy(g => g.Key).Select(g => new { module = g.Key, permissions = g.ToList() });

    public async Task<RoleDto> SaveRole(long? id, RoleInput i)
    {
        var me = _cu.Ctx; me.Require(Perms.RolesManage);
        if (string.IsNullOrWhiteSpace(i.Name)) throw new ValidationFailedException("name", "Role name is required.");
        var bad = i.Permissions.Where(p => !Perms.All.Contains(p)).ToList(); if (bad.Count > 0) throw new ValidationFailedException("permissions", "Unknown permission: " + bad[0]);
        var escalate = i.Permissions.Where(p => !me.Has(p)).ToList(); if (escalate.Count > 0) throw new ForbiddenException($"You cannot grant permissions you do not hold ({escalate[0]}).", "privilege_escalation");
        long rid = 0; List<long> affected = new();
        await using (var tx = await _db.Database.BeginTransactionAsync())
        {
            Role r; object? before = null;
            if (id == null) { r = new Role { CompanyId = me.CompanyId }; _db.Roles.Add(r); }
            else
            {
                r = await _db.Roles.FirstOrDefaultAsync(x => x.Id == id) ?? throw new NotFoundException("Role");
                if (r.IsSystem && r.Name == RoleTemplates.Owner) throw new ConflictException("The System Owner role always holds every permission and cannot be edited.");
                before = await RoleDto_(r);
                if (!i.IsActive && await _db.UserRoles.AnyAsync(x => x.RoleId == r.Id)) throw new ConflictException("Reassign this role's users before deactivating it.");
            }
            r.Name = i.Name.Trim(); r.Description = i.Description; r.IsActive = i.IsActive;
            if (await _db.Roles.AnyAsync(x => x.Name == r.Name && x.Id != r.Id)) throw new ConflictException("A role with that name exists.", "duplicate");
            await _db.SaveChangesAsync();
            var map = await _db.Permissions.AsNoTracking().ToDictionaryAsync(p => p.Code, p => p.Id);
            _db.RolePermissions.RemoveRange(await _db.RolePermissions.Where(x => x.RoleId == r.Id).ToListAsync());
            foreach (var p in i.Permissions.Distinct()) _db.RolePermissions.Add(new RolePermission { RoleId = r.Id, PermissionId = map[p] });
            _db.ApprovalLimits.RemoveRange(await _db.ApprovalLimits.Where(x => x.RoleId == r.Id).ToListAsync());
            foreach (var l in i.Limits) { if (l.MaxValue < 0) throw new ValidationFailedException("limits", "Limits cannot be negative."); if (l.BranchId != null) me.RequireBranch(l.BranchId.Value); _db.ApprovalLimits.Add(new ApprovalLimit { CompanyId = me.CompanyId, RoleId = r.Id, Type = l.Type, MaxValue = l.MaxValue, BranchId = l.BranchId }); }
            // everyone holding this role must be re-authenticated against the new permission set
            affected = await _db.UserRoles.Where(x => x.RoleId == r.Id).Select(x => x.UserId).Distinct().ToListAsync();
            foreach (var u in await _db.Users.Where(x => affected.Contains(x.Id)).ToListAsync()) { u.SecurityStamp = Guid.NewGuid().ToString("N"); }
            foreach (var t in await _db.RefreshTokens.Where(t => affected.Contains(t.UserId) && t.RevokedUtc == null).ToListAsync()) t.RevokedUtc = DateTime.UtcNow;
            _audit.Add(id == null ? "Role.Created" : "Role.Updated", nameof(Role), r.Id, before, new { r.Name, permissions = i.Permissions.Count, limits = i.Limits.Count });
            await _db.SaveChangesAsync(); await tx.CommitAsync(); rid = r.Id;
        }
        foreach (var uid in affected) _access.Invalidate(uid);
        return await RoleDto_(await _db.Roles.AsNoTracking().FirstAsync(x => x.Id == rid));
    }

    // ================= branches =================
    public async Task<List<BranchDto>> Branches()
    {
        var u = _cu.Ctx;
        var rows = await _db.Branches.AsNoTracking().OrderBy(b => b.BranchName).ToListAsync();
        var visible = u.Has(Perms.BranchesManage) ? rows : rows.Where(b => u.BranchIds.Contains(b.Id)).ToList();
        return visible.Select(b => new BranchDto(b.Id, b.BranchCode, b.BranchName, b.City, b.Address, b.Phone, b.IsActive, b.IsHeadOffice, b.BranchType, b.InvoicePrefix, b.ReceiptFooter, b.DefaultCashAccountId, b.RatePolicy)).ToList();
    }

    public async Task<object> SaveBranch(long? id, BranchInput i)
    {
        var u = _cu.Ctx; u.Require(Perms.BranchesManage);
        if (string.IsNullOrWhiteSpace(i.BranchCode) || string.IsNullOrWhiteSpace(i.BranchName)) throw new ValidationFailedException("branchName", "Code and name are required.");
        var prefix = (string.IsNullOrWhiteSpace(i.InvoicePrefix) ? i.BranchCode : i.InvoicePrefix).Trim().ToUpperInvariant();
        if (prefix.Length > 8 || !prefix.All(char.IsLetterOrDigit)) throw new ValidationFailedException("invoicePrefix", "Prefix: up to 8 letters/digits.");
        if (await _db.Branches.AnyAsync(b => b.Id != (id ?? 0) && (b.BranchCode == i.BranchCode.Trim() || b.InvoicePrefix == prefix))) throw new ConflictException("Branch code or invoice prefix already exists.", "duplicate");
        Branch b; bool isNew = id == null; object? before = null;
        if (isNew) { b = new Branch { CompanyId = u.CompanyId }; _db.Branches.Add(b); }
        else
        {
            b = await _db.Branches.FirstOrDefaultAsync(x => x.Id == id) ?? throw new NotFoundException("Branch"); before = new { b.BranchName, b.IsActive, b.InvoicePrefix };
            if (b.InvoicePrefix != prefix && await _db.InvoiceSequences.AnyAsync(s => s.BranchId == b.Id && s.LastNumber > 0)) throw new ConflictException("The invoice prefix cannot change once documents have been numbered.");
        }
        b.BranchCode = i.BranchCode.Trim(); b.BranchName = i.BranchName.Trim(); b.Address = i.Address; b.City = i.City; b.Phone = i.Phone; b.BranchType = i.BranchType; b.InvoicePrefix = prefix; b.IsActive = i.IsActive; b.ReceiptFooter = i.ReceiptFooter; b.DefaultCashAccountId = i.DefaultCashAccountId; b.RatePolicy = i.RatePolicy;
        await _db.SaveChangesAsync();
        if (isNew)
        {
            foreach (var (code, name, kind, def) in new[] { ("SHW", "Showroom", "Showroom", true), ("VLT", "Vault", "Vault", false), ("INS", "Inspection", "Inspection", false), ("WSP", "Workshop", "Workshop", false) })
                _db.StoreLocations.Add(new StoreLocation { CompanyId = u.CompanyId, BranchId = b.Id, Code = code, Name = name, Kind = kind, IsDefault = def });
            _db.UserBranchAccess.Add(new UserBranchAccess { UserId = u.UserId, BranchId = b.Id });   // the creator can immediately work in the new branch
        }
        _audit.Add(isNew ? "Branch.Created" : "Branch.Updated", nameof(Branch), b.Id, before, new { b.BranchName, b.IsActive, b.InvoicePrefix }, targetBranchId: b.Id);
        await _db.SaveChangesAsync(); _access.Invalidate(u.UserId);
        return new { b.Id, b.BranchCode, b.BranchName, b.InvoicePrefix, b.IsActive };
    }

    // ================= audit log =================
    public async Task<PagedResult<AuditRow>> AuditLogs(AuditQuery q)
    {
        var u = _cu.Ctx; u.Require(Perms.AuditLogView);
        var s = AuditQ(q);
        var total = await s.CountAsync();
        var rows = await s.OrderByDescending(a => a.Id).Skip(q.Skip).Take(q.Take).ToListAsync();
        var sensitive = u.Has(Perms.AuditLogExport);
        return new PagedResult<AuditRow>(rows.Select(a => new AuditRow(a.Id, a.AtUtc, a.UserName, a.Action, a.EntityType, a.EntityId, a.ActiveBranchId, a.TargetBranchId, a.Reason, a.Denied, a.CorrelationId, sensitive ? a.BeforeJson : null, sensitive ? a.AfterJson : null, a.Ip)).ToList(), total, q.Page, q.Take);
    }
    IQueryable<AuditLog> AuditQ(AuditQuery q)
    {
        var u = _cu.Ctx; var allowed = u.BranchIds.ToArray(); var all = u.CanSeeAllBranches;
        var s = _db.AuditLogs.AsNoTracking().Where(a => all || a.TargetBranchId == null && a.ActiveBranchId == null || (a.TargetBranchId != null && allowed.Contains(a.TargetBranchId.Value)) || (a.ActiveBranchId != null && allowed.Contains(a.ActiveBranchId.Value)));
        if (q.From != null) s = s.Where(a => a.AtUtc >= q.From); if (q.To != null) s = s.Where(a => a.AtUtc < q.To.Value.AddDays(1));
        if (q.UserId != null) s = s.Where(a => a.UserId == q.UserId); if (!string.IsNullOrWhiteSpace(q.Action)) { var x = q.Action.Trim(); s = s.Where(a => a.Action.Contains(x)); }
        if (!string.IsNullOrWhiteSpace(q.EntityType)) s = s.Where(a => a.EntityType == q.EntityType); if (!string.IsNullOrWhiteSpace(q.EntityId)) s = s.Where(a => a.EntityId == q.EntityId); if (q.Denied != null) s = s.Where(a => a.Denied == q.Denied);
        return s;
    }
    public async Task<ReportTable> AuditExport(AuditQuery q)
    {
        var u = _cu.Ctx; u.Require(Perms.AuditLogExport);   // restricted: the log can hold before/after values
        var rows = await AuditQ(q).OrderByDescending(a => a.Id).Take(50_000).ToListAsync();
        var t = new ReportTable { Title = "Audit log", Scope = $"{q.From:yyyy-MM-dd} to {q.To:yyyy-MM-dd}", GeneratedBy = u.UserName, Columns = new() { new("at", "When (UTC)", "datetime"), new("u", "User"), new("a", "Action"), new("e", "Entity"), new("id", "Id"), new("b", "Active branch"), new("tb", "Target branch"), new("r", "Reason"), new("d", "Denied"), new("c", "Correlation") } };
        foreach (var a in rows) t.Rows.Add(new object?[] { a.AtUtc, a.UserName, a.Action, a.EntityType, a.EntityId, a.ActiveBranchId, a.TargetBranchId, a.Reason, a.Denied, a.CorrelationId });
        await _audit.Save("AuditLog.Exported", "AuditLog", "export", after: new { rows = rows.Count });
        return t;
    }

    // ================= approvals =================
    public async Task<PagedResult<ApprovalDto>> Approvals(PageQuery q, ApprovalStatus? status, bool mine)
    {
        var u = _cu.Ctx; u.RequireAny(Perms.ApprovalsView, Perms.ApprovalsDecide);
        var s = _db.ApprovalRequests.AsNoTracking().AsQueryable();
        if (status != null) s = s.Where(a => a.Status == status); if (mine) s = s.Where(a => a.RequestedBy == u.UserId);
        var total = await s.CountAsync();
        var rows = await s.OrderByDescending(a => a.Id).Skip(q.Skip).Take(q.Take).ToListAsync();
        var uids = rows.SelectMany(r => new[] { (long?)r.RequestedBy, r.DecidedBy }).Where(x => x != null).Select(x => x!.Value).Distinct().ToList();
        var names = await _db.Users.AsNoTracking().Where(x => uids.Contains(x.Id)).ToDictionaryAsync(x => x.Id, x => x.UserName);
        return new PagedResult<ApprovalDto>(rows.Select(r => new ApprovalDto(r.Id, r.Type, r.EntityType, r.EntityId, r.EntityNumber, r.Value, r.Limit, r.Reason, r.Status, names.GetValueOrDefault(r.RequestedBy, "?"), r.RequestedAtUtc, r.DecidedBy != null ? names.GetValueOrDefault(r.DecidedBy.Value) : null, r.DecisionReason, r.BranchId)).ToList(), total, q.Page, q.Take);
    }
    public async Task Decide(long id, bool approve, string? reason)
    {
        if (!approve && string.IsNullOrWhiteSpace(reason)) throw new ValidationFailedException("reason", "A reason is required to reject.");
        await _approvals.Decide(id, approve, reason);
    }

    // ================= settings =================
    public async Task<List<SettingDto>> Settings(long? branchId)
    {
        var u = _cu.Ctx; u.RequireAny(Perms.SettingsManage, Perms.ReportsDashboard);
        if (branchId != null) u.RequireBranch(branchId.Value);
        var rows = await _db.AppSettings.AsNoTracking().Where(s => s.BranchId == null || s.BranchId == branchId).ToListAsync();
        return SettingsService.DefaultValues.Select(d =>
        {
            var o = rows.FirstOrDefault(r => r.Key == d.Key && r.BranchId == branchId && branchId != null) ?? rows.FirstOrDefault(r => r.Key == d.Key && r.BranchId == null);
            return new SettingDto(d.Key, o?.Value ?? d.Value, d.Value, o?.BranchId, o != null);
        }).OrderBy(s => s.Key).ToList();
    }
    public async Task SetSetting(string key, string value, long? branchId)
    {
        var u = _cu.Ctx; u.Require(Perms.SettingsManage);
        if (!SettingsService.DefaultValues.ContainsKey(key)) throw new ValidationFailedException("key", "Unknown setting.");
        if (branchId != null) u.RequireBranch(branchId.Value);
        var def = SettingsService.DefaultValues[key];
        if (bool.TryParse(def, out _) && !bool.TryParse(value, out _)) throw new ValidationFailedException("value", "Must be true or false.");
        if (decimal.TryParse(def, out _) && !decimal.TryParse(value, System.Globalization.NumberStyles.Number, System.Globalization.CultureInfo.InvariantCulture, out _)) throw new ValidationFailedException("value", "Must be a number.");
        if (key == SettingsService.Keys.Rounding && !Enum.TryParse<RoundingPolicy>(value, true, out _)) throw new ValidationFailedException("value", "Use None, PerLine or PerInvoice.");
        if (key == SettingsService.Keys.Costing && !Enum.TryParse<CostingMethod>(value, true, out _)) throw new ValidationFailedException("value", "Use ItemSpecific, MovingAverage or Fifo.");
        var before = await _settings.Get(key, branchId);
        await _settings.Set(key, value, branchId);
        await _audit.Save("Setting.Changed", "AppSetting", key, new { before }, new { value }, targetBranchId: branchId);
    }

    /// <summary>Unit conversions must be approved in writing before any non-gram unit can be used (SRS 2.1).</summary>
    public async Task<object> ApproveUnitConversion(long unitId, decimal factorToGram, string approvalNote)
    {
        var u = _cu.Ctx; u.Require(Perms.SettingsManage);
        if (factorToGram <= 0) throw new ValidationFailedException("factorToGram", "Factor must be positive.");
        if (string.IsNullOrWhiteSpace(approvalNote)) throw new ValidationFailedException("approvalNote", "Record who approved the conversion and where (document reference).");
        var unit = await _guard.Find(_db.Units.AsNoTracking(), unitId, "Unit");
        var uc = await _db.UnitConversions.FirstOrDefaultAsync(c => c.UnitId == unitId);
        var before = uc == null ? null : new { uc.FactorToGram, uc.IsApproved };
        if (uc == null) { uc = new UnitConversion { CompanyId = u.CompanyId, UnitId = unitId }; _db.UnitConversions.Add(uc); }
        uc.FactorToGram = factorToGram; uc.IsApproved = true; uc.ApprovalNote = approvalNote; uc.ApprovedBy = u.UserId;
        await _audit.Save("Unit.ConversionApproved", nameof(Unit), unitId, before, new { unit.Name, factorToGram }, reason: approvalNote);
        return new { unitId, unit.Name, factorToGram, approved = true };
    }
}

// ====================================================================================================
// Backups (SRS 12): native SQL Server backups, optionally encrypted, with restore-drill tracking
// ====================================================================================================
public sealed class BackupService
{
    readonly ErpDbContext _db; readonly CurrentUser _cu; readonly AuditService _audit; readonly IConfiguration _cfg; readonly ILogger<BackupService> _log;
    public BackupService(ErpDbContext db, CurrentUser cu, AuditService audit, IConfiguration cfg, ILogger<BackupService> log) { _db = db; _cu = cu; _audit = audit; _cfg = cfg; _log = log; }

    public async Task<List<BackupDto>> Status()
    {
        _cu.Ctx.Require(Perms.BackupManage);
        return (await _db.BackupHistory.AsNoTracking().OrderByDescending(b => b.Id).Take(30).ToListAsync()).Select(b => new BackupDto(b.Id, b.StartedUtc, b.FinishedUtc, b.Status, b.Encrypted, b.SizeBytes, b.Message, b.RestoreTestedUtc)).ToList();
    }

    public async Task<BackupDto> Run()
    {
        var u = _cu.Ctx; u.Require(Perms.BackupManage);
        var dir = _cfg["Backup:Directory"]; var cert = _cfg["Backup:CertificateName"];
        var h = new BackupHistory { CompanyId = u.CompanyId, StartedUtc = DateTime.UtcNow, Status = "Pending", Encrypted = !string.IsNullOrWhiteSpace(cert) };
        _db.BackupHistory.Add(h); await _db.SaveChangesAsync();
        try
        {
            if (string.IsNullOrWhiteSpace(dir)) throw new InvalidOperationException("Backup:Directory is not configured (a path the SQL Server service account can write to).");
            var file = $"{dir.TrimEnd('/', '\\')}/jewellery-erp-{DateTime.UtcNow:yyyyMMdd-HHmmss}.bak";
            h.Location = file;
            // BACKUP needs a literal database name, so build the statement from QUOTENAME(DB_NAME()) and pass the path/certificate as parameters
            if (string.IsNullOrWhiteSpace(cert))
                await _db.Database.ExecuteSqlInterpolatedAsync($@"DECLARE @sql nvarchar(max) = N'BACKUP DATABASE ' + QUOTENAME(DB_NAME()) + N' TO DISK = @p WITH COMPRESSION, CHECKSUM, INIT'; EXEC sp_executesql @sql, N'@p nvarchar(400)', @p = {file};");
            else
                await _db.Database.ExecuteSqlInterpolatedAsync($@"DECLARE @sql nvarchar(max) = N'BACKUP DATABASE ' + QUOTENAME(DB_NAME()) + N' TO DISK = @p WITH COMPRESSION, CHECKSUM, INIT, ENCRYPTION (ALGORITHM = AES_256, SERVER CERTIFICATE = ' + QUOTENAME({cert}) + N')'; EXEC sp_executesql @sql, N'@p nvarchar(400)', @p = {file};");
            h.Status = "Succeeded"; h.FinishedUtc = DateTime.UtcNow;
            h.Message = h.Encrypted ? "Encrypted backup completed." : "Backup completed WITHOUT encryption - configure Backup:CertificateName for encrypted backups (required before go-live).";
        }
        catch (Exception ex) { _log.LogError(ex, "Backup failed"); h.Status = "Failed"; h.FinishedUtc = DateTime.UtcNow; h.Message = ex.GetType().Name + ": " + ex.Message.Split('\n')[0]; }
        await _db.SaveChangesAsync();
        await _audit.Save("Backup.Run", nameof(BackupHistory), h.Id, after: new { h.Status, h.Encrypted });
        return new BackupDto(h.Id, h.StartedUtc, h.FinishedUtc, h.Status, h.Encrypted, h.SizeBytes, h.Message, h.RestoreTestedUtc);
    }

    /// <summary>Records that this backup was restored in a test environment and the data + image references were verified.</summary>
    public async Task MarkRestoreTested(long id, string note)
    {
        _cu.Ctx.Require(Perms.BackupManage);
        if (string.IsNullOrWhiteSpace(note)) throw new ValidationFailedException("note", "Describe what was verified in the restore drill.");
        var b = await _db.BackupHistory.FirstOrDefaultAsync(x => x.Id == id) ?? throw new NotFoundException("Backup");
        if (b.Status != "Succeeded") throw new ConflictException("Only a successful backup can be restore-tested.");
        b.RestoreTestedUtc = DateTime.UtcNow; b.Message = (b.Message ?? "") + " | Restore drill: " + note;
        await _audit.Save("Backup.RestoreTested", nameof(BackupHistory), id, reason: note);
    }
}
