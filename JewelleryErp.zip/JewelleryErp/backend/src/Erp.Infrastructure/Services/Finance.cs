using Erp.Domain;
using Erp.Domain.Calc;
using Erp.Domain.Entities;
using Erp.Infrastructure.Contracts;
using Erp.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;

namespace Erp.Infrastructure.Services;

public sealed class ExpenseInput { public long? BranchId { get; set; } public long ExpenseHeadId { get; set; } public string? Payee { get; set; } public string? Description { get; set; } public decimal Amount { get; set; } public decimal TaxAmount { get; set; } public long PaymentAccountId { get; set; } public DateTime? DateUtc { get; set; } public string? IdempotencyKey { get; set; } }
public sealed record ExpenseDto(long Id, string Number, DateTime DateUtc, long BranchId, string Head, string? Payee, string? Description, decimal Amount, decimal Tax, string Account, DocStatus Status, string? EnteredBy);
public sealed class AllocateInvoice { public long InvoiceId { get; set; } public decimal Amount { get; set; } }
public sealed class VoucherInput
{
    public VoucherType Type { get; set; }
    public long? BranchId { get; set; }
    public long AccountId { get; set; }
    public long? ToAccountId { get; set; }
    public PartyType? PartyType { get; set; }
    public long? PartyId { get; set; }
    public long? CounterAccountId { get; set; }
    public decimal Amount { get; set; }
    public string? Reference { get; set; }
    public string? Description { get; set; }
    public List<AllocateInvoice> Allocations { get; set; } = new();
    public bool AutoAllocate { get; set; } = true;
    public DateTime? DateUtc { get; set; }
    public string? IdempotencyKey { get; set; }
}
public sealed record VoucherDto(long Id, string Number, VoucherType Type, DateTime DateUtc, long BranchId, string Account, string? ToAccount, string? Party, decimal Amount, string? Reference, string? Description, DocStatus Status);
public sealed class RegisterOpenInput { public long AccountId { get; set; } public long? BranchId { get; set; } public decimal OpeningAmount { get; set; } }
public sealed class RegisterCloseInput { public decimal CountedClosing { get; set; } public string? VarianceNote { get; set; } }
public sealed record RegisterDto(long Id, long AccountId, string Account, DateTime OpenedAtUtc, decimal OpeningAmount, DateTime? ClosedAtUtc, decimal? Expected, decimal? Counted, decimal? Variance, string? Note);
public sealed class MetalEntryInput { public PartyType PartyType { get; set; } public long PartyId { get; set; } public long MetalTypeId { get; set; } public long PurityId { get; set; } public decimal NetWeight { get; set; } public bool ReceivedFromParty { get; set; } public string? Description { get; set; } public long? BranchId { get; set; } }

public sealed record StatementRow(DateTime DateUtc, string DocNo, string Type, string? Description, decimal Debit, decimal Credit, decimal Balance, bool IsReversal);
public sealed record MetalRow(string Metal, string? Purity, decimal NetIn, decimal NetOut, decimal FineIn, decimal FineOut);
public sealed record StatementDto(string PartyType, long PartyId, string Name, DateTime From, DateTime To, decimal Opening, IReadOnlyList<StatementRow> Rows, decimal Closing, string BalanceMeaning, IReadOnlyList<MetalRow> Metal, decimal MetalOpeningFine, decimal MetalBalanceFine, IReadOnlyList<CustodyRow> Custody);
public sealed record CommissionRow(long SalesmanId, string Salesman, decimal Eligible, decimal Calculated, decimal Approved, decimal Paid, decimal Unpaid, int Entries);
public sealed record CommissionDetail(long Id, DateTime DateUtc, long? InvoiceId, long? ReturnId, decimal Eligible, decimal Rate, decimal Calculated, decimal Approved, decimal Paid, bool IsApproved, bool IsReversal, string? Note);

public sealed class FinanceService
{
    readonly ErpDbContext _db; readonly CurrentUser _cu; readonly AuditService _audit; readonly NumberingService _num; readonly PostingEngine _post; readonly SettingsService _settings; readonly AccessGuard _guard; readonly ApprovalService _approvals;
    public FinanceService(ErpDbContext db, CurrentUser cu, AuditService audit, NumberingService num, PostingEngine post, SettingsService settings, AccessGuard guard, ApprovalService approvals)
    { _db = db; _cu = cu; _audit = audit; _num = num; _post = post; _settings = settings; _guard = guard; _approvals = approvals; }

    async Task CheckAccount(long accountId, long branch)
    {
        var a = await _db.CashBankAccounts.AsNoTracking().FirstOrDefaultAsync(x => x.Id == accountId && x.IsActive) ?? throw new ValidationFailedException("accountId", "Cash/bank account not found or inactive.");
        if (a.BranchId != null && a.BranchId != branch) throw new ValidationFailedException("accountId", "That cash/bank account belongs to another branch.");
    }

    // ============================ expenses ============================
    public async Task<ExpenseDto> CreateExpense(ExpenseInput i)
    {
        var u = _cu.Ctx; u.Require(Perms.FinanceExpenseCreate);
        var branch = await _post.PostingBranch(i.BranchId);
        if (i.Amount <= 0) throw new ValidationFailedException("amount", "Amount must be positive.");
        if (i.TaxAmount < 0 || i.TaxAmount > i.Amount) throw new ValidationFailedException("taxAmount", "Tax cannot be negative or exceed the amount.");
        if (!string.IsNullOrWhiteSpace(i.IdempotencyKey)) { var d = await _db.ExpenseVouchers.AsNoTracking().FirstOrDefaultAsync(x => x.IdempotencyKey == i.IdempotencyKey); if (d != null) return await GetExpense(d.Id); }
        var date = i.DateUtc ?? DateTime.UtcNow; await _post.EnsureBackdating(date, branch);
        long id = 0;
        await _post.InTransaction(async () =>
        {
            var head = await _db.ExpenseHeads.AsNoTracking().FirstOrDefaultAsync(h => h.Id == i.ExpenseHeadId && h.IsActive) ?? throw new ValidationFailedException("expenseHeadId", "Expense head not found.");
            await CheckAccount(i.PaymentAccountId, branch);
            var v = new ExpenseVoucher { CompanyId = u.CompanyId, BranchId = branch, Number = await _num.Next("EXP", branch), DocDateUtc = date, ExpenseHeadId = head.Id, Payee = i.Payee, Description = i.Description, Amount = Money.R2(i.Amount), TaxAmount = Money.R2(i.TaxAmount), PaymentAccountId = i.PaymentAccountId, EnteredBy = u.UserId, IdempotencyKey = i.IdempotencyKey, Status = DocStatus.Draft };
            _db.ExpenseVouchers.Add(v); await _db.SaveChangesAsync(); id = v.Id;
            var chk = await _approvals.Check(ApprovalType.ExpenseOverLimit, v.Amount, branch);
            if (chk.NeedsApproval) { v.Status = DocStatus.PendingApproval; _approvals.Request(ApprovalType.ExpenseOverLimit, nameof(ExpenseVoucher), v.Id, v.Number, v.Amount, chk.Limit ?? 0, branch, i.Description); }
            else await PostExpenseInternal(v, head);
            _audit.Add("Expense.Created", nameof(ExpenseVoucher), v.Id, after: new { v.Number, v.Amount, status = v.Status.ToString() }, targetBranchId: branch);
            return 0;
        });
        return await GetExpense(id);
    }

    public async Task<ExpenseDto> PostExpense(long id)
    {
        _cu.Ctx.Require(Perms.FinanceExpenseCreate);
        await _post.InTransaction(async () =>
        {
            var v = await _guard.Find(_db.ExpenseVouchers, id, "Expense voucher");
            if (v.Status != DocStatus.Approved) throw new ConflictException("Only approved expenses can be posted.");
            var head = await _db.ExpenseHeads.AsNoTracking().FirstAsync(h => h.Id == v.ExpenseHeadId);
            await PostExpenseInternal(v, head); return 0;
        });
        return await GetExpense(id);
    }

    async Task PostExpenseInternal(ExpenseVoucher v, ExpenseHead head)
    {
        var u = _cu.Ctx;
        v.Status = DocStatus.Posted; v.PostedBy = u.UserId; v.PostedAtUtc = DateTime.UtcNow;
        var exp = head.AccountId ?? await _post.Account(Acc.ExpMisc);
        var j = new JournalBuilder().DrAcc(exp, Money.R2(v.Amount - v.TaxAmount), head.Name);
        if (v.TaxAmount > 0) j.Dr(Acc.TaxPayable, v.TaxAmount, "Input tax");
        j.CrAcc(await _post.LedgerAccountFor(v.PaymentAccountId), v.Amount, "Paid");
        await _post.Journal(j, TxnType.Expense, v.Id, v.Number, v.BranchId, v.DocDateUtc, head.Name + (v.Payee != null ? " - " + v.Payee : ""));
        var e = _post.Reg(TxnType.Expense, v, 1, PartyType.Other, null, v.Payee); e.ItemName = head.Name + ": " + v.Description; e.PkrDebit = v.Amount; e.PaymentMethod = "Cash/Bank";
        _audit.Add("Expense.Posted", nameof(ExpenseVoucher), v.Id, after: new { v.Number, v.Amount }, targetBranchId: v.BranchId);
    }

    public async Task<ExpenseDto> GetExpense(long id)
    {
        _cu.Ctx.RequireAny(Perms.FinanceView, Perms.FinanceExpenseCreate);
        var v = await _guard.Find(_db.ExpenseVouchers.AsNoTracking(), id, "Expense voucher");
        var head = await _db.ExpenseHeads.AsNoTracking().Where(h => h.Id == v.ExpenseHeadId).Select(h => h.Name).FirstOrDefaultAsync() ?? "";
        var acc = await _db.CashBankAccounts.AsNoTracking().Where(a => a.Id == v.PaymentAccountId).Select(a => a.Name).FirstOrDefaultAsync() ?? "";
        var by = await _db.Users.AsNoTracking().Where(x => x.Id == v.EnteredBy).Select(x => x.UserName).FirstOrDefaultAsync();
        return new ExpenseDto(v.Id, v.Number, v.DocDateUtc, v.BranchId, head, v.Payee, v.Description, v.Amount, v.TaxAmount, acc, v.Status, by);
    }

    public async Task<PagedResult<ExpenseDto>> ListExpenses(PageQuery q, long[]? branchIds, DateTime? from, DateTime? to, long? headId)
    {
        var u = _cu.Ctx; u.RequireAny(Perms.FinanceView, Perms.FinanceExpenseCreate);
        var br = u.ResolveScope(branchIds);
        var s = _db.ExpenseVouchers.AsNoTracking().Where(x => br.Contains(x.BranchId));
        if (from != null) s = s.Where(x => x.DocDateUtc >= from); if (to != null) s = s.Where(x => x.DocDateUtc < to.Value.AddDays(1)); if (headId != null) s = s.Where(x => x.ExpenseHeadId == headId);
        if (!string.IsNullOrWhiteSpace(q.Search)) { var t = q.Search.Trim(); s = s.Where(x => x.Number.Contains(t) || (x.Payee != null && x.Payee.Contains(t))); }
        var total = await s.CountAsync();
        var ids = await s.OrderByDescending(x => x.Id).Skip(q.Skip).Take(q.Take).Select(x => x.Id).ToListAsync();
        var items = new List<ExpenseDto>(); foreach (var id in ids) items.Add(await GetExpense(id));
        return new PagedResult<ExpenseDto>(items, total, q.Page, q.Take, new Dictionary<string, decimal> { ["amount"] = await s.Where(x => x.Status == DocStatus.Posted).SumAsync(x => x.Amount) });
    }

    // ============================ cash / bank vouchers ============================
    public async Task<VoucherDto> CreateVoucher(VoucherInput i)
    {
        var u = _cu.Ctx; u.Require(Perms.FinancePaymentPost);
        var branch = await _post.PostingBranch(i.BranchId);
        if (i.Amount <= 0) throw new ValidationFailedException("amount", "Amount must be positive.");
        if (!string.IsNullOrWhiteSpace(i.IdempotencyKey)) { var d = await _db.CashBankVouchers.AsNoTracking().FirstOrDefaultAsync(x => x.IdempotencyKey == i.IdempotencyKey); if (d != null) return await GetVoucher(d.Id); }
        var date = i.DateUtc ?? DateTime.UtcNow; await _post.EnsureBackdating(date, branch);
        long id = 0;
        await _post.InTransaction(async () =>
        {
            await CheckAccount(i.AccountId, branch);
            var acc = await _db.CashBankAccounts.AsNoTracking().FirstAsync(a => a.Id == i.AccountId);
            var v = new CashBankVoucher { CompanyId = u.CompanyId, BranchId = branch, Number = await _num.Next(i.Type switch { VoucherType.Receipt => "CRV", VoucherType.Payment => "CPV", _ => "BTR" }, branch), DocDateUtc = date, VoucherType = i.Type, AccountId = i.AccountId, ToAccountId = i.ToAccountId, PartyType = i.PartyType, PartyId = i.PartyId, CounterAccountId = i.CounterAccountId, Amount = Money.R2(i.Amount), Reference = i.Reference, Description = i.Description, IdempotencyKey = i.IdempotencyKey, Status = DocStatus.Posted, PostedBy = u.UserId, PostedAtUtc = DateTime.UtcNow };
            _db.CashBankVouchers.Add(v); await _db.SaveChangesAsync(); id = v.Id;
            var cashAcc = await _post.LedgerAccountFor(i.AccountId);
            var j = new JournalBuilder(); string? partyName = null;
            switch (i.Type)
            {
                case VoucherType.Receipt:
                    if (i.PartyType == PartyType.Customer && i.PartyId != null)
                    {
                        var cust = await _guard.Find(_db.Customers.AsNoTracking(), i.PartyId.Value, "Customer"); partyName = cust.Name;
                        await AllocateReceipt(v, i); 
                        j.DrAcc(cashAcc, v.Amount, "Customer receipt").Cr(Acc.Receivable, v.Amount, "Receivable reduced", PartyType.Customer, cust.Id);
                        _post.Party(PartyType.Customer, cust.Id, branch, date, TxnType.CustomerReceipt, v.Id, v.Number, "Receipt " + (i.Reference ?? ""), 0, v.Amount);
                    }
                    else
                    {
                        if (i.CounterAccountId == null) throw new ValidationFailedException("counterAccountId", "Choose the account this receipt is credited to.");
                        await CheckCounter(i.CounterAccountId.Value);
                        j.DrAcc(cashAcc, v.Amount, i.Description).CrAcc(i.CounterAccountId.Value, v.Amount, i.Description);
                    }
                    break;
                case VoucherType.Payment:
                    if (i.PartyType is PartyType.Supplier or PartyType.Worker) throw new ValidationFailedException("partyType", "Pay suppliers through Supplier Payment and workers through Worker Payment so invoices/jobs are allocated.");
                    if (i.CounterAccountId == null) throw new ValidationFailedException("counterAccountId", "Choose the expense/asset account this payment is for.");
                    await CheckCounter(i.CounterAccountId.Value);
                    if (i.PartyType == PartyType.Customer && i.PartyId != null)
                    {
                        var cust = await _guard.Find(_db.Customers.AsNoTracking(), i.PartyId.Value, "Customer"); partyName = cust.Name;
                        _post.Party(PartyType.Customer, cust.Id, branch, date, TxnType.CashPayment, v.Id, v.Number, "Payment to customer", v.Amount, 0);
                        j.Dr(Acc.CustomerAdvances == "" ? Acc.Receivable : Acc.Receivable, v.Amount, "Refund / payout to customer", PartyType.Customer, cust.Id).CrAcc(cashAcc, v.Amount, i.Description);
                    }
                    else j.DrAcc(i.CounterAccountId.Value, v.Amount, i.Description).CrAcc(cashAcc, v.Amount, i.Description);
                    break;
                case VoucherType.Transfer:
                case VoucherType.Deposit:
                case VoucherType.Withdrawal:
                    if (i.ToAccountId == null || i.ToAccountId == i.AccountId) throw new ValidationFailedException("toAccountId", "Choose a different destination account.");
                    var to = await _db.CashBankAccounts.AsNoTracking().FirstOrDefaultAsync(a => a.Id == i.ToAccountId && a.IsActive) ?? throw new ValidationFailedException("toAccountId", "Destination account not found.");
                    if (i.Type == VoucherType.Deposit && !(acc.Type == CashBankType.Cash && to.Type == CashBankType.Bank)) throw new ValidationFailedException("type", "A deposit moves cash into a bank account.");
                    if (i.Type == VoucherType.Withdrawal && !(acc.Type == CashBankType.Bank && to.Type == CashBankType.Cash)) throw new ValidationFailedException("type", "A withdrawal moves money from a bank account to cash.");
                    j.DrAcc(await _post.LedgerAccountFor(to.Id), v.Amount, "Transfer in").CrAcc(cashAcc, v.Amount, "Transfer out");
                    break;
            }
            await _post.Journal(j, i.Type == VoucherType.Receipt ? TxnType.CashReceipt : i.Type == VoucherType.Payment ? TxnType.CashPayment : TxnType.BankTransfer, v.Id, v.Number, branch, date, i.Description ?? i.Type.ToString());
            var e = _post.Reg(i.Type == VoucherType.Receipt ? TxnType.CashReceipt : i.Type == VoucherType.Payment ? TxnType.CashPayment : TxnType.BankTransfer, v, 1, i.PartyType, i.PartyId, partyName); e.ItemName = i.Type + (i.Description != null ? ": " + i.Description : ""); e.PaymentMethod = acc.Name;
            if (i.Type == VoucherType.Receipt) e.PkrCredit = v.Amount; else e.PkrDebit = v.Amount;
            _audit.Add("Voucher.Posted", nameof(CashBankVoucher), v.Id, after: new { v.Number, i.Type, v.Amount }, targetBranchId: branch);
            return 0;
        });
        return await GetVoucher(id);
    }

    async Task CheckCounter(long chartAccountId)
    {
        var ca = await _db.ChartAccounts.AsNoTracking().FirstOrDefaultAsync(a => a.Id == chartAccountId && a.IsActive) ?? throw new ValidationFailedException("counterAccountId", "Account not found.");
        if (ca.IsControl) throw new ValidationFailedException("counterAccountId", "Control accounts (receivables/payables/inventory) are posted by the system only.");
    }

    /// <summary>Customer receipt settles invoices: explicit allocations, otherwise oldest-first when AutoAllocate.</summary>
    async Task AllocateReceipt(CashBankVoucher v, VoucherInput i)
    {
        decimal left = v.Amount;
        var invoices = new List<(SalesInvoice inv, decimal amt)>();
        if (i.Allocations.Count > 0)
        {
            foreach (var a in i.Allocations)
            {
                var inv = await _db.SalesInvoices.FirstOrDefaultAsync(x => x.Id == a.InvoiceId && x.CustomerId == i.PartyId) ?? throw new ValidationFailedException("allocations", "Invoice not found for this customer.");
                if (a.Amount <= 0 || a.Amount > inv.DueTotal) throw new ValidationFailedException("allocations", $"{inv.Number}: allocation must be between 0 and the outstanding {inv.DueTotal:N2}.");
                invoices.Add((inv, a.Amount)); left -= a.Amount;
            }
            if (left < 0) throw new ValidationFailedException("allocations", "Allocations exceed the receipt amount.");
        }
        else if (i.AutoAllocate)
        {
            foreach (var inv in await _db.SalesInvoices.Where(x => x.CustomerId == i.PartyId && x.DueTotal > 0 && (x.Status == DocStatus.PartiallyPaid || x.Status == DocStatus.Posted)).OrderBy(x => x.DocDateUtc).Take(100).ToListAsync())
            { if (left <= 0) break; var a = Math.Min(left, inv.DueTotal); invoices.Add((inv, a)); left -= a; }
        }
        foreach (var (inv, amt) in invoices) { inv.PaidTotal = Money.R2(inv.PaidTotal + amt); inv.DueTotal = Money.R2(inv.DueTotal - amt); inv.Status = inv.DueTotal == 0 ? DocStatus.Posted : DocStatus.PartiallyPaid; }
    }

    public async Task<VoucherDto> GetVoucher(long id)
    {
        _cu.Ctx.RequireAny(Perms.FinanceView, Perms.FinancePaymentPost);
        var v = await _guard.Find(_db.CashBankVouchers.AsNoTracking(), id, "Voucher");
        var names = await _db.CashBankAccounts.AsNoTracking().Where(a => a.Id == v.AccountId || a.Id == v.ToAccountId).ToDictionaryAsync(a => a.Id, a => a.Name);
        return new VoucherDto(v.Id, v.Number, v.VoucherType, v.DocDateUtc, v.BranchId, names.GetValueOrDefault(v.AccountId, ""), v.ToAccountId != null ? names.GetValueOrDefault(v.ToAccountId.Value) : null, await _post.PartyName(v.PartyType ?? PartyType.Other, v.PartyId), v.Amount, v.Reference, v.Description, v.Status);
    }

    public async Task<PagedResult<VoucherDto>> ListVouchers(PageQuery q, long[]? branchIds, VoucherType? type, DateTime? from, DateTime? to)
    {
        var u = _cu.Ctx; u.RequireAny(Perms.FinanceView, Perms.FinancePaymentPost);
        var br = u.ResolveScope(branchIds);
        var s = _db.CashBankVouchers.AsNoTracking().Where(x => br.Contains(x.BranchId));
        if (type != null) s = s.Where(x => x.VoucherType == type); if (from != null) s = s.Where(x => x.DocDateUtc >= from); if (to != null) s = s.Where(x => x.DocDateUtc < to.Value.AddDays(1));
        var total = await s.CountAsync();
        var ids = await s.OrderByDescending(x => x.Id).Skip(q.Skip).Take(q.Take).Select(x => x.Id).ToListAsync();
        var items = new List<VoucherDto>(); foreach (var id in ids) items.Add(await GetVoucher(id));
        return new PagedResult<VoucherDto>(items, total, q.Page, q.Take);
    }

    // ============================ reversal (never delete) ============================
    /// <summary>Posted money documents are reversed with mirrored journal/ledger lines. The reverser must not be the person who created the document.</summary>
    public async Task Reverse(string kind, long id, string reason)
    {
        var u = _cu.Ctx; u.Require(Perms.FinanceReverse);
        if (string.IsNullOrWhiteSpace(reason)) throw new ValidationFailedException("reason", "A reason is mandatory.");
        await _post.InTransaction(async () =>
        {
            PostableDocument doc; TxnType type;
            if (kind == "expense") { doc = await _guard.Find(_db.ExpenseVouchers, id, "Expense voucher"); type = TxnType.Expense; }
            else if (kind == "voucher")
            {
                var v = await _guard.Find(_db.CashBankVouchers, id, "Voucher"); doc = v;
                type = v.VoucherType == VoucherType.Receipt ? TxnType.CashReceipt : v.VoucherType == VoucherType.Payment ? TxnType.CashPayment : TxnType.BankTransfer;
                if (v.VoucherType == VoucherType.Receipt && v.PartyType == PartyType.Customer && await _db.SalesInvoices.AnyAsync(x => x.CustomerId == v.PartyId && x.PaidTotal > 0 && x.DocDateUtc >= v.DocDateUtc)) { /* allocation restore below */ }
            }
            else throw new ValidationFailedException("kind", "Supported kinds: expense, voucher.");
            if (doc.Status != DocStatus.Posted) throw new ConflictException("Only posted documents can be reversed.");
            if (doc.CreatedBy == u.UserId || doc.PostedBy == u.UserId) throw new ForbiddenException("You cannot reverse a document you created or posted (separation of duties).", "separation_of_duties");
            u.RequireBranch(doc.BranchId);
            var rev = await ReverseLedgers(type, doc.Id, doc.Number, doc.BranchId, reason);
            if (doc is CashBankVoucher cv && cv.VoucherType == VoucherType.Receipt && cv.PartyType == PartyType.Customer) { /* invoice settlements are not auto-restored: the customer ledger shows the reversal and Due is re-opened below */
                var back = cv.Amount;
                foreach (var inv in await _db.SalesInvoices.Where(x => x.CustomerId == cv.PartyId && x.PaidTotal > 0).OrderByDescending(x => x.DocDateUtc).Take(50).ToListAsync())
                { if (back <= 0) break; var a = Math.Min(back, inv.PaidTotal); inv.PaidTotal = Money.R2(inv.PaidTotal - a); inv.DueTotal = Money.R2(inv.DueTotal + a); inv.Status = DocStatus.PartiallyPaid; back -= a; }
            }
            doc.Status = DocStatus.Reversed; doc.VoidReason = reason;
            await _post.MarkRegisterReversed(type, doc.Id, rev);
            _audit.Add("Finance.Reversed", doc.GetType().Name, doc.Id, after: new { doc.Number }, reason: reason, targetBranchId: doc.BranchId);
            return 0;
        });
    }

    /// <summary>Creates mirrored journal + party-ledger rows for a document and returns the reversal journal id.</summary>
    async Task<long> ReverseLedgers(TxnType type, long docId, string docNo, long branchId, string reason)
    {
        var entries = await _db.JournalEntries.Include(e => e.Lines).Where(e => e.DocType == type && e.DocId == docId && !e.IsReversal).ToListAsync();
        long last = 0;
        foreach (var e in entries)
        {
            var b = new JournalBuilder();
            foreach (var l in e.Lines) { if (l.Credit > 0) b.DrAcc(l.AccountId, l.Credit, "Reversal"); if (l.Debit > 0) b.CrAcc(l.AccountId, l.Debit, "Reversal"); }
            var je = await _post.Journal(b, type, docId, docNo, branchId, DateTime.UtcNow, "REVERSAL: " + reason, true, e.Id);
            await _db.SaveChangesAsync(); last = je.Id;
        }
        var ledger = await _db.PartyLedger.Where(p => p.DocType == type && p.DocId == docId && !p.IsReversal).ToListAsync();
        foreach (var p in ledger) _post.Party(p.PartyType, p.PartyId, p.BranchId, DateTime.UtcNow, type, docId, docNo, "Reversal: " + reason, p.Credit, p.Debit, true);
        return last;
    }

    // ============================ cash register ============================
    public async Task<RegisterDto> OpenRegister(RegisterOpenInput i)
    {
        var u = _cu.Ctx; u.Require(Perms.FinanceCashRegister);
        var branch = await _post.PostingBranch(i.BranchId);
        await CheckAccount(i.AccountId, branch);
        if (await _db.CashRegisterSessions.AnyAsync(s => s.AccountId == i.AccountId && s.ClosedAtUtc == null)) throw new ConflictException("This cash register is already open.");
        if (i.OpeningAmount < 0) throw new ValidationFailedException("openingAmount", "Opening amount cannot be negative.");
        var s = new CashRegisterSession { CompanyId = u.CompanyId, BranchId = branch, AccountId = i.AccountId, OpenedAtUtc = DateTime.UtcNow, OpenedBy = u.UserId, OpeningAmount = Money.R2(i.OpeningAmount) };
        _db.CashRegisterSessions.Add(s);
        await _audit.Save("Register.Opened", nameof(CashRegisterSession), "new", after: new { i.AccountId, i.OpeningAmount }, targetBranchId: branch);
        return await GetRegister(s.Id);
    }

    public async Task<RegisterDto> CloseRegister(long id, RegisterCloseInput i)
    {
        var u = _cu.Ctx; u.Require(Perms.FinanceCashRegister);
        await _post.InTransaction(async () =>
        {
            var s = await _guard.Find(_db.CashRegisterSessions, id, "Register session");
            if (s.ClosedAtUtc != null) throw new ConflictException("The register is already closed.");
            var ledgerAcc = await _post.LedgerAccountFor(s.AccountId);
            var movement = await (from l in _db.JournalLines.AsNoTracking() join e in _db.JournalEntries.AsNoTracking() on l.JournalEntryId equals e.Id where l.AccountId == ledgerAcc && e.BranchId == s.BranchId && e.EntryDateUtc >= s.OpenedAtUtc select l.Debit - l.Credit).ToListAsync();
            var expected = Money.R2(s.OpeningAmount + movement.Sum());
            var variance = Money.R2(i.CountedClosing - expected);
            var tol = await _settings.Dec(SettingsService.Keys.CashVarianceTolerance, s.BranchId);
            if (Math.Abs(variance) > tol && string.IsNullOrWhiteSpace(i.VarianceNote)) throw new ValidationFailedException("varianceNote", $"The count differs from the books by {variance:N2}; a variance note is required.");
            s.ClosedAtUtc = DateTime.UtcNow; s.ClosedBy = u.UserId; s.ExpectedClosing = expected; s.CountedClosing = Money.R2(i.CountedClosing); s.Variance = variance; s.VarianceNote = i.VarianceNote;
            if (variance != 0)
            {
                var j = variance < 0 ? new JournalBuilder().Dr(Acc.CashShortage, -variance, "Cash shortage").CrAcc(ledgerAcc, -variance, "Cash shortage") : new JournalBuilder().DrAcc(ledgerAcc, variance, "Cash overage").Cr(Acc.CashShortage, variance, "Cash overage");
                await _post.Journal(j, TxnType.CashPayment, s.Id, "REG-" + s.Id, s.BranchId, s.ClosedAtUtc.Value, "Register close variance: " + i.VarianceNote);
            }
            _audit.Add("Register.Closed", nameof(CashRegisterSession), s.Id, after: new { expected, counted = i.CountedClosing, variance }, reason: i.VarianceNote, targetBranchId: s.BranchId);
            return 0;
        });
        return await GetRegister(id);
    }

    public async Task<RegisterDto> GetRegister(long id)
    {
        _cu.Ctx.RequireAny(Perms.FinanceCashRegister, Perms.FinanceView);
        var s = await _guard.Find(_db.CashRegisterSessions.AsNoTracking(), id, "Register session");
        var name = await _db.CashBankAccounts.AsNoTracking().Where(a => a.Id == s.AccountId).Select(a => a.Name).FirstOrDefaultAsync() ?? "";
        return new RegisterDto(s.Id, s.AccountId, name, s.OpenedAtUtc, s.OpeningAmount, s.ClosedAtUtc, s.ExpectedClosing, s.CountedClosing, s.Variance, s.VarianceNote);
    }

    public async Task<List<RegisterDto>> Registers(bool openOnly)
    {
        _cu.Ctx.RequireAny(Perms.FinanceCashRegister, Perms.FinanceView);
        var ids = await _db.CashRegisterSessions.AsNoTracking().Where(s => !openOnly || s.ClosedAtUtc == null).OrderByDescending(s => s.Id).Take(100).Select(s => s.Id).ToListAsync();
        var res = new List<RegisterDto>(); foreach (var id in ids) res.Add(await GetRegister(id)); return res;
    }

    // ============================ party statements (PKR and metal kept apart) ============================
    public async Task<StatementDto> Statement(PartyType type, long partyId, DateTime from, DateTime to)
    {
        var u = _cu.Ctx;
        switch (type)
        {
            case PartyType.Customer: u.Require(Perms.CustomersLedger); break;
            case PartyType.Supplier: u.Require(Perms.SuppliersLedger); break;
            case PartyType.Worker: u.RequireAny(Perms.WorkersView, Perms.JobWorkView, Perms.FinanceView); break;
            default: u.Require(Perms.FinanceView); break;
        }
        decimal opening = 0, metalOpening = 0; string name; bool debitPositive = type == PartyType.Customer;
        switch (type)
        {
            case PartyType.Customer: { var c = await _guard.Find(_db.Customers.AsNoTracking(), partyId, "Customer"); name = c.Name; opening = c.OpeningBalance; metalOpening = c.OpeningMetalFine; break; }
            case PartyType.Supplier: { var c = await _guard.Find(_db.Suppliers.AsNoTracking(), partyId, "Supplier"); name = c.Name; opening = c.OpeningBalance; metalOpening = c.OpeningMetalFine; break; }
            case PartyType.Worker: { var c = await _guard.Find(_db.Workers.AsNoTracking(), partyId, "Worker"); name = c.Name; opening = c.OpeningBalance; metalOpening = c.OpeningMetalFine; break; }
            default: throw new ValidationFailedException("partyType", "Statements are available for customers, suppliers and workers.");
        }
        var allowed = u.BranchIds.ToArray(); var all = u.CanSeeAllBranches;
        var scoped = _db.PartyLedger.AsNoTracking().Where(p => p.PartyType == type && p.PartyId == partyId && (all || p.BranchId == null || allowed.Contains(p.BranchId.Value)));
        var before = await scoped.Where(p => p.EntryDateUtc < from).ToListAsync();
        decimal Sign(decimal d, decimal c) => debitPositive ? d - c : c - d;
        var open = (all ? opening : 0m) + before.Sum(p => Sign(p.Debit, p.Credit));
        var rows = await scoped.Where(p => p.EntryDateUtc >= from && p.EntryDateUtc < to.Date.AddDays(1)).OrderBy(p => p.EntryDateUtc).ThenBy(p => p.Id).ToListAsync();
        var running = open; var list = new List<StatementRow>();
        foreach (var r in rows) { running += Sign(r.Debit, r.Credit); list.Add(new StatementRow(r.EntryDateUtc, r.DocNo, r.DocType.ToString(), r.Description, r.Debit, r.Credit, Money.R2(running), r.IsReversal)); }
        var mets = await _db.MetalLedger.AsNoTracking().Where(m => m.PartyType == type && m.PartyId == partyId && m.EntryDateUtc < to.Date.AddDays(1) && (all || m.BranchId == null || allowed.Contains(m.BranchId.Value))).ToListAsync();
        var mn = await _db.MetalTypes.AsNoTracking().ToDictionaryAsync(m => m.Id, m => m.Name); var pl = await _db.Purities.AsNoTracking().ToDictionaryAsync(p => p.Id, p => p.Label);
        var metal = mets.GroupBy(m => new { m.MetalTypeId, m.PurityId }).Select(g => new MetalRow(mn.GetValueOrDefault(g.Key.MetalTypeId, ""), g.Key.PurityId != null ? pl.GetValueOrDefault(g.Key.PurityId.Value) : null, g.Sum(x => x.NetIn), g.Sum(x => x.NetOut), g.Sum(x => x.FineIn), g.Sum(x => x.FineOut))).ToList();
        var custody = new List<CustodyRow>();
        if (type == PartyType.Worker)
        {
            var cb = await _db.StockBalances.AsNoTracking().Where(b => b.Status == StockStatus.WithWorker && b.NetWeight > 0 && _db.JobCards.Any(j => j.Id == b.CustodyRefId && j.WorkerId == partyId)).ToListAsync();
            custody = cb.Select(b => new CustodyRow(b.LocationId, b.MetalTypeId != null ? mn.GetValueOrDefault(b.MetalTypeId.Value) : null, b.PurityId != null ? pl.GetValueOrDefault(b.PurityId.Value) : null, b.GrossWeight, b.NetWeight, b.FineWeight)).ToList();
        }
        var meaning = type == PartyType.Customer ? "Positive = customer owes the shop (receivable); negative = customer credit." : type == PartyType.Supplier ? "Positive = shop owes the supplier (payable); negative = supplier credit/advance." : "Positive = shop owes the worker (making charges payable).";
        return new StatementDto(type.ToString(), partyId, name, from, to, Money.R2(open), list, Money.R2(running), meaning, metal, metalOpening, Money.R3(metalOpening + metal.Sum(m => m.FineOut - m.FineIn)), custody);
    }

    /// <summary>Manual metal ledger entry (opening metal balance, metal settlement). Never changes the PKR ledger.</summary>
    public async Task MetalEntry(MetalEntryInput i)
    {
        var u = _cu.Ctx; u.Require(Perms.FinanceMetalLedger);
        var branch = await _post.PostingBranch(i.BranchId);
        if (i.NetWeight <= 0) throw new ValidationFailedException("netWeight", "Weight must be positive.");
        if (string.IsNullOrWhiteSpace(i.Description)) throw new ValidationFailedException("description", "Describe the settlement.");
        var pur = await _db.Purities.AsNoTracking().FirstOrDefaultAsync(p => p.Id == i.PurityId && p.MetalTypeId == i.MetalTypeId) ?? throw new ValidationFailedException("purityId", "Purity does not match the metal.");
        var fine = WeightCalc.Fine(i.NetWeight, pur.Factor);
        _post.Metal(i.PartyType, i.PartyId, branch, i.MetalTypeId, i.PurityId, DateTime.UtcNow, TxnType.Opening, 0, "MET-" + DateTime.UtcNow.Ticks, i.ReceivedFromParty ? i.NetWeight : 0, i.ReceivedFromParty ? 0 : i.NetWeight, i.ReceivedFromParty ? fine : 0, i.ReceivedFromParty ? 0 : fine, i.Description);
        await _audit.Save("MetalLedger.Entry", i.PartyType.ToString(), i.PartyId, after: i, targetBranchId: branch);
    }

    // ============================ commission ============================
    public async Task<List<CommissionRow>> Commission(DateTime? from, DateTime? to, long[]? branchIds)
    {
        var u = _cu.Ctx; u.RequireAny(Perms.ReportsCommission, Perms.CommissionApprove);
        var br = u.ResolveScope(branchIds);
        var q = _db.CommissionEntries.AsNoTracking().Where(c => br.Contains(c.BranchId));
        if (from != null) q = q.Where(c => c.EntryDateUtc >= from); if (to != null) q = q.Where(c => c.EntryDateUtc < to.Value.AddDays(1));
        var rows = await q.ToListAsync();
        var ids = rows.Select(r => r.SalesmanId).Distinct().ToList();
        var names = await _db.Employees.AsNoTracking().Where(e => ids.Contains(e.Id)).ToDictionaryAsync(e => e.Id, e => e.Name);
        return rows.GroupBy(r => r.SalesmanId).Select(g => new CommissionRow(g.Key, names.GetValueOrDefault(g.Key, "?"), Money.R2(g.Sum(x => x.EligibleAmount)), Money.R2(g.Sum(x => x.CalculatedAmount)), Money.R2(g.Where(x => x.IsApproved).Sum(x => x.ApprovedAmount)), Money.R2(g.Sum(x => x.PaidAmount)),
            Money.R2(g.Where(x => x.IsApproved).Sum(x => x.ApprovedAmount) - g.Sum(x => x.PaidAmount)), g.Count())).OrderBy(r => r.Salesman).ToList();
    }

    public async Task<List<CommissionDetail>> CommissionDetails(long salesmanId, DateTime? from, DateTime? to)
    {
        var u = _cu.Ctx; u.RequireAny(Perms.ReportsCommission, Perms.CommissionApprove);
        var q = _db.CommissionEntries.AsNoTracking().Where(c => c.SalesmanId == salesmanId);
        if (from != null) q = q.Where(c => c.EntryDateUtc >= from); if (to != null) q = q.Where(c => c.EntryDateUtc < to.Value.AddDays(1));
        return (await q.OrderByDescending(c => c.EntryDateUtc).Take(500).ToListAsync()).Select(c => new CommissionDetail(c.Id, c.EntryDateUtc, c.SalesInvoiceId, c.SalesReturnId, c.EligibleAmount, c.Rate, c.CalculatedAmount, c.ApprovedAmount, c.PaidAmount, c.IsApproved, c.IsReversal, c.Note)).ToList();
    }

    /// <summary>Approve calculated commission (optionally with a manual amount per entry). Posts the accrual: Dr commission expense / Cr commission payable.</summary>
    public async Task<int> ApproveCommission(IList<long> entryIds, IDictionary<long, decimal>? overrides)
    {
        var u = _cu.Ctx; u.Require(Perms.CommissionApprove);
        var n = 0;
        await _post.InTransaction(async () =>
        {
            var rows = await _db.CommissionEntries.Where(c => entryIds.Contains(c.Id) && !c.IsApproved).ToListAsync();
            decimal total = 0; long branch = 0;
            foreach (var c in rows)
            {
                u.RequireBranch(c.BranchId); branch = c.BranchId;
                c.ApprovedAmount = overrides != null && overrides.TryGetValue(c.Id, out var o) ? Money.R2(o) : c.CalculatedAmount; c.IsApproved = true; total += c.ApprovedAmount; n++;
            }
            if (total > 0) await _post.Journal(new JournalBuilder().Dr(Acc.CommissionExpense, total, "Commission").Cr(Acc.CommissionPayable, total, "Commission payable"), TxnType.Commission, 0, "COM-" + DateTime.UtcNow.Ticks, branch, DateTime.UtcNow, "Commission approved");
            else if (total < 0) await _post.Journal(new JournalBuilder().Dr(Acc.CommissionPayable, -total, "Commission reversed").Cr(Acc.CommissionExpense, -total, "Commission reversed"), TxnType.Commission, 0, "COM-" + DateTime.UtcNow.Ticks, branch, DateTime.UtcNow, "Commission reversal approved");
            _audit.Add("Commission.Approved", nameof(CommissionEntry), string.Join(",", entryIds), after: new { n, total });
            return 0;
        });
        return n;
    }

    public async Task PayCommission(long salesmanId, decimal amount, long accountId, long? branchId)
    {
        var u = _cu.Ctx; u.Require(Perms.FinancePaymentPost);
        var branch = await _post.PostingBranch(branchId);
        if (amount <= 0) throw new ValidationFailedException("amount", "Amount must be positive.");
        await _post.InTransaction(async () =>
        {
            await CheckAccount(accountId, branch);
            var due = await _db.CommissionEntries.Where(c => c.SalesmanId == salesmanId && c.IsApproved && c.ApprovedAmount > c.PaidAmount).OrderBy(c => c.EntryDateUtc).ToListAsync();
            var unpaid = due.Sum(c => c.ApprovedAmount - c.PaidAmount);
            if (amount > unpaid) throw new ValidationFailedException("amount", $"Only {unpaid:N2} of approved commission is unpaid.");
            var left = amount;
            foreach (var c in due) { if (left <= 0) break; var a = Math.Min(left, c.ApprovedAmount - c.PaidAmount); c.PaidAmount = Money.R2(c.PaidAmount + a); left -= a; }
            await _post.Journal(new JournalBuilder().Dr(Acc.CommissionPayable, amount, "Commission paid").CrAcc(await _post.LedgerAccountFor(accountId), amount, "Paid"), TxnType.Commission, 0, "COMP-" + DateTime.UtcNow.Ticks, branch, DateTime.UtcNow, "Commission payment");
            _audit.Add("Commission.Paid", nameof(CommissionEntry), salesmanId, after: new { amount }, targetBranchId: branch);
            return 0;
        });
    }

    // ============================ opening balances (cutover) ============================
    /// <summary>One-time opening journal from the party/account masters, as of the cutover date. Stock opening goes through approved Opening adjustments.</summary>
    public async Task<string> PostOpeningJournal(long? branchId, DateTime cutoverUtc)
    {
        var u = _cu.Ctx; u.Require(Perms.FinanceAccountsManage); u.Require(Perms.ApprovalsDecide);
        var branch = await _post.PostingBranch(branchId);
        if (await _settings.Get("Opening.Posted") == "true") throw new ConflictException("The opening journal has already been posted. Corrections need a reversal.");
        string number = "";
        await _post.InTransaction(async () =>
        {
            var j = new JournalBuilder(); decimal net = 0;
            foreach (var a in await _db.CashBankAccounts.AsNoTracking().Where(a => a.OpeningBalance != 0).ToListAsync()) { j.DrAcc(await _post.LedgerAccountFor(a.Id), a.OpeningBalance, "Opening " + a.Name); net += a.OpeningBalance; }
            var cust = await _db.Customers.AsNoTracking().Where(c => c.OpeningBalance != 0).ToListAsync();
            foreach (var c in cust) { if (c.OpeningBalance > 0) j.Dr(Acc.Receivable, c.OpeningBalance, "Opening " + c.Name, PartyType.Customer, c.Id); else j.Cr(Acc.CustomerAdvances, -c.OpeningBalance, "Opening credit " + c.Name, PartyType.Customer, c.Id); net += c.OpeningBalance; }
            foreach (var s in await _db.Suppliers.AsNoTracking().Where(c => c.OpeningBalance != 0).ToListAsync()) { if (s.OpeningBalance > 0) j.Cr(Acc.Payable, s.OpeningBalance, "Opening " + s.Name, PartyType.Supplier, s.Id); else j.Dr(Acc.Payable, -s.OpeningBalance, "Opening advance " + s.Name, PartyType.Supplier, s.Id); net -= s.OpeningBalance; }
            foreach (var w in await _db.Workers.AsNoTracking().Where(c => c.OpeningBalance != 0).ToListAsync()) { if (w.OpeningBalance > 0) j.Cr(Acc.WorkerPayable, w.OpeningBalance, "Opening " + w.Name, PartyType.Worker, w.Id); else j.Dr(Acc.WorkerPayable, -w.OpeningBalance, "Opening advance " + w.Name, PartyType.Worker, w.Id); net -= w.OpeningBalance; }
            if (j.Lines.Count == 0) throw new DomainException("There are no opening balances on the cash/bank, customer, supplier or worker masters.", "nothing_to_post");
            if (net > 0) j.Cr(Acc.OpeningEquity, net, "Opening balance equity"); else if (net < 0) j.Dr(Acc.OpeningEquity, -net, "Opening balance equity");
            var je = await _post.Journal(j, TxnType.Opening, 0, "OPENING", branch, cutoverUtc, "Opening balances at cutover");
            number = je.Number;
            await _db.SaveChangesAsync();
            await _settings.Set("Opening.Posted", "true", null, "Opening journal posted");
            _audit.Add("Finance.OpeningPosted", nameof(JournalEntry), je.Id, after: new { cutoverUtc, je.TotalDebit }, targetBranchId: branch);
            return 0;
        });
        return number;
    }
}
