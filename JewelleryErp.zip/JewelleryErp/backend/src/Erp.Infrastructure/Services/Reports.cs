using Erp.Domain;
using Erp.Domain.Calc;
using Erp.Domain.Entities;
using Erp.Infrastructure.Contracts;
using Erp.Infrastructure.Data;
using Erp.Infrastructure.Exports;
using Microsoft.EntityFrameworkCore;

namespace Erp.Infrastructure.Services;

public sealed class ReportFilter
{
    public DateTime? From { get; set; }
    public DateTime? To { get; set; }
    public long[]? BranchIds { get; set; }
    public long? PartyId { get; set; }
    public long? ProductId { get; set; }
    public long? CategoryId { get; set; }
    public long? PurityId { get; set; }
    public long? SalesmanId { get; set; }
    public long? AccountId { get; set; }
    public string? By { get; set; }
    public string? Status { get; set; }
    public string? Search { get; set; }
}

public sealed class RegisterQuery : PageQuery
{
    public DateTime? From { get; set; }
    public DateTime? To { get; set; }
    public long[]? BranchIds { get; set; }
    public TxnType? TxnType { get; set; }
    public PartyType? PartyType { get; set; }
    public long? PartyId { get; set; }
    public string? Sku { get; set; }
    public long? PurityId { get; set; }
    public decimal? MinNet { get; set; }
    public decimal? MaxNet { get; set; }
    public string? PaymentMethod { get; set; }
    public DocStatus? Status { get; set; }
    public long? UserId { get; set; }
    public bool? ApprovedOnly { get; set; }
}

public sealed record RegisterRowDto(long Id, DateTime PostedAtUtc, long BranchId, string Branch, string? DestinationBranch, string TxnType, int TxnTypeCode, string DocNo, long DocId, int LineNo, string Status, string? PartyType, string? Party, string? Sku, string? Item, string? Metal, string? Purity,
    decimal Gross, decimal Stone, decimal Net, decimal Fine, decimal Rate, decimal Making, decimal Wastage, decimal StoneValue, decimal PkrDebit, decimal PkrCredit, decimal PkrNet, string? PaymentMethod, string? LinkedDocType, string? LinkedDocNo, long? LinkedDocId, string? EnteredBy, bool Approved, bool IsReversal);

public sealed record KpiDto(string Key, string Label, decimal? Value, string Format, string? Hint = null);
public sealed record SeriesPoint(string Label, decimal Value);
public sealed record AlertDto(string Type, string Severity, string Message, int Count, string? Route);
public sealed record DashboardDto(DateTime From, DateTime To, string Scope, IReadOnlyList<KpiDto> Kpis, IReadOnlyDictionary<string, IReadOnlyList<SeriesPoint>> Charts, IReadOnlyList<AlertDto> Alerts, IReadOnlyDictionary<string, int> RepairsByStatus);

public sealed class ReportService
{
    readonly ErpDbContext _db; readonly CurrentUser _cu; readonly AuditService _audit; readonly PostingEngine _post; readonly SettingsService _settings; readonly AccessGuard _guard;
    public ReportService(ErpDbContext db, CurrentUser cu, AuditService audit, PostingEngine post, SettingsService settings, AccessGuard guard) { _db = db; _cu = cu; _audit = audit; _post = post; _settings = settings; _guard = guard; }

    const int ExportCap = 50_000;
    static readonly DocStatus[] SaleOk = { DocStatus.Posted, DocStatus.PartiallyPaid, DocStatus.Closed };

    (DateTime fromD, DateTime toExcl) Range(ReportFilter f) { var today = DateTime.UtcNow.Date; return ((f.From?.Date ?? today.AddDays(-29)), (f.To?.Date ?? today).AddDays(1)); }

    async Task<string> ScopeText(long[] branches, DateTime fromD, DateTime toExcl)
    {
        var names = await _db.Branches.AsNoTracking().IgnoreQueryFilters().Where(b => branches.Contains(b.Id)).Select(b => b.BranchName).ToListAsync();
        return $"Branches: {(names.Count == 0 ? "-" : string.Join(", ", names))} | {fromD:yyyy-MM-dd} to {toExcl.AddDays(-1):yyyy-MM-dd}";
    }

    // =================================================================================================
    // Dashboard (SRS 3.13) - every figure is branch-scoped and permission-gated
    // =================================================================================================
    public async Task<DashboardDto> Dashboard(ReportFilter f)
    {
        var u = _cu.Ctx; u.Require(Perms.ReportsDashboard);
        var br = u.ResolveScope(f.BranchIds); var (fromD, toX) = Range(f);
        var kpis = new List<KpiDto>(); var charts = new Dictionary<string, IReadOnlyList<SeriesPoint>>();
        var sales = _db.SalesInvoices.AsNoTracking().Where(s => br.Contains(s.BranchId) && SaleOk.Contains(s.Status) && s.DocDateUtc >= fromD && s.DocDateUtc < toX);
        var seeSales = u.Has(Perms.SalesView) || u.Has(Perms.ReportsSales);
        if (seeSales)
        {
            var today = DateTime.UtcNow.Date;
            kpis.Add(new("salesToday", "Today's sales", await _db.SalesInvoices.AsNoTracking().Where(s => br.Contains(s.BranchId) && SaleOk.Contains(s.Status) && s.DocDateUtc >= today).SumAsync(s => (decimal?)s.Total) ?? 0, "money"));
            var tot = await sales.SumAsync(s => (decimal?)s.Total) ?? 0; kpis.Add(new("sales", "Sales (period)", tot, "money"));
            kpis.Add(new("receivables", "Customer receivables", await _db.SalesInvoices.AsNoTracking().Where(s => br.Contains(s.BranchId) && SaleOk.Contains(s.Status)).SumAsync(s => (decimal?)s.DueTotal) ?? 0, "money"));
            if (u.Has(Perms.ReportsProfit)) { var cost = await sales.SumAsync(s => (decimal?)s.CostTotal) ?? 0; kpis.Add(new("margin", "Gross margin", tot - cost - (await sales.SumAsync(s => (decimal?)s.TaxTotal) ?? 0), "money", "Item-specific cost; confirm the approved costing policy")); }
            var days = await sales.Select(s => new { s.DocDateUtc, s.Total }).ToListAsync();
            charts["salesTrend"] = days.GroupBy(d => d.DocDateUtc.Date).OrderBy(g => g.Key).Select(g => new SeriesPoint(g.Key.ToString("MM-dd"), g.Sum(x => x.Total))).ToList();
            var lines = await (from l in _db.SalesInvoiceLines.AsNoTracking() join s in sales on l.SalesInvoiceId equals s.Id select new { l.ProductId, l.PurityId, l.Sku, l.Description, l.LineTotal }).ToListAsync();
            var pids = lines.Select(x => x.ProductId).Distinct().ToList();
            var prod = await _db.Products.AsNoTracking().Where(p => pids.Contains(p.Id)).Select(p => new { p.Id, p.CategoryId }).ToDictionaryAsync(p => p.Id, p => p.CategoryId);
            var cat = await _db.ProductCategories.AsNoTracking().ToDictionaryAsync(c => c.Id, c => c.Name); var pur = await _db.Purities.AsNoTracking().ToDictionaryAsync(p => p.Id, p => p.Label);
            charts["categoryMix"] = lines.GroupBy(l => prod.GetValueOrDefault(l.ProductId) is long c ? cat.GetValueOrDefault(c, "Other") : "Other").Select(g => new SeriesPoint(g.Key, g.Sum(x => x.LineTotal))).OrderByDescending(x => x.Value).Take(8).ToList();
            charts["karatMix"] = lines.GroupBy(l => l.PurityId != null ? pur.GetValueOrDefault(l.PurityId.Value, "?") : "n/a").Select(g => new SeriesPoint(g.Key, g.Sum(x => x.LineTotal))).OrderByDescending(x => x.Value).ToList();
            charts["topProducts"] = lines.GroupBy(l => l.Sku + " " + l.Description).Select(g => new SeriesPoint(g.Key.Length > 28 ? g.Key[..28] : g.Key, g.Sum(x => x.LineTotal))).OrderByDescending(x => x.Value).Take(8).ToList();
            var pm = await _db.SalesPayments.AsNoTracking().Where(p => _db.SalesInvoices.Any(s => s.Id == p.SalesInvoiceId && br.Contains(s.BranchId) && SaleOk.Contains(s.Status) && s.DocDateUtc >= fromD && s.DocDateUtc < toX)).Select(p => new { p.PaymentMethodId, p.Amount }).ToListAsync();
            var pmn = await _db.PaymentMethods.AsNoTracking().ToDictionaryAsync(m => m.Id, m => m.Name);
            charts["paymentMethods"] = pm.GroupBy(p => pmn.GetValueOrDefault(p.PaymentMethodId, "?")).Select(g => new SeriesPoint(g.Key, g.Sum(x => x.Amount))).ToList();
            var bn = await _db.Branches.AsNoTracking().IgnoreQueryFilters().ToDictionaryAsync(b => b.Id, b => b.BranchName);
            var inv = await sales.Select(s => new { s.BranchId, s.SalesmanId, s.Total }).ToListAsync();
            charts["branchPerformance"] = inv.GroupBy(s => bn.GetValueOrDefault(s.BranchId, "?")).Select(g => new SeriesPoint(g.Key, g.Sum(x => x.Total))).OrderByDescending(x => x.Value).ToList();
            var en = await _db.Employees.AsNoTracking().ToDictionaryAsync(e => e.Id, e => e.Name);
            charts["salesmanPerformance"] = inv.Where(s => s.SalesmanId != null).GroupBy(s => en.GetValueOrDefault(s.SalesmanId!.Value, "?")).Select(g => new SeriesPoint(g.Key, g.Sum(x => x.Total))).OrderByDescending(x => x.Value).Take(8).ToList();
        }
        if (u.Has(Perms.ReportsPurchase) || u.Has(Perms.PurchasesView))
        {
            kpis.Add(new("purchases", "Purchases (period)", await _db.PurchaseInvoices.AsNoTracking().Where(s => br.Contains(s.BranchId) && SaleOk.Contains(s.Status) && s.DocDateUtc >= fromD && s.DocDateUtc < toX).SumAsync(s => (decimal?)s.Total) ?? 0, "money"));
            kpis.Add(new("payables", "Supplier payables", await _db.PurchaseInvoices.AsNoTracking().Where(s => br.Contains(s.BranchId) && SaleOk.Contains(s.Status)).SumAsync(s => (decimal?)s.DueTotal) ?? 0, "money"));
        }
        if (u.Has(Perms.FinanceView) || u.Has(Perms.ReportsFinance))
        {
            var ex = await _db.ExpenseVouchers.AsNoTracking().Where(e => br.Contains(e.BranchId) && e.Status == DocStatus.Posted && e.DocDateUtc >= fromD && e.DocDateUtc < toX).Select(e => new { e.ExpenseHeadId, e.Amount }).ToListAsync();
            kpis.Add(new("expenses", "Expenses (period)", ex.Sum(e => e.Amount), "money"));
            var heads = await _db.ExpenseHeads.AsNoTracking().ToDictionaryAsync(h => h.Id, h => h.Name);
            charts["expenseDistribution"] = ex.GroupBy(e => heads.GetValueOrDefault(e.ExpenseHeadId, "?")).Select(g => new SeriesPoint(g.Key, g.Sum(x => x.Amount))).OrderByDescending(x => x.Value).ToList();
            var cashAccs = await _db.CashBankAccounts.AsNoTracking().Where(a => a.ChartAccountId != null).Select(a => a.ChartAccountId!.Value).ToListAsync();
            var mv = await (from l in _db.JournalLines.AsNoTracking() join e in _db.JournalEntries.AsNoTracking() on l.JournalEntryId equals e.Id where cashAccs.Contains(l.AccountId) && br.Contains(e.BranchId) && e.EntryDateUtc >= fromD && e.EntryDateUtc < toX select new { l.Debit, l.Credit }).ToListAsync();
            kpis.Add(new("cashIn", "Cash/bank in", mv.Sum(m => m.Debit), "money")); kpis.Add(new("cashOut", "Cash/bank out", mv.Sum(m => m.Credit), "money"));
        }
        if (u.Has(Perms.InventoryView) || u.Has(Perms.ReportsStock))
        {
            var withWorker = await _db.StockBalances.AsNoTracking().Where(b => br.Contains(b.BranchId) && b.Status == StockStatus.WithWorker).SumAsync(b => (decimal?)b.FineWeight) ?? 0;
            kpis.Add(new("workerMetal", "Metal with workers (fine g)", withWorker, "weight"));
            kpis.Add(new("stockValue", "Available stock (items)", await _db.StockBalances.AsNoTracking().Where(b => br.Contains(b.BranchId) && b.Status == StockStatus.Available && b.ProductId != null).SumAsync(b => (decimal?)b.Quantity) ?? 0, "number"));
        }
        var repairs = new Dictionary<string, int>();
        if (u.Has(Perms.RepairsViewBranch))
            foreach (var g in (await _db.RepairTickets.AsNoTracking().Where(t => br.Contains(t.BranchId)).GroupBy(t => t.RepairStatus).Select(g => new { g.Key, N = g.Count() }).ToListAsync())) repairs[g.Key.ToString()] = g.N;
        return new DashboardDto(fromD, toX.AddDays(-1), await ScopeText(br, fromD, toX), kpis, charts, await Alerts(br), repairs);
    }

    async Task<List<AlertDto>> Alerts(long[] br)
    {
        var u = _cu.Ctx; var a = new List<AlertDto>(); var now = DateTime.UtcNow;
        if (u.Has(Perms.InventoryView))
        {
            var mins = await _db.Products.AsNoTracking().Where(p => p.IsActive && p.IsStockItem && p.MinStock > 0 && p.Tracking != TrackingMode.Serialized).Select(p => new { p.Id, p.MinStock }).ToListAsync();
            var avail = await _db.StockBalances.AsNoTracking().Where(b => br.Contains(b.BranchId) && b.Status == StockStatus.Available && b.ProductId != null).GroupBy(b => b.ProductId).Select(g => new { Id = g.Key, Q = g.Sum(x => x.Quantity) }).ToListAsync();
            var low = mins.Count(m => (avail.FirstOrDefault(x => x.Id == m.Id)?.Q ?? 0) < m.MinStock);
            if (low > 0) a.Add(new("LowStock", "warning", $"{low} item(s) below minimum stock", low, "/inventory/stock"));
            var neg = await _db.AuditLogs.AsNoTracking().CountAsync(l => l.Action == "Stock.NegativeAttempt" && l.AtUtc > now.AddDays(-7)); if (neg > 0 && u.Has(Perms.AuditLogView)) a.Add(new("NegativeStock", "warning", $"{neg} negative-stock attempt(s) in 7 days", neg, "/admin/audit"));
            var adj = await _db.StockAdjustments.AsNoTracking().CountAsync(x => br.Contains(x.BranchId) && x.DocDateUtc > now.AddDays(-7) && x.TotalValue > 0 && x.Status == DocStatus.Posted && x.Kind != "Opening"); if (adj >= 5) a.Add(new("UnusualAdjustments", "warning", $"{adj} stock adjustments posted in 7 days - review", adj, "/inventory/adjustments"));
        }
        if (u.Has(Perms.RepairsViewBranch)) { var od = await _db.RepairTickets.AsNoTracking().CountAsync(t => br.Contains(t.BranchId) && t.PromisedDateUtc < now && t.RepairStatus != RepairStatus.Delivered && t.RepairStatus != RepairStatus.Cancelled && t.RepairStatus != RepairStatus.Rejected && t.RepairStatus != RepairStatus.Unrepairable); if (od > 0) a.Add(new("RepairOverdue", "danger", $"{od} repair(s) past the promised date", od, "/repairs")); }
        if (u.Has(Perms.JobWorkView))
        {
            var jo = await _db.JobCards.AsNoTracking().CountAsync(j => br.Contains(j.BranchId) && j.DueDateUtc < now && j.JobStatus != JobStatus.Closed && j.JobStatus != JobStatus.Cancelled && j.JobStatus != JobStatus.Reconciled); if (jo > 0) a.Add(new("JobOverdue", "danger", $"{jo} job card(s) overdue", jo, "/job-work"));
            var un = await _db.JobCards.AsNoTracking().CountAsync(j => br.Contains(j.BranchId) && j.JobStatus == JobStatus.Completed); if (un > 0) a.Add(new("WorkerMetalUnreconciled", "warning", $"{un} completed job(s) not reconciled", un, "/job-work"));
        }
        if (u.Has(Perms.ApprovalsView) || u.Has(Perms.ApprovalsDecide)) { var pa = await _db.ApprovalRequests.AsNoTracking().CountAsync(r => br.Contains(r.BranchId) && r.Status == ApprovalStatus.Pending); if (pa > 0) a.Add(new("PendingApproval", "info", $"{pa} approval(s) waiting", pa, "/approvals")); }
        if (u.Has(Perms.BackupManage)) { var last = await _db.BackupHistory.AsNoTracking().OrderByDescending(b => b.Id).FirstOrDefaultAsync(); if (last == null || last.Status == "Failed" || last.StartedUtc < now.AddDays(-2)) a.Add(new("BackupFailure", "danger", last == null ? "No backup has ever been recorded" : last.Status == "Failed" ? "The last backup failed" : "No successful backup in 48 hours", 1, "/admin/settings")); }
        return a;
    }

    // =================================================================================================
    // Comprehensive transaction register (SRS 7.1)
    // =================================================================================================
    IQueryable<TransactionRegisterEntry> RegisterQ(RegisterQuery q, long[] br)
    {
        var (fromD, toX) = Range(new ReportFilter { From = q.From, To = q.To });
        var s = _db.TransactionRegister.AsNoTracking().Where(r => br.Contains(r.BranchId) && r.PostedAtUtc >= fromD && r.PostedAtUtc < toX);
        if (q.TxnType != null) s = s.Where(r => r.TxnType == q.TxnType);
        if (q.PartyType != null) s = s.Where(r => r.PartyType == q.PartyType);
        if (q.PartyId != null) s = s.Where(r => r.PartyId == q.PartyId);
        if (!string.IsNullOrWhiteSpace(q.Sku)) { var k = q.Sku.Trim(); s = s.Where(r => r.Sku != null && r.Sku.Contains(k)); }
        if (q.PurityId != null) s = s.Where(r => r.PurityId == q.PurityId);
        if (q.MinNet != null) s = s.Where(r => r.Net >= q.MinNet); if (q.MaxNet != null) s = s.Where(r => r.Net <= q.MaxNet);
        if (!string.IsNullOrWhiteSpace(q.PaymentMethod)) { var k = q.PaymentMethod.Trim(); s = s.Where(r => r.PaymentMethod != null && r.PaymentMethod.Contains(k)); }
        if (q.Status != null) s = s.Where(r => r.Status == q.Status);
        if (q.UserId != null) s = s.Where(r => r.EnteredBy == q.UserId);
        if (q.ApprovedOnly == true) s = s.Where(r => r.ApprovedBy != null);
        if (!string.IsNullOrWhiteSpace(q.Search)) { var k = q.Search.Trim(); s = s.Where(r => r.DocNo.Contains(k) || (r.PartyName != null && r.PartyName.Contains(k)) || (r.ItemName != null && r.ItemName.Contains(k)) || (r.Sku != null && r.Sku.Contains(k))); }
        return s;
    }

    static readonly string[] RegSort = { "PostedAtUtc", "DocNo", "TxnType", "Status", "PkrDebit", "PkrCredit", "Net", "Sku" };

    async Task<List<RegisterRowDto>> MapRegister(List<TransactionRegisterEntry> rows)
    {
        var u = _cu.Ctx;
        var br = await _db.Branches.AsNoTracking().IgnoreQueryFilters().ToDictionaryAsync(b => b.Id, b => b.BranchName);
        var met = await _db.MetalTypes.AsNoTracking().ToDictionaryAsync(m => m.Id, m => m.Name); var pur = await _db.Purities.AsNoTracking().ToDictionaryAsync(p => p.Id, p => p.Label);
        return rows.Select(r => new RegisterRowDto(r.Id, r.PostedAtUtc, r.BranchId, br.GetValueOrDefault(r.BranchId, ""), r.DestinationBranchId != null ? br.GetValueOrDefault(r.DestinationBranchId.Value) : null, r.TxnType.ToString(), (int)r.TxnType, r.DocNo, r.DocId, r.LineNo, r.Status.ToString(), r.PartyType?.ToString(), r.PartyName, r.Sku, r.ItemName,
            r.MetalTypeId != null ? met.GetValueOrDefault(r.MetalTypeId.Value) : null, r.PurityId != null ? pur.GetValueOrDefault(r.PurityId.Value) : null, r.Gross, r.Stone, r.Net, r.Fine, r.Rate, r.Making, r.Wastage, r.StoneValue, r.PkrDebit, r.PkrCredit, r.PkrCredit - r.PkrDebit, r.PaymentMethod, r.LinkedDocType, r.LinkedDocNo, r.LinkedDocId, r.EnteredByName, r.ApprovedBy != null, r.IsReversal)).ToList();
    }

    public async Task<PagedResult<RegisterRowDto>> Register(RegisterQuery q)
    {
        var u = _cu.Ctx; u.Require(Perms.ReportsTransactions);
        var br = u.ResolveScope(q.BranchIds);
        var s = RegisterQ(q, br);
        var total = await s.CountAsync();
        var rows = await s.OrderByProp(q.Sort, q.Desc || q.Sort == null, RegSort, "PostedAtUtc").Skip(q.Skip).Take(q.Take).ToListAsync();
        var totals = new Dictionary<string, decimal> { ["debit"] = await s.SumAsync(r => (decimal?)r.PkrDebit) ?? 0, ["credit"] = await s.SumAsync(r => (decimal?)r.PkrCredit) ?? 0, ["net"] = await s.SumAsync(r => (decimal?)r.Net) ?? 0, ["fine"] = await s.SumAsync(r => (decimal?)r.Fine) ?? 0, ["gross"] = await s.SumAsync(r => (decimal?)r.Gross) ?? 0 };
        return new PagedResult<RegisterRowDto>(await MapRegister(rows), total, q.Page, q.Take, totals);
    }

    /// <summary>Drill-through: source document rows, stock movements, journal postings, party ledger, images and the audit trail.</summary>
    public async Task<object> RegisterDetail(TxnType type, long docId)
    {
        var u = _cu.Ctx; u.Require(Perms.ReportsTransactions);
        var rows = await _db.TransactionRegister.AsNoTracking().Where(r => r.TxnType == type && r.DocId == docId).OrderBy(r => r.LineNo).ToListAsync();
        if (rows.Count == 0) { if (await _db.TransactionRegister.IgnoreQueryFilters().AnyAsync(r => r.TxnType == type && r.DocId == docId)) await _audit.Save("Access.Denied", "TransactionRegister", docId, denied: true); throw new NotFoundException("Transaction"); }
        var mv = await _db.StockMovements.AsNoTracking().Where(m => m.RefType == type && m.RefId == docId).OrderBy(m => m.Id).ToListAsync();
        var je = await _db.JournalEntries.AsNoTracking().Include(j => j.Lines).Where(j => j.DocType == type && j.DocId == docId).ToListAsync();
        var acc = await _db.ChartAccounts.AsNoTracking().ToDictionaryAsync(a => a.Id, a => a.Code + " " + a.Name);
        var ledger = u.Has(Perms.FinanceView) ? await _db.PartyLedger.AsNoTracking().Where(p => p.DocType == type && p.DocId == docId).ToListAsync() : new List<PartyLedgerEntry>();
        var audit = u.Has(Perms.AuditLogView) ? await _db.AuditLogs.AsNoTracking().Where(a => a.EntityId == docId.ToString()).OrderBy(a => a.AtUtc).Take(50).Select(a => new { a.AtUtc, a.UserName, a.Action, a.Reason }).ToListAsync() : null;
        var owner = type switch { TxnType.RepairIntake or TxnType.RepairDelivery => FileOwnerType.RepairTicket, _ => FileOwnerType.Product };
        return new
        {
            rows = await MapRegister(rows),
            movements = mv.Select(m => new { m.Id, m.PostedAtUtc, m.Kind, fromD = m.FromStatus?.ToString(), to = m.ToStatus?.ToString(), m.Quantity, m.NetWeight, m.FineWeight, m.Reason }),
            journals = je.Select(j => new { j.Number, j.EntryDateUtc, j.Description, j.IsReversal, j.TotalDebit, j.TotalCredit, lines = j.Lines.Select(l => new { account = acc.GetValueOrDefault(l.AccountId, "?"), l.Debit, l.Credit, l.Memo }) }),
            ledger = ledger.Select(l => new { l.EntryDateUtc, party = l.PartyType.ToString(), l.PartyId, l.Description, l.Debit, l.Credit }),
            audit,
            totals = new { debit = rows.Sum(r => r.PkrDebit), credit = rows.Sum(r => r.PkrCredit) }
        };
    }

    // =================================================================================================
    // Generic report engine: one table shape -> screen, CSV, Excel, PDF with identical numbers and scope
    // =================================================================================================
    public static readonly IReadOnlyDictionary<string, (string Title, string Perm, string Group)> Catalogue = new Dictionary<string, (string, string, string)>
    {
        ["sales-register"] = ("Sales register (invoice-wise)", Perms.ReportsSales, "Sales & POS"), ["sales-items"] = ("Item-wise sales", Perms.ReportsSales, "Sales & POS"), ["sales-summary"] = ("Sales summary (by salesman/branch/category/karat/customer/product/day)", Perms.ReportsSales, "Sales & POS"),
        ["payment-summary"] = ("Payment method summary", Perms.ReportsSales, "Sales & POS"), ["discount-making-wastage"] = ("Discount, making & wastage", Perms.ReportsSales, "Sales & POS"), ["sales-returns"] = ("Sales returns & exchanges", Perms.ReportsSales, "Sales & POS"),
        ["receivables-aging"] = ("Customer receivables aging", Perms.ReportsSales, "Sales & POS"), ["old-gold"] = ("Old gold / buy-back", Perms.ReportsSales, "Sales & POS"),
        ["purchase-register"] = ("Purchase register", Perms.ReportsPurchase, "Purchase & suppliers"), ["purchase-variance"] = ("Weight / purity variance on receipt", Perms.ReportsPurchase, "Purchase & suppliers"), ["payables-aging"] = ("Supplier payables aging", Perms.ReportsPurchase, "Purchase & suppliers"),
        ["supplier-payments"] = ("Supplier payments & advances", Perms.ReportsPurchase, "Purchase & suppliers"), ["purchase-rates"] = ("Purchase rate history", Perms.ReportsPurchase, "Purchase & suppliers"),
        ["stock-current"] = ("Current stock", Perms.ReportsStock, "Inventory & metal"), ["stock-valuation"] = ("Stock valuation (cost)", Perms.ReportsCost, "Inventory & metal"), ["stock-metal-purity"] = ("Metal weight by metal & purity", Perms.ReportsStock, "Inventory & metal"),
        ["stock-ledger"] = ("Stock movement ledger (opening + in - out = closing)", Perms.ReportsStock, "Inventory & metal"), ["stock-status"] = ("Reserved / in-transit / with worker / inspection / damaged", Perms.ReportsStock, "Inventory & metal"),
        ["count-variance"] = ("Stock count variances", Perms.ReportsStock, "Inventory & metal"), ["low-stock"] = ("Low stock", Perms.ReportsStock, "Inventory & metal"), ["dead-stock"] = ("Dead stock (no sale in 90 days)", Perms.ReportsStock, "Inventory & metal"),
        ["aging-stock"] = ("Aging stock", Perms.ReportsStock, "Inventory & metal"), ["high-value-stock"] = ("High-value stock", Perms.ReportsStock, "Inventory & metal"), ["serial-history"] = ("Serial / SKU history", Perms.ReportsStock, "Inventory & metal"),
        ["jobs-by-stage"] = ("Job cards by stage", Perms.ReportsWorkshop, "Karigar"), ["worker-custody"] = ("Material in worker custody", Perms.ReportsWorkshop, "Karigar"), ["weight-reconciliation"] = ("Worker weight reconciliation / wastage / variance", Perms.ReportsWorkshop, "Karigar"),
        ["worker-payable"] = ("Worker making-charge payable", Perms.ReportsWorkshop, "Karigar"), ["overdue-jobs"] = ("Overdue job cards", Perms.ReportsWorkshop, "Karigar"),
        ["repair-register"] = ("Repair intake & customer-owned property", Perms.ReportsWorkshop, "Repairs"), ["repair-overdue"] = ("Overdue repairs", Perms.ReportsWorkshop, "Repairs"), ["repair-estimate-actual"] = ("Repair estimate vs actual", Perms.ReportsWorkshop, "Repairs"),
        ["repair-balances"] = ("Repair advance / balance due", Perms.ReportsWorkshop, "Repairs"), ["repair-consumption"] = ("Repair part & metal consumption", Perms.ReportsWorkshop, "Repairs"), ["repair-photo-audit"] = ("Before / after photo audit", Perms.ReportsWorkshop, "Repairs"),
        ["expense-register"] = ("Expense register", Perms.ReportsFinance, "Finance"), ["cash-book"] = ("Cash / bank book", Perms.ReportsFinance, "Finance"), ["receipts-payments"] = ("Receipts & payments", Perms.ReportsFinance, "Finance"), ["party-balances"] = ("Customer / supplier / worker balances", Perms.ReportsFinance, "Finance"),
        ["trial-balance"] = ("Trial balance", Perms.ReportsFinance, "Finance"), ["profit-loss"] = ("Profit & loss", Perms.ReportsFinance, "Finance"), ["balance-sheet"] = ("Balance sheet", Perms.ReportsFinance, "Finance"), ["cash-flow"] = ("Cash flow (direct)", Perms.ReportsFinance, "Finance"),
        ["gross-profit"] = ("Realised gross profit", Perms.ReportsProfit, "Finance"), ["commission"] = ("Salesman commission", Perms.ReportsCommission, "Finance"), ["tax-summary"] = ("Tax summary (validate rules first)", Perms.ReportsFinance, "Finance"),
        ["audit-reversals"] = ("Voided / reversed transactions", Perms.ReportsTransactions, "Audit"),
    };

    ReportTable T(string key, long[] br, string scope, params ReportColumn[] cols) => new() { Title = Catalogue[key].Title, Scope = scope, GeneratedBy = _cu.Ctx.UserName, Columns = cols.ToList() };
    static ReportColumn C(string k, string t, string type = "text") => new(k, t, type);

    public async Task<ReportTable> Run(string key, ReportFilter f, bool forExport = false)
    {
        if (!Catalogue.TryGetValue(key, out var def)) throw new NotFoundException("Report");
        var u = _cu.Ctx; u.Require(def.Perm); if (forExport) u.Require(Perms.ReportsExport);
        var br = u.ResolveScope(f.BranchIds); var (fromD, toX) = Range(f); var scope = await ScopeText(br, fromD, toX);
        var seeCost = u.Has(Perms.ReportsCost);
        var t = key switch
        {
            "sales-register" => await SalesRegister(f, br, fromD, toX, scope),
            "sales-items" => await SalesItems(f, br, fromD, toX, scope, seeCost),
            "sales-summary" => await SalesSummary(f, br, fromD, toX, scope),
            "payment-summary" => await PaymentSummary(br, fromD, toX, scope),
            "discount-making-wastage" => await DiscountMaking(br, fromD, toX, scope),
            "sales-returns" => await SalesReturnsRpt(br, fromD, toX, scope),
            "receivables-aging" => await Aging(br, scope, true),
            "payables-aging" => await Aging(br, scope, false),
            "old-gold" => await OldGoldRpt(br, fromD, toX, scope),
            "purchase-register" => await PurchaseRegister(f, br, fromD, toX, scope),
            "purchase-variance" => await PurchaseVariance(br, fromD, toX, scope),
            "supplier-payments" => await SupplierPaymentsRpt(br, fromD, toX, scope),
            "purchase-rates" => await PurchaseRates(br, fromD, toX, scope),
            "stock-current" or "stock-valuation" => await StockCurrent(f, br, scope, key == "stock-valuation"),
            "stock-metal-purity" => await StockMetalPurity(br, scope),
            "stock-ledger" => await StockLedger(f, br, fromD, toX, scope),
            "stock-status" => await StockStatusRpt(br, scope),
            "count-variance" => await CountVariance(br, fromD, toX, scope),
            "low-stock" => await LowStock(br, scope),
            "dead-stock" => await DeadStock(br, scope),
            "aging-stock" => await AgingStock(br, scope),
            "high-value-stock" => await HighValue(br, scope, seeCost),
            "serial-history" => await SerialHistory(f, br, scope),
            "jobs-by-stage" => await Jobs(br, scope, false), "overdue-jobs" => await Jobs(br, scope, true),
            "worker-custody" => await WorkerCustody(br, scope),
            "weight-reconciliation" => await WeightRecon(br, fromD, toX, scope),
            "worker-payable" => await WorkerPayable(scope),
            "repair-register" => await Repairs(br, scope, key, false), "repair-overdue" => await Repairs(br, scope, key, true), "repair-estimate-actual" => await Repairs(br, scope, key, false), "repair-balances" => await Repairs(br, scope, key, false),
            "repair-consumption" => await RepairParts(br, scope), "repair-photo-audit" => await RepairPhotos(br, scope),
            "expense-register" => await ExpenseRegister(br, fromD, toX, scope),
            "cash-book" => await CashBook(f, br, fromD, toX, scope),
            "receipts-payments" => await ReceiptsPayments(br, fromD, toX, scope),
            "party-balances" => await PartyBalances(f, scope),
            "trial-balance" => await TrialBalance(br, toX, scope),
            "profit-loss" => await ProfitLoss(br, fromD, toX, scope),
            "balance-sheet" => await BalanceSheet(br, toX, scope),
            "cash-flow" => await CashFlow(br, fromD, toX, scope),
            "gross-profit" => await GrossProfit(br, fromD, toX, scope),
            "commission" => await CommissionRpt(br, fromD, toX, scope),
            "tax-summary" => await TaxSummary(br, fromD, toX, scope),
            "audit-reversals" => await Reversals(br, fromD, toX, scope),
            _ => throw new NotFoundException("Report")
        };
        t.Title = def.Title;
        if (forExport && t.Rows.Count > ExportCap) { t.Rows = t.Rows.Take(ExportCap).ToList(); t.Truncated = true; }
        if (forExport) await _audit.Save("Report.Exported", "Report", key, after: new { rows = t.Rows.Count, scope }, targetBranchId: br.Length == 1 ? br[0] : null);
        return t;
    }

    public async Task<ReportTable> RegisterTable(RegisterQuery q)
    {
        var u = _cu.Ctx; u.Require(Perms.ReportsTransactions); u.Require(Perms.ReportsExport);
        var br = u.ResolveScope(q.BranchIds); var (fromD, toX) = Range(new ReportFilter { From = q.From, To = q.To });
        var rows = await RegisterQ(q, br).OrderByDescending(r => r.PostedAtUtc).ThenBy(r => r.Id).Take(ExportCap + 1).ToListAsync();
        var dto = await MapRegister(rows.Take(ExportCap).ToList());
        var t = new ReportTable { Title = "Comprehensive Transaction Register", Scope = await ScopeText(br, fromD, toX), GeneratedBy = u.UserName, Truncated = rows.Count > ExportCap,
            Columns = new() { C("at", "Date/Time", "datetime"), C("branch", "Branch"), C("type", "Type"), C("no", "Number"), C("status", "Status"), C("party", "Party"), C("sku", "SKU"), C("item", "Item"), C("purity", "Purity"), C("gross", "Gross", "weight"), C("stone", "Stone", "weight"), C("net", "Net", "weight"), C("fine", "Fine", "weight"),
                C("rate", "Rate", "money"), C("making", "Making", "money"), C("wastage", "Wastage", "money"), C("stoneValue", "Stone value", "money"), C("debit", "PKR Debit", "money"), C("credit", "PKR Credit", "money"), C("pay", "Payment"), C("linked", "Linked doc"), C("by", "Entered by") } };
        foreach (var r in dto) t.Rows.Add(new object?[] { r.PostedAtUtc, r.Branch, r.TxnType, r.DocNo, r.Status, r.Party, r.Sku, r.Item, r.Purity, r.Gross, r.Stone, r.Net, r.Fine, r.Rate, r.Making, r.Wastage, r.StoneValue, r.PkrDebit, r.PkrCredit, r.PaymentMethod, r.LinkedDocNo, r.EnteredBy });
        t.Totals["debit"] = dto.Sum(r => r.PkrDebit); t.Totals["credit"] = dto.Sum(r => r.PkrCredit); t.Totals["net g"] = dto.Sum(r => r.Net);
        await _audit.Save("Report.Exported", "TransactionRegister", "register", after: new { rows = t.Rows.Count, t.Scope });
        return t;
    }

    // ---------------- sales ----------------
    IQueryable<SalesInvoice> Sales(long[] br, DateTime fromD, DateTime toX) => _db.SalesInvoices.AsNoTracking().Where(s => br.Contains(s.BranchId) && SaleOk.Contains(s.Status) && s.DocDateUtc >= fromD && s.DocDateUtc < toX);
    async Task<Dictionary<long, string>> Names(IEnumerable<long?> ids, PartyType type)
    {
        var l = ids.Where(x => x != null).Select(x => x!.Value).Distinct().ToList();
        return type switch { PartyType.Customer => await _db.Customers.AsNoTracking().Where(c => l.Contains(c.Id)).ToDictionaryAsync(c => c.Id, c => c.Name), PartyType.Supplier => await _db.Suppliers.AsNoTracking().Where(c => l.Contains(c.Id)).ToDictionaryAsync(c => c.Id, c => c.Name), PartyType.Worker => await _db.Workers.AsNoTracking().Where(c => l.Contains(c.Id)).ToDictionaryAsync(c => c.Id, c => c.Name), _ => await _db.Employees.AsNoTracking().Where(c => l.Contains(c.Id)).ToDictionaryAsync(c => c.Id, c => c.Name) };
    }
    Task<Dictionary<long, string>> BranchNames() => _db.Branches.AsNoTracking().IgnoreQueryFilters().ToDictionaryAsync(b => b.Id, b => b.BranchName);

    async Task<ReportTable> SalesRegister(ReportFilter f, long[] br, DateTime fromD, DateTime toX, string scope)
    {
        var s = Sales(br, fromD, toX); if (f.PartyId != null) s = s.Where(x => x.CustomerId == f.PartyId); if (f.SalesmanId != null) s = s.Where(x => x.SalesmanId == f.SalesmanId);
        var rows = await s.OrderBy(x => x.DocDateUtc).Take(ExportCap + 1).ToListAsync();
        var cn = await Names(rows.Select(r => r.CustomerId), PartyType.Customer); var sn = await Names(rows.Select(r => r.SalesmanId), PartyType.Employee); var bn = await BranchNames();
        var t = T("sales-register", br, scope, C("d", "Date", "date"), C("no", "Invoice"), C("br", "Branch"), C("c", "Customer"), C("s", "Salesman"), C("sub", "Subtotal", "money"), C("disc", "Discount", "money"), C("tax", "Tax", "money"), C("og", "Old gold", "money"), C("tot", "Total", "money"), C("paid", "Paid", "money"), C("due", "Due", "money"), C("st", "Status"));
        foreach (var r in rows) t.Rows.Add(new object?[] { r.DocDateUtc, r.Number, bn.GetValueOrDefault(r.BranchId), r.CustomerId != null ? cn.GetValueOrDefault(r.CustomerId.Value) : "Walk-in", r.SalesmanId != null ? sn.GetValueOrDefault(r.SalesmanId.Value) : null, r.Subtotal, r.DiscountTotal, r.TaxTotal, r.OldGoldCredit, r.Total, r.PaidTotal, r.DueTotal, r.Status });
        t.Totals["total"] = rows.Sum(r => r.Total); t.Totals["paid"] = rows.Sum(r => r.PaidTotal); t.Totals["due"] = rows.Sum(r => r.DueTotal); return t;
    }

    async Task<ReportTable> SalesItems(ReportFilter f, long[] br, DateTime fromD, DateTime toX, string scope, bool seeCost)
    {
        var q = from l in _db.SalesInvoiceLines.AsNoTracking() join s in Sales(br, fromD, toX) on l.SalesInvoiceId equals s.Id select new { s.DocDateUtc, s.Number, s.BranchId, l.Sku, l.Description, l.PurityId, l.NetWeight, l.Rate, l.MakingCharge, l.WastageCharge, l.StoneValue, l.Discount, l.LineTotal, l.CostSnapshot, l.ProductId };
        if (f.ProductId != null) q = q.Where(x => x.ProductId == f.ProductId); if (f.PurityId != null) q = q.Where(x => x.PurityId == f.PurityId);
        var rows = await q.OrderBy(x => x.DocDateUtc).Take(ExportCap + 1).ToListAsync(); var pur = await _db.Purities.AsNoTracking().ToDictionaryAsync(p => p.Id, p => p.Label);
        var cols = new List<ReportColumn> { C("d", "Date", "date"), C("no", "Invoice"), C("sku", "SKU"), C("desc", "Item"), C("p", "Purity"), C("net", "Net (g)", "weight"), C("rate", "Rate", "money"), C("mk", "Making", "money"), C("w", "Wastage", "money"), C("sv", "Stone", "money"), C("disc", "Discount", "money"), C("tot", "Total", "money") };
        if (seeCost) cols.Add(C("cost", "Cost", "money"));
        var t = T("sales-items", br, scope, cols.ToArray());
        foreach (var r in rows) { var row = new List<object?> { r.DocDateUtc, r.Number, r.Sku, r.Description, r.PurityId != null ? pur.GetValueOrDefault(r.PurityId.Value) : null, r.NetWeight, r.Rate, r.MakingCharge, r.WastageCharge, r.StoneValue, r.Discount, r.LineTotal }; if (seeCost) row.Add(r.CostSnapshot); t.Rows.Add(row.ToArray()); }
        t.Totals["total"] = rows.Sum(r => r.LineTotal); t.Totals["net g"] = rows.Sum(r => r.NetWeight); return t;
    }

    async Task<ReportTable> SalesSummary(ReportFilter f, long[] br, DateTime fromD, DateTime toX, string scope)
    {
        var by = (f.By ?? "salesman").ToLowerInvariant(); var t = T("sales-summary", br, scope, C("k", "Group"), C("n", "Invoices", "number"), C("net", "Net (g)", "weight"), C("tot", "Total", "money"));
        var inv = await Sales(br, fromD, toX).Select(s => new { s.Id, s.BranchId, s.CustomerId, s.SalesmanId, s.DocDateUtc, s.Total }).ToListAsync();
        var lines = await (from l in _db.SalesInvoiceLines.AsNoTracking() join s in Sales(br, fromD, toX) on l.SalesInvoiceId equals s.Id select new { l.SalesInvoiceId, l.ProductId, l.PurityId, l.Sku, l.Description, l.NetWeight, l.LineTotal }).ToListAsync();
        IEnumerable<(string k, int n, decimal net, decimal tot)> g;
        if (by is "salesman" or "branch" or "customer" or "day" or "month")
        {
            var netBy = lines.GroupBy(l => l.SalesInvoiceId).ToDictionary(x => x.Key, x => x.Sum(y => y.NetWeight));
            var sn = await Names(inv.Select(i => i.SalesmanId), PartyType.Employee); var cn = await Names(inv.Select(i => i.CustomerId), PartyType.Customer); var bn = await BranchNames();
            g = inv.GroupBy(i => by switch { "salesman" => i.SalesmanId != null ? sn.GetValueOrDefault(i.SalesmanId.Value, "?") : "(none)", "branch" => bn.GetValueOrDefault(i.BranchId, "?"), "customer" => i.CustomerId != null ? cn.GetValueOrDefault(i.CustomerId.Value, "?") : "Walk-in", "day" => i.DocDateUtc.ToString("yyyy-MM-dd"), _ => i.DocDateUtc.ToString("yyyy-MM") })
                .Select(x => (x.Key, x.Count(), x.Sum(i => netBy.GetValueOrDefault(i.Id)), x.Sum(i => i.Total)));
        }
        else
        {
            var pr = await _db.Products.AsNoTracking().Select(p => new { p.Id, p.CategoryId }).ToDictionaryAsync(p => p.Id, p => p.CategoryId); var cat = await _db.ProductCategories.AsNoTracking().ToDictionaryAsync(c => c.Id, c => c.Name); var pur = await _db.Purities.AsNoTracking().ToDictionaryAsync(p => p.Id, p => p.Label);
            g = lines.GroupBy(l => by switch { "category" => pr.GetValueOrDefault(l.ProductId) is long c ? cat.GetValueOrDefault(c, "Other") : "Other", "karat" or "purity" => l.PurityId != null ? pur.GetValueOrDefault(l.PurityId.Value, "?") : "n/a", _ => l.Sku + " " + l.Description })
                .Select(x => (x.Key, x.Select(y => y.SalesInvoiceId).Distinct().Count(), x.Sum(y => y.NetWeight), x.Sum(y => y.LineTotal)));
        }
        foreach (var r in g.OrderByDescending(x => x.tot)) t.Rows.Add(new object?[] { r.k, r.n, r.net, r.tot });
        t.Totals["total"] = g.Sum(x => x.tot); t.Note = "Grouped by: " + by; return t;
    }

    async Task<ReportTable> PaymentSummary(long[] br, DateTime fromD, DateTime toX, string scope)
    {
        var pay = await (from p in _db.SalesPayments.AsNoTracking() join s in Sales(br, fromD, toX) on p.SalesInvoiceId equals s.Id select new { p.PaymentMethodId, p.Amount }).ToListAsync();
        var pm = await _db.PaymentMethods.AsNoTracking().ToDictionaryAsync(m => m.Id, m => m.Name); var due = await Sales(br, fromD, toX).SumAsync(s => (decimal?)s.DueTotal) ?? 0;
        var t = T("payment-summary", br, scope, C("m", "Method"), C("n", "Payments", "number"), C("a", "Amount", "money"));
        foreach (var g in pay.GroupBy(p => pm.GetValueOrDefault(p.PaymentMethodId, "?")).OrderByDescending(g => g.Sum(x => x.Amount))) t.Rows.Add(new object?[] { g.Key, g.Count(), g.Sum(x => x.Amount) });
        t.Rows.Add(new object?[] { "Credit / udhaar (unpaid)", null, due }); t.Totals["received"] = pay.Sum(p => p.Amount); t.Totals["credit"] = due; return t;
    }

    async Task<ReportTable> DiscountMaking(long[] br, DateTime fromD, DateTime toX, string scope)
    {
        var rows = await (from l in _db.SalesInvoiceLines.AsNoTracking() join s in Sales(br, fromD, toX) on l.SalesInvoiceId equals s.Id select new { s.Number, s.DocDateUtc, l.Discount, l.MakingCharge, l.WastageCharge, l.LineTotal }).ToListAsync();
        var t = T("discount-making-wastage", br, scope, C("d", "Date", "date"), C("no", "Invoice"), C("disc", "Discount", "money"), C("mk", "Making", "money"), C("w", "Wastage", "money"), C("tot", "Line total", "money"));
        foreach (var g in rows.GroupBy(r => new { r.Number, r.DocDateUtc }).OrderBy(g => g.Key.DocDateUtc)) t.Rows.Add(new object?[] { g.Key.DocDateUtc, g.Key.Number, g.Sum(x => x.Discount), g.Sum(x => x.MakingCharge), g.Sum(x => x.WastageCharge), g.Sum(x => x.LineTotal) });
        t.Totals["discount"] = rows.Sum(r => r.Discount); t.Totals["making"] = rows.Sum(r => r.MakingCharge); t.Totals["wastage"] = rows.Sum(r => r.WastageCharge); return t;
    }

    async Task<ReportTable> SalesReturnsRpt(long[] br, DateTime fromD, DateTime toX, string scope)
    {
        var rows = await _db.SalesReturns.AsNoTracking().Where(r => br.Contains(r.BranchId) && r.DocDateUtc >= fromD && r.DocDateUtc < toX && r.Status != DocStatus.Cancelled).OrderBy(r => r.DocDateUtc).ToListAsync(); var inv = rows.Select(r => r.OriginalInvoiceId).Distinct().ToList();
        var nums = await _db.SalesInvoices.AsNoTracking().Where(i => inv.Contains(i.Id)).ToDictionaryAsync(i => i.Id, i => i.Number); var cn = await Names(rows.Select(r => r.CustomerId), PartyType.Customer);
        var t = T("sales-returns", br, scope, C("d", "Date", "date"), C("no", "Return"), C("o", "Original invoice"), C("c", "Customer"), C("r", "Reason"), C("a", "Amount", "money"), C("rf", "Refunded", "money"), C("cr", "Ledger credit", "money"), C("s", "Status"));
        foreach (var r in rows) t.Rows.Add(new object?[] { r.DocDateUtc, r.Number, nums.GetValueOrDefault(r.OriginalInvoiceId), r.CustomerId != null ? cn.GetValueOrDefault(r.CustomerId.Value) : "Walk-in", r.Reason, r.Subtotal, r.RefundTotal, r.CreditToLedger, r.Status });
        t.Totals["amount"] = rows.Sum(r => r.Subtotal); return t;
    }

    async Task<ReportTable> Aging(long[] br, string scope, bool receivable)
    {
        var today = DateTime.UtcNow.Date;
        var t = T(receivable ? "receivables-aging" : "payables-aging", br, scope, C("p", receivable ? "Customer" : "Supplier"), C("b1", "0-30", "money"), C("b2", "31-60", "money"), C("b3", "61-90", "money"), C("b4", "90+", "money"), C("tot", "Outstanding", "money"));
        List<(long? party, DateTime date, decimal due)> docs = receivable
            ? (await _db.SalesInvoices.AsNoTracking().Where(s => br.Contains(s.BranchId) && SaleOk.Contains(s.Status) && s.DueTotal > 0).Select(s => new { s.CustomerId, s.DocDateUtc, s.DueTotal }).ToListAsync()).Select(x => (x.CustomerId, x.DocDateUtc, x.DueTotal)).ToList()
            : (await _db.PurchaseInvoices.AsNoTracking().Where(s => br.Contains(s.BranchId) && SaleOk.Contains(s.Status) && s.DueTotal > 0).Select(s => new { s.SupplierId, s.DocDateUtc, s.DueTotal }).ToListAsync()).Select(x => ((long?)x.SupplierId, x.DocDateUtc, x.DueTotal)).ToList();
        var names = await Names(docs.Select(d => d.party), receivable ? PartyType.Customer : PartyType.Supplier);
        foreach (var g in docs.GroupBy(d => d.party).OrderByDescending(g => g.Sum(x => x.due)))
        {
            decimal b1 = 0, b2 = 0, b3 = 0, b4 = 0;
            foreach (var d in g) { var bucket = Domain.Calc.Aging.Bucket((int)(today - d.date.Date).TotalDays); if (bucket == "0-30") b1 += d.due; else if (bucket == "31-60") b2 += d.due; else if (bucket == "61-90") b3 += d.due; else b4 += d.due; }
            t.Rows.Add(new object?[] { g.Key != null ? names.GetValueOrDefault(g.Key.Value, "?") : "Walk-in", b1, b2, b3, b4, b1 + b2 + b3 + b4 });
        }
        t.Totals["outstanding"] = docs.Sum(d => d.due); t.Note = "As of " + today.ToString("yyyy-MM-dd") + ", aged by invoice date."; return t;
    }

    async Task<ReportTable> OldGoldRpt(long[] br, DateTime fromD, DateTime toX, string scope)
    {
        var rows = await _db.OldGoldTransactions.AsNoTracking().Where(o => br.Contains(o.BranchId) && o.DocDateUtc >= fromD && o.DocDateUtc < toX && o.Status != DocStatus.Cancelled).OrderBy(o => o.DocDateUtc).ToListAsync(); var cn = await Names(rows.Select(r => r.CustomerId), PartyType.Customer); var pur = await _db.Purities.AsNoTracking().ToDictionaryAsync(p => p.Id, p => p.Label);
        var t = T("old-gold", br, scope, C("d", "Date", "date"), C("no", "Number"), C("c", "Customer"), C("p", "Purity"), C("g", "Gross", "weight"), C("n", "Net", "weight"), C("f", "Fine", "weight"), C("r", "Rate", "money"), C("v", "Value", "money"), C("dd", "Deduction %", "number"), C("po", "Paid out", "money"), C("s", "Status"));
        foreach (var r in rows) t.Rows.Add(new object?[] { r.DocDateUtc, r.Number, r.CustomerId != null ? cn.GetValueOrDefault(r.CustomerId.Value) : "Walk-in", pur.GetValueOrDefault(r.PurityId), r.GrossWeight, r.NetWeight, r.FineWeight, r.AcceptedRate, r.Value, r.DeductionPercent, r.PaidOutAmount, r.Status });
        t.Totals["value"] = rows.Sum(r => r.Value); t.Totals["fine g"] = rows.Sum(r => r.FineWeight); return t;
    }

    // ---------------- purchases ----------------
    async Task<ReportTable> PurchaseRegister(ReportFilter f, long[] br, DateTime fromD, DateTime toX, string scope)
    {
        var q = _db.PurchaseInvoices.AsNoTracking().Where(s => br.Contains(s.BranchId) && SaleOk.Contains(s.Status) && s.DocDateUtc >= fromD && s.DocDateUtc < toX); if (f.PartyId != null) q = q.Where(s => s.SupplierId == f.PartyId);
        var rows = await q.OrderBy(s => s.DocDateUtc).ToListAsync(); var sn = await Names(rows.Select(r => (long?)r.SupplierId), PartyType.Supplier);
        var t = T("purchase-register", br, scope, C("d", "Date", "date"), C("no", "Number"), C("si", "Supplier invoice"), C("s", "Supplier"), C("tot", "Total", "money"), C("p", "Paid", "money"), C("due", "Due", "money"), C("rc", "Received"), C("st", "Status"));
        foreach (var r in rows) t.Rows.Add(new object?[] { r.DocDateUtc, r.Number, r.SupplierInvoiceNo, sn.GetValueOrDefault(r.SupplierId), r.Total, r.PaidTotal, r.DueTotal, r.Received, r.Status });
        t.Totals["total"] = rows.Sum(r => r.Total); t.Totals["due"] = rows.Sum(r => r.DueTotal); return t;
    }

    async Task<ReportTable> PurchaseVariance(long[] br, DateTime fromD, DateTime toX, string scope)
    {
        var rows = await (from l in _db.PurchaseInvoiceLines.AsNoTracking() join p in _db.PurchaseInvoices.AsNoTracking() on l.PurchaseInvoiceId equals p.Id where br.Contains(p.BranchId) && p.DocDateUtc >= fromD && p.DocDateUtc < toX && l.ReceivedNetWeight != null select new { p.Number, p.DocDateUtc, p.SupplierId, l.Description, l.NetWeight, l.ReceivedNetWeight, l.PurityId, l.ReceivedPurityId, l.VarianceReason }).ToListAsync();
        var sn = await Names(rows.Select(r => (long?)r.SupplierId), PartyType.Supplier); var pur = await _db.Purities.AsNoTracking().ToDictionaryAsync(p => p.Id, p => p.Label);
        var t = T("purchase-variance", br, scope, C("d", "Date", "date"), C("no", "Invoice"), C("s", "Supplier"), C("i", "Item"), C("inv", "Invoiced net (g)", "weight"), C("rec", "Received net (g)", "weight"), C("v", "Variance (g)", "weight"), C("p1", "Invoiced purity"), C("p2", "Received purity"), C("r", "Reason"));
        foreach (var r in rows.Where(r => r.NetWeight != r.ReceivedNetWeight || r.PurityId != r.ReceivedPurityId)) t.Rows.Add(new object?[] { r.DocDateUtc, r.Number, sn.GetValueOrDefault(r.SupplierId), r.Description, r.NetWeight, r.ReceivedNetWeight, Money.R3((r.ReceivedNetWeight ?? 0) - r.NetWeight), pur.GetValueOrDefault(r.PurityId), r.ReceivedPurityId != null ? pur.GetValueOrDefault(r.ReceivedPurityId.Value) : null, r.VarianceReason });
        return t;
    }

    async Task<ReportTable> SupplierPaymentsRpt(long[] br, DateTime fromD, DateTime toX, string scope)
    {
        var rows = await _db.SupplierPayments.AsNoTracking().Where(p => br.Contains(p.BranchId) && p.DocDateUtc >= fromD && p.DocDateUtc < toX && p.Status == DocStatus.Posted).OrderBy(p => p.DocDateUtc).ToListAsync(); var sn = await Names(rows.Select(r => (long?)r.SupplierId), PartyType.Supplier);
        var t = T("supplier-payments", br, scope, C("d", "Date", "date"), C("no", "Payment"), C("s", "Supplier"), C("a", "Amount", "money"), C("al", "Allocated", "money"), C("u", "Advance (unapplied)", "money"), C("r", "Reference"));
        foreach (var r in rows) t.Rows.Add(new object?[] { r.DocDateUtc, r.Number, sn.GetValueOrDefault(r.SupplierId), r.Amount, r.AllocatedAmount, r.UnappliedAmount, r.Reference });
        t.Totals["paid"] = rows.Sum(r => r.Amount); t.Totals["advance"] = rows.Sum(r => r.UnappliedAmount); return t;
    }

    async Task<ReportTable> PurchaseRates(long[] br, DateTime fromD, DateTime toX, string scope)
    {
        var rows = await (from l in _db.PurchaseInvoiceLines.AsNoTracking() join p in _db.PurchaseInvoices.AsNoTracking() on l.PurchaseInvoiceId equals p.Id where br.Contains(p.BranchId) && p.DocDateUtc >= fromD && p.DocDateUtc < toX select new { p.DocDateUtc, p.SupplierId, l.PurityId, l.Rate }).ToListAsync();
        var sn = await Names(rows.Select(r => (long?)r.SupplierId), PartyType.Supplier); var pur = await _db.Purities.AsNoTracking().ToDictionaryAsync(p => p.Id, p => p.Label);
        var t = T("purchase-rates", br, scope, C("p", "Purity"), C("s", "Supplier"), C("n", "Purchases", "number"), C("min", "Min rate", "money"), C("avg", "Avg rate", "money"), C("max", "Max rate", "money"), C("last", "Latest rate", "money"));
        foreach (var g in rows.GroupBy(r => new { r.PurityId, r.SupplierId }).OrderBy(g => g.Key.PurityId)) t.Rows.Add(new object?[] { pur.GetValueOrDefault(g.Key.PurityId), sn.GetValueOrDefault(g.Key.SupplierId), g.Count(), g.Min(x => x.Rate), Money.R2(g.Average(x => x.Rate)), g.Max(x => x.Rate), g.OrderByDescending(x => x.DocDateUtc).First().Rate });
        return t;
    }

    // ---------------- inventory ----------------
    async Task<ReportTable> StockCurrent(ReportFilter f, long[] br, string scope, bool valuation)
    {
        var u = _cu.Ctx; var seeCost = u.Has(Perms.ReportsCost);
        var bal = await _db.StockBalances.AsNoTracking().Where(b => br.Contains(b.BranchId) && b.Status != StockStatus.Sold && (b.Quantity != 0 || b.NetWeight != 0)).ToListAsync();
        var pids = bal.Where(b => b.ProductId != null).Select(b => b.ProductId!.Value).Distinct().ToList(); var pr = await _db.Products.AsNoTracking().Where(p => pids.Contains(p.Id)).ToDictionaryAsync(p => p.Id, p => p);
        var bn = await BranchNames(); var ln = await _db.StoreLocations.AsNoTracking().IgnoreQueryFilters().ToDictionaryAsync(l => l.Id, l => l.Name); var pur = await _db.Purities.AsNoTracking().ToDictionaryAsync(p => p.Id, p => p.Label);
        var cols = new List<ReportColumn> { C("b", "Branch"), C("l", "Location"), C("sku", "SKU"), C("n", "Item"), C("p", "Purity"), C("st", "Status"), C("o", "Owner"), C("q", "Qty", "number"), C("g", "Gross (g)", "weight"), C("net", "Net (g)", "weight"), C("f", "Fine (g)", "weight") };
        if (valuation || seeCost) cols.Add(C("c", "Cost value", "money"));
        var t = T(valuation ? "stock-valuation" : "stock-current", br, scope, cols.ToArray());
        foreach (var b in bal.Where(b => (f.PurityId == null || (b.PurityId ?? pr.GetValueOrDefault(b.ProductId ?? 0)?.PurityId) == f.PurityId) && (f.CategoryId == null || pr.GetValueOrDefault(b.ProductId ?? 0)?.CategoryId == f.CategoryId)).OrderBy(b => b.BranchId).ThenBy(b => b.ProductId))
        {
            pr.TryGetValue(b.ProductId ?? 0, out var p); var pu = b.PurityId ?? p?.PurityId;
            var row = new List<object?> { bn.GetValueOrDefault(b.BranchId), ln.GetValueOrDefault(b.LocationId), p?.Sku, p?.Name ?? "Loose metal", pu != null ? pur.GetValueOrDefault(pu.Value) : null, b.Status, b.Ownership, b.Quantity, b.GrossWeight, b.NetWeight, b.FineWeight }; if (valuation || seeCost) row.Add(b.CostValue); t.Rows.Add(row.ToArray());
        }
        t.Totals["net g"] = bal.Sum(b => b.NetWeight); t.Totals["fine g"] = bal.Sum(b => b.FineWeight); if (valuation) t.Totals["cost"] = bal.Sum(b => b.CostValue);
        t.Note = valuation ? "Valuation uses the item-specific cost captured at purchase/production. Confirm the approved costing policy before relying on margins." : "Excludes sold items. In-transit stock is shown once, in the destination branch, so consolidated totals never double count."; return t;
    }

    async Task<ReportTable> StockMetalPurity(long[] br, string scope)
    {
        var bal = await _db.StockBalances.AsNoTracking().Where(b => br.Contains(b.BranchId) && b.Status != StockStatus.Sold && b.Ownership == Ownership.Shop).ToListAsync(); var pr = await _db.Products.AsNoTracking().Select(p => new { p.Id, p.MetalTypeId, p.PurityId }).ToDictionaryAsync(p => p.Id);
        var met = await _db.MetalTypes.AsNoTracking().ToDictionaryAsync(m => m.Id, m => m.Name); var pur = await _db.Purities.AsNoTracking().ToDictionaryAsync(p => p.Id, p => p.Label);
        var t = T("stock-metal-purity", br, scope, C("m", "Metal"), C("p", "Purity"), C("g", "Gross (g)", "weight"), C("s", "Stone (g)", "weight"), C("n", "Net (g)", "weight"), C("f", "Fine equivalent (g)", "weight"));
        foreach (var g in bal.GroupBy(b => new { M = b.MetalTypeId ?? pr.GetValueOrDefault(b.ProductId ?? 0)?.MetalTypeId, P = b.PurityId ?? pr.GetValueOrDefault(b.ProductId ?? 0)?.PurityId }).OrderBy(g => g.Key.M)) t.Rows.Add(new object?[] { g.Key.M != null ? met.GetValueOrDefault(g.Key.M.Value) : "-", g.Key.P != null ? pur.GetValueOrDefault(g.Key.P.Value) : "-", g.Sum(x => x.GrossWeight), g.Sum(x => x.StoneWeight), g.Sum(x => x.NetWeight), g.Sum(x => x.FineWeight) });
        t.Totals["fine g"] = bal.Sum(b => b.FineWeight); return t;
    }

    async Task<ReportTable> StockLedger(ReportFilter f, long[] br, DateTime fromD, DateTime toX, string scope)
    {
        var mv = await _db.StockMovements.AsNoTracking().Where(m => ((m.ToBranchId != null && br.Contains(m.ToBranchId.Value) && m.ToStatus == StockStatus.Available) || (m.FromBranchId != null && br.Contains(m.FromBranchId.Value) && m.FromStatus == StockStatus.Available)) && m.PostedAtUtc < toX).Select(m => new { m.ProductId, m.MetalTypeId, m.PurityId, m.PostedAtUtc, m.Quantity, m.NetWeight, In = m.ToBranchId != null && br.Contains(m.ToBranchId.Value) && m.ToStatus == StockStatus.Available, Out = m.FromBranchId != null && br.Contains(m.FromBranchId.Value) && m.FromStatus == StockStatus.Available }).ToListAsync();
        var pids = mv.Where(m => m.ProductId != null).Select(m => m.ProductId!.Value).Distinct().ToList(); var pr = await _db.Products.AsNoTracking().Where(p => pids.Contains(p.Id)).ToDictionaryAsync(p => p.Id, p => p); var pur = await _db.Purities.AsNoTracking().ToDictionaryAsync(p => p.Id, p => p.Label);
        var t = T("stock-ledger", br, scope, C("sku", "SKU"), C("n", "Item"), C("p", "Purity"), C("oq", "Opening qty", "number"), C("on", "Opening net (g)", "weight"), C("iq", "In qty", "number"), C("in", "In net (g)", "weight"), C("xq", "Out qty", "number"), C("xn", "Out net (g)", "weight"), C("cq", "Closing qty", "number"), C("cn", "Closing net (g)", "weight"));
        foreach (var g in mv.GroupBy(m => new { m.ProductId, m.MetalTypeId, m.PurityId }))
        {
            var pre = g.Where(x => x.PostedAtUtc < fromD); var cur = g.Where(x => x.PostedAtUtc >= fromD);
            decimal oq = pre.Where(x => x.In).Sum(x => x.Quantity) - pre.Where(x => x.Out).Sum(x => x.Quantity), on = pre.Where(x => x.In).Sum(x => x.NetWeight) - pre.Where(x => x.Out).Sum(x => x.NetWeight);
            decimal iq = cur.Where(x => x.In).Sum(x => x.Quantity), xq = cur.Where(x => x.Out).Sum(x => x.Quantity), inn = cur.Where(x => x.In).Sum(x => x.NetWeight), xn = cur.Where(x => x.Out).Sum(x => x.NetWeight);
            pr.TryGetValue(g.Key.ProductId ?? 0, out var p); var pu = g.Key.PurityId ?? p?.PurityId;
            t.Rows.Add(new object?[] { p?.Sku, p?.Name ?? "Loose metal", pu != null ? pur.GetValueOrDefault(pu.Value) : null, oq, on, iq, inn, xq, xn, oq + iq - xq, on + inn - xn });
        }
        t.Note = "Available stock only. Closing = opening + receipts + transfers in - sales/issues/transfers out +/- approved adjustments."; return t;
    }

    async Task<ReportTable> StockStatusRpt(long[] br, string scope)
    {
        var st = new[] { StockStatus.Reserved, StockStatus.InTransit, StockStatus.WithWorker, StockStatus.InInspection, StockStatus.Damaged, StockStatus.Quarantine, StockStatus.Scrapped };
        var bal = await _db.StockBalances.AsNoTracking().Where(b => br.Contains(b.BranchId) && st.Contains(b.Status) && (b.Quantity > 0 || b.NetWeight > 0)).ToListAsync(); var bn = await BranchNames();
        var t = T("stock-status", br, scope, C("b", "Branch"), C("s", "Status"), C("o", "Owner"), C("q", "Qty", "number"), C("n", "Net (g)", "weight"), C("f", "Fine (g)", "weight"));
        foreach (var g in bal.GroupBy(b => new { b.BranchId, b.Status, b.Ownership }).OrderBy(g => g.Key.Status)) t.Rows.Add(new object?[] { bn.GetValueOrDefault(g.Key.BranchId), g.Key.Status, g.Key.Ownership, g.Sum(x => x.Quantity), g.Sum(x => x.NetWeight), g.Sum(x => x.FineWeight) });
        return t;
    }

    async Task<ReportTable> CountVariance(long[] br, DateTime fromD, DateTime toX, string scope)
    {
        var rows = await (from l in _db.StockCountLines.AsNoTracking() join c in _db.StockCounts.AsNoTracking() on l.StockCountId equals c.Id where br.Contains(c.BranchId) && c.DocDateUtc >= fromD && c.DocDateUtc < toX && c.Status == DocStatus.Posted select new { c.Number, c.DocDateUtc, l.ProductId, l.SystemQuantity, l.CountedQuantity, l.SystemNetWeight, l.CountedNetWeight, l.VarianceNote }).ToListAsync();
        var pids = rows.Where(r => r.ProductId != null).Select(r => r.ProductId!.Value).ToList(); var pr = await _db.Products.AsNoTracking().Where(p => pids.Contains(p.Id)).ToDictionaryAsync(p => p.Id, p => p);
        var t = T("count-variance", br, scope, C("d", "Date", "date"), C("c", "Count"), C("sku", "SKU"), C("n", "Item"), C("sq", "System qty", "number"), C("cq", "Counted qty", "number"), C("vq", "Qty variance", "number"), C("sn", "System net", "weight"), C("cn", "Counted net", "weight"), C("vn", "Net variance", "weight"), C("note", "Note"));
        foreach (var r in rows.Where(r => (r.CountedQuantity ?? r.SystemQuantity) != r.SystemQuantity || (r.CountedNetWeight ?? r.SystemNetWeight) != r.SystemNetWeight)) { pr.TryGetValue(r.ProductId ?? 0, out var p); t.Rows.Add(new object?[] { r.DocDateUtc, r.Number, p?.Sku, p?.Name ?? "Loose metal", r.SystemQuantity, r.CountedQuantity, (r.CountedQuantity ?? r.SystemQuantity) - r.SystemQuantity, r.SystemNetWeight, r.CountedNetWeight, (r.CountedNetWeight ?? r.SystemNetWeight) - r.SystemNetWeight, r.VarianceNote }); }
        return t;
    }

    async Task<ReportTable> LowStock(long[] br, string scope)
    {
        var mins = await _db.Products.AsNoTracking().Where(p => p.IsActive && p.IsStockItem && p.MinStock > 0).ToListAsync();
        var avail = await _db.StockBalances.AsNoTracking().Where(b => br.Contains(b.BranchId) && b.Status == StockStatus.Available && b.ProductId != null).GroupBy(b => b.ProductId).Select(g => new { Id = g.Key, Q = g.Sum(x => x.Quantity) }).ToListAsync();
        var t = T("low-stock", br, scope, C("sku", "SKU"), C("n", "Item"), C("min", "Minimum", "number"), C("a", "Available", "number"), C("s", "Shortfall", "number"));
        foreach (var p in mins) { var a = avail.FirstOrDefault(x => x.Id == p.Id)?.Q ?? 0; if (a < p.MinStock) t.Rows.Add(new object?[] { p.Sku, p.Name, p.MinStock, a, p.MinStock - a }); }
        return t;
    }

    async Task<ReportTable> DeadStock(long[] br, string scope)
    {
        var cutoff = DateTime.UtcNow.AddDays(-90);
        var bal = await _db.StockBalances.AsNoTracking().Where(b => br.Contains(b.BranchId) && b.Status == StockStatus.Available && b.ProductId != null && b.Quantity > 0).ToListAsync(); var pids = bal.Select(b => b.ProductId!.Value).Distinct().ToList();
        var lastSale = await _db.StockMovements.AsNoTracking().Where(m => m.RefType == TxnType.Sale && pids.Contains(m.ProductId ?? 0)).GroupBy(m => m.ProductId).Select(g => new { Id = g.Key, At = g.Max(x => x.PostedAtUtc) }).ToDictionaryAsync(x => x.Id!.Value, x => x.At);
        var firstIn = await _db.StockMovements.AsNoTracking().Where(m => pids.Contains(m.ProductId ?? 0) && m.ToStatus == StockStatus.Available).GroupBy(m => m.ProductId).Select(g => new { Id = g.Key, At = g.Min(x => x.PostedAtUtc) }).ToDictionaryAsync(x => x.Id!.Value, x => x.At);
        var pr = await _db.Products.AsNoTracking().Where(p => pids.Contains(p.Id)).ToDictionaryAsync(p => p.Id, p => p);
        var t = T("dead-stock", br, scope, C("sku", "SKU"), C("n", "Item"), C("q", "Qty", "number"), C("net", "Net (g)", "weight"), C("in", "In stock since", "date"), C("ls", "Last sold", "date"));
        foreach (var g in bal.GroupBy(b => b.ProductId!.Value)) { var since = firstIn.GetValueOrDefault(g.Key); var ls = lastSale.TryGetValue(g.Key, out var l) ? (DateTime?)l : null; if ((ls ?? since) < cutoff) t.Rows.Add(new object?[] { pr[g.Key].Sku, pr[g.Key].Name, g.Sum(x => x.Quantity), g.Sum(x => x.NetWeight), since == default ? null : since, ls }); }
        return t;
    }

    async Task<ReportTable> AgingStock(long[] br, string scope)
    {
        var bal = await _db.StockBalances.AsNoTracking().Where(b => br.Contains(b.BranchId) && b.Status == StockStatus.Available && b.ProductId != null && b.Quantity > 0).ToListAsync(); var pids = bal.Select(b => b.ProductId!.Value).Distinct().ToList();
        var firstIn = await _db.StockMovements.AsNoTracking().Where(m => pids.Contains(m.ProductId ?? 0) && m.ToStatus == StockStatus.Available).GroupBy(m => m.ProductId).Select(g => new { Id = g.Key, At = g.Min(x => x.PostedAtUtc) }).ToDictionaryAsync(x => x.Id!.Value, x => x.At);
        var t = T("aging-stock", br, scope, C("b", "Age bucket"), C("q", "Items", "number"), C("n", "Net (g)", "weight"));
        foreach (var g in bal.GroupBy(b => Domain.Calc.Aging.Bucket((int)(DateTime.UtcNow - firstIn.GetValueOrDefault(b.ProductId!.Value, DateTime.UtcNow)).TotalDays)).OrderBy(g => g.Key)) t.Rows.Add(new object?[] { g.Key + " days", g.Sum(x => x.Quantity), g.Sum(x => x.NetWeight) });
        return t;
    }

    async Task<ReportTable> HighValue(long[] br, string scope, bool seeCost)
    {
        var bal = await _db.StockBalances.AsNoTracking().Where(b => br.Contains(b.BranchId) && b.Status == StockStatus.Available && b.ProductId != null && b.Quantity > 0).ToListAsync(); var pids = bal.Select(b => b.ProductId!.Value).Distinct().ToList();
        var pr = await _db.Products.AsNoTracking().Where(p => pids.Contains(p.Id)).ToDictionaryAsync(p => p.Id, p => p);
        var t = T("high-value-stock", br, scope, C("sku", "SKU"), C("n", "Item"), C("net", "Net (g)", "weight"), C("v", seeCost ? "Cost value" : "Tag price", "money"));
        foreach (var b in bal.OrderByDescending(b => seeCost ? b.CostValue : pr[b.ProductId!.Value].TagPrice * b.Quantity).Take(50)) t.Rows.Add(new object?[] { pr[b.ProductId!.Value].Sku, pr[b.ProductId!.Value].Name, b.NetWeight, seeCost ? b.CostValue : pr[b.ProductId!.Value].TagPrice * b.Quantity });
        return t;
    }

    async Task<ReportTable> SerialHistory(ReportFilter f, long[] br, string scope)
    {
        var t = T("serial-history", br, scope, C("at", "When", "datetime"), C("ref", "Document"), C("type", "Type"), C("from", "From"), C("to", "To"), C("q", "Qty", "number"), C("n", "Net (g)", "weight"), C("k", "Kind"), C("r", "Reason"));
        if (f.ProductId == null && string.IsNullOrWhiteSpace(f.Search)) { t.Note = "Choose an item (product id or SKU in search)."; return t; }
        var pid = f.ProductId ?? (await _db.Products.AsNoTracking().Where(p => p.Sku == f.Search!.Trim().ToUpper()).Select(p => (long?)p.Id).FirstOrDefaultAsync());
        if (pid == null) { t.Note = "SKU not found."; return t; }
        var rows = await _db.StockMovements.AsNoTracking().Where(m => m.ProductId == pid && ((m.FromBranchId != null && br.Contains(m.FromBranchId.Value)) || (m.ToBranchId != null && br.Contains(m.ToBranchId.Value)))).OrderBy(m => m.Id).ToListAsync(); var bn = await BranchNames();
        foreach (var m in rows) t.Rows.Add(new object?[] { m.PostedAtUtc, m.RefNo, m.RefType, m.FromBranchId != null ? $"{bn.GetValueOrDefault(m.FromBranchId.Value)} / {m.FromStatus}" : "-", m.ToBranchId != null ? $"{bn.GetValueOrDefault(m.ToBranchId.Value)} / {m.ToStatus}" : "-", m.Quantity, m.NetWeight, m.Kind, m.Reason });
        t.Note = "Purchase -> transfer -> worker/repair -> sale/return, as posted."; return t;
    }

    // ---------------- karigar & repairs ----------------
    async Task<ReportTable> Jobs(long[] br, string scope, bool overdueOnly)
    {
        var q = _db.JobCards.AsNoTracking().Where(j => br.Contains(j.BranchId)); var now = DateTime.UtcNow;
        if (overdueOnly) q = q.Where(j => j.DueDateUtc < now && j.JobStatus != JobStatus.Closed && j.JobStatus != JobStatus.Cancelled && j.JobStatus != JobStatus.Reconciled);
        var rows = await q.OrderBy(j => j.DueDateUtc).ToListAsync(); var wn = await Names(rows.Select(r => (long?)r.WorkerId), PartyType.Worker);
        var t = T(overdueOnly ? "overdue-jobs" : "jobs-by-stage", br, scope, C("no", "Job"), C("w", "Worker"), C("st", "Stage"), C("m", "Mode"), C("due", "Due", "date"), C("is", "Issued fine (g)", "weight"), C("o", "Output fine (g)", "weight"), C("v", "Variance (g)", "weight"));
        foreach (var r in rows) t.Rows.Add(new object?[] { r.Number, wn.GetValueOrDefault(r.WorkerId), r.JobStatus, r.StockPostingMode, r.DueDateUtc, r.IssuedFine, r.ReceivedOutputFine, r.VarianceFine }); return t;
    }

    async Task<ReportTable> WorkerCustody(long[] br, string scope)
    {
        var bal = await _db.StockBalances.AsNoTracking().Where(b => br.Contains(b.BranchId) && b.Status == StockStatus.WithWorker && b.NetWeight > 0).ToListAsync(); var jobs = await _db.JobCards.AsNoTracking().Where(j => bal.Select(b => b.CustodyRefId).Contains(j.Id)).ToDictionaryAsync(j => j.Id, j => j);
        var wn = await Names(jobs.Values.Select(j => (long?)j.WorkerId), PartyType.Worker); var pur = await _db.Purities.AsNoTracking().ToDictionaryAsync(p => p.Id, p => p.Label);
        var t = T("worker-custody", br, scope, C("w", "Worker"), C("j", "Job"), C("p", "Purity"), C("g", "Gross (g)", "weight"), C("n", "Net (g)", "weight"), C("f", "Fine (g)", "weight"), C("c", "Cost value", "money"));
        foreach (var b in bal.OrderBy(b => b.CustodyRefId)) { jobs.TryGetValue(b.CustodyRefId, out var j); t.Rows.Add(new object?[] { j != null ? wn.GetValueOrDefault(j.WorkerId) : "?", j?.Number, b.PurityId != null ? pur.GetValueOrDefault(b.PurityId.Value) : null, b.GrossWeight, b.NetWeight, b.FineWeight, _cu.Ctx.Has(Perms.ReportsCost) ? b.CostValue : null }); }
        t.Totals["fine g"] = bal.Sum(b => b.FineWeight); return t;
    }

    async Task<ReportTable> WeightRecon(long[] br, DateTime fromD, DateTime toX, string scope)
    {
        var rows = await _db.JobCards.AsNoTracking().Where(j => br.Contains(j.BranchId) && j.DocDateUtc >= fromD && j.DocDateUtc < toX && j.JobStatus != JobStatus.Cancelled).OrderBy(j => j.Id).ToListAsync(); var wn = await Names(rows.Select(r => (long?)r.WorkerId), PartyType.Worker);
        var t = T("weight-reconciliation", br, scope, C("no", "Job"), C("w", "Worker"), C("st", "Stage"), C("is", "Issued", "weight"), C("ad", "Additional", "weight"), C("o", "Output", "weight"), C("r", "Returned", "weight"), C("sc", "Scrap", "weight"), C("l", "Approved loss", "weight"), C("v", "Variance", "weight"), C("tol", "Tolerance", "weight"));
        foreach (var r in rows) t.Rows.Add(new object?[] { r.Number, wn.GetValueOrDefault(r.WorkerId), r.JobStatus, r.IssuedFine, r.AdditionalInputFine, r.ReceivedOutputFine, r.ReturnedFine, r.ScrapFine, r.ApprovedLossFine, r.VarianceFine, r.ToleranceFineGrams });
        t.Note = "All weights are fine (purity-adjusted) grams."; return t;
    }

    async Task<ReportTable> WorkerPayable(string scope)
    {
        var ws = await _db.Workers.AsNoTracking().Where(w => w.IsActive).ToListAsync(); var led = await _db.PartyLedger.AsNoTracking().Where(p => p.PartyType == PartyType.Worker).GroupBy(p => p.PartyId).Select(g => new { Id = g.Key, Dr = g.Sum(x => x.Debit), Cr = g.Sum(x => x.Credit) }).ToListAsync();
        var t = new ReportTable { Title = "Worker payable", Scope = scope, GeneratedBy = _cu.Ctx.UserName, Columns = new() { C("w", "Worker"), C("o", "Opening", "money"), C("c", "Charges accrued", "money"), C("p", "Paid", "money"), C("b", "Payable", "money") } };
        foreach (var w in ws) { var l = led.FirstOrDefault(x => x.Id == w.Id); t.Rows.Add(new object?[] { w.Name, w.OpeningBalance, l?.Cr ?? 0, l?.Dr ?? 0, w.OpeningBalance + (l?.Cr ?? 0) - (l?.Dr ?? 0) }); }
        t.Totals["payable"] = t.Rows.Sum(r => (decimal)r[4]!); return t;
    }

    async Task<ReportTable> Repairs(long[] br, string scope, string key, bool overdueOnly)
    {
        var now = DateTime.UtcNow; var q = _db.RepairTickets.AsNoTracking().Where(r => br.Contains(r.BranchId));
        if (overdueOnly) q = q.Where(r => r.PromisedDateUtc < now && r.RepairStatus != RepairStatus.Delivered && r.RepairStatus != RepairStatus.Cancelled && r.RepairStatus != RepairStatus.Rejected && r.RepairStatus != RepairStatus.Unrepairable);
        if (key == "repair-balances") q = q.Where(r => r.BalanceAmount != 0);
        var rows = await q.OrderByDescending(r => r.Id).Take(ExportCap).ToListAsync(); var cn = await Names(rows.Select(r => (long?)r.CustomerId), PartyType.Customer); var en = await Names(rows.Select(r => r.TechnicianId), PartyType.Employee);
        var t = T(key, br, scope, C("no", "Ticket"), C("d", "Received", "date"), C("c", "Customer"), C("i", "Item"), C("g", "Gross (g)", "weight"), C("st", "Status"), C("tech", "Technician"), C("pd", "Promised", "date"), C("e", "Estimate", "money"), C("a", "Actual", "money"), C("adv", "Advance", "money"), C("b", "Balance", "money"));
        foreach (var r in rows) t.Rows.Add(new object?[] { r.Number, r.ReceivedDateUtc, cn.GetValueOrDefault(r.CustomerId), r.ItemDescription, r.GrossWeight, r.RepairStatus, r.TechnicianId != null ? en.GetValueOrDefault(r.TechnicianId.Value) : null, r.PromisedDateUtc, r.EstimateAmount, r.ActualCharges, r.AdvanceAmount, r.BalanceAmount });
        if (key == "repair-register") t.Note = "Items shown are customer-owned property and are never part of saleable stock.";
        t.Totals["balance"] = rows.Sum(r => r.BalanceAmount); return t;
    }

    async Task<ReportTable> RepairParts(long[] br, string scope)
    {
        var rows = await (from p in _db.RepairPartUsages.AsNoTracking() join r in _db.RepairTickets.AsNoTracking() on p.RepairTicketId equals r.Id where br.Contains(r.BranchId) select new { r.Number, p.Description, p.Quantity, p.MetalAddedNet, p.MetalRemovedNet, p.Charge, p.CostValue }).ToListAsync(); var seeCost = _cu.Ctx.Has(Perms.ReportsCost);
        var cols = new List<ReportColumn> { C("t", "Ticket"), C("d", "Part / metal"), C("q", "Qty", "number"), C("a", "Metal added (g)", "weight"), C("r", "Metal removed (g)", "weight"), C("c", "Charge", "money") }; if (seeCost) cols.Add(C("cost", "Cost", "money"));
        var t = T("repair-consumption", br, scope, cols.ToArray());
        foreach (var r in rows) { var row = new List<object?> { r.Number, r.Description, r.Quantity, r.MetalAddedNet, r.MetalRemovedNet, r.Charge }; if (seeCost) row.Add(r.CostValue); t.Rows.Add(row.ToArray()); }
        return t;
    }

    async Task<ReportTable> RepairPhotos(long[] br, string scope)
    {
        var rows = await _db.RepairTickets.AsNoTracking().Where(r => br.Contains(r.BranchId)).OrderByDescending(r => r.Id).Take(2000).ToListAsync(); var ids = rows.Select(r => r.Id).ToList();
        var files = await _db.Files.AsNoTracking().Where(f => f.OwnerType == FileOwnerType.RepairTicket && ids.Contains(f.OwnerId) && !f.IsArchived).Select(f => new { f.OwnerId, f.Kind }).ToListAsync();
        var t = T("repair-photo-audit", br, scope, C("no", "Ticket"), C("st", "Status"), C("i", "Intake photos", "number"), C("b", "Before", "number"), C("a", "After", "number"), C("ok", "Complete"));
        foreach (var r in rows) { var f = files.Where(x => x.OwnerId == r.Id).ToList(); var i = f.Count(x => x.Kind == FileKind.Intake); var a = f.Count(x => x.Kind == FileKind.After); t.Rows.Add(new object?[] { r.Number, r.RepairStatus, i, f.Count(x => x.Kind == FileKind.Before), a, i > 0 && (a > 0 || r.RepairStatus < RepairStatus.Ready) }); }
        return t;
    }

    // ---------------- finance ----------------
    async Task<ReportTable> ExpenseRegister(long[] br, DateTime fromD, DateTime toX, string scope)
    {
        var rows = await _db.ExpenseVouchers.AsNoTracking().Where(e => br.Contains(e.BranchId) && e.DocDateUtc >= fromD && e.DocDateUtc < toX).OrderBy(e => e.DocDateUtc).ToListAsync(); var heads = await _db.ExpenseHeads.AsNoTracking().ToDictionaryAsync(h => h.Id, h => h.Name); var bn = await BranchNames();
        var uids = rows.Select(r => r.EnteredBy).Distinct().ToList(); var un = await _db.Users.AsNoTracking().Where(x => uids.Contains(x.Id)).ToDictionaryAsync(x => x.Id, x => x.UserName);
        var t = T("expense-register", br, scope, C("d", "Date", "date"), C("no", "Voucher"), C("b", "Branch"), C("h", "Head"), C("p", "Payee"), C("ds", "Description"), C("a", "Amount", "money"), C("u", "Entered by"), C("s", "Status"));
        foreach (var r in rows) t.Rows.Add(new object?[] { r.DocDateUtc, r.Number, bn.GetValueOrDefault(r.BranchId), heads.GetValueOrDefault(r.ExpenseHeadId), r.Payee, r.Description, r.Amount, un.GetValueOrDefault(r.EnteredBy), r.Status });
        t.Totals["posted"] = rows.Where(r => r.Status == DocStatus.Posted).Sum(r => r.Amount); return t;
    }

    async Task<ReportTable> CashBook(ReportFilter f, long[] br, DateTime fromD, DateTime toX, string scope)
    {
        var t = T("cash-book", br, scope, C("d", "Date", "date"), C("no", "Document"), C("ds", "Description"), C("dr", "Receipts (Dr)", "money"), C("cr", "Payments (Cr)", "money"), C("b", "Balance", "money"));
        if (f.AccountId == null) { t.Note = "Select a cash or bank account."; return t; }
        var acc = await _db.CashBankAccounts.AsNoTracking().FirstOrDefaultAsync(a => a.Id == f.AccountId) ?? throw new NotFoundException("Account"); var ledger = await _post.LedgerAccountFor(acc.Id);
        var all = await (from l in _db.JournalLines.AsNoTracking() join e in _db.JournalEntries.AsNoTracking() on l.JournalEntryId equals e.Id where l.AccountId == ledger && br.Contains(e.BranchId) && e.EntryDateUtc < toX orderby e.EntryDateUtc, e.Id select new { e.EntryDateUtc, e.DocNo, e.Description, l.Debit, l.Credit }).ToListAsync();
        var bal = acc.OpeningBalance * 0 + all.Where(x => x.EntryDateUtc < fromD).Sum(x => x.Debit - x.Credit); t.Rows.Add(new object?[] { fromD, "", "Opening balance", null, null, bal });
        foreach (var x in all.Where(x => x.EntryDateUtc >= fromD)) { bal += x.Debit - x.Credit; t.Rows.Add(new object?[] { x.EntryDateUtc, x.DocNo, x.Description, x.Debit, x.Credit, bal }); }
        t.Totals["closing"] = bal; t.Note = acc.Name + (acc.Type == CashBankType.Bank ? " (bank book)" : " (cash book)"); return t;
    }

    async Task<ReportTable> ReceiptsPayments(long[] br, DateTime fromD, DateTime toX, string scope)
    {
        var rows = await _db.CashBankVouchers.AsNoTracking().Where(v => br.Contains(v.BranchId) && v.DocDateUtc >= fromD && v.DocDateUtc < toX).OrderBy(v => v.DocDateUtc).ToListAsync(); var acc = await _db.CashBankAccounts.AsNoTracking().ToDictionaryAsync(a => a.Id, a => a.Name);
        var t = T("receipts-payments", br, scope, C("d", "Date", "date"), C("no", "Voucher"), C("t", "Type"), C("a", "Account"), C("ds", "Description"), C("amt", "Amount", "money"), C("s", "Status"));
        foreach (var r in rows) t.Rows.Add(new object?[] { r.DocDateUtc, r.Number, r.VoucherType, acc.GetValueOrDefault(r.AccountId), r.Description, r.Amount, r.Status });
        t.Totals["receipts"] = rows.Where(r => r.VoucherType == VoucherType.Receipt && r.Status == DocStatus.Posted).Sum(r => r.Amount); t.Totals["payments"] = rows.Where(r => r.VoucherType == VoucherType.Payment && r.Status == DocStatus.Posted).Sum(r => r.Amount); return t;
    }

    async Task<ReportTable> PartyBalances(ReportFilter f, string scope)
    {
        var by = (f.By ?? "customer").ToLowerInvariant(); var type = by == "supplier" ? PartyType.Supplier : by == "worker" ? PartyType.Worker : PartyType.Customer;
        var u = _cu.Ctx; u.Require(type == PartyType.Customer ? Perms.CustomersLedger : type == PartyType.Supplier ? Perms.SuppliersLedger : Perms.WorkersView);
        var led = await _db.PartyLedger.AsNoTracking().Where(p => p.PartyType == type).GroupBy(p => p.PartyId).Select(g => new { Id = g.Key, Dr = g.Sum(x => x.Debit), Cr = g.Sum(x => x.Credit) }).ToListAsync();
        var met = await _db.MetalLedger.AsNoTracking().Where(p => p.PartyType == type).GroupBy(p => p.PartyId).Select(g => new { Id = g.Key, Fine = g.Sum(x => x.FineOut - x.FineIn) }).ToListAsync();
        var list = type switch { PartyType.Customer => (await _db.Customers.AsNoTracking().ToListAsync()).Select(c => (c.Id, c.Name, c.OpeningBalance, c.OpeningMetalFine)).ToList(), PartyType.Supplier => (await _db.Suppliers.AsNoTracking().ToListAsync()).Select(c => (c.Id, c.Name, c.OpeningBalance, c.OpeningMetalFine)).ToList(), _ => (await _db.Workers.AsNoTracking().ToListAsync()).Select(c => (c.Id, c.Name, c.OpeningBalance, c.OpeningMetalFine)).ToList() };
        var t = new ReportTable { Title = "Party balances - " + type, Scope = scope, GeneratedBy = u.UserName, Columns = new() { C("n", "Name"), C("o", "Opening (PKR)", "money"), C("d", "Debit", "money"), C("c", "Credit", "money"), C("b", "Balance (PKR)", "money"), C("m", "Metal balance (fine g)", "weight") } };
        foreach (var p in list)
        {
            var l = led.FirstOrDefault(x => x.Id == p.Id); var dr = l?.Dr ?? 0; var cr = l?.Cr ?? 0; var bal = type == PartyType.Customer ? p.OpeningBalance + dr - cr : p.OpeningBalance + cr - dr; var m = p.OpeningMetalFine + (met.FirstOrDefault(x => x.Id == p.Id)?.Fine ?? 0);
            if (bal != 0 || m != 0) t.Rows.Add(new object?[] { p.Name, p.OpeningBalance, dr, cr, bal, m });
        }
        t.Totals["balance"] = t.Rows.Sum(r => (decimal)r[4]!); t.Note = "PKR and metal balances are independent. " + (type == PartyType.Customer ? "Positive = customer owes the shop." : "Positive = shop owes the party."); return t;
    }

    async Task<Dictionary<long, (decimal dr, decimal cr)>> JournalSums(long[] br, DateTime? fromD, DateTime toX)
    {
        var q = from l in _db.JournalLines.AsNoTracking() join e in _db.JournalEntries.AsNoTracking() on l.JournalEntryId equals e.Id where br.Contains(e.BranchId) && e.EntryDateUtc < toX && (fromD == null || e.EntryDateUtc >= fromD) select new { l.AccountId, l.Debit, l.Credit };
        return (await q.ToListAsync()).GroupBy(x => x.AccountId).ToDictionary(g => g.Key, g => (g.Sum(x => x.Debit), g.Sum(x => x.Credit)));
    }

    async Task<ReportTable> TrialBalance(long[] br, DateTime toX, string scope)
    {
        var sums = await JournalSums(br, null, toX); var acc = await _db.ChartAccounts.AsNoTracking().OrderBy(a => a.Code).ToListAsync();
        var t = T("trial-balance", br, scope, C("c", "Code"), C("n", "Account"), C("t", "Type"), C("dr", "Debit", "money"), C("cr", "Credit", "money"));
        decimal D = 0, Cr = 0;
        foreach (var a in acc) { if (!sums.TryGetValue(a.Id, out var s)) continue; var net = s.dr - s.cr; var d = net > 0 ? net : 0; var c = net < 0 ? -net : 0; if (d == 0 && c == 0) continue; D += d; Cr += c; t.Rows.Add(new object?[] { a.Code, a.Name, a.Type, d, c }); }
        t.Totals["debit"] = D; t.Totals["credit"] = Cr; t.Note = Money.Balanced(D, Cr) ? "Balanced." : "NOT BALANCED - investigate before relying on any financial report."; return t;
    }

    async Task<ReportTable> ProfitLoss(long[] br, DateTime fromD, DateTime toX, string scope)
    {
        var sums = await JournalSums(br, fromD, toX); var acc = await _db.ChartAccounts.AsNoTracking().Where(a => a.Type == AccountType.Revenue || a.Type == AccountType.Expense).OrderBy(a => a.Code).ToListAsync();
        var t = T("profit-loss", br, scope, C("c", "Code"), C("n", "Account"), C("s", "Section"), C("a", "Amount", "money")); decimal rev = 0, exp = 0;
        foreach (var a in acc) { if (!sums.TryGetValue(a.Id, out var s)) continue; var amt = a.Type == AccountType.Revenue ? s.cr - s.dr : s.dr - s.cr; if (amt == 0) continue; if (a.Type == AccountType.Revenue) rev += amt; else exp += amt; t.Rows.Add(new object?[] { a.Code, a.Name, a.Type == AccountType.Revenue ? "Revenue" : "Expense", amt }); }
        t.Totals["revenue"] = rev; t.Totals["expenses"] = exp; t.Totals["net profit"] = rev - exp; t.Note = "Cost of sales uses the posted item-specific cost. Not a statutory statement until the accounting policy is approved."; return t;
    }

    async Task<ReportTable> BalanceSheet(long[] br, DateTime toX, string scope)
    {
        var sums = await JournalSums(br, null, toX); var acc = await _db.ChartAccounts.AsNoTracking().OrderBy(a => a.Code).ToListAsync();
        var t = T("balance-sheet", br, scope, C("c", "Code"), C("n", "Account"), C("s", "Section"), C("a", "Amount", "money")); decimal A = 0, L = 0, E = 0, earn = 0;
        foreach (var a in acc)
        {
            if (!sums.TryGetValue(a.Id, out var s)) continue; var net = s.dr - s.cr;
            switch (a.Type) { case AccountType.Asset: A += net; if (net != 0) t.Rows.Add(new object?[] { a.Code, a.Name, "Assets", net }); break; case AccountType.Liability: L += -net; if (net != 0) t.Rows.Add(new object?[] { a.Code, a.Name, "Liabilities", -net }); break; case AccountType.Equity: E += -net; if (net != 0) t.Rows.Add(new object?[] { a.Code, a.Name, "Equity", -net }); break; default: earn += -net; break; }
        }
        t.Rows.Add(new object?[] { "", "Current earnings (revenue - expenses)", "Equity", earn }); E += earn;
        t.Totals["assets"] = A; t.Totals["liabilities"] = L; t.Totals["equity"] = E; t.Note = Money.Balanced(A, L + E) ? "Assets = Liabilities + Equity." : "OUT OF BALANCE by " + Money.R2(A - L - E); return t;
    }

    async Task<ReportTable> CashFlow(long[] br, DateTime fromD, DateTime toX, string scope)
    {
        var cash = await _db.CashBankAccounts.AsNoTracking().Where(a => a.ChartAccountId != null).Select(a => a.ChartAccountId!.Value).ToListAsync();
        var rows = await (from l in _db.JournalLines.AsNoTracking() join e in _db.JournalEntries.AsNoTracking() on l.JournalEntryId equals e.Id where cash.Contains(l.AccountId) && br.Contains(e.BranchId) && e.EntryDateUtc >= fromD && e.EntryDateUtc < toX select new { e.DocType, l.Debit, l.Credit }).ToListAsync();
        var t = T("cash-flow", br, scope, C("t", "Source"), C("i", "Cash in", "money"), C("o", "Cash out", "money"), C("n", "Net", "money"));
        foreach (var g in rows.GroupBy(r => r.DocType).OrderBy(g => g.Key)) t.Rows.Add(new object?[] { g.Key, g.Sum(x => x.Debit), g.Sum(x => x.Credit), g.Sum(x => x.Debit - x.Credit) });
        t.Totals["net"] = rows.Sum(r => r.Debit - r.Credit); t.Note = "Inter-account transfers appear on both sides and net to zero."; return t;
    }

    async Task<ReportTable> GrossProfit(long[] br, DateTime fromD, DateTime toX, string scope)
    {
        var rows = await (from l in _db.SalesInvoiceLines.AsNoTracking() join s in Sales(br, fromD, toX) on l.SalesInvoiceId equals s.Id select new { s.Number, s.DocDateUtc, l.Sku, l.Description, l.LineTotalUnrounded, l.TaxAmount, l.CostSnapshot }).ToListAsync();
        var t = T("gross-profit", br, scope, C("d", "Date", "date"), C("no", "Invoice"), C("sku", "SKU"), C("n", "Item"), C("r", "Revenue (ex tax)", "money"), C("c", "Cost", "money"), C("p", "Gross profit", "money"));
        foreach (var r in rows) { var rev = r.LineTotalUnrounded - r.TaxAmount; t.Rows.Add(new object?[] { r.DocDateUtc, r.Number, r.Sku, r.Description, rev, r.CostSnapshot, rev - r.CostSnapshot }); }
        t.Totals["revenue"] = rows.Sum(r => r.LineTotalUnrounded - r.TaxAmount); t.Totals["cost"] = rows.Sum(r => r.CostSnapshot); t.Totals["profit"] = t.Totals["revenue"] - t.Totals["cost"];
        t.Note = "Realised margin on posted sales using item-specific cost. Valid only under the approved costing policy; never derive profit from cash in minus cash out."; return t;
    }

    async Task<ReportTable> CommissionRpt(long[] br, DateTime fromD, DateTime toX, string scope)
    {
        var rows = await _db.CommissionEntries.AsNoTracking().Where(c => br.Contains(c.BranchId) && c.EntryDateUtc >= fromD && c.EntryDateUtc < toX).ToListAsync(); var sn = await Names(rows.Select(r => (long?)r.SalesmanId), PartyType.Employee);
        var t = T("commission", br, scope, C("s", "Salesman"), C("e", "Eligible sales", "money"), C("c", "Calculated", "money"), C("a", "Approved", "money"), C("p", "Paid", "money"), C("u", "Unpaid", "money"));
        foreach (var g in rows.GroupBy(r => r.SalesmanId)) { var a = g.Where(x => x.IsApproved).Sum(x => x.ApprovedAmount); t.Rows.Add(new object?[] { sn.GetValueOrDefault(g.Key), g.Sum(x => x.EligibleAmount), g.Sum(x => x.CalculatedAmount), a, g.Sum(x => x.PaidAmount), a - g.Sum(x => x.PaidAmount) }); }
        t.Note = "Returns are deducted (negative entries)."; return t;
    }

    async Task<ReportTable> TaxSummary(long[] br, DateTime fromD, DateTime toX, string scope)
    {
        var s = await Sales(br, fromD, toX).SumAsync(x => (decimal?)x.TaxTotal) ?? 0; var p = await _db.PurchaseInvoices.AsNoTracking().Where(x => br.Contains(x.BranchId) && SaleOk.Contains(x.Status) && x.DocDateUtc >= fromD && x.DocDateUtc < toX).SumAsync(x => (decimal?)x.TaxTotal) ?? 0;
        var t = T("tax-summary", br, scope, C("k", "Item"), C("a", "Amount", "money")); t.Rows.Add(new object?[] { "Tax collected on sales", s }); t.Rows.Add(new object?[] { "Tax paid on purchases", p }); t.Rows.Add(new object?[] { "Net", s - p });
        t.Note = "Tax rules are configurable and have NOT been validated by the system. Confirm with the business's accountant/tax adviser before filing."; return t;
    }

    async Task<ReportTable> Reversals(long[] br, DateTime fromD, DateTime toX, string scope)
    {
        var rows = await _db.TransactionRegister.AsNoTracking().Where(r => br.Contains(r.BranchId) && r.PostedAtUtc >= fromD && r.PostedAtUtc < toX && (r.Status == DocStatus.Reversed || r.IsReversal)).OrderBy(r => r.PostedAtUtc).Take(ExportCap).ToListAsync();
        var t = T("audit-reversals", br, scope, C("at", "When", "datetime"), C("t", "Type"), C("no", "Document"), C("s", "Status"), C("p", "Party"), C("d", "PKR Debit", "money"), C("c", "PKR Credit", "money"), C("u", "Entered by"));
        foreach (var r in rows) t.Rows.Add(new object?[] { r.PostedAtUtc, r.TxnType, r.DocNo, r.Status, r.PartyName, r.PkrDebit, r.PkrCredit, r.EnteredByName }); return t;
    }
}
