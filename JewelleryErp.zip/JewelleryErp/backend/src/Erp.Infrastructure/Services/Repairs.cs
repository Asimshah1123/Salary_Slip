using Erp.Domain;
using Erp.Domain.Calc;
using Erp.Domain.Entities;
using Erp.Infrastructure.Contracts;
using Erp.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;

namespace Erp.Infrastructure.Services;

public sealed class RepairIntakeInput
{
    public long CustomerId { get; set; }
    public long? BranchId { get; set; }
    public string ItemDescription { get; set; } = "";
    public string? Condition { get; set; }
    public string RequestedWork { get; set; } = "";
    public long? MetalTypeId { get; set; }
    public long? PurityId { get; set; }
    public decimal GrossWeight { get; set; }
    public decimal StoneWeight { get; set; }
    public string? StoneDetails { get; set; }
    public string? AccessoriesReceived { get; set; }
    public DateTime? PromisedDateUtc { get; set; }
    public long? TechnicianId { get; set; }
    public decimal EstimateAmount { get; set; }
    public decimal AdvanceAmount { get; set; }
    public long? AdvanceMethodId { get; set; }
    public long? AdvanceAccountId { get; set; }
    public string? AcknowledgementName { get; set; }
    public bool CustomerAcknowledged { get; set; }
    public string? IdempotencyKey { get; set; }
}
public sealed class RepairEstimateInput { public decimal Amount { get; set; } public string? Description { get; set; } }
public sealed class RepairApprovalInput { public bool Approve { get; set; } = true; public string? ApprovedByCustomer { get; set; } public string? Channel { get; set; } public string? Reason { get; set; } }
public sealed class RepairStatusInput { public RepairStatus To { get; set; } public string? WorkPerformed { get; set; } public decimal? FinalGrossWeight { get; set; } public string? WarrantyNote { get; set; } public long? TechnicianId { get; set; } }
public sealed class RepairPartInput { public string Description { get; set; } = ""; public long? MetalTypeId { get; set; } public long? PurityId { get; set; } public decimal Quantity { get; set; } = 1; public decimal MetalAddedNet { get; set; } public decimal MetalRemovedNet { get; set; } public decimal Charge { get; set; } }
public sealed class RepairDeliverInput
{
    public string CollectorName { get; set; } = "";
    public string? CollectorCnic { get; set; }
    public bool CollectorIsCustomer { get; set; } = true;
    public List<PaymentInput> Payments { get; set; } = new();
    public bool AllowCredit { get; set; }
    public bool Override { get; set; }
    public string? OverrideReason { get; set; }
    public string? WarrantyNote { get; set; }
}
public sealed class RepairQuery : PageQuery { public RepairStatus? Status { get; set; } public long? TechnicianId { get; set; } public bool? Overdue { get; set; } public long? CustomerId { get; set; } public long[]? BranchIds { get; set; } }

public sealed record RepairEstimateDto(int Version, decimal Amount, string? Description, ApprovalStatus ApprovalStatus, string? ApprovedByCustomer, string? Channel, DateTime PreparedAtUtc);
public sealed record RepairLogDto(RepairStatus From, RepairStatus To, DateTime AtUtc, string? Work);
public sealed record RepairPartDto(long Id, string Description, decimal Quantity, decimal MetalAddedNet, decimal MetalRemovedNet, decimal Charge, bool Posted);
public sealed record RepairDto(long Id, string Number, long BranchId, long CustomerId, string Customer, string? CustomerPhone, RepairStatus RepairStatus, DateTime ReceivedDateUtc, DateTime? PromisedDateUtc, bool Overdue, long? TechnicianId, string? Technician, long? WorkerId,
    string ItemDescription, string? Condition, string RequestedWork, string? Metal, string? Purity, decimal Gross, decimal Stone, decimal Net, decimal FinalGross, string? StoneDetails, string? Accessories, bool CustomerAcknowledged, string? AcknowledgementName,
    decimal Estimate, decimal Actual, decimal Advance, decimal Paid, decimal Balance, bool ApprovalRequired, bool EstimateApproved, string? WarrantyNote, bool IsCustomerProperty, int IntakePhotos, int AfterPhotos,
    IReadOnlyList<RepairEstimateDto> Estimates, IReadOnlyList<RepairLogDto> Log, IReadOnlyList<RepairPartDto> Parts, IReadOnlyList<long> LinkedJobIds, DateTime? DeliveredAtUtc, string? CollectorName);
public sealed record RepairRow(long Id, string Number, string Customer, string ItemDescription, RepairStatus RepairStatus, DateTime? PromisedDateUtc, bool Overdue, string? Technician, decimal Estimate, decimal Balance);

public sealed class RepairService
{
    readonly ErpDbContext _db; readonly CurrentUser _cu; readonly AuditService _audit; readonly NumberingService _num; readonly PostingEngine _post; readonly SettingsService _settings; readonly AccessGuard _guard;
    public RepairService(ErpDbContext db, CurrentUser cu, AuditService audit, NumberingService num, PostingEngine post, SettingsService settings, AccessGuard guard)
    { _db = db; _cu = cu; _audit = audit; _num = num; _post = post; _settings = settings; _guard = guard; }

    async Task<RepairTicket> Load(long id, bool includeChildren = false)
    {
        var u = _cu.Ctx;
        IQueryable<RepairTicket> q = _db.RepairTickets;
        if (includeChildren) q = q.Include(x => x.Estimates).Include(x => x.WorkLogs).Include(x => x.Parts);
        var t = await _guard.Find(q, id, "Repair ticket");
        // technicians only see tickets assigned to them (SRS 19.1)
        if (!u.Has(Perms.RepairsViewBranch) && !(u.Has(Perms.RepairsViewAssigned) && t.TechnicianId != null && t.TechnicianId == u.EmployeeId)) throw new NotFoundException("Repair ticket");
        return t;
    }

    static bool IsOverdue(RepairTicket t) => t.PromisedDateUtc != null && t.PromisedDateUtc < DateTime.UtcNow && t.RepairStatus is not (RepairStatus.Delivered or RepairStatus.Cancelled or RepairStatus.Rejected or RepairStatus.Unrepairable);

    void Move(RepairTicket t, RepairStatus to, string? work)
    {
        RepairFlow.Require(t.RepairStatus, to, t.ApprovalRequired);
        t.WorkLogs.Add(new RepairWorkLog { FromStatus = t.RepairStatus, ToStatus = to, AtUtc = DateTime.UtcNow, UserId = _cu.Ctx.UserId, WorkPerformed = work });
        t.RepairStatus = to;
    }

    // ---------------- intake ----------------
    public async Task<RepairDto> Intake(RepairIntakeInput i)
    {
        var u = _cu.Ctx; u.Require(Perms.RepairsCreate);
        var branch = await _post.PostingBranch(i.BranchId);
        if (!string.IsNullOrWhiteSpace(i.IdempotencyKey)) { var d = await _db.RepairTickets.AsNoTracking().FirstOrDefaultAsync(x => x.IdempotencyKey == i.IdempotencyKey); if (d != null) return await Get(d.Id); }
        var errs = new Dictionary<string, string[]>();
        if (string.IsNullOrWhiteSpace(i.ItemDescription)) errs["itemDescription"] = new[] { "Describe the item." };
        if (string.IsNullOrWhiteSpace(i.RequestedWork)) errs["requestedWork"] = new[] { "Describe the requested work." };
        if (i.AdvanceAmount < 0 || i.EstimateAmount < 0) errs["advanceAmount"] = new[] { "Amounts cannot be negative." };
        if (i.AdvanceAmount > 0 && i.AdvanceMethodId == null) errs["advanceMethodId"] = new[] { "Choose how the advance was paid." };
        if (errs.Count > 0) throw new ValidationFailedException(errs);
        decimal net = WeightCalc.NetMetal(i.GrossWeight, i.StoneWeight);
        long id = 0;
        await _post.InTransaction(async () =>
        {
            var cust = await _guard.Find(_db.Customers.AsNoTracking(), i.CustomerId, "Customer");
            if (i.TechnicianId != null && !await _db.Employees.AnyAsync(e => e.Id == i.TechnicianId && e.IsActive)) throw new ValidationFailedException("technicianId", "Technician not found.");
            Purity? pur = null; if (i.PurityId != null) { pur = await _db.Purities.AsNoTracking().FirstOrDefaultAsync(p => p.Id == i.PurityId && (i.MetalTypeId == null || p.MetalTypeId == i.MetalTypeId)) ?? throw new ValidationFailedException("purityId", "Purity not found."); }
            var loc = await _post.DefaultLocation(branch, "Vault");
            var t = new RepairTicket
            {
                CompanyId = u.CompanyId, BranchId = branch, Number = await _num.Next("RPR", branch), DocDateUtc = DateTime.UtcNow, CustomerId = cust.Id, RepairStatus = RepairStatus.Received, ReceivedDateUtc = DateTime.UtcNow, PromisedDateUtc = i.PromisedDateUtc, TechnicianId = i.TechnicianId,
                ItemDescription = i.ItemDescription.Trim(), Condition = i.Condition, RequestedWork = i.RequestedWork.Trim(), MetalTypeId = i.MetalTypeId ?? pur?.MetalTypeId, PurityId = i.PurityId, GrossWeight = i.GrossWeight, StoneWeight = i.StoneWeight, NetWeight = net, StoneDetails = i.StoneDetails,
                AccessoriesReceived = i.AccessoriesReceived, AcknowledgementName = i.AcknowledgementName, CustomerAcknowledged = i.CustomerAcknowledged, CustodyLocationId = loc, EstimateAmount = i.EstimateAmount, AdvanceAmount = Money.R2(i.AdvanceAmount), PaidAmount = 0,
                ApprovalRequired = await _settings.Bool(SettingsService.Keys.RepairApproval, branch), IdempotencyKey = i.IdempotencyKey, Status = DocStatus.Posted, PostedBy = u.UserId, PostedAtUtc = DateTime.UtcNow
            };
            t.BalanceAmount = Money.R2(t.EstimateAmount - t.AdvanceAmount);
            t.WorkLogs.Add(new RepairWorkLog { FromStatus = RepairStatus.Received, ToStatus = RepairStatus.Received, AtUtc = DateTime.UtcNow, UserId = u.UserId, WorkPerformed = "Item received" });
            _db.RepairTickets.Add(t); await _db.SaveChangesAsync(); id = t.Id;
            // customer-owned property: tracked as custody, NEVER as saleable shop stock
            await _post.Move(new StockMoveSpec { RefType = TxnType.RepairIntake, RefId = t.Id, RefNo = t.Number, To = new StockLoc(branch, loc, StockStatus.RepairIntake), ToOwnership = Ownership.Customer, ToCustodyRefId = t.Id, MetalTypeId = t.MetalTypeId, PurityId = t.PurityId, Qty = 1, Gross = t.GrossWeight, Stone = t.StoneWeight, Net = net, Fine = pur != null ? WeightCalc.Fine(net, pur.Factor) : 0, Kind = "Receipt", Reason = "Customer repair item" });
            var e = _post.Reg(TxnType.RepairIntake, t, 1, PartyType.Customer, cust.Id, cust.Name); e.ItemName = t.ItemDescription; e.MetalTypeId = t.MetalTypeId; e.PurityId = t.PurityId; e.Gross = t.GrossWeight; e.Stone = t.StoneWeight; e.Net = net; e.PaymentMethod = "Customer property";
            if (t.AdvanceAmount > 0)
            {
                var pm = await _db.PaymentMethods.AsNoTracking().FirstOrDefaultAsync(m => m.Id == i.AdvanceMethodId && m.IsActive) ?? throw new ValidationFailedException("advanceMethodId", "Invalid payment method.");
                _post.Party(PartyType.Customer, cust.Id, branch, t.DocDateUtc, TxnType.RepairPayment, t.Id, t.Number, "Repair advance", 0, t.AdvanceAmount);
                await _post.Journal(new JournalBuilder().DrAcc(await _post.LedgerAccountFor(i.AdvanceAccountId), t.AdvanceAmount, "Repair advance").Cr(Acc.CustomerAdvances, t.AdvanceAmount, "Advance held", PartyType.Customer, cust.Id), TxnType.RepairPayment, t.Id, t.Number, branch, t.DocDateUtc, "Repair advance " + t.Number);
                t.PaidAmount = 0; // advance is tracked separately from later payments
            }
            _audit.Add("Repair.Intake", nameof(RepairTicket), t.Id, after: new { t.Number, cust = cust.Name, t.GrossWeight, t.AdvanceAmount }, targetBranchId: branch);
            return 0;
        });
        return await Get(id);
    }

    // ---------------- estimate & approval ----------------
    public async Task<RepairDto> PrepareEstimate(long id, RepairEstimateInput i)
    {
        _cu.Ctx.RequireAny(Perms.RepairsEstimate, Perms.RepairsUpdateStatus);
        if (i.Amount < 0) throw new ValidationFailedException("amount", "Estimate cannot be negative.");
        var t = await Load(id, true);
        if (t.RepairStatus is RepairStatus.Inspection) Move(t, RepairStatus.EstimatePrepared, "Estimate prepared");
        else if (t.RepairStatus == RepairStatus.AwaitingApproval) Move(t, RepairStatus.EstimatePrepared, "Estimate revised");
        else if (t.RepairStatus != RepairStatus.EstimatePrepared) throw new ConflictException($"An estimate cannot be prepared while the ticket is {t.RepairStatus}.");
        foreach (var e in t.Estimates.Where(x => x.ApprovalStatus == ApprovalStatus.Pending)) e.ApprovalStatus = ApprovalStatus.Rejected;   // superseded
        t.Estimates.Add(new RepairEstimate { Version = t.Estimates.Count + 1, Amount = Money.R2(i.Amount), Description = i.Description, PreparedBy = _cu.Ctx.UserId, PreparedAtUtc = DateTime.UtcNow, ApprovalStatus = ApprovalStatus.Pending });
        t.EstimateAmount = Money.R2(i.Amount); t.EstimateApproved = false; t.BalanceAmount = Money.R2(t.EstimateAmount - t.AdvanceAmount - t.PaidAmount);
        await _audit.Save("Repair.Estimate", nameof(RepairTicket), t.Id, after: new { i.Amount }, targetBranchId: t.BranchId);
        return await Get(id);
    }

    public async Task<RepairDto> SubmitForApproval(long id)
    {
        _cu.Ctx.RequireAny(Perms.RepairsEstimate, Perms.RepairsUpdateStatus);
        var t = await Load(id, true);
        Move(t, RepairStatus.AwaitingApproval, "Sent to customer for approval");
        await _audit.Save("Repair.SubmittedForApproval", nameof(RepairTicket), id, targetBranchId: t.BranchId);
        return await Get(id);
    }

    /// <summary>Customer approval (or rejection) of the estimate before chargeable work (SRS 3.10).</summary>
    public async Task<RepairDto> DecideEstimate(long id, RepairApprovalInput i)
    {
        _cu.Ctx.Require(Perms.RepairsEstimateApprove);
        var t = await Load(id, true);
        var est = t.Estimates.OrderByDescending(e => e.Version).FirstOrDefault() ?? throw new ConflictException("Prepare an estimate first.");
        if (i.Approve)
        {
            if (string.IsNullOrWhiteSpace(i.ApprovedByCustomer)) throw new ValidationFailedException("approvedByCustomer", "Record who approved (customer name) and how.");
            Move(t, RepairStatus.Approved, "Estimate approved"); est.ApprovalStatus = ApprovalStatus.Approved; est.ApprovedByCustomer = i.ApprovedByCustomer; est.ApprovalChannel = i.Channel; est.ApprovedAtUtc = DateTime.UtcNow; t.EstimateApproved = true; t.ActualCharges = est.Amount;
        }
        else
        {
            if (string.IsNullOrWhiteSpace(i.Reason)) throw new ValidationFailedException("reason", "A rejection reason is required.");
            Move(t, RepairStatus.Rejected, "Estimate rejected: " + i.Reason); est.ApprovalStatus = ApprovalStatus.Rejected; t.RejectionReason = i.Reason;
        }
        await _audit.Save(i.Approve ? "Repair.EstimateApproved" : "Repair.EstimateRejected", nameof(RepairTicket), id, after: new { est.Amount, i.ApprovedByCustomer }, reason: i.Reason, targetBranchId: t.BranchId);
        return await Get(id);
    }

    // ---------------- workbench ----------------
    public async Task<RepairDto> UpdateStatus(long id, RepairStatusInput i)
    {
        var u = _cu.Ctx; u.Require(Perms.RepairsUpdateStatus);
        var t = await Load(id, true);
        if (i.To is RepairStatus.Delivered or RepairStatus.Approved or RepairStatus.Rejected or RepairStatus.EstimatePrepared or RepairStatus.AwaitingApproval) throw new ForbiddenException("This transition is made through its dedicated action (estimate, approval or delivery).");
        if (i.TechnicianId != null) { if (!await _db.Employees.AnyAsync(e => e.Id == i.TechnicianId && e.IsActive)) throw new ValidationFailedException("technicianId", "Technician not found."); t.TechnicianId = i.TechnicianId; }
        if (i.To == RepairStatus.Inspection)
        {
            if (!t.CustomerAcknowledged) throw new ConflictException("Capture the customer's acknowledgement of the item's condition and accessories first.", "ack_required");
            var photos = await _db.Files.CountAsync(f => f.OwnerType == FileOwnerType.RepairTicket && f.OwnerId == t.Id && f.Kind == FileKind.Intake && !f.IsArchived);
            if (photos == 0) throw new ConflictException("Upload at least one intake photograph before inspection.", "photos_required");
        }
        if (i.To == RepairStatus.QualityCheck && string.IsNullOrWhiteSpace(i.WorkPerformed)) throw new ValidationFailedException("workPerformed", "Record the work performed.");
        if (i.To == RepairStatus.Ready)
        {
            if (i.FinalGrossWeight == null || i.FinalGrossWeight <= 0) throw new ValidationFailedException("finalGrossWeight", "Record the final weight after repair.");
            t.FinalGrossWeight = i.FinalGrossWeight.Value; t.WarrantyNote = i.WarrantyNote ?? t.WarrantyNote;
            if (t.ActualCharges == 0) t.ActualCharges = t.EstimateAmount;
            t.ReadyNotifiedUtc = DateTime.UtcNow;
            _db.Notifications.Add(new Notification { CompanyId = t.CompanyId, BranchId = t.BranchId, Type = "RepairReady", Severity = "Info", Message = $"Repair {t.Number} is ready - notify the customer.", RefType = nameof(RepairTicket), RefId = t.Id });
        }
        Move(t, i.To, i.WorkPerformed);
        t.BalanceAmount = Money.R2(t.ActualCharges - t.AdvanceAmount - t.PaidAmount);
        await _audit.Save("Repair.Status", nameof(RepairTicket), id, after: new { to = i.To.ToString(), i.WorkPerformed }, targetBranchId: t.BranchId);
        return await Get(id);
    }

    /// <summary>Records parts / metal used. Metal added is consumed from shop loose-metal stock; metal removed is only recorded (it stays customer property).</summary>
    public async Task<RepairDto> AddPart(long id, RepairPartInput i)
    {
        var u = _cu.Ctx; u.Require(Perms.RepairsUpdateStatus);
        if (string.IsNullOrWhiteSpace(i.Description)) throw new ValidationFailedException("description", "Describe the part or metal.");
        if (i.MetalAddedNet < 0 || i.MetalRemovedNet < 0 || i.Charge < 0) throw new ValidationFailedException("charge", "Values cannot be negative.");
        await _post.InTransaction(async () =>
        {
            var t = await Load(id, true);
            if (t.RepairStatus is not (RepairStatus.InRepair or RepairStatus.QualityCheck)) throw new ConflictException("Parts can only be recorded while the ticket is In Repair / Quality Check.");
            var part = new RepairPartUsage { RepairTicketId = t.Id, Description = i.Description, MetalTypeId = i.MetalTypeId, PurityId = i.PurityId, Quantity = i.Quantity, MetalAddedNet = i.MetalAddedNet, MetalRemovedNet = i.MetalRemovedNet, Charge = Money.R2(i.Charge) };
            if (i.MetalAddedNet > 0)
            {
                if (i.MetalTypeId == null || i.PurityId == null) throw new ValidationFailedException("metalTypeId", "Metal and purity are required when metal is added.");
                var pu = await _db.Purities.AsNoTracking().FirstOrDefaultAsync(p => p.Id == i.PurityId && p.MetalTypeId == i.MetalTypeId) ?? throw new ValidationFailedException("purityId", "Purity does not match the metal.");
                var bal = await _db.StockBalances.FirstOrDefaultAsync(b => b.BranchId == t.BranchId && b.ProductId == null && b.MetalTypeId == i.MetalTypeId && b.PurityId == i.PurityId && b.Status == StockStatus.Available && b.Ownership == Ownership.Shop && b.NetWeight >= i.MetalAddedNet)
                          ?? throw new DomainException("Not enough loose metal of that purity in stock to add to this repair.", "negative_stock");
                var cost = bal.NetWeight == 0 ? 0 : Money.R2(bal.CostValue * Math.Min(1m, i.MetalAddedNet / bal.NetWeight));
                part.CostValue = cost; part.Posted = true;
                await _post.Move(new StockMoveSpec { RefType = TxnType.RepairPayment, RefId = t.Id, RefNo = t.Number, From = new StockLoc(t.BranchId, bal.LocationId, StockStatus.Available), MetalTypeId = i.MetalTypeId, PurityId = i.PurityId, Net = i.MetalAddedNet, Gross = i.MetalAddedNet, Fine = WeightCalc.Fine(i.MetalAddedNet, pu.Factor), Cost = cost, Kind = "Issue", Reason = "Metal added to repair " + t.Number });
                if (cost > 0) await _post.Journal(new JournalBuilder().Dr(Acc.Cogs, cost, "Repair material").Cr(Acc.InvRawMetal, cost, "Metal consumed"), TxnType.RepairPayment, t.Id, t.Number, t.BranchId, DateTime.UtcNow, "Repair material " + t.Number);
            }
            t.Parts.Add(part);
            t.ActualCharges = Money.R2(t.ActualCharges + part.Charge); t.BalanceAmount = Money.R2(t.ActualCharges - t.AdvanceAmount - t.PaidAmount);
            _audit.Add("Repair.Part", nameof(RepairTicket), t.Id, after: new { i.Description, i.MetalAddedNet, i.Charge }, targetBranchId: t.BranchId);
            return 0;
        });
        return await Get(id);
    }

    public async Task<RepairDto> LinkJob(long id, long jobCardId)
    {
        _cu.Ctx.RequireAny(Perms.RepairsUpdateStatus, Perms.JobWorkCreate);
        var t = await Load(id); var j = await _guard.Find(_db.JobCards, jobCardId, "Job card");
        if (j.BranchId != t.BranchId) throw new ValidationFailedException("jobCardId", "The job card belongs to a different branch/workshop.");
        j.RepairTicketId = t.Id; t.WorkerId = j.WorkerId;
        await _audit.Save("Repair.JobLinked", nameof(RepairTicket), id, after: new { j.Number }, targetBranchId: t.BranchId);
        return await Get(id);
    }

    // ---------------- delivery ----------------
    public async Task<RepairDto> Deliver(long id, RepairDeliverInput i)
    {
        var u = _cu.Ctx; u.Require(Perms.RepairsDeliver);
        if (string.IsNullOrWhiteSpace(i.CollectorName)) throw new ValidationFailedException("collectorName", "Record who is collecting the item.");
        if (!i.CollectorIsCustomer && string.IsNullOrWhiteSpace(i.CollectorCnic)) throw new ValidationFailedException("collectorCnic", "An authorised collector's ID number is required.");
        await _post.InTransaction(async () =>
        {
            var t = await Load(id, true);
            await _post.PostingBranch(t.BranchId);
            var returnedUnrepaired = t.RepairStatus is RepairStatus.Rejected or RepairStatus.Cancelled or RepairStatus.Unrepairable;
            var overrideUsed = false;
            if (t.RepairStatus != RepairStatus.Ready && !returnedUnrepaired)
            {
                if (!i.Override) throw new ConflictException($"The ticket is {t.RepairStatus}; quality check and ready status are required before delivery.", "not_ready");
                u.Require(Perms.RepairsDeliveryOverride); if (string.IsNullOrWhiteSpace(i.OverrideReason)) throw new ValidationFailedException("overrideReason", "A reason is mandatory for an override.");
                overrideUsed = true;
                if (t.RepairStatus is not (RepairStatus.InRepair or RepairStatus.QualityCheck)) throw new ConflictException("Override is only possible for tickets already in repair / quality check.");
                if (t.RepairStatus == RepairStatus.InRepair) Move(t, RepairStatus.QualityCheck, "Override: QC skipped");
                Move(t, RepairStatus.Ready, "Override: released before normal QC sign-off"); if (t.ActualCharges == 0) t.ActualCharges = t.EstimateAmount;
            }
            var charges = returnedUnrepaired ? 0m : (t.ActualCharges > 0 ? t.ActualCharges : t.EstimateAmount);
            var paidNow = Money.R2(i.Payments.Sum(p => p.Amount));
            if (i.Payments.Any(p => p.Amount <= 0)) throw new ValidationFailedException("payments", "Payment amounts must be positive.");
            var balance = Money.R2(charges - t.AdvanceAmount - t.PaidAmount);
            if (paidNow > Math.Max(0, balance)) throw new ValidationFailedException("payments", "Payment exceeds the outstanding balance.");
            var remaining = Money.R2(Math.Max(0, balance) - paidNow);
            if (remaining > 0)
            {
                if (!i.AllowCredit && !overrideUsed) throw new ConflictException($"Outstanding balance of {remaining:N2} must be collected, or an approved credit override recorded.", "balance_due");
                if (i.AllowCredit) { u.Require(Perms.RepairsDeliveryOverride); if (string.IsNullOrWhiteSpace(i.OverrideReason)) throw new ValidationFailedException("overrideReason", "A reason is mandatory to release on credit."); overrideUsed = true; }
            }
            var cust = await _db.Customers.AsNoTracking().FirstAsync(c => c.Id == t.CustomerId);
            // release the customer's property from custody
            var rows = await _db.StockBalances.Where(b => b.BranchId == t.BranchId && b.Status == StockStatus.RepairIntake && b.CustodyRefId == t.Id && (b.Quantity > 0 || b.NetWeight > 0 || b.GrossWeight > 0)).ToListAsync();
            if (rows.Count == 0) throw new DomainException("The item is not in custody for this ticket.", "custody_missing");
            foreach (var r in rows)
                await _post.Move(new StockMoveSpec { RefType = TxnType.RepairDelivery, RefId = t.Id, RefNo = t.Number, From = new StockLoc(t.BranchId, r.LocationId, StockStatus.RepairIntake), FromOwnership = Ownership.Customer, FromCustodyRefId = t.Id, MetalTypeId = r.MetalTypeId, PurityId = r.PurityId, Qty = r.Quantity, Gross = r.GrossWeight, Stone = r.StoneWeight, Net = r.NetWeight, Fine = r.FineWeight, Kind = "Issue", Reason = "Delivered to " + i.CollectorName });
            t.PaidAmount = Money.R2(t.PaidAmount + paidNow); t.ActualCharges = charges; t.BalanceAmount = remaining;
            t.DeliveredAtUtc = DateTime.UtcNow; t.CollectorName = i.CollectorName; t.CollectorCnic = i.CollectorCnic; t.DeliveryOverride = overrideUsed; t.DeliveryOverrideReason = i.OverrideReason; t.WarrantyNote = i.WarrantyNote ?? t.WarrantyNote;
            Move(t, RepairStatus.Delivered, "Delivered to " + i.CollectorName);
            t.Status = remaining > 0 ? DocStatus.PartiallyPaid : DocStatus.Closed;
            // accounting: advance consumed + payments + credit = repair income
            var j = new JournalBuilder();
            var advUsed = Math.Min(t.AdvanceAmount, charges);
            if (advUsed > 0) j.Dr(Acc.CustomerAdvances, advUsed, "Advance applied", PartyType.Customer, cust.Id);
            foreach (var p in i.Payments) j.DrAcc(await _post.LedgerAccountFor(p.AccountId), p.Amount, "Repair payment");
            if (remaining > 0) j.Dr(Acc.Receivable, remaining, "Repair on credit", PartyType.Customer, cust.Id);
            j.Cr(Acc.RepairIncome, charges, "Repair income");
            var refundAdv = Money.R2(t.AdvanceAmount - advUsed);   // advance larger than charges: stays as customer credit
            if (charges > 0 || j.Lines.Count > 0) { if (refundAdv > 0 && charges == 0) { /* unrepaired return: advance remains a customer credit, no entry */ } else await _post.Journal(j, TxnType.RepairDelivery, t.Id, t.Number, t.BranchId, t.DeliveredAtUtc.Value, "Repair delivery " + t.Number); }
            if (charges > 0) _post.Party(PartyType.Customer, cust.Id, t.BranchId, t.DeliveredAtUtc.Value, TxnType.RepairDelivery, t.Id, t.Number, "Repair charges", charges, 0);
            foreach (var p in i.Payments) _post.Party(PartyType.Customer, cust.Id, t.BranchId, t.DeliveredAtUtc.Value, TxnType.RepairPayment, t.Id, t.Number, "Payment at delivery", 0, p.Amount);
            var e = _post.Reg(TxnType.RepairDelivery, t, 2, PartyType.Customer, cust.Id, cust.Name); e.ItemName = t.ItemDescription; e.Net = t.NetWeight; e.Gross = t.FinalGrossWeight > 0 ? t.FinalGrossWeight : t.GrossWeight; e.PkrCredit = charges; e.PaymentMethod = overrideUsed ? "Override" : null; e.LinkedDocType = "RepairTicket"; e.LinkedDocNo = t.Number; e.LinkedDocId = t.Id;
            _audit.Add("Repair.Delivered", nameof(RepairTicket), t.Id, after: new { t.Number, i.CollectorName, charges, paidNow, remaining }, reason: i.OverrideReason, targetBranchId: t.BranchId);
            return 0;
        });
        return await Get(id);
    }

    // ---------------- queries ----------------
    public async Task<PagedResult<RepairRow>> List(RepairQuery q)
    {
        var u = _cu.Ctx; u.RequireAny(Perms.RepairsViewBranch, Perms.RepairsViewAssigned);
        var s = _db.RepairTickets.AsNoTracking().AsQueryable();
        if (!u.Has(Perms.RepairsViewBranch)) { var eid = u.EmployeeId ?? -1; s = s.Where(t => t.TechnicianId == eid); }
        else { var br = u.ResolveScope(q.BranchIds); s = s.Where(t => br.Contains(t.BranchId)); }
        if (q.Status != null) s = s.Where(t => t.RepairStatus == q.Status);
        if (q.TechnicianId != null) s = s.Where(t => t.TechnicianId == q.TechnicianId);
        if (q.CustomerId != null) s = s.Where(t => t.CustomerId == q.CustomerId);
        var now = DateTime.UtcNow;
        if (q.Overdue == true) s = s.Where(t => t.PromisedDateUtc != null && t.PromisedDateUtc < now && t.RepairStatus != RepairStatus.Delivered && t.RepairStatus != RepairStatus.Cancelled && t.RepairStatus != RepairStatus.Rejected && t.RepairStatus != RepairStatus.Unrepairable);
        if (!string.IsNullOrWhiteSpace(q.Search)) { var x = q.Search.Trim(); s = s.Where(t => t.Number.Contains(x) || t.ItemDescription.Contains(x)); }
        var total = await s.CountAsync();
        var rows = await s.OrderByDescending(t => t.Id).Skip(q.Skip).Take(q.Take).ToListAsync();
        var cids = rows.Select(r => r.CustomerId).Distinct().ToList(); var eids = rows.Where(r => r.TechnicianId != null).Select(r => r.TechnicianId!.Value).Distinct().ToList();
        var cn = await _db.Customers.AsNoTracking().Where(c => cids.Contains(c.Id)).ToDictionaryAsync(c => c.Id, c => c.Name);
        var en = await _db.Employees.AsNoTracking().Where(c => eids.Contains(c.Id)).ToDictionaryAsync(c => c.Id, c => c.Name);
        return new PagedResult<RepairRow>(rows.Select(r => new RepairRow(r.Id, r.Number, cn.GetValueOrDefault(r.CustomerId, ""), r.ItemDescription, r.RepairStatus, r.PromisedDateUtc, IsOverdue(r), r.TechnicianId != null ? en.GetValueOrDefault(r.TechnicianId.Value) : null, r.EstimateAmount, r.BalanceAmount)).ToList(), total, q.Page, q.Take);
    }

    public async Task<RepairDto> Get(long id)
    {
        var u = _cu.Ctx;
        var t = await Load(id, true);
        var c = await _db.Customers.AsNoTracking().FirstAsync(x => x.Id == t.CustomerId);
        var tech = t.TechnicianId != null ? await _db.Employees.AsNoTracking().Where(e => e.Id == t.TechnicianId).Select(e => e.Name).FirstOrDefaultAsync() : null;
        var met = t.MetalTypeId != null ? await _db.MetalTypes.AsNoTracking().Where(m => m.Id == t.MetalTypeId).Select(m => m.Name).FirstOrDefaultAsync() : null;
        var pur = t.PurityId != null ? await _db.Purities.AsNoTracking().Where(m => m.Id == t.PurityId).Select(m => m.Label).FirstOrDefaultAsync() : null;
        var photos = await _db.Files.AsNoTracking().Where(f => f.OwnerType == FileOwnerType.RepairTicket && f.OwnerId == t.Id && !f.IsArchived).Select(f => f.Kind).ToListAsync();
        var jobs = await _db.JobCards.AsNoTracking().Where(j => j.RepairTicketId == t.Id).Select(j => j.Id).ToListAsync();
        var inCustody = t.RepairStatus != RepairStatus.Delivered;
        var seeMoney = u.Has(Perms.RepairsViewBranch);   // technicians never see customer money details
        return new RepairDto(t.Id, t.Number, t.BranchId, t.CustomerId, c.Name, seeMoney ? c.Phone : null, t.RepairStatus, t.ReceivedDateUtc, t.PromisedDateUtc, IsOverdue(t), t.TechnicianId, tech, t.WorkerId, t.ItemDescription, t.Condition, t.RequestedWork, met, pur, t.GrossWeight, t.StoneWeight, t.NetWeight, t.FinalGrossWeight,
            t.StoneDetails, t.AccessoriesReceived, t.CustomerAcknowledged, t.AcknowledgementName, seeMoney ? t.EstimateAmount : 0, seeMoney ? t.ActualCharges : 0, seeMoney ? t.AdvanceAmount : 0, seeMoney ? t.PaidAmount : 0, seeMoney ? t.BalanceAmount : 0, t.ApprovalRequired, t.EstimateApproved, t.WarrantyNote, inCustody,
            photos.Count(k => k == FileKind.Intake), photos.Count(k => k == FileKind.After),
            t.Estimates.OrderBy(e => e.Version).Select(e => new RepairEstimateDto(e.Version, seeMoney ? e.Amount : 0, e.Description, e.ApprovalStatus, e.ApprovedByCustomer, e.ApprovalChannel, e.PreparedAtUtc)).ToList(),
            t.WorkLogs.OrderBy(l => l.AtUtc).Select(l => new RepairLogDto(l.FromStatus, l.ToStatus, l.AtUtc, l.WorkPerformed)).ToList(),
            t.Parts.Select(p => new RepairPartDto(p.Id, p.Description, p.Quantity, p.MetalAddedNet, p.MetalRemovedNet, seeMoney ? p.Charge : 0, p.Posted)).ToList(), jobs, t.DeliveredAtUtc, t.CollectorName);
    }
}
