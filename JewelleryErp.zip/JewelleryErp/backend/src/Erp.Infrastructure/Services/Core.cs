using System.Data;
using System.Text.Json;
using Erp.Domain;
using Erp.Domain.Calc;
using Erp.Domain.Entities;
using Erp.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;

namespace Erp.Infrastructure.Services;

public static class Json
{
    public static readonly JsonSerializerOptions Opts = new(JsonSerializerDefaults.Web) { WriteIndented = false };
    public static string? To(object? o) => o == null ? null : JsonSerializer.Serialize(o, Opts);
}

/// <summary>Typed settings with explicit company-wide default and branch override (SRS 18.1).</summary>
public sealed class SettingsService
{
    public static class Keys
    {
        public const string TaxEnabled = "Tax.Enabled", TaxPercent = "Tax.Percent", Rounding = "Pricing.Rounding", RoundStep = "Pricing.RoundStep",
            Costing = "Costing.Method", BackdateDays = "Posting.BackdateDays", NegativeStock = "Inventory.AllowNegative",
            PurchaseTolGrams = "Purchase.VarianceToleranceGrams", TransferTolGrams = "Transfer.VarianceToleranceGrams", CountTolGrams = "Count.ToleranceGrams",
            OldGoldDeductionPct = "OldGold.DeductionApprovalPercent", OldGoldMethod = "OldGold.ValuationMethod", RepairApproval = "Repair.ApprovalRequired",
            JobToleranceFine = "Job.DefaultToleranceFine", RatePolicy = "Rate.Policy", LogDuplicatePrint = "Print.LogDuplicates", PostCostJournal = "Accounting.PostCostOfSales",
            MaxImageMb = "Images.MaxMegabytes", ReorderAlertDays = "Alerts.RepairDueDays", Language = "UI.Language", ReceiptWidthMm = "Print.ThermalWidthMm",
            CashVarianceTolerance = "Cash.VarianceTolerance", CommissionOnReturn = "Commission.ReverseOnReturn";
    }

    static readonly Dictionary<string, string> Defaults = new()
    {
        [Keys.TaxEnabled] = "false", [Keys.TaxPercent] = "0", [Keys.Rounding] = nameof(RoundingPolicy.PerLine), [Keys.RoundStep] = "1",
        [Keys.Costing] = nameof(CostingMethod.ItemSpecific), [Keys.BackdateDays] = "0", [Keys.NegativeStock] = "false",
        [Keys.PurchaseTolGrams] = "0.050", [Keys.TransferTolGrams] = "0.050", [Keys.CountTolGrams] = "0.050",
        [Keys.OldGoldDeductionPct] = "3", [Keys.OldGoldMethod] = "ByPurityRate", [Keys.RepairApproval] = "true",
        [Keys.JobToleranceFine] = "0.100", [Keys.RatePolicy] = "Company", [Keys.LogDuplicatePrint] = "true", [Keys.PostCostJournal] = "true",
        [Keys.MaxImageMb] = "8", [Keys.ReorderAlertDays] = "2", [Keys.Language] = "en", [Keys.ReceiptWidthMm] = "80", [Keys.CashVarianceTolerance] = "0", [Keys.CommissionOnReturn] = "true",
    };

    readonly ErpDbContext _db; readonly CurrentUser _cu;
    Dictionary<(long?, string), string>? _cache;
    public SettingsService(ErpDbContext db, CurrentUser cu) { _db = db; _cu = cu; }

    async Task Load()
    {
        if (_cache != null) return;
        var rows = await _db.AppSettings.AsNoTracking().ToListAsync();
        _cache = rows.ToDictionary(r => (r.BranchId, r.Key), r => r.Value);
    }
    public void Invalidate() => _cache = null;

    public async Task<string> Get(string key, long? branchId = null)
    {
        await Load();
        if (branchId != null && _cache!.TryGetValue((branchId, key), out var b)) return b;
        if (_cache!.TryGetValue((null, key), out var c)) return c;
        return Defaults.TryGetValue(key, out var d) ? d : "";
    }
    public async Task<bool> Bool(string key, long? branchId = null) => bool.TryParse(await Get(key, branchId), out var v) && v;
    public async Task<decimal> Dec(string key, long? branchId = null) => decimal.TryParse(await Get(key, branchId), System.Globalization.NumberStyles.Number, System.Globalization.CultureInfo.InvariantCulture, out var v) ? v : 0m;
    public async Task<int> Int(string key, long? branchId = null) => int.TryParse(await Get(key, branchId), out var v) ? v : 0;
    public async Task<T> Enum<T>(string key, long? branchId = null) where T : struct => System.Enum.TryParse<T>(await Get(key, branchId), true, out var v) ? v : default;
    public static IReadOnlyDictionary<string, string> DefaultValues => Defaults;

    public async Task Set(string key, string value, long? branchId, string? description = null)
    {
        var row = await _db.AppSettings.FirstOrDefaultAsync(s => s.Key == key && s.BranchId == branchId);
        if (row == null) _db.AppSettings.Add(new AppSetting { Key = key, Value = value, BranchId = branchId, Description = description, CompanyId = _cu.Ctx.CompanyId });
        else row.Value = value;
        await _db.SaveChangesAsync();
        Invalidate();
    }
}

public sealed class AuditService
{
    readonly ErpDbContext _db; readonly CurrentUser _cu;
    public AuditService(ErpDbContext db, CurrentUser cu) { _db = db; _cu = cu; }

    /// <summary>Adds an audit row to the current unit of work (caller saves). Never pass passwords/tokens in before/after.</summary>
    public void Add(string action, string entityType, object? entityId, object? before = null, object? after = null, string? reason = null, long? targetBranchId = null, bool denied = false)
    {
        var u = _cu.Value;
        _db.AuditLogs.Add(new AuditLog
        {
            CompanyId = u?.CompanyId ?? _db.Scope.CompanyId, AtUtc = DateTime.UtcNow, UserId = u?.UserId, UserName = u?.UserName,
            ActiveBranchId = u?.ActiveBranchId, TargetBranchId = targetBranchId, Action = action, EntityType = entityType, EntityId = entityId?.ToString(),
            BeforeJson = Json.To(before), AfterJson = Json.To(after), Reason = reason, CorrelationId = u?.CorrelationId, Ip = u?.Ip, Denied = denied
        });
    }
    public async Task Save(string action, string entityType, object? entityId, object? before = null, object? after = null, string? reason = null, long? targetBranchId = null, bool denied = false)
    {
        Add(action, entityType, entityId, before, after, reason, targetBranchId, denied);
        await _db.SaveChangesAsync();
    }
}

/// <summary>Atomic gap-free numbering. The UPDATE ... OUTPUT takes a row lock held until the surrounding transaction commits.</summary>
public sealed class NumberingService
{
    readonly ErpDbContext _db; readonly CurrentUser _cu;
    public NumberingService(ErpDbContext db, CurrentUser cu) { _db = db; _cu = cu; }

    public async Task<string> Next(string docPrefix, long branchId, int pad = 6)
    {
        var year = DateTime.UtcNow.Year;
        var companyId = _cu.Ctx.CompanyId;
        var seq = await _db.InvoiceSequences.AsNoTracking().FirstOrDefaultAsync(s => s.BranchId == branchId && s.DocType == docPrefix && s.Year == year);
        if (seq == null)
        {
            var created = new InvoiceSequence { CompanyId = companyId, BranchId = branchId, DocType = docPrefix, Year = year, LastNumber = 0 };
            _db.InvoiceSequences.Add(created);
            await _db.SaveChangesAsync();
            seq = created;
        }
        var rows = await _db.Database.SqlQuery<long>($"UPDATE InvoiceSequences SET LastNumber = LastNumber + 1 OUTPUT INSERTED.LastNumber AS Value WHERE Id = {seq.Id}").ToListAsync();
        var n = rows.Single();
        var branchPrefix = await _db.Branches.AsNoTracking().Where(b => b.Id == branchId).Select(b => b.InvoicePrefix).FirstOrDefaultAsync();
        return DocNumber.Format(docPrefix, branchPrefix, year, n, pad);
    }
}

public sealed record RateSnapshot(decimal Rate, long? RateId, DateTime? AtUtc, string Policy, bool IsOverride);

public sealed class RateService
{
    readonly ErpDbContext _db; readonly SettingsService _settings;
    public RateService(ErpDbContext db, SettingsService s) { _db = db; _settings = s; }

    /// <summary>Latest effective rate (branch-specific wins over company-wide). The caller stores the snapshot on the document; later rate changes never touch it.</summary>
    public async Task<RateSnapshot> Resolve(long metalTypeId, long purityId, long branchId, bool selling, DateTime? atUtc = null)
    {
        var at = atUtc ?? DateTime.UtcNow;
        var q = _db.GoldRates.AsNoTracking().Where(r => r.MetalTypeId == metalTypeId && r.PurityId == purityId && r.EffectiveFromUtc <= at && (r.BranchId == null || r.BranchId == branchId));
        var rows = await q.OrderByDescending(r => r.EffectiveFromUtc).Take(10).ToListAsync();
        var pick = rows.Where(r => r.BranchId == branchId).Concat(rows.Where(r => r.BranchId == null)).FirstOrDefault();
        // branch rate wins only if it is at least as recent as the company card
        var company = rows.FirstOrDefault(r => r.BranchId == null);
        var branch = rows.FirstOrDefault(r => r.BranchId == branchId);
        pick = branch != null && (company == null || branch.EffectiveFromUtc >= company.EffectiveFromUtc) ? branch : company ?? branch;
        if (pick == null) throw new DomainException("No gold rate has been set for this metal/purity. Set today's rate first.", "rate_missing");
        var rate = selling ? pick.SellRate : pick.BuyRate;
        if (rate <= 0) throw new DomainException("The configured rate is zero.", "rate_invalid");
        return new RateSnapshot(rate, pick.Id, pick.EffectiveFromUtc, pick.BranchId == null ? "Company" : "Branch", pick.IsOverride);
    }
}

public sealed record ApprovalCheck(bool NeedsApproval, decimal? Limit);

public sealed class ApprovalService
{
    readonly ErpDbContext _db; readonly CurrentUser _cu; readonly AuditService _audit;
    public ApprovalService(ErpDbContext db, CurrentUser cu, AuditService audit) { _db = db; _cu = cu; _audit = audit; }

    /// <summary>User's effective limit = most generous limit across their roles for the branch. No configured limit = unrestricted (grant-based).</summary>
    public async Task<decimal?> EffectiveLimit(ApprovalType type, long branchId, UserContext? user = null)
    {
        var u = user ?? _cu.Ctx;
        var roleIds = u.RoleIds.ToArray();
        var limits = await _db.ApprovalLimits.AsNoTracking().Where(l => l.Type == type && roleIds.Contains(l.RoleId) && (l.BranchId == null || l.BranchId == branchId)).Select(l => l.MaxValue).ToListAsync();
        return limits.Count == 0 ? null : limits.Max();
    }

    public async Task<ApprovalCheck> Check(ApprovalType type, decimal value, long branchId)
    {
        var limit = await EffectiveLimit(type, branchId);
        return new ApprovalCheck(limit != null && value > limit.Value, limit);
    }

    public ApprovalRequest Request(ApprovalType type, string entityType, long entityId, string? number, decimal value, decimal limit, long branchId, string? reason, object? after = null)
    {
        var r = new ApprovalRequest
        {
            Type = type, EntityType = entityType, EntityId = entityId, EntityNumber = number, Value = value, Limit = limit, BranchId = branchId, Reason = reason,
            Status = ApprovalStatus.Pending, RequestedBy = _cu.Ctx.UserId, RequestedAtUtc = DateTime.UtcNow, AfterJson = Json.To(after), CompanyId = _cu.Ctx.CompanyId
        };
        _db.ApprovalRequests.Add(r);
        _audit.Add("Approval.Requested", entityType, entityId, after: new { type = type.ToString(), value, limit }, reason: reason, targetBranchId: branchId);
        return r;
    }

    public async Task<ApprovalRequest> Decide(long id, bool approve, string? reason)
    {
        var u = _cu.Ctx; u.Require(Perms.ApprovalsDecide);
        var r = await _db.ApprovalRequests.FirstOrDefaultAsync(x => x.Id == id) ?? throw new NotFoundException("Approval request");
        if (r.Status != ApprovalStatus.Pending) throw new ConflictException("This request has already been decided.");
        u.RequireBranch(r.BranchId);
        if (r.RequestedBy == u.UserId) throw new ForbiddenException("You cannot approve your own request (separation of duties).", "separation_of_duties");
        if (approve)
        {
            var limit = await EffectiveLimit(r.Type, r.BranchId);
            if (limit != null && r.Value > limit.Value) throw new ForbiddenException($"The request value exceeds your approval limit of {limit}.", "approval_limit");
        }
        r.Status = approve ? ApprovalStatus.Approved : ApprovalStatus.Rejected;
        r.DecidedBy = u.UserId; r.DecidedAtUtc = DateTime.UtcNow; r.DecisionReason = reason;

        // reflect the decision on the document
        var newStatus = approve ? DocStatus.Approved : DocStatus.Cancelled;
        switch (r.EntityType)
        {
            case nameof(SalesInvoice): Apply(await _db.SalesInvoices.FirstOrDefaultAsync(x => x.Id == r.EntityId), newStatus, u, reason); break;
            case nameof(SalesReturn): Apply(await _db.SalesReturns.FirstOrDefaultAsync(x => x.Id == r.EntityId), newStatus, u, reason); break;
            case nameof(StockAdjustment): Apply(await _db.StockAdjustments.FirstOrDefaultAsync(x => x.Id == r.EntityId), newStatus, u, reason); break;
            case nameof(ExpenseVoucher): Apply(await _db.ExpenseVouchers.FirstOrDefaultAsync(x => x.Id == r.EntityId), newStatus, u, reason); break;
            case nameof(OldGoldTransaction): Apply(await _db.OldGoldTransactions.FirstOrDefaultAsync(x => x.Id == r.EntityId), newStatus, u, reason); break;
            case nameof(StockTransfer): Apply(await _db.StockTransfers.FirstOrDefaultAsync(x => x.Id == r.EntityId), newStatus, u, reason); break;
        }
        _audit.Add(approve ? "Approval.Approved" : "Approval.Rejected", r.EntityType, r.EntityId, after: new { r.Type, r.Value, r.Limit }, reason: reason, targetBranchId: r.BranchId);
        await _db.SaveChangesAsync();
        return r;
    }

    static void Apply(PostableDocument? d, DocStatus s, UserContext u, string? reason)
    {
        if (d == null || d.Status != DocStatus.PendingApproval) return;
        d.Status = s; d.ApprovedBy = u.UserId; d.ApprovedAtUtc = DateTime.UtcNow;
        if (s == DocStatus.Cancelled) d.VoidReason = reason ?? "Approval rejected";
    }
}

public sealed record StockLoc(long BranchId, long LocationId, StockStatus Status);

public sealed class StockMoveSpec
{
    public TxnType RefType { get; init; }
    public long RefId { get; init; }
    public string RefNo { get; init; } = "";
    public StockLoc? From { get; init; }
    public StockLoc? To { get; init; }
    public long? ProductId { get; init; }
    public long? MetalTypeId { get; init; }
    public long? PurityId { get; init; }
    public Ownership FromOwnership { get; init; } = Ownership.Shop;
    public Ownership ToOwnership { get; init; } = Ownership.Shop;
    public long FromCustodyRefId { get; init; }
    public long ToCustodyRefId { get; init; }
    public decimal Qty { get; init; }
    public decimal Gross { get; init; }
    public decimal Stone { get; init; }
    public decimal Net { get; init; }
    public decimal Fine { get; init; }
    public decimal Cost { get; init; }
    public string? Reason { get; init; }
    public string Kind { get; init; } = "Move";
    public long? ReversalOfId { get; init; }
    public bool AllowNegative { get; init; }
}

/// <summary>
/// The posting engine: stock movements (immutable ledger + materialised balances), PKR party ledger, metal ledger,
/// balanced journals and the transaction register. All writes join the caller's DB transaction.
/// </summary>
public sealed class PostingEngine
{
    readonly ErpDbContext _db; readonly CurrentUser _cu; readonly SettingsService _settings; readonly NumberingService _num; readonly AuditService _audit;
    Dictionary<string, long>? _accounts;
    readonly Dictionary<long, long> _defaultLoc = new();
    public PostingEngine(ErpDbContext db, CurrentUser cu, SettingsService s, NumberingService n, AuditService a) { _db = db; _cu = cu; _settings = s; _num = n; _audit = a; }

    // ---------------- stock ----------------
    public async Task<long> DefaultLocation(long branchId, string? kind = null)
    {
        var key = kind == null ? branchId : branchId * 1000 + kind.GetHashCode() % 997;
        if (_defaultLoc.TryGetValue(key, out var id)) return id;
        var q = _db.StoreLocations.AsNoTracking().Where(l => l.BranchId == branchId && l.IsActive);
        long found;
        if (kind != null)
        {
            var k = await q.Where(l => l.Kind == kind).Select(l => (long?)l.Id).FirstOrDefaultAsync();
            found = k ?? await DefaultLocation(branchId);
        }
        else
        {
            var d = await q.OrderByDescending(l => l.IsDefault).ThenBy(l => l.Id).Select(l => (long?)l.Id).FirstOrDefaultAsync();
            found = d ?? throw new DomainException("This branch has no active store location. Create one first.", "no_location");
        }
        _defaultLoc[key] = found;
        return found;
    }

    async Task<StockBalance> Bal(StockLoc loc, long? productId, long? metalId, long? purityId, Ownership own, long custody, bool create)
    {
        var b = await _db.StockBalances.FirstOrDefaultAsync(x => x.BranchId == loc.BranchId && x.LocationId == loc.LocationId && x.ProductId == productId
                && x.MetalTypeId == metalId && x.PurityId == purityId && x.Status == loc.Status && x.Ownership == own && x.CustodyRefId == custody);
        if (b != null || !create) return b!;
        b = new StockBalance { CompanyId = _cu.Ctx.CompanyId, BranchId = loc.BranchId, LocationId = loc.LocationId, ProductId = productId, MetalTypeId = metalId, PurityId = purityId, Status = loc.Status, Ownership = own, CustodyRefId = custody };
        _db.StockBalances.Add(b);
        return b;
    }

    public async Task<StockMovement> Move(StockMoveSpec s)
    {
        if (s.From == null && s.To == null) throw new DomainException("A stock movement needs a source or a destination.");
        if (s.Qty < 0 || s.Gross < 0 || s.Net < 0 || s.Fine < 0) throw new DomainException("Movement quantities cannot be negative; use the opposite direction.", "movement_negative");
        if (s.Qty == 0 && s.Net == 0 && s.Gross == 0) throw new DomainException("Movement has no quantity or weight.", "movement_empty");
        var u = _cu.Ctx;
        if (s.From != null)
        {
            var from = await Bal(s.From, s.ProductId, s.MetalTypeId, s.PurityId, s.FromOwnership, s.FromCustodyRefId, create: s.AllowNegative);
            var allowNeg = s.AllowNegative || await _settings.Bool(SettingsService.Keys.NegativeStock, s.From.BranchId);
            if (from == null || (!allowNeg && (from.Quantity < s.Qty || (s.ProductId == null && from.NetWeight < s.Net))))
            {
                _audit.Add("Stock.NegativeAttempt", "StockBalance", s.ProductId ?? s.MetalTypeId, after: new { s.RefNo, s.Qty, s.Net, status = s.From.Status.ToString() }, targetBranchId: s.From.BranchId, denied: true);
                await _db.SaveChangesAsync();
                throw new DomainException($"Insufficient stock ({s.From.Status}) for {s.RefNo}. Negative stock is blocked.", "negative_stock");
            }
            if (allowNeg && from.Quantity < s.Qty) u.Require(Perms.InventoryNegativeOverride);
            from.Quantity -= s.Qty; from.GrossWeight -= s.Gross; from.StoneWeight -= s.Stone; from.NetWeight -= s.Net; from.FineWeight -= s.Fine; from.CostValue -= s.Cost;
        }
        if (s.To != null)
        {
            var to = await Bal(s.To, s.ProductId, s.MetalTypeId, s.PurityId, s.ToOwnership, s.ToCustodyRefId, create: true);
            to.Quantity += s.Qty; to.GrossWeight += s.Gross; to.StoneWeight += s.Stone; to.NetWeight += s.Net; to.FineWeight += s.Fine; to.CostValue += s.Cost;
        }
        var m = new StockMovement
        {
            CompanyId = u.CompanyId, PostedAtUtc = DateTime.UtcNow, PostedBy = u.UserId,
            FromBranchId = s.From?.BranchId, FromLocationId = s.From?.LocationId, FromStatus = s.From?.Status,
            ToBranchId = s.To?.BranchId, ToLocationId = s.To?.LocationId, ToStatus = s.To?.Status,
            ProductId = s.ProductId, MetalTypeId = s.MetalTypeId, PurityId = s.PurityId, FromOwnership = s.FromOwnership, FromCustodyRefId = s.FromCustodyRefId, Ownership = s.ToOwnership, CustodyRefId = s.ToCustodyRefId,
            Quantity = s.Qty, GrossWeight = s.Gross, StoneWeight = s.Stone, NetWeight = s.Net, FineWeight = s.Fine, CostValue = s.Cost,
            RefType = s.RefType, RefId = s.RefId, RefNo = s.RefNo, Reason = s.Reason, Kind = s.Kind, ReversalOfId = s.ReversalOfId
        };
        _db.StockMovements.Add(m);
        return m;
    }

    /// <summary>Picks the balance row (location) that actually holds enough available stock of a product in the branch.</summary>
    public async Task<StockBalance> FindAvailable(long branchId, long productId, decimal qty, string? sku = null)
    {
        var rows = await _db.StockBalances.Where(b => b.BranchId == branchId && b.ProductId == productId && b.Status == StockStatus.Available && b.Ownership == Ownership.Shop && b.Quantity > 0).OrderByDescending(b => b.Quantity).ToListAsync();
        return rows.FirstOrDefault(b => b.Quantity >= qty) ?? throw new DomainException($"{sku ?? "Item"} is not available in this branch (sold, reserved, in transit or not received).", "not_available");
    }

    public async Task<long> PostingBranch(long? requested)
    {
        var b = _cu.Ctx.PostingBranch(requested);
        var active = await _db.Branches.AsNoTracking().Where(x => x.Id == b).Select(x => x.IsActive).FirstOrDefaultAsync();
        if (!active) throw new DomainException("This branch is inactive and cannot receive new postings.", "branch_inactive");
        return b;
    }

    public async Task<string?> PartyName(PartyType pt, long? id)
    {
        if (id == null) return null;
        return pt switch
        {
            PartyType.Customer => await _db.Customers.AsNoTracking().Where(x => x.Id == id).Select(x => x.Name).FirstOrDefaultAsync(),
            PartyType.Supplier => await _db.Suppliers.AsNoTracking().Where(x => x.Id == id).Select(x => x.Name).FirstOrDefaultAsync(),
            PartyType.Worker => await _db.Workers.AsNoTracking().Where(x => x.Id == id).Select(x => x.Name).FirstOrDefaultAsync(),
            PartyType.Employee => await _db.Employees.AsNoTracking().Where(x => x.Id == id).Select(x => x.Name).FirstOrDefaultAsync(),
            _ => null
        };
    }

    // ---------------- chart of accounts & journals ----------------
    public async Task<long> Account(string code)
    {
        _accounts ??= await _db.ChartAccounts.AsNoTracking().ToDictionaryAsync(a => a.Code, a => a.Id);
        return _accounts.TryGetValue(code, out var id) ? id : throw new DomainException($"Chart account {code} is not configured.", "account_missing");
    }

    /// <summary>Cash/bank account -> its mapped ledger account (falls back to the default cash/bank control account).</summary>
    public async Task<long> LedgerAccountFor(long? cashBankAccountId, bool allowNull = false)
    {
        if (cashBankAccountId == null) return await Account(Acc.Cash);
        var a = await _db.CashBankAccounts.AsNoTracking().FirstOrDefaultAsync(x => x.Id == cashBankAccountId) ?? throw new NotFoundException("Cash/bank account");
        if (!a.IsActive) throw new DomainException("That cash/bank account is inactive.", "account_inactive");
        return a.ChartAccountId ?? await Account(a.Type == CashBankType.Cash ? Acc.Cash : Acc.Bank);
    }

    public async Task<JournalEntry> Journal(JournalBuilder b, TxnType type, long docId, string docNo, long branchId, DateTime dateUtc, string? description, bool isReversal = false, long? reversalOfId = null)
    {
        b.AssertBalanced();
        var jv = await _num.Next("JV", branchId);
        var je = new JournalEntry
        {
            CompanyId = _cu.Ctx.CompanyId, BranchId = branchId, Number = jv, EntryDateUtc = dateUtc, DocType = type, DocId = docId, DocNo = docNo, Description = description,
            TotalDebit = b.TotalDebit, TotalCredit = b.TotalCredit, IsReversal = isReversal, ReversalOfId = reversalOfId
        };
        foreach (var l in b.Lines)
            je.Lines.Add(new JournalLine { AccountId = l.AccountId ?? await Account(l.AccountCode!), Debit = l.Debit, Credit = l.Credit, PartyType = l.PartyType, PartyId = l.PartyId, Memo = l.Memo });
        _db.JournalEntries.Add(je);
        return je;
    }

    // ---------------- party & metal ledgers ----------------
    public void Party(PartyType pt, long partyId, long? branchId, DateTime date, TxnType type, long docId, string docNo, string? desc, decimal debit, decimal credit, bool reversal = false)
    {
        if (debit == 0 && credit == 0) return;
        _db.PartyLedger.Add(new PartyLedgerEntry { CompanyId = _cu.Ctx.CompanyId, BranchId = branchId, PartyType = pt, PartyId = partyId, EntryDateUtc = date, DocType = type, DocId = docId, DocNo = docNo, Description = desc, Debit = Money.R2(debit), Credit = Money.R2(credit), IsReversal = reversal });
    }

    public void Metal(PartyType pt, long partyId, long? branchId, long metalTypeId, long? purityId, DateTime date, TxnType type, long docId, string docNo, decimal netIn, decimal netOut, decimal fineIn, decimal fineOut, string? desc = null)
    {
        if (netIn == 0 && netOut == 0 && fineIn == 0 && fineOut == 0) return;
        _db.MetalLedger.Add(new MetalLedgerEntry { CompanyId = _cu.Ctx.CompanyId, BranchId = branchId, PartyType = pt, PartyId = partyId, MetalTypeId = metalTypeId, PurityId = purityId, EntryDateUtc = date, DocType = type, DocId = docId, DocNo = docNo, NetIn = netIn, NetOut = netOut, FineIn = fineIn, FineOut = fineOut, Description = desc });
    }

    // ---------------- transaction register ----------------
    public TransactionRegisterEntry Reg(TxnType type, PostableDocument doc, int lineNo = 1, PartyType? pt = null, long? partyId = null, string? partyName = null, bool reversal = false)
    {
        var u = _cu.Ctx;
        var e = new TransactionRegisterEntry
        {
            CompanyId = u.CompanyId, BranchId = doc.BranchId, PostedAtUtc = doc.PostedAtUtc ?? DateTime.UtcNow, TxnType = type, DocId = doc.Id, DocNo = doc.Number, LineNo = lineNo, Status = doc.Status,
            PartyType = pt, PartyId = partyId, PartyName = partyName, EnteredBy = doc.CreatedBy ?? u.UserId, EnteredByName = u.UserName, ApprovedBy = doc.ApprovedBy, IsReversal = reversal
        };
        _db.TransactionRegister.Add(e);
        return e;
    }

    /// <summary>Marks every register row of a document as reversed (history stays visible).</summary>
    public async Task MarkRegisterReversed(TxnType type, long docId, long reversalDocId)
    {
        var rows = await _db.TransactionRegister.Where(r => r.TxnType == type && r.DocId == docId).ToListAsync();
        foreach (var r in rows) { r.Status = DocStatus.Reversed; r.ReversedByDocId = reversalDocId; }
    }

    public async Task EnsureBackdating(DateTime docDateUtc, long branchId)
    {
        var days = await _settings.Int(SettingsService.Keys.BackdateDays, branchId);
        if (docDateUtc.Date < DateTime.UtcNow.Date.AddDays(-days)) _cu.Ctx.Require(Perms.FinanceReverse); // backdating needs an explicit grant
        if (docDateUtc > DateTime.UtcNow.AddMinutes(10)) throw new DomainException("Transaction date cannot be in the future.", "future_date");
    }

    /// <summary>Runs a unit of work in one DB transaction; concurrency/uniqueness failures surface as 409 conflicts.</summary>
    public async Task<T> InTransaction<T>(Func<Task<T>> work)
    {
        if (_db.Database.CurrentTransaction != null) return await work();
        await using var tx = await _db.Database.BeginTransactionAsync(IsolationLevel.ReadCommitted);
        try
        {
            var result = await work();
            await _db.SaveChangesAsync();
            await tx.CommitAsync();
            return result;
        }
        catch (DbUpdateConcurrencyException)
        {
            await tx.RollbackAsync();
            throw new ConflictException("Another user changed this record at the same time. Reload and try again.", "concurrency");
        }
        catch (DbUpdateException ex) when (IsUniqueViolation(ex))
        {
            await tx.RollbackAsync();
            throw new ConflictException("A conflicting record was posted at the same time (duplicate or already sold).", "duplicate");
        }
        catch { await tx.RollbackAsync(); throw; }
    }

    static bool IsUniqueViolation(Exception ex)
    {
        for (var e = ex; e != null; e = e.InnerException!)
        {
            var m = e.Message;
            if (m.Contains("duplicate key", StringComparison.OrdinalIgnoreCase) || m.Contains("UNIQUE KEY constraint", StringComparison.OrdinalIgnoreCase) || m.Contains("Cannot insert duplicate", StringComparison.OrdinalIgnoreCase)) return true;
            if (e.InnerException == null) break;
        }
        return false;
    }
}
