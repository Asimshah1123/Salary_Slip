using Erp.Domain;
using Erp.Domain.Calc;
using Erp.Domain.Entities;
using Erp.Infrastructure.Contracts;
using Erp.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;

namespace Erp.Infrastructure.Services;

public sealed class StockQuery : PageQuery
{
    public long[]? BranchIds { get; set; }
    public StockStatus? Status { get; set; }
    public long? LocationId { get; set; }
    public long? CategoryId { get; set; }
    public long? PurityId { get; set; }
    public Ownership? Ownership { get; set; }
    public bool IncludeSold { get; set; }
}
public sealed record StockRow(long BranchId, string Branch, long LocationId, string Location, long? ProductId, string? Sku, string? Name, string? Metal, string? Purity, StockStatus Status, Ownership Ownership, long CustodyRefId,
    decimal Qty, decimal Gross, decimal Net, decimal Fine, decimal? CostValue);
public sealed class MovementQuery : PageQuery { public long? ProductId { get; set; } public DateTime? From { get; set; } public DateTime? To { get; set; } public long[]? BranchIds { get; set; } public TxnType? RefType { get; set; } public StockStatus? Status { get; set; } }
public sealed record MovementRow(long Id, DateTime PostedAtUtc, string RefType, string RefNo, string? Sku, string? Item, string? FromBranch, StockStatus? FromStatus, string? ToBranch, StockStatus? ToStatus, decimal Qty, decimal Gross, decimal Net, decimal Fine, string Kind, string? Reason, string? PostedBy);

public sealed class TransferLineInput { public long? ProductId { get; set; } public long? MetalTypeId { get; set; } public long? PurityId { get; set; } public decimal Quantity { get; set; } = 1; public decimal GrossWeight { get; set; } public decimal NetWeight { get; set; } }
public sealed class TransferInput
{
    public long OriginBranchId { get; set; }
    public long DestinationBranchId { get; set; }
    public long? FromLocationId { get; set; }
    public long? ToLocationId { get; set; }
    public List<TransferLineInput> Lines { get; set; } = new();
    public string? Notes { get; set; }
    public bool DispatchNow { get; set; } = true;
    public string? IdempotencyKey { get; set; }
}
public sealed class TransferReceiveLine { public long LineId { get; set; } public decimal ReceivedQuantity { get; set; } public decimal ReceivedGrossWeight { get; set; } public decimal ReceivedNetWeight { get; set; } }
public sealed class TransferReceiveInput { public List<TransferReceiveLine> Lines { get; set; } = new(); public string? VarianceReason { get; set; } public bool CloseWithShortage { get; set; } public long? ToLocationId { get; set; } }
public sealed record TransferLineDto(long Id, long? ProductId, string? Sku, string? Item, string? Purity, decimal Qty, decimal Gross, decimal Net, decimal ReceivedQty, decimal ReceivedGross, decimal ReceivedNet);
public sealed record TransferDto(long Id, string Number, long OriginBranchId, string Origin, long DestinationBranchId, string Destination, TransferStatus TransferStatus, DocStatus Status, DateTime? DispatchedAtUtc, DateTime? ReceivedAtUtc, string? VarianceReason, string? Notes, IReadOnlyList<TransferLineDto> Lines);

public sealed class AdjustLineInput { public long? ProductId { get; set; } public long? MetalTypeId { get; set; } public long? PurityId { get; set; } public long? LocationId { get; set; } public decimal QuantityDelta { get; set; } public decimal NetDelta { get; set; } public decimal GrossDelta { get; set; } public decimal? UnitCost { get; set; } public StockStatus? ToStatus { get; set; } }
public sealed class AdjustInput { public long? BranchId { get; set; } public string Kind { get; set; } = "Adjustment"; public string Reason { get; set; } = ""; public List<AdjustLineInput> Lines { get; set; } = new(); public bool PostNow { get; set; } = true; public string? IdempotencyKey { get; set; } }
public sealed record AdjustmentDto(long Id, string Number, string Kind, DocStatus Status, string Reason, decimal TotalValue, int Lines, string? PendingReason);

public sealed class CountInput { public long? BranchId { get; set; } public long? LocationId { get; set; } public string? Notes { get; set; } }
public sealed class CountEntry { public long LineId { get; set; } public decimal? CountedQuantity { get; set; } public decimal? CountedNetWeight { get; set; } public string? Note { get; set; } }
public sealed record CountLineDto(long Id, long? ProductId, string? Sku, string? Item, string? Purity, long LocationId, decimal SystemQty, decimal SystemNet, decimal? CountedQty, decimal? CountedNet, decimal? QtyVariance, decimal? NetVariance, string? Note);
public sealed record CountDto(long Id, string Number, long BranchId, DocStatus Status, long? LocationId, string? Notes, IReadOnlyList<CountLineDto> Lines);
public sealed class ReserveInput { public long ProductId { get; set; } public long? BranchId { get; set; } public long? CustomerId { get; set; } public int Hours { get; set; } = 24; public string? Note { get; set; } }
public sealed record ReservationDto(long Id, long ProductId, string Sku, string Item, long? CustomerId, DateTime ReservedUntilUtc, string? Note, bool IsActive);
public sealed record ReconcileRow(string Key, decimal LedgerQty, decimal BalanceQty, decimal LedgerNet, decimal BalanceNet);

public sealed class InventoryService
{
    readonly ErpDbContext _db; readonly CurrentUser _cu; readonly AuditService _audit; readonly NumberingService _num; readonly PostingEngine _post; readonly SettingsService _settings; readonly AccessGuard _guard; readonly ApprovalService _approvals;
    public InventoryService(ErpDbContext db, CurrentUser cu, AuditService audit, NumberingService num, PostingEngine post, SettingsService settings, AccessGuard guard, ApprovalService approvals)
    { _db = db; _cu = cu; _audit = audit; _num = num; _post = post; _settings = settings; _guard = guard; _approvals = approvals; }

    static decimal CostShare(StockBalance b, decimal qty, decimal net) =>
        b.Quantity > 0 && qty > 0 ? Money.R2(b.CostValue * Math.Min(1m, qty / b.Quantity)) : b.NetWeight > 0 && net > 0 ? Money.R2(b.CostValue * Math.Min(1m, net / b.NetWeight)) : 0m;

    // ================= stock views =================
    public async Task<PagedResult<StockRow>> Stock(StockQuery q)
    {
        var u = _cu.Ctx; u.Require(Perms.InventoryView);
        var branches = u.ResolveScope(q.BranchIds);
        var s = _db.StockBalances.AsNoTracking().Where(b => branches.Contains(b.BranchId) && (b.Quantity != 0 || b.NetWeight != 0));
        if (q.Status != null) s = s.Where(b => b.Status == q.Status); else if (!q.IncludeSold) s = s.Where(b => b.Status != StockStatus.Sold);
        if (q.LocationId != null) s = s.Where(b => b.LocationId == q.LocationId);
        if (q.PurityId != null) s = s.Where(b => b.PurityId == q.PurityId);
        if (q.Ownership != null) s = s.Where(b => b.Ownership == q.Ownership);
        if (q.CategoryId != null) s = s.Where(b => _db.Products.Any(p => p.Id == b.ProductId && p.CategoryId == q.CategoryId));
        if (!string.IsNullOrWhiteSpace(q.Search)) { var t = q.Search.Trim(); s = s.Where(b => _db.Products.Any(p => p.Id == b.ProductId && (p.Sku.Contains(t) || p.Name.Contains(t) || p.Barcode == t))); }
        var total = await s.CountAsync();
        var rows = await s.OrderBy(b => b.BranchId).ThenBy(b => b.ProductId).ThenBy(b => b.Status).Skip(q.Skip).Take(q.Take).ToListAsync();
        var pids = rows.Where(r => r.ProductId != null).Select(r => r.ProductId!.Value).Distinct().ToList();
        var prods = await _db.Products.AsNoTracking().Where(p => pids.Contains(p.Id)).ToDictionaryAsync(p => p.Id, p => p);
        var br = await _db.Branches.AsNoTracking().IgnoreQueryFilters().ToDictionaryAsync(b => b.Id, b => b.BranchName);
        var lc = await _db.StoreLocations.AsNoTracking().IgnoreQueryFilters().ToDictionaryAsync(l => l.Id, l => l.Name);
        var pur = await _db.Purities.AsNoTracking().ToDictionaryAsync(p => p.Id, p => p.Label);
        var met = await _db.MetalTypes.AsNoTracking().ToDictionaryAsync(m => m.Id, m => m.Name);
        var cost = u.Has(Perms.ReportsCost);
        var items = rows.Select(b =>
        {
            prods.TryGetValue(b.ProductId ?? 0, out var p);
            var metalId = b.MetalTypeId ?? p?.MetalTypeId; var purId = b.PurityId ?? p?.PurityId;
            return new StockRow(b.BranchId, br.GetValueOrDefault(b.BranchId, ""), b.LocationId, lc.GetValueOrDefault(b.LocationId, ""), b.ProductId, p?.Sku, p?.Name ?? (metalId != null ? (met.GetValueOrDefault(metalId.Value, "Metal") + " (loose)") : null), metalId != null ? met.GetValueOrDefault(metalId.Value) : null, purId != null ? pur.GetValueOrDefault(purId.Value) : null,
                b.Status, b.Ownership, b.CustodyRefId, b.Quantity, b.GrossWeight, b.NetWeight, b.FineWeight, cost ? b.CostValue : null);
        }).ToList();
        return new PagedResult<StockRow>(items, total, q.Page, q.Take, new Dictionary<string, decimal> { ["qty"] = await s.SumAsync(x => x.Quantity), ["net"] = await s.SumAsync(x => x.NetWeight), ["fine"] = await s.SumAsync(x => x.FineWeight) });
    }

    public async Task<PagedResult<MovementRow>> Movements(MovementQuery q)
    {
        var u = _cu.Ctx; u.Require(Perms.InventoryView);
        var branches = u.ResolveScope(q.BranchIds);
        var s = _db.StockMovements.AsNoTracking().Where(m => (m.FromBranchId != null && branches.Contains(m.FromBranchId.Value)) || (m.ToBranchId != null && branches.Contains(m.ToBranchId.Value)));
        if (q.ProductId != null) s = s.Where(m => m.ProductId == q.ProductId);
        if (q.From != null) s = s.Where(m => m.PostedAtUtc >= q.From);
        if (q.To != null) s = s.Where(m => m.PostedAtUtc < q.To.Value.AddDays(1));
        if (q.RefType != null) s = s.Where(m => m.RefType == q.RefType);
        if (q.Status != null) s = s.Where(m => m.ToStatus == q.Status || m.FromStatus == q.Status);
        if (!string.IsNullOrWhiteSpace(q.Search)) { var t = q.Search.Trim(); s = s.Where(m => m.RefNo.Contains(t) || _db.Products.Any(p => p.Id == m.ProductId && p.Sku.Contains(t))); }
        var total = await s.CountAsync();
        var rows = await s.OrderByDescending(m => m.Id).Skip(q.Skip).Take(q.Take).ToListAsync();
        var pids = rows.Where(r => r.ProductId != null).Select(r => r.ProductId!.Value).Distinct().ToList();
        var prods = await _db.Products.AsNoTracking().Where(p => pids.Contains(p.Id)).ToDictionaryAsync(p => p.Id, p => p);
        var br = await _db.Branches.AsNoTracking().IgnoreQueryFilters().ToDictionaryAsync(b => b.Id, b => b.BranchName);
        var uids = rows.Select(r => r.PostedBy).Distinct().ToList();
        var names = await _db.Users.AsNoTracking().Where(x => uids.Contains(x.Id)).ToDictionaryAsync(x => x.Id, x => x.UserName);
        return new PagedResult<MovementRow>(rows.Select(m => { prods.TryGetValue(m.ProductId ?? 0, out var p); return new MovementRow(m.Id, m.PostedAtUtc, m.RefType.ToString(), m.RefNo, p?.Sku, p?.Name, m.FromBranchId != null ? br.GetValueOrDefault(m.FromBranchId.Value) : null, m.FromStatus, m.ToBranchId != null ? br.GetValueOrDefault(m.ToBranchId.Value) : null, m.ToStatus, m.Quantity, m.GrossWeight, m.NetWeight, m.FineWeight, m.Kind, m.Reason, names.GetValueOrDefault(m.PostedBy)); }).ToList(), total, q.Page, q.Take);
    }

    // ================= transfers (SRS 18.2) =================
    public async Task<TransferDto> CreateTransfer(TransferInput i)
    {
        var u = _cu.Ctx; u.Require(Perms.InventoryTransfer);
        await _post.PostingBranch(i.OriginBranchId);
        if (i.OriginBranchId == i.DestinationBranchId) throw new ValidationFailedException("destinationBranchId", "Origin and destination must differ.");
        var dest = await _db.Branches.AsNoTracking().FirstOrDefaultAsync(b => b.Id == i.DestinationBranchId && b.IsActive) ?? throw new ValidationFailedException("destinationBranchId", "Destination branch not found or inactive.");
        if (!string.IsNullOrWhiteSpace(i.IdempotencyKey))
        {
            var dup = await _db.StockTransfers.AsNoTracking().FirstOrDefaultAsync(x => x.IdempotencyKey == i.IdempotencyKey);
            if (dup != null) return await GetTransfer(dup.Id);
        }
        if (i.Lines.Count == 0) throw new ValidationFailedException("lines", "Add at least one item.");
        long id = 0;
        await _post.InTransaction(async () =>
        {
            var t = new StockTransfer { CompanyId = u.CompanyId, BranchId = i.OriginBranchId, OriginBranchId = i.OriginBranchId, DestinationBranchId = dest.Id, FromLocationId = i.FromLocationId, ToLocationId = i.ToLocationId, Number = await _num.Next("TRF", i.OriginBranchId), DocDateUtc = DateTime.UtcNow, Notes = i.Notes, IdempotencyKey = i.IdempotencyKey, TransferStatus = TransferStatus.Draft, Status = DocStatus.Draft };
            foreach (var l in i.Lines)
            {
                if (l.ProductId == null && (l.MetalTypeId == null || l.PurityId == null || l.NetWeight <= 0)) throw new ValidationFailedException("lines", "Loose metal lines need metal, purity and net weight.");
                if (l.ProductId != null)
                {
                    var p = await _db.Products.AsNoTracking().FirstOrDefaultAsync(x => x.Id == l.ProductId) ?? throw new NotFoundException("Item");
                    if (p.Tracking == TrackingMode.Serialized && l.Quantity != 1) throw new ValidationFailedException("lines", $"{p.Sku} is a unique piece (quantity 1).");
                    t.Lines.Add(new StockTransferLine { ProductId = p.Id, MetalTypeId = p.MetalTypeId, PurityId = p.PurityId, Quantity = l.Quantity, GrossWeight = Money.R3(p.GrossWeight * l.Quantity), NetWeight = Money.R3(p.NetMetalWeight * l.Quantity) });
                }
                else t.Lines.Add(new StockTransferLine { MetalTypeId = l.MetalTypeId, PurityId = l.PurityId, Quantity = 0, GrossWeight = l.GrossWeight == 0 ? l.NetWeight : l.GrossWeight, NetWeight = l.NetWeight });
            }
            _db.StockTransfers.Add(t);
            await _db.SaveChangesAsync();
            id = t.Id;
            _audit.Add("Transfer.Created", nameof(StockTransfer), t.Id, after: new { t.Number, dest = dest.BranchName }, targetBranchId: dest.Id);
            if (i.DispatchNow) await DispatchInternal(t);
            return 0;
        });
        return await GetTransfer(id);
    }

    public async Task<TransferDto> Dispatch(long id)
    {
        _cu.Ctx.Require(Perms.InventoryTransfer);
        await _post.InTransaction(async () =>
        {
            var t = await _guard.Find(_db.StockTransfers.Include(x => x.Lines), id, "Transfer");
            await _post.PostingBranch(t.OriginBranchId);
            await DispatchInternal(t);
            return 0;
        });
        return await GetTransfer(id);
    }

    async Task DispatchInternal(StockTransfer t)
    {
        var u = _cu.Ctx;
        TransferFlow.RequireDispatch(t.TransferStatus);
        if (t.Lines.Count == 0) t = await _db.StockTransfers.Include(x => x.Lines).FirstAsync(x => x.Id == t.Id);
        var destLoc = t.ToLocationId ?? await _post.DefaultLocation(t.DestinationBranchId);
        var srcName = await _db.Branches.AsNoTracking().Where(b => b.Id == t.OriginBranchId).Select(b => b.BranchName).FirstOrDefaultAsync();
        int no = 1;
        foreach (var l in t.Lines)
        {
            StockBalance bal;
            if (l.ProductId != null) bal = await _post.FindAvailable(t.OriginBranchId, l.ProductId.Value, l.Quantity, null);
            else
            {
                bal = await _db.StockBalances.Where(b => b.BranchId == t.OriginBranchId && b.ProductId == null && b.MetalTypeId == l.MetalTypeId && b.PurityId == l.PurityId && b.Status == StockStatus.Available && b.Ownership == Ownership.Shop && b.NetWeight >= l.NetWeight).FirstOrDefaultAsync()
                      ?? throw new DomainException("Not enough loose metal of that purity available in the origin branch.", "not_available");
            }
            if (t.FromLocationId != null && bal.LocationId != t.FromLocationId) throw new DomainException("The item is not in the selected source location.", "wrong_location");
            decimal fine = 0;
            if (l.PurityId != null) { var pf = await _db.Purities.AsNoTracking().Where(p => p.Id == l.PurityId).Select(p => p.Factor).FirstAsync(); fine = WeightCalc.Fine(l.NetWeight, pf); }
            var cost = CostShare(bal, l.Quantity, l.NetWeight);
            await _post.Move(new StockMoveSpec
            {
                RefType = TxnType.StockTransferOut, RefId = t.Id, RefNo = t.Number, From = new StockLoc(t.OriginBranchId, bal.LocationId, StockStatus.Available), To = new StockLoc(t.DestinationBranchId, destLoc, StockStatus.InTransit), ToCustodyRefId = t.Id,
                ProductId = l.ProductId, MetalTypeId = l.MetalTypeId, PurityId = l.PurityId, Qty = l.Quantity, Gross = l.GrossWeight, Net = l.NetWeight, Fine = fine, Cost = cost, Kind = "Move", Reason = "Dispatch " + t.Number
            });
            var e = _post.Reg(TxnType.StockTransferOut, t, no++); e.DestinationBranchId = t.DestinationBranchId; e.ProductId = l.ProductId; e.MetalTypeId = l.MetalTypeId; e.PurityId = l.PurityId; e.Gross = l.GrossWeight; e.Net = l.NetWeight; e.Fine = fine;
            if (l.ProductId != null) { var p = await _db.Products.AsNoTracking().FirstAsync(x => x.Id == l.ProductId); e.Sku = p.Sku; e.ItemName = p.Name; } else e.ItemName = "Loose metal";
        }
        t.TransferStatus = TransferStatus.InTransit; t.Status = DocStatus.Posted; t.DispatchedAtUtc = DateTime.UtcNow; t.DispatchedBy = u.UserId; t.PostedAtUtc = t.DispatchedAtUtc; t.PostedBy = u.UserId;
        _audit.Add("Transfer.Dispatched", nameof(StockTransfer), t.Id, after: new { t.Number, lines = t.Lines.Count }, targetBranchId: t.DestinationBranchId);
    }

    public async Task<TransferDto> Receive(long id, TransferReceiveInput i)
    {
        var u = _cu.Ctx; u.Require(Perms.InventoryTransferReceive);
        await _post.InTransaction(async () =>
        {
            var t = await _guard.Find(_db.StockTransfers.Include(x => x.Lines), id, "Transfer");
            u.RequireBranch(t.DestinationBranchId);
            TransferFlow.RequireReceive(t.TransferStatus);
            var tol = await _settings.Dec(SettingsService.Keys.TransferTolGrams, t.DestinationBranchId);
            var toLoc = i.ToLocationId ?? t.ToLocationId ?? await _post.DefaultLocation(t.DestinationBranchId);
            var transitLoc = t.ToLocationId ?? await _post.DefaultLocation(t.DestinationBranchId);
            var entries = i.Lines.Count == 0 ? t.Lines.Select(l => new TransferReceiveLine { LineId = l.Id, ReceivedQuantity = l.Quantity - l.ReceivedQuantity, ReceivedGrossWeight = l.GrossWeight - l.ReceivedGrossWeight, ReceivedNetWeight = l.NetWeight - l.ReceivedNetWeight }).ToList() : i.Lines;
            bool variance = false; int no = 1;
            foreach (var r in entries)
            {
                var l = t.Lines.FirstOrDefault(x => x.Id == r.LineId) ?? throw new ValidationFailedException("lines", "Line does not belong to this transfer.");
                var remQty = l.Quantity - l.ReceivedQuantity; var remNet = l.NetWeight - l.ReceivedNetWeight;
                if (r.ReceivedQuantity < 0 || r.ReceivedQuantity > remQty || r.ReceivedNetWeight < 0 || r.ReceivedNetWeight > remNet + tol) throw new ValidationFailedException("lines", $"Receipt exceeds what is still in transit for line {l.Id}.");
                if (r.ReceivedQuantity == 0 && r.ReceivedNetWeight == 0) continue;
                var moveQty = r.ReceivedQuantity; var moveNet = l.ProductId == null ? Math.Min(r.ReceivedNetWeight, remNet) : (l.Quantity == 0 ? 0 : Money.R3(l.NetWeight * r.ReceivedQuantity / l.Quantity));
                var moveGross = l.ProductId == null ? Math.Min(r.ReceivedGrossWeight, l.GrossWeight - l.ReceivedGrossWeight) : (l.Quantity == 0 ? 0 : Money.R3(l.GrossWeight * r.ReceivedQuantity / l.Quantity));
                decimal fine = 0; if (l.PurityId != null) fine = WeightCalc.Fine(moveNet, await _db.Purities.AsNoTracking().Where(p => p.Id == l.PurityId).Select(p => p.Factor).FirstAsync());
                var transit = await _db.StockBalances.FirstOrDefaultAsync(b => b.BranchId == t.DestinationBranchId && b.LocationId == transitLoc && b.ProductId == l.ProductId && b.MetalTypeId == l.MetalTypeId && b.PurityId == l.PurityId && b.Status == StockStatus.InTransit && b.CustodyRefId == t.Id)
                              ?? throw new DomainException("The in-transit stock record was not found.", "transit_missing");
                await _post.Move(new StockMoveSpec
                {
                    RefType = TxnType.StockTransferIn, RefId = t.Id, RefNo = t.Number, From = new StockLoc(t.DestinationBranchId, transitLoc, StockStatus.InTransit), FromCustodyRefId = t.Id, To = new StockLoc(t.DestinationBranchId, toLoc, StockStatus.Available),
                    ProductId = l.ProductId, MetalTypeId = l.MetalTypeId, PurityId = l.PurityId, Qty = moveQty, Gross = moveGross, Net = moveNet, Fine = fine, Cost = CostShare(transit, moveQty, moveNet), Kind = "Move", Reason = "Receipt " + t.Number
                });
                var diff = Money.R3(r.ReceivedNetWeight - (l.ProductId == null ? moveNet : Money.R3(l.NetWeight * r.ReceivedQuantity / Math.Max(l.Quantity, 1m))));
                if (l.ProductId != null && Math.Abs(diff) > tol) { variance = true; if (string.IsNullOrWhiteSpace(i.VarianceReason)) throw new ValidationFailedException("varianceReason", "Weight differs beyond tolerance: a reason is required."); u.Require(Perms.InventoryAdjust); }
                l.ReceivedQuantity += moveQty; l.ReceivedNetWeight += moveNet; l.ReceivedGrossWeight += moveGross;
                var e = _post.Reg(TxnType.StockTransferIn, t, no++); e.BranchId = t.DestinationBranchId; e.DestinationBranchId = t.OriginBranchId; e.ProductId = l.ProductId; e.MetalTypeId = l.MetalTypeId; e.PurityId = l.PurityId; e.Net = moveNet; e.Gross = moveGross; e.Fine = fine; e.ItemName = l.ProductId != null ? "Transfer receipt" : "Loose metal";
            }
            var fully = t.Lines.All(l => l.ReceivedQuantity >= l.Quantity && l.ReceivedNetWeight + tol >= l.NetWeight);
            if (!fully && i.CloseWithShortage)
            {
                u.Require(Perms.InventoryAdjust);
                if (string.IsNullOrWhiteSpace(i.VarianceReason)) throw new ValidationFailedException("varianceReason", "A reason is required to close with a shortage.");
                decimal lossCost = 0;
                foreach (var l in t.Lines)
                {
                    var remQty = l.Quantity - l.ReceivedQuantity; var remNet = Math.Max(0, l.NetWeight - l.ReceivedNetWeight);
                    if (remQty <= 0 && remNet <= 0.0005m) continue;
                    var transit = await _db.StockBalances.FirstOrDefaultAsync(b => b.BranchId == t.DestinationBranchId && b.LocationId == transitLoc && b.ProductId == l.ProductId && b.MetalTypeId == l.MetalTypeId && b.PurityId == l.PurityId && b.Status == StockStatus.InTransit && b.CustodyRefId == t.Id);
                    if (transit == null) continue;
                    var cost = CostShare(transit, remQty, remNet); lossCost += cost;
                    await _post.Move(new StockMoveSpec { RefType = TxnType.StockAdjustment, RefId = t.Id, RefNo = t.Number, From = new StockLoc(t.DestinationBranchId, transitLoc, StockStatus.InTransit), FromCustodyRefId = t.Id, ProductId = l.ProductId, MetalTypeId = l.MetalTypeId, PurityId = l.PurityId, Qty = remQty, Net = remNet, Gross = Math.Max(0, l.GrossWeight - l.ReceivedGrossWeight), Cost = cost, Kind = "Adjustment", Reason = "Transfer shortage: " + i.VarianceReason, AllowNegative = false });
                }
                if (lossCost > 0) await _post.Journal(new JournalBuilder().Dr(Acc.StockLoss, lossCost, "Transfer shortage").Cr(Acc.InvFinished, lossCost, "Stock written off"), TxnType.StockAdjustment, t.Id, t.Number, t.DestinationBranchId, DateTime.UtcNow, "Shortage on " + t.Number);
                fully = true; variance = true;
            }
            t.VarianceReason = i.VarianceReason ?? t.VarianceReason;
            t.TransferStatus = fully ? TransferStatus.Received : TransferStatus.PartiallyReceived;
            if (fully) { t.ReceivedAtUtc = DateTime.UtcNow; t.ReceivedBy = u.UserId; t.Status = DocStatus.Closed; }
            _audit.Add("Transfer.Received", nameof(StockTransfer), t.Id, after: new { t.Number, status = t.TransferStatus.ToString(), variance }, reason: i.VarianceReason, targetBranchId: t.DestinationBranchId);
            return 0;
        });
        return await GetTransfer(id);
    }

    public async Task CancelTransfer(long id, string reason)
    {
        _cu.Ctx.Require(Perms.InventoryTransfer);
        var t = await _guard.Find(_db.StockTransfers, id, "Transfer");
        if (t.TransferStatus != TransferStatus.Draft) throw new ConflictException("Only draft transfers can be cancelled; receive or return dispatched stock instead.");
        t.TransferStatus = TransferStatus.Cancelled; t.Status = DocStatus.Cancelled; t.VoidReason = reason;
        await _audit.Save("Transfer.Cancelled", nameof(StockTransfer), id, reason: reason, targetBranchId: t.DestinationBranchId);
    }

    public async Task<TransferDto> GetTransfer(long id)
    {
        _cu.Ctx.RequireAny(Perms.InventoryView, Perms.InventoryTransfer, Perms.InventoryTransferReceive);
        var t = await _guard.Find(_db.StockTransfers.AsNoTracking().Include(x => x.Lines), id, "Transfer");
        var br = await _db.Branches.AsNoTracking().IgnoreQueryFilters().ToDictionaryAsync(b => b.Id, b => b.BranchName);
        var pids = t.Lines.Where(l => l.ProductId != null).Select(l => l.ProductId!.Value).ToList();
        var prods = await _db.Products.AsNoTracking().Where(p => pids.Contains(p.Id)).ToDictionaryAsync(p => p.Id, p => p);
        var pur = await _db.Purities.AsNoTracking().ToDictionaryAsync(p => p.Id, p => p.Label);
        return new TransferDto(t.Id, t.Number, t.OriginBranchId, br.GetValueOrDefault(t.OriginBranchId, ""), t.DestinationBranchId, br.GetValueOrDefault(t.DestinationBranchId, ""), t.TransferStatus, t.Status, t.DispatchedAtUtc, t.ReceivedAtUtc, t.VarianceReason, t.Notes,
            t.Lines.Select(l => { prods.TryGetValue(l.ProductId ?? 0, out var p); return new TransferLineDto(l.Id, l.ProductId, p?.Sku, p?.Name ?? "Loose metal", l.PurityId != null ? pur.GetValueOrDefault(l.PurityId.Value) : null, l.Quantity, l.GrossWeight, l.NetWeight, l.ReceivedQuantity, l.ReceivedGrossWeight, l.ReceivedNetWeight); }).ToList());
    }

    public async Task<PagedResult<TransferDto>> ListTransfers(PageQuery q, TransferStatus? status)
    {
        var u = _cu.Ctx; u.RequireAny(Perms.InventoryView, Perms.InventoryTransfer, Perms.InventoryTransferReceive);
        var s = _db.StockTransfers.AsNoTracking().AsQueryable();
        if (status != null) s = s.Where(t => t.TransferStatus == status);
        if (!string.IsNullOrWhiteSpace(q.Search)) { var x = q.Search.Trim(); s = s.Where(t => t.Number.Contains(x)); }
        var total = await s.CountAsync();
        var ids = await s.OrderByDescending(t => t.Id).Skip(q.Skip).Take(q.Take).Select(t => t.Id).ToListAsync();
        var items = new List<TransferDto>(); foreach (var id in ids) items.Add(await GetTransfer(id));
        return new PagedResult<TransferDto>(items, total, q.Page, q.Take);
    }

    // ================= adjustments / damage / loss / opening stock =================
    public async Task<AdjustmentDto> Adjust(AdjustInput i)
    {
        var u = _cu.Ctx; u.Require(Perms.InventoryAdjust);
        var branch = await _post.PostingBranch(i.BranchId);
        if (string.IsNullOrWhiteSpace(i.Reason)) throw new ValidationFailedException("reason", "A reason is mandatory.");
        if (i.Lines.Count == 0) throw new ValidationFailedException("lines", "Add at least one line.");
        var kinds = new[] { "Adjustment", "Damage", "Quarantine", "Loss", "Scrap", "Opening" };
        if (!kinds.Contains(i.Kind)) throw new ValidationFailedException("kind", "Unknown adjustment kind.");
        if (!string.IsNullOrWhiteSpace(i.IdempotencyKey))
        {
            var dup = await _db.StockAdjustments.AsNoTracking().FirstOrDefaultAsync(x => x.IdempotencyKey == i.IdempotencyKey);
            if (dup != null) return ToDto(dup, null);
        }
        long id = 0;
        await _post.InTransaction(async () =>
        {
            var a = new StockAdjustment { CompanyId = u.CompanyId, BranchId = branch, Number = await _num.Next("ADJ", branch), DocDateUtc = DateTime.UtcNow, Kind = i.Kind, Reason = i.Reason, IdempotencyKey = i.IdempotencyKey, Status = DocStatus.Draft };
            decimal value = 0;
            foreach (var l in i.Lines)
            {
                Product? p = l.ProductId != null ? await _db.Products.AsNoTracking().FirstOrDefaultAsync(x => x.Id == l.ProductId) ?? throw new NotFoundException("Item") : null;
                if (p == null && (l.MetalTypeId == null || l.PurityId == null)) throw new ValidationFailedException("lines", "Each line needs an item or a metal + purity.");
                var qtyD = l.QuantityDelta; var netD = l.NetDelta;
                if (p != null && p.Tracking == TrackingMode.Serialized && qtyD != 0 && Math.Abs(qtyD) != 1) throw new ValidationFailedException("lines", $"{p.Sku} is a unique piece; adjust by exactly 1.");
                if (p != null && netD == 0 && qtyD != 0) netD = Money.R3(p.NetMetalWeight * qtyD);
                if (qtyD == 0 && netD == 0) throw new ValidationFailedException("lines", "A line has no quantity or weight change.");
                var unit = l.UnitCost ?? p?.CostPrice ?? 0m;
                var cost = Money.R2(unit * (qtyD != 0 ? Math.Abs(qtyD) : Math.Abs(netD))) * (qtyD < 0 || netD < 0 ? -1 : 1);
                value += Math.Abs(cost);
                a.Lines.Add(new StockAdjustmentLine { ProductId = p?.Id, MetalTypeId = l.MetalTypeId ?? p?.MetalTypeId, PurityId = l.PurityId ?? p?.PurityId, LocationId = l.LocationId ?? 0, QuantityDelta = qtyD, NetDelta = netD, GrossDelta = l.GrossDelta != 0 ? l.GrossDelta : (p != null && qtyD != 0 ? Money.R3(p.GrossWeight * qtyD) : netD), CostDelta = cost, ToStatus = l.ToStatus ?? KindStatus(i.Kind) });
            }
            a.TotalValue = Money.R2(value);
            _db.StockAdjustments.Add(a);
            await _db.SaveChangesAsync();
            id = a.Id;
            var chk = await _approvals.Check(ApprovalType.StockAdjustment, a.TotalValue, branch);
            if (chk.NeedsApproval || i.Kind == "Opening" && !u.Has(Perms.ApprovalsDecide))
            {
                a.Status = DocStatus.PendingApproval;
                _approvals.Request(ApprovalType.StockAdjustment, nameof(StockAdjustment), a.Id, a.Number, a.TotalValue, chk.Limit ?? 0, branch, i.Reason);
            }
            else if (i.PostNow) await PostAdjustmentInternal(a);
            _audit.Add("Adjustment.Created", nameof(StockAdjustment), a.Id, after: new { a.Number, a.Kind, a.TotalValue, status = a.Status.ToString() }, reason: i.Reason, targetBranchId: branch);
            return 0;
        });
        return ToDto(await _db.StockAdjustments.AsNoTracking().FirstAsync(x => x.Id == id), null);
    }

    public async Task<PagedResult<AdjustmentDto>> ListAdjustments(PageQuery q)
    {
        var u = _cu.Ctx; u.RequireAny(Perms.InventoryAdjust, Perms.InventoryView);
        var s = _db.StockAdjustments.AsNoTracking().AsQueryable();
        if (!string.IsNullOrWhiteSpace(q.Search)) { var t = q.Search.Trim(); s = s.Where(a => a.Number.Contains(t) || a.Reason.Contains(t)); }
        var total = await s.CountAsync();
        var rows = await s.OrderByDescending(a => a.Id).Skip(q.Skip).Take(q.Take).Include(a => a.Lines).ToListAsync();
        return new PagedResult<AdjustmentDto>(rows.Select(a => ToDto(a, null)).ToList(), total, q.Page, q.Take);
    }

    static StockStatus? KindStatus(string kind) => kind switch { "Damage" => StockStatus.Damaged, "Quarantine" => StockStatus.Quarantine, "Scrap" => StockStatus.Scrapped, _ => null };

    public async Task<AdjustmentDto> PostAdjustment(long id)
    {
        _cu.Ctx.Require(Perms.InventoryAdjust);
        await _post.InTransaction(async () =>
        {
            var a = await _guard.Find(_db.StockAdjustments.Include(x => x.Lines), id, "Adjustment");
            if (a.Status is not (DocStatus.Approved or DocStatus.Draft)) throw new ConflictException("This adjustment cannot be posted in its current state.");
            await PostAdjustmentInternal(a);
            return 0;
        });
        return ToDto(await _db.StockAdjustments.AsNoTracking().FirstAsync(x => x.Id == id), null);
    }

    async Task PostAdjustmentInternal(StockAdjustment a)
    {
        var u = _cu.Ctx;
        if (a.Lines.Count == 0) a = await _db.StockAdjustments.Include(x => x.Lines).FirstAsync(x => x.Id == a.Id);
        a.Status = DocStatus.Posted; a.PostedBy = u.UserId; a.PostedAtUtc = DateTime.UtcNow;
        decimal gain = 0, loss = 0; int no = 1;
        foreach (var l in a.Lines)
        {
            var loc = l.LocationId != 0 ? l.LocationId : await _post.DefaultLocation(a.BranchId);
            var qty = Math.Abs(l.QuantityDelta); var net = Math.Abs(l.NetDelta); var gross = Math.Abs(l.GrossDelta);
            decimal fine = 0;
            if (l.PurityId != null) fine = WeightCalc.Fine(net, await _db.Purities.AsNoTracking().Where(p => p.Id == l.PurityId).Select(p => p.Factor).FirstAsync());
            var positive = l.QuantityDelta > 0 || (l.QuantityDelta == 0 && l.NetDelta > 0);
            if (positive)
            {
                await _post.Move(new StockMoveSpec { RefType = TxnType.StockAdjustment, RefId = a.Id, RefNo = a.Number, To = new StockLoc(a.BranchId, loc, StockStatus.Available), ProductId = l.ProductId, MetalTypeId = l.MetalTypeId, PurityId = l.PurityId, Qty = qty, Gross = gross, Net = net, Fine = fine, Cost = Math.Abs(l.CostDelta), Kind = a.Kind == "Opening" ? "Opening" : "Adjustment", Reason = a.Reason });
                gain += Math.Abs(l.CostDelta);
            }
            else
            {
                StockBalance bal = l.ProductId != null ? await _post.FindAvailable(a.BranchId, l.ProductId.Value, qty, null)
                    : await _db.StockBalances.FirstOrDefaultAsync(b => b.BranchId == a.BranchId && b.ProductId == null && b.MetalTypeId == l.MetalTypeId && b.PurityId == l.PurityId && b.Status == StockStatus.Available && b.NetWeight >= net) ?? throw new DomainException("Not enough loose metal to remove.", "negative_stock");
                var cost = CostShare(bal, qty, net);
                var toStatus = l.ToStatus;
                await _post.Move(new StockMoveSpec { RefType = TxnType.StockAdjustment, RefId = a.Id, RefNo = a.Number, From = new StockLoc(a.BranchId, bal.LocationId, StockStatus.Available), To = toStatus != null ? new StockLoc(a.BranchId, bal.LocationId, toStatus.Value) : null, ProductId = l.ProductId, MetalTypeId = l.MetalTypeId, PurityId = l.PurityId, Qty = qty, Gross = gross, Net = net, Fine = fine, Cost = cost, Kind = "Adjustment", Reason = a.Reason });
                if (toStatus == null || toStatus == StockStatus.Scrapped) loss += cost;   // damage/quarantine stay on the books; loss/scrap are written off
            }
            var e = _post.Reg(TxnType.StockAdjustment, a, no++); e.ProductId = l.ProductId; e.MetalTypeId = l.MetalTypeId; e.PurityId = l.PurityId; e.Net = l.NetDelta; e.Gross = l.GrossDelta; e.Fine = positive ? fine : -fine; e.ItemName = a.Kind + ": " + a.Reason; if (positive) e.PkrCredit = Math.Abs(l.CostDelta); else e.PkrDebit = Math.Abs(l.CostDelta);
            if (l.ProductId != null) e.Sku = (await _db.Products.AsNoTracking().Where(p => p.Id == l.ProductId).Select(p => p.Sku).FirstOrDefaultAsync());
        }
        var j = new JournalBuilder();
        if (gain > 0) j.Dr(Acc.InvFinished, gain, "Stock added").Cr(a.Kind == "Opening" ? Acc.OpeningEquity : Acc.StockLoss, gain, a.Kind == "Opening" ? "Opening stock" : "Stock gain");
        if (loss > 0) j.Dr(Acc.StockLoss, loss, "Stock loss / write-off").Cr(Acc.InvFinished, loss, "Stock removed");
        if (j.Lines.Count > 0) await _post.Journal(j, TxnType.StockAdjustment, a.Id, a.Number, a.BranchId, DateTime.UtcNow, "Adjustment " + a.Number);
        _audit.Add("Adjustment.Posted", nameof(StockAdjustment), a.Id, after: new { a.Number, a.Kind, a.TotalValue }, reason: a.Reason, targetBranchId: a.BranchId);
    }

    static AdjustmentDto ToDto(StockAdjustment a, string? pending) => new(a.Id, a.Number, a.Kind, a.Status, a.Reason, a.TotalValue, a.Lines.Count, a.Status == DocStatus.PendingApproval ? "Above your approval limit - waiting for approval." : pending);

    // ================= stock counts =================
    public async Task<CountDto> CreateCount(CountInput i)
    {
        var u = _cu.Ctx; u.Require(Perms.InventoryCount);
        var branch = await _post.PostingBranch(i.BranchId);
        long id = 0;
        await _post.InTransaction(async () =>
        {
            var c = new StockCount { CompanyId = u.CompanyId, BranchId = branch, LocationId = i.LocationId, Number = await _num.Next("CNT", branch), DocDateUtc = DateTime.UtcNow, Notes = i.Notes, Status = DocStatus.Draft };
            var q = _db.StockBalances.AsNoTracking().Where(b => b.BranchId == branch && b.Status == StockStatus.Available && b.Ownership == Ownership.Shop && (b.Quantity > 0 || b.NetWeight > 0));
            if (i.LocationId != null) q = q.Where(b => b.LocationId == i.LocationId);
            foreach (var b in await q.ToListAsync())
                c.Lines.Add(new StockCountLine { ProductId = b.ProductId, MetalTypeId = b.MetalTypeId, PurityId = b.PurityId, LocationId = b.LocationId, SystemQuantity = b.Quantity, SystemNetWeight = b.NetWeight });   // system figures are frozen at sheet creation
            if (c.Lines.Count == 0) throw new DomainException("There is no stock to count in this scope.", "empty_count");
            _db.StockCounts.Add(c);
            await _db.SaveChangesAsync();
            id = c.Id;
            _audit.Add("Count.Created", nameof(StockCount), c.Id, after: new { c.Number, lines = c.Lines.Count }, targetBranchId: branch);
            return 0;
        });
        return await GetCount(id);
    }

    public async Task<CountDto> EnterCount(long id, List<CountEntry> entries)
    {
        _cu.Ctx.Require(Perms.InventoryCount);
        var c = await _guard.Find(_db.StockCounts.Include(x => x.Lines), id, "Stock count");
        if (c.Status != DocStatus.Draft) throw new ConflictException("Counting is closed for this sheet.");
        foreach (var e in entries)
        {
            var l = c.Lines.FirstOrDefault(x => x.Id == e.LineId) ?? throw new ValidationFailedException("lines", "Line does not belong to this count.");
            if (e.CountedQuantity < 0 || e.CountedNetWeight < 0) throw new ValidationFailedException("lines", "Counted values cannot be negative.");
            l.CountedQuantity = e.CountedQuantity; l.CountedNetWeight = e.CountedNetWeight; l.VarianceNote = e.Note;
        }
        await _db.SaveChangesAsync();
        return await GetCount(id);
    }

    public async Task<CountDto> SubmitCount(long id)
    {
        _cu.Ctx.Require(Perms.InventoryCount);
        var c = await _guard.Find(_db.StockCounts.Include(x => x.Lines), id, "Stock count");
        if (c.Status != DocStatus.Draft) throw new ConflictException("This count was already submitted.");
        if (c.Lines.Any(l => l.CountedQuantity == null && l.CountedNetWeight == null)) throw new ValidationFailedException("lines", "Enter the physical count for every line before submitting.");
        var tol = await _settings.Dec(SettingsService.Keys.CountTolGrams, c.BranchId);
        foreach (var l in c.Lines)
        {
            var qv = (l.CountedQuantity ?? l.SystemQuantity) - l.SystemQuantity; var nv = (l.CountedNetWeight ?? l.SystemNetWeight) - l.SystemNetWeight;
            if ((qv != 0 || Math.Abs(nv) > tol) && string.IsNullOrWhiteSpace(l.VarianceNote)) throw new ValidationFailedException("lines", "Every variance needs a note before submitting.");
        }
        c.Status = DocStatus.PendingApproval;
        await _audit.Save("Count.Submitted", nameof(StockCount), c.Id, targetBranchId: c.BranchId);
        return await GetCount(id);
    }

    /// <summary>The approver must differ from the person who created the count (separation of duties). Approval posts the variance as a stock adjustment.</summary>
    public async Task<CountDto> ApproveCount(long id, bool approve, string? reason)
    {
        var u = _cu.Ctx; u.Require(Perms.InventoryCountApprove);
        await _post.InTransaction(async () =>
        {
            var c = await _guard.Find(_db.StockCounts.Include(x => x.Lines), id, "Stock count");
            if (c.Status != DocStatus.PendingApproval) throw new ConflictException("This count is not waiting for approval.");
            u.RequireBranch(c.BranchId);
            if (c.CreatedBy == u.UserId) throw new ForbiddenException("You cannot approve a count you created (separation of duties).", "separation_of_duties");
            if (!approve) { c.Status = DocStatus.Cancelled; c.ApprovalNote = reason; _audit.Add("Count.Rejected", nameof(StockCount), c.Id, reason: reason, targetBranchId: c.BranchId); return 0; }
            var tol = await _settings.Dec(SettingsService.Keys.CountTolGrams, c.BranchId);
            var adj = new StockAdjustment { CompanyId = u.CompanyId, BranchId = c.BranchId, Number = await _num.Next("ADJ", c.BranchId), DocDateUtc = DateTime.UtcNow, Kind = "Adjustment", Reason = "Stock count " + c.Number, StockCountId = c.Id, Status = DocStatus.Draft, ApprovedBy = u.UserId, ApprovedAtUtc = DateTime.UtcNow };
            decimal value = 0;
            foreach (var l in c.Lines)
            {
                var qv = (l.CountedQuantity ?? l.SystemQuantity) - l.SystemQuantity; var nv = Money.R3((l.CountedNetWeight ?? l.SystemNetWeight) - l.SystemNetWeight);
                if (qv == 0 && Math.Abs(nv) <= tol && l.ProductId != null) continue;
                if (qv == 0 && nv == 0) continue;
                var p = l.ProductId != null ? await _db.Products.AsNoTracking().FirstAsync(x => x.Id == l.ProductId) : null;
                var cost = Money.R2((p?.CostPrice ?? 0m) * Math.Abs(qv)) * (qv < 0 ? -1 : 1);
                value += Math.Abs(cost);
                adj.Lines.Add(new StockAdjustmentLine { ProductId = l.ProductId, MetalTypeId = l.MetalTypeId ?? p?.MetalTypeId, PurityId = l.PurityId ?? p?.PurityId, LocationId = l.LocationId, QuantityDelta = l.ProductId != null ? qv : 0, NetDelta = l.ProductId != null ? (p != null ? Money.R3(p.NetMetalWeight * qv) : nv) : nv, GrossDelta = l.ProductId != null && p != null ? Money.R3(p.GrossWeight * qv) : nv, CostDelta = cost });
            }
            adj.TotalValue = Money.R2(value);
            c.ApprovalNote = reason;
            if (adj.Lines.Count > 0) { _db.StockAdjustments.Add(adj); await _db.SaveChangesAsync(); await PostAdjustmentInternal(adj); }
            c.Status = DocStatus.Posted; c.PostedBy = u.UserId; c.PostedAtUtc = DateTime.UtcNow; c.ApprovedBy = u.UserId; c.ApprovedAtUtc = DateTime.UtcNow;
            _audit.Add("Count.Approved", nameof(StockCount), c.Id, after: new { adjustments = adj.Lines.Count, adj.TotalValue }, reason: reason, targetBranchId: c.BranchId);
            return 0;
        });
        return await GetCount(id);
    }

    public async Task<CountDto> GetCount(long id)
    {
        _cu.Ctx.RequireAny(Perms.InventoryCount, Perms.InventoryView);
        var c = await _guard.Find(_db.StockCounts.AsNoTracking().Include(x => x.Lines), id, "Stock count");
        var pids = c.Lines.Where(l => l.ProductId != null).Select(l => l.ProductId!.Value).ToList();
        var prods = await _db.Products.AsNoTracking().Where(p => pids.Contains(p.Id)).ToDictionaryAsync(p => p.Id, p => p);
        var pur = await _db.Purities.AsNoTracking().ToDictionaryAsync(p => p.Id, p => p.Label);
        return new CountDto(c.Id, c.Number, c.BranchId, c.Status, c.LocationId, c.Notes, c.Lines.Select(l =>
        {
            prods.TryGetValue(l.ProductId ?? 0, out var p);
            return new CountLineDto(l.Id, l.ProductId, p?.Sku, p?.Name ?? "Loose metal", (l.PurityId ?? p?.PurityId) is long pu ? pur.GetValueOrDefault(pu) : null, l.LocationId, l.SystemQuantity, l.SystemNetWeight, l.CountedQuantity, l.CountedNetWeight,
                l.CountedQuantity == null ? null : l.CountedQuantity - l.SystemQuantity, l.CountedNetWeight == null ? null : Money.R3(l.CountedNetWeight.Value - l.SystemNetWeight), l.VarianceNote);
        }).ToList());
    }

    public async Task<PagedResult<CountDto>> ListCounts(PageQuery q)
    {
        _cu.Ctx.RequireAny(Perms.InventoryCount, Perms.InventoryView);
        var s = _db.StockCounts.AsNoTracking();
        var total = await s.CountAsync();
        var ids = await s.OrderByDescending(c => c.Id).Skip(q.Skip).Take(q.Take).Select(c => c.Id).ToListAsync();
        var items = new List<CountDto>(); foreach (var id in ids) items.Add(await GetCount(id));
        return new PagedResult<CountDto>(items, total, q.Page, q.Take);
    }

    // ================= reservations =================
    public async Task ExpireReservations()
    {
        var due = await _db.StockReservations.Where(r => r.IsActive && r.ReservedUntilUtc < DateTime.UtcNow).Take(200).ToListAsync();
        foreach (var r in due) await ReleaseInternal(r, "Reservation expired");
        if (due.Count > 0) await _db.SaveChangesAsync();
    }

    public async Task<ReservationDto> Reserve(ReserveInput i)
    {
        var u = _cu.Ctx; u.Require(Perms.InventoryReserve);
        var branch = await _post.PostingBranch(i.BranchId);
        if (i.Hours < 1 || i.Hours > 24 * 30) throw new ValidationFailedException("hours", "Reservation must be 1 hour to 30 days.");
        long id = 0;
        await _post.InTransaction(async () =>
        {
            var p = await _db.Products.AsNoTracking().FirstOrDefaultAsync(x => x.Id == i.ProductId && x.IsActive) ?? throw new NotFoundException("Item");
            var bal = await _post.FindAvailable(branch, p.Id, 1, p.Sku);
            await _post.Move(new StockMoveSpec { RefType = TxnType.StockAdjustment, RefId = p.Id, RefNo = "RESERVE", From = new StockLoc(branch, bal.LocationId, StockStatus.Available), To = new StockLoc(branch, bal.LocationId, StockStatus.Reserved), ProductId = p.Id, MetalTypeId = p.MetalTypeId, PurityId = p.PurityId, Qty = 1, Gross = p.GrossWeight, Stone = p.StoneWeight, Net = p.NetMetalWeight, Cost = p.CostPrice, Kind = "Move", Reason = "Reserved" });
            var r = new StockReservation { CompanyId = u.CompanyId, BranchId = branch, ProductId = p.Id, CustomerId = i.CustomerId, ReservedUntilUtc = DateTime.UtcNow.AddHours(i.Hours), Note = i.Note };
            _db.StockReservations.Add(r);
            await _db.SaveChangesAsync();
            id = r.Id;
            _audit.Add("Stock.Reserved", nameof(StockReservation), r.Id, after: new { p.Sku, i.Hours }, targetBranchId: branch);
            return 0;
        });
        var res = await _db.StockReservations.AsNoTracking().FirstAsync(x => x.Id == id);
        var prod = await _db.Products.AsNoTracking().FirstAsync(x => x.Id == res.ProductId);
        return new ReservationDto(res.Id, res.ProductId, prod.Sku, prod.Name, res.CustomerId, res.ReservedUntilUtc, res.Note, res.IsActive);
    }

    public async Task Release(long reservationId)
    {
        _cu.Ctx.Require(Perms.InventoryReserve);
        await _post.InTransaction(async () =>
        {
            var r = await _guard.Find(_db.StockReservations, reservationId, "Reservation");
            if (!r.IsActive) throw new ConflictException("The reservation is already released.");
            await ReleaseInternal(r, "Reservation released");
            return 0;
        });
    }

    async Task ReleaseInternal(StockReservation r, string reason)
    {
        var p = await _db.Products.AsNoTracking().FirstAsync(x => x.Id == r.ProductId);
        var bal = await _db.StockBalances.FirstOrDefaultAsync(b => b.BranchId == r.BranchId && b.ProductId == r.ProductId && b.Status == StockStatus.Reserved && b.Quantity > 0);
        if (bal != null)
            await _post.Move(new StockMoveSpec { RefType = TxnType.StockAdjustment, RefId = p.Id, RefNo = "RELEASE", From = new StockLoc(r.BranchId, bal.LocationId, StockStatus.Reserved), To = new StockLoc(r.BranchId, bal.LocationId, StockStatus.Available), ProductId = p.Id, MetalTypeId = p.MetalTypeId, PurityId = p.PurityId, Qty = 1, Gross = p.GrossWeight, Stone = p.StoneWeight, Net = p.NetMetalWeight, Cost = p.CostPrice, Kind = "Move", Reason = reason });
        r.IsActive = false;
    }

    public async Task<List<ReservationDto>> Reservations(bool activeOnly = true)
    {
        _cu.Ctx.RequireAny(Perms.InventoryView, Perms.InventoryReserve);
        await ExpireReservations();
        var rows = await _db.StockReservations.AsNoTracking().Where(r => !activeOnly || r.IsActive).OrderByDescending(r => r.Id).Take(200).ToListAsync();
        var pids = rows.Select(r => r.ProductId).Distinct().ToList();
        var prods = await _db.Products.AsNoTracking().Where(p => pids.Contains(p.Id)).ToDictionaryAsync(p => p.Id, p => p);
        return rows.Select(r => new ReservationDto(r.Id, r.ProductId, prods[r.ProductId].Sku, prods[r.ProductId].Name, r.CustomerId, r.ReservedUntilUtc, r.Note, r.IsActive)).ToList();
    }

    // ================= ledger vs balance reconciliation (SRS 3.8) =================
    /// <summary>Rebuilds every balance from the immutable movement ledger and lists any difference with the materialised balance table.</summary>
    public async Task<List<ReconcileRow>> Reconcile(long[]? branchIds)
    {
        var u = _cu.Ctx; u.RequireAny(Perms.InventoryView, Perms.ReportsStock);
        var branches = u.ResolveScope(branchIds);
        var incoming = await _db.StockMovements.AsNoTracking().Where(m => m.ToBranchId != null && branches.Contains(m.ToBranchId.Value))
            .GroupBy(m => new { B = m.ToBranchId, L = m.ToLocationId, m.ProductId, m.MetalTypeId, m.PurityId, S = m.ToStatus, O = m.Ownership, C = m.CustodyRefId })
            .Select(g => new { g.Key.B, g.Key.L, g.Key.ProductId, g.Key.MetalTypeId, g.Key.PurityId, g.Key.S, g.Key.O, g.Key.C, Q = g.Sum(x => x.Quantity), N = g.Sum(x => x.NetWeight) }).ToListAsync();
        var outgoing = await _db.StockMovements.AsNoTracking().Where(m => m.FromBranchId != null && branches.Contains(m.FromBranchId.Value))
            .GroupBy(m => new { B = m.FromBranchId, L = m.FromLocationId, m.ProductId, m.MetalTypeId, m.PurityId, S = m.FromStatus, O = m.FromOwnership, C = m.FromCustodyRefId })
            .Select(g => new { g.Key.B, g.Key.L, g.Key.ProductId, g.Key.MetalTypeId, g.Key.PurityId, g.Key.S, g.Key.O, g.Key.C, Q = g.Sum(x => x.Quantity), N = g.Sum(x => x.NetWeight) }).ToListAsync();
        var ledger = new Dictionary<string, (decimal q, decimal n)>();
        string K(object? b, object? l, object? p, object? m, object? pu, object? s, object? o, object? c) => $"{b}|{l}|{p}|{m}|{pu}|{(int?)(s as StockStatus?)}|{(int?)(o as Ownership?)}|{c}";
        foreach (var x in incoming) { var k = K(x.B, x.L, x.ProductId, x.MetalTypeId, x.PurityId, x.S, x.O, x.C); ledger[k] = ledger.TryGetValue(k, out var v) ? (v.q + x.Q, v.n + x.N) : (x.Q, x.N); }
        foreach (var x in outgoing) { var k = K(x.B, x.L, x.ProductId, x.MetalTypeId, x.PurityId, x.S, x.O, x.C); ledger[k] = ledger.TryGetValue(k, out var v) ? (v.q - x.Q, v.n - x.N) : (-x.Q, -x.N); }
        var bals = await _db.StockBalances.AsNoTracking().Where(b => branches.Contains(b.BranchId)).ToListAsync();
        var res = new List<ReconcileRow>(); var seen = new HashSet<string>();
        foreach (var b in bals)
        {
            var k = K(b.BranchId, b.LocationId, b.ProductId, b.MetalTypeId, b.PurityId, b.Status, b.Ownership, b.CustodyRefId); seen.Add(k);
            ledger.TryGetValue(k, out var lv);
            if (Money.R3(lv.q) != Money.R3(b.Quantity) || Money.R3(lv.n) != Money.R3(b.NetWeight)) res.Add(new ReconcileRow(k, lv.q, b.Quantity, lv.n, b.NetWeight));
        }
        foreach (var kv in ledger.Where(kv => !seen.Contains(kv.Key) && (Money.R3(kv.Value.q) != 0 || Money.R3(kv.Value.n) != 0))) res.Add(new ReconcileRow(kv.Key, kv.Value.q, 0, kv.Value.n, 0));
        return res;
    }
}
