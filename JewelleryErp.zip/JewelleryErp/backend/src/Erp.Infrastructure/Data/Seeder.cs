using System.Security.Cryptography;
using Erp.Domain;
using Erp.Domain.Calc;
using Erp.Domain.Entities;
using Erp.Infrastructure.Services;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace Erp.Infrastructure.Data;

/// <summary>Idempotent bootstrap: safe to run on every start. Never overwrites a role/setting an administrator already changed.</summary>
public static class DbSeeder
{
    public static async Task RunAsync(IServiceProvider root, IConfiguration cfg, bool isDevelopment, ILogger log)
    {
        using var scope = root.CreateScope();
        scope.ServiceProvider.GetRequiredService<DbScope>().Bypass = true;   // system work: bypass the per-user query filters
        var db = scope.ServiceProvider.GetRequiredService<ErpDbContext>();
        if (cfg.GetValue("Database:AutoCreate", isDevelopment)) await db.Database.EnsureCreatedAsync(); else await db.Database.MigrateAsync();

        var company = await db.Companies.FirstOrDefaultAsync();
        if (company == null) { company = new Company { Name = cfg["Seed:CompanyName"] ?? "Jewellery Retail Co.", BaseCurrency = "PKR" }; db.Companies.Add(company); await db.SaveChangesAsync(); }
        var cid = company.Id;

        // ---- branch + locations ----
        var hq = await db.Branches.FirstOrDefaultAsync(b => b.IsHeadOffice);
        if (hq == null)
        {
            hq = new Branch { CompanyId = cid, BranchCode = "HO", BranchName = "Head Office", City = cfg["Seed:City"] ?? "Lahore", IsHeadOffice = true, BranchType = "HeadOffice", InvoicePrefix = "HO" };
            db.Branches.Add(hq); await db.SaveChangesAsync();
            foreach (var (code, name, kind, def) in new[] { ("SHW", "Showroom", "Showroom", true), ("VLT", "Vault", "Vault", false), ("INS", "Inspection", "Inspection", false), ("WSP", "Workshop", "Workshop", false) })
                db.StoreLocations.Add(new StoreLocation { CompanyId = cid, BranchId = hq.Id, Code = code, Name = name, Kind = kind, IsDefault = def });
            await db.SaveChangesAsync();
        }

        // ---- permissions & roles ----
        var have = await db.Permissions.Select(p => p.Code).ToListAsync();
        foreach (var code in Perms.All.Except(have)) db.Permissions.Add(new Permission { Code = code, Module = Perms.ModuleOf(code), Description = code.Replace('.', ' ') });
        await db.SaveChangesAsync();
        var pmap = await db.Permissions.ToDictionaryAsync(p => p.Code, p => p.Id);
        var limitsByRole = new Dictionary<string, (ApprovalType t, decimal v)[]>
        {
            [RoleTemplates.Cashier] = new[] { (ApprovalType.DiscountOverLimit, 5m), (ApprovalType.RefundOverLimit, 50_000m), (ApprovalType.RateOverride, 0.5m) },
            [RoleTemplates.BranchManager] = new[] { (ApprovalType.DiscountOverLimit, 15m), (ApprovalType.ExpenseOverLimit, 100_000m), (ApprovalType.StockAdjustment, 500_000m), (ApprovalType.RefundOverLimit, 500_000m), (ApprovalType.RateOverride, 2m) },
            [RoleTemplates.Accountant] = new[] { (ApprovalType.ExpenseOverLimit, 500_000m) },
            [RoleTemplates.Inventory] = new[] { (ApprovalType.StockAdjustment, 100_000m) },
        };
        foreach (var (name, perms) in RoleTemplates.Defaults())
        {
            var role = await db.Roles.FirstOrDefaultAsync(r => r.Name == name);
            if (role == null)
            {
                role = new Role { CompanyId = cid, Name = name, IsSystem = true, Description = "Default template - adjust to the business's approved matrix" };
                db.Roles.Add(role); await db.SaveChangesAsync();
                foreach (var p in perms) db.RolePermissions.Add(new RolePermission { RoleId = role.Id, PermissionId = pmap[p] });
                if (limitsByRole.TryGetValue(name, out var lim)) foreach (var (t, v) in lim) db.ApprovalLimits.Add(new ApprovalLimit { CompanyId = cid, RoleId = role.Id, Type = t, MaxValue = v });
            }
            else if (name == RoleTemplates.Owner)
            {
                var haveP = await db.RolePermissions.Where(x => x.RoleId == role.Id).Select(x => x.PermissionId).ToListAsync();
                foreach (var p in perms.Where(p => !haveP.Contains(pmap[p]))) db.RolePermissions.Add(new RolePermission { RoleId = role.Id, PermissionId = pmap[p] });   // new releases add new permissions to the owner only
            }
            await db.SaveChangesAsync();
        }

        // ---- chart of accounts ----
        var coa = new (string code, string name, AccountType type, bool control)[]
        {
            (Acc.Cash, "Cash in Hand", AccountType.Asset, false), (Acc.Bank, "Bank - Main Account", AccountType.Asset, false), (Acc.Receivable, "Accounts Receivable", AccountType.Asset, true),
            (Acc.InvFinished, "Inventory - Finished Goods", AccountType.Asset, true), (Acc.InvRawMetal, "Inventory - Raw Metal", AccountType.Asset, true), (Acc.InvOldGold, "Inventory - Old Gold / Unrefined", AccountType.Asset, true), (Acc.MetalWithWorkers, "Metal With Workers (WIP)", AccountType.Asset, true),
            (Acc.Payable, "Accounts Payable - Suppliers", AccountType.Liability, true), (Acc.WorkerPayable, "Worker Payable", AccountType.Liability, true), (Acc.CustomerAdvances, "Customer Advances & Credits", AccountType.Liability, true), (Acc.TaxPayable, "Tax Payable", AccountType.Liability, false), (Acc.CommissionPayable, "Commission Payable", AccountType.Liability, false),
            (Acc.Equity, "Owner's Equity", AccountType.Equity, false), (Acc.RetainedEarnings, "Retained Earnings", AccountType.Equity, false), (Acc.OpeningEquity, "Opening Balance Equity", AccountType.Equity, false),
            (Acc.SalesRevenue, "Sales Revenue", AccountType.Revenue, false), (Acc.RepairIncome, "Repair Income", AccountType.Revenue, false), (Acc.SalesReturns, "Sales Returns", AccountType.Revenue, false), (Acc.OtherIncome, "Other Income", AccountType.Revenue, false), (Acc.RoundingAdj, "Rounding Adjustments", AccountType.Revenue, false),
            (Acc.Cogs, "Cost of Goods Sold", AccountType.Expense, false), (Acc.StockLoss, "Stock Loss / Adjustments", AccountType.Expense, false), (Acc.CommissionExpense, "Commission Expense", AccountType.Expense, false), (Acc.MetalLoss, "Metal Process Loss", AccountType.Expense, false), (Acc.CashShortage, "Cash Over / Short", AccountType.Expense, false),
            ("6000", "Rent", AccountType.Expense, false), ("6010", "Salaries", AccountType.Expense, false), ("6020", "Utilities", AccountType.Expense, false), ("6030", "Security", AccountType.Expense, false), ("6040", "Repair Tools", AccountType.Expense, false),
            ("6050", "Transport", AccountType.Expense, false), ("6060", "Packaging", AccountType.Expense, false), ("6070", "Marketing", AccountType.Expense, false), ("6080", "Bank Charges", AccountType.Expense, false), (Acc.ExpMisc, "Miscellaneous Expense", AccountType.Expense, false),
        };
        var existingCoa = await db.ChartAccounts.ToDictionaryAsync(a => a.Code, a => a.Id);
        foreach (var a in coa.Where(a => !existingCoa.ContainsKey(a.code))) db.ChartAccounts.Add(new ChartAccount { CompanyId = cid, Code = a.code, Name = a.name, Type = a.type, IsControl = a.control });
        await db.SaveChangesAsync();
        var coaId = await db.ChartAccounts.ToDictionaryAsync(a => a.Code, a => a.Id);

        // ---- cash & bank accounts (each with its own ledger account) ----
        if (!await db.CashBankAccounts.AnyAsync())
        {
            var cash = new CashBankAccount { CompanyId = cid, Type = CashBankType.Cash, Name = "Main Cash", ChartAccountId = coaId[Acc.Cash] };
            var bank = new CashBankAccount { CompanyId = cid, Type = CashBankType.Bank, Name = "Main Bank Account", BankName = "(set bank)", ChartAccountId = coaId[Acc.Bank] };
            db.CashBankAccounts.AddRange(cash, bank); await db.SaveChangesAsync(); hq.DefaultCashAccountId = cash.Id; await db.SaveChangesAsync();
        }

        // ---- masters ----
        if (!await db.MetalTypes.AnyAsync())
        {
            var gold = new MetalType { CompanyId = cid, Code = "GOLD", Name = "Gold", NameUrdu = "سونا" }; var silver = new MetalType { CompanyId = cid, Code = "SILVER", Name = "Silver", NameUrdu = "چاندی" }; var plat = new MetalType { CompanyId = cid, Code = "PLATINUM", Name = "Platinum" };
            db.MetalTypes.AddRange(gold, silver, plat); await db.SaveChangesAsync();
            foreach (var k in new[] { 24m, 22m, 21m, 18m, 14m }) db.Purities.Add(new Purity { CompanyId = cid, MetalTypeId = gold.Id, Label = $"{k}K", Karat = k, Factor = WeightCalc.KaratFactor(k) });   // conventional k/24 default; editable per the shop's assay rules
            db.Purities.Add(new Purity { CompanyId = cid, MetalTypeId = silver.Id, Label = "999", Karat = 0, Factor = 0.999m }); db.Purities.Add(new Purity { CompanyId = cid, MetalTypeId = silver.Id, Label = "925", Karat = 0, Factor = 0.925m });
            db.Purities.Add(new Purity { CompanyId = cid, MetalTypeId = plat.Id, Label = "950", Karat = 0, Factor = 0.950m });
            await db.SaveChangesAsync();
        }
        if (!await db.Units.AnyAsync())
        {
            var units = new[] { ("g", "Gram", true, 1m, true), ("mg", "Milligram", true, 0.001m, true), ("kg", "Kilogram", true, 1000m, true), ("tola", "Tola", true, 0m, false), ("ratti", "Ratti", true, 0m, false), ("pc", "Piece", false, 0m, false) };
            foreach (var (code, name, metal, f, ok) in units)
            {
                var u = new Unit { CompanyId = cid, Code = code, Name = name, IsMetalWeight = metal }; db.Units.Add(u); await db.SaveChangesAsync();
                if (metal) db.UnitConversions.Add(new UnitConversion { CompanyId = cid, UnitId = u.Id, FactorToGram = ok ? f : null, IsApproved = ok, ApprovalNote = ok ? "SI definition" : "NOT APPROVED - confirm the shop's written conversion in Settings before use" });
            }
            await db.SaveChangesAsync();
        }
        if (!await db.PaymentMethods.AnyAsync())
        {
            db.PaymentMethods.AddRange(new PaymentMethod { CompanyId = cid, Name = "Cash", Kind = "Cash" }, new PaymentMethod { CompanyId = cid, Name = "Bank Transfer", Kind = "Bank" }, new PaymentMethod { CompanyId = cid, Name = "Card", Kind = "Card" }, new PaymentMethod { CompanyId = cid, Name = "Cheque", Kind = "Cheque" }, new PaymentMethod { CompanyId = cid, Name = "Digital Wallet", Kind = "Digital" });
            await db.SaveChangesAsync();
        }
        if (!await db.ExpenseHeads.AnyAsync())
        {
            foreach (var (n, code) in new[] { ("Rent", "6000"), ("Salaries", "6010"), ("Utilities", "6020"), ("Security", "6030"), ("Repair tools", "6040"), ("Transport", "6050"), ("Packaging", "6060"), ("Marketing", "6070"), ("Bank charges", "6080"), ("Miscellaneous", Acc.ExpMisc) })
                db.ExpenseHeads.Add(new ExpenseHead { CompanyId = cid, Name = n, AccountId = coaId[code] });
            await db.SaveChangesAsync();
        }
        if (!await db.ProductCategories.AnyAsync())
        {
            foreach (var n in new[] { "Rings", "Necklaces", "Bangles", "Earrings", "Bracelets", "Chains", "Pendants", "Sets", "Bullion & Coins", "Accessories" }) db.ProductCategories.Add(new ProductCategory { CompanyId = cid, Name = n });
            await db.SaveChangesAsync();
        }

        // ---- bootstrap administrator ----
        if (!await db.Users.AnyAsync())
        {
            var pw = cfg["Seed:AdminPassword"]; var generated = false;
            if (string.IsNullOrWhiteSpace(pw) && isDevelopment) { pw = "Adm" + Convert.ToHexString(RandomNumberGenerator.GetBytes(6)).ToLowerInvariant() + "!9"; generated = true; }
            if (string.IsNullOrWhiteSpace(pw)) log.LogWarning("No users exist and Seed:AdminPassword is not configured; no administrator was created.");
            else
            {
                var admin = new AppUser { CompanyId = cid, UserName = cfg["Seed:AdminUser"] ?? "admin", Email = cfg["Seed:AdminEmail"] ?? "admin@example.local", FullName = "System Owner", IsSuperAdmin = true, DefaultBranchId = hq.Id, MustChangePassword = true };
                AuthService.SetPassword(admin, pw); admin.MustChangePassword = true; db.Users.Add(admin); await db.SaveChangesAsync();
                db.UserRoles.Add(new UserRole { UserId = admin.Id, RoleId = (await db.Roles.FirstAsync(r => r.Name == RoleTemplates.Owner)).Id });
                db.UserBranchAccess.Add(new UserBranchAccess { UserId = admin.Id, BranchId = hq.Id, IsDefault = true }); await db.SaveChangesAsync();
                if (generated) Console.WriteLine($"\n=== ONE-TIME DEVELOPMENT BOOTSTRAP ===\n user: {admin.UserName}\n password: {pw}\n (you must change it at first sign-in; this is printed once and never logged)\n=======================================\n");
            }
        }

        if (cfg.GetValue("Seed:Demo", false)) await Demo(db, cfg, cid, hq.Id, log);
    }

    static async Task Demo(ErpDbContext db, IConfiguration cfg, long cid, long branchId, ILogger log)
    {
        if (await db.Customers.AnyAsync()) return;
        db.Customers.AddRange(new Customer { CompanyId = cid, Code = "CUS-DEMO-1", Name = "Ayesha Khan", Phone = "0300-1111111", City = "Lahore" }, new Customer { CompanyId = cid, Code = "CUS-DEMO-2", Name = "Bilal Ahmed", Phone = "0321-2222222", City = "Lahore", OpeningBalance = 0 });
        db.Suppliers.AddRange(new Supplier { CompanyId = cid, Code = "SUP-DEMO-1", Name = "Sarafa Bazaar Traders", Phone = "042-3333333", City = "Lahore" });
        var emp = new Employee { CompanyId = cid, Code = "EMP-DEMO-1", Name = "Usman (Salesman)", JobTitle = "Salesman", BranchId = branchId }; db.Employees.Add(emp);
        db.Workers.AddRange(new Worker { CompanyId = cid, Code = "WRK-DEMO-1", Name = "Ustad Rafiq (Karigar)", Skills = "Casting, setting", RateType = ChargeType.PerGram, RateValue = 350, DefaultWastagePercent = 1 });
        await db.SaveChangesAsync();
        db.SalesmanProfiles.Add(new SalesmanProfile { CompanyId = cid, EmployeeId = emp.Id, CommissionType = CommissionType.Percent, CommissionValue = 1 });
        // demo rate card so the POS works immediately (illustrative numbers - set the real card in Gold Rates)
        var gold = await db.MetalTypes.FirstAsync(m => m.Code == "GOLD"); var silver = await db.MetalTypes.FirstAsync(m => m.Code == "SILVER");
        foreach (var p in await db.Purities.Where(p => p.MetalTypeId == gold.Id || p.MetalTypeId == silver.Id).ToListAsync())
        {
            var perGram = p.MetalTypeId == gold.Id ? 24000m * p.Factor : 300m * p.Factor;
            db.GoldRates.Add(new GoldRate { CompanyId = cid, MetalTypeId = p.MetalTypeId, PurityId = p.Id, BuyRate = Math.Round(perGram * 0.985m, 2), SellRate = Math.Round(perGram, 2), EffectiveFromUtc = DateTime.UtcNow.AddMinutes(-1), Reason = "Demo seed", Source = "Manual" });
        }
        var rings = await db.ProductCategories.FirstAsync(c => c.Name == "Rings"); var p22 = await db.Purities.FirstAsync(p => p.MetalTypeId == gold.Id && p.Label == "22K");
        db.Products.AddRange(
            new Product { CompanyId = cid, Sku = "R-0001", Barcode = "R-0001", Name = "Solitaire style ring", CategoryId = rings.Id, MetalTypeId = gold.Id, PurityId = p22.Id, GrossWeight = 6.250m, StoneWeight = 0.250m, NetMetalWeight = 6.000m, StoneValue = 15000, MakingType = ChargeType.PerGram, MakingValue = 600, PricingMode = PricingMode.MetalStoneMakingWastage, WastagePercent = 1, CostPrice = 150000, DefaultBranchId = branchId },
            new Product { CompanyId = cid, Sku = "R-0002", Barcode = "R-0002", Name = "Plain band", CategoryId = rings.Id, MetalTypeId = gold.Id, PurityId = p22.Id, GrossWeight = 4.100m, NetMetalWeight = 4.100m, MakingType = ChargeType.PerGram, MakingValue = 450, PricingMode = PricingMode.MetalPlusMaking, CostPrice = 95000, DefaultBranchId = branchId });
        await db.SaveChangesAsync();
        log.LogInformation("Demo master data seeded (customers, supplier, salesman, karigar, rate card, 2 catalogue items). Receive stock through Purchases or an Opening adjustment.");
    }
}
