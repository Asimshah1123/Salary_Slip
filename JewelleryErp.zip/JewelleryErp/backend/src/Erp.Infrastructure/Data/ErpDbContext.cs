using System.Reflection;
using System.Text.RegularExpressions;
using Erp.Domain;
using Erp.Domain.Entities;
using Microsoft.EntityFrameworkCore;

namespace Erp.Infrastructure.Data;

public class ErpDbContext : DbContext
{
    readonly DbScope _scope;
    public ErpDbContext(DbContextOptions<ErpDbContext> options, DbScope scope) : base(options) { _scope = scope; }
    public DbScope Scope => _scope;

    // organization & security
    public DbSet<Company> Companies => Set<Company>();
    public DbSet<Branch> Branches => Set<Branch>();
    public DbSet<StoreLocation> StoreLocations => Set<StoreLocation>();
    public DbSet<AppSetting> AppSettings => Set<AppSetting>();
    public DbSet<InvoiceSequence> InvoiceSequences => Set<InvoiceSequence>();
    public DbSet<AppUser> Users => Set<AppUser>();
    public DbSet<Role> Roles => Set<Role>();
    public DbSet<Permission> Permissions => Set<Permission>();
    public DbSet<RolePermission> RolePermissions => Set<RolePermission>();
    public DbSet<UserRole> UserRoles => Set<UserRole>();
    public DbSet<UserBranchAccess> UserBranchAccess => Set<UserBranchAccess>();
    public DbSet<RefreshToken> RefreshTokens => Set<RefreshToken>();
    public DbSet<LoginAttempt> LoginAttempts => Set<LoginAttempt>();
    public DbSet<PasswordResetToken> PasswordResetTokens => Set<PasswordResetToken>();
    public DbSet<AuditLog> AuditLogs => Set<AuditLog>();
    public DbSet<ApprovalLimit> ApprovalLimits => Set<ApprovalLimit>();
    public DbSet<ApprovalRequest> ApprovalRequests => Set<ApprovalRequest>();
    // masters
    public DbSet<ProductCategory> ProductCategories => Set<ProductCategory>();
    public DbSet<MetalType> MetalTypes => Set<MetalType>();
    public DbSet<Purity> Purities => Set<Purity>();
    public DbSet<Unit> Units => Set<Unit>();
    public DbSet<UnitConversion> UnitConversions => Set<UnitConversion>();
    public DbSet<StoneType> StoneTypes => Set<StoneType>();
    public DbSet<GoldRate> GoldRates => Set<GoldRate>();
    public DbSet<ExpenseHead> ExpenseHeads => Set<ExpenseHead>();
    public DbSet<PaymentMethod> PaymentMethods => Set<PaymentMethod>();
    public DbSet<Product> Products => Set<Product>();
    public DbSet<FileAsset> Files => Set<FileAsset>();
    // parties
    public DbSet<Customer> Customers => Set<Customer>();
    public DbSet<Supplier> Suppliers => Set<Supplier>();
    public DbSet<Employee> Employees => Set<Employee>();
    public DbSet<SalesmanProfile> SalesmanProfiles => Set<SalesmanProfile>();
    public DbSet<Worker> Workers => Set<Worker>();
    // inventory
    public DbSet<StockBalance> StockBalances => Set<StockBalance>();
    public DbSet<StockMovement> StockMovements => Set<StockMovement>();
    public DbSet<StockTransfer> StockTransfers => Set<StockTransfer>();
    public DbSet<StockTransferLine> StockTransferLines => Set<StockTransferLine>();
    public DbSet<StockAdjustment> StockAdjustments => Set<StockAdjustment>();
    public DbSet<StockAdjustmentLine> StockAdjustmentLines => Set<StockAdjustmentLine>();
    public DbSet<StockCount> StockCounts => Set<StockCount>();
    public DbSet<StockCountLine> StockCountLines => Set<StockCountLine>();
    public DbSet<StockReservation> StockReservations => Set<StockReservation>();
    // sales
    public DbSet<SalesInvoice> SalesInvoices => Set<SalesInvoice>();
    public DbSet<SalesInvoiceLine> SalesInvoiceLines => Set<SalesInvoiceLine>();
    public DbSet<SalesPayment> SalesPayments => Set<SalesPayment>();
    public DbSet<SalesReturn> SalesReturns => Set<SalesReturn>();
    public DbSet<SalesReturnLine> SalesReturnLines => Set<SalesReturnLine>();
    public DbSet<SalesReturnRefund> SalesReturnRefunds => Set<SalesReturnRefund>();
    public DbSet<OldGoldTransaction> OldGoldTransactions => Set<OldGoldTransaction>();
    // purchasing
    public DbSet<PurchaseOrder> PurchaseOrders => Set<PurchaseOrder>();
    public DbSet<PurchaseOrderLine> PurchaseOrderLines => Set<PurchaseOrderLine>();
    public DbSet<PurchaseInvoice> PurchaseInvoices => Set<PurchaseInvoice>();
    public DbSet<PurchaseInvoiceLine> PurchaseInvoiceLines => Set<PurchaseInvoiceLine>();
    public DbSet<PurchasePayment> PurchasePayments => Set<PurchasePayment>();
    public DbSet<SupplierReturn> SupplierReturns => Set<SupplierReturn>();
    public DbSet<SupplierReturnLine> SupplierReturnLines => Set<SupplierReturnLine>();
    public DbSet<SupplierPayment> SupplierPayments => Set<SupplierPayment>();
    public DbSet<PaymentAllocation> PaymentAllocations => Set<PaymentAllocation>();
    // job work
    public DbSet<JobCard> JobCards => Set<JobCard>();
    public DbSet<JobStage> JobStages => Set<JobStage>();
    public DbSet<JobMaterialIssue> JobMaterialIssues => Set<JobMaterialIssue>();
    public DbSet<JobMaterialIssueLine> JobMaterialIssueLines => Set<JobMaterialIssueLine>();
    public DbSet<JobReceipt> JobReceipts => Set<JobReceipt>();
    public DbSet<JobReceiptLine> JobReceiptLines => Set<JobReceiptLine>();
    public DbSet<JobReconciliation> JobReconciliations => Set<JobReconciliation>();
    public DbSet<WorkerPayment> WorkerPayments => Set<WorkerPayment>();
    // repairs
    public DbSet<RepairTicket> RepairTickets => Set<RepairTicket>();
    public DbSet<RepairEstimate> RepairEstimates => Set<RepairEstimate>();
    public DbSet<RepairWorkLog> RepairWorkLogs => Set<RepairWorkLog>();
    public DbSet<RepairPartUsage> RepairPartUsages => Set<RepairPartUsage>();
    // finance & support
    public DbSet<ChartAccount> ChartAccounts => Set<ChartAccount>();
    public DbSet<CashBankAccount> CashBankAccounts => Set<CashBankAccount>();
    public DbSet<CashBankVoucher> CashBankVouchers => Set<CashBankVoucher>();
    public DbSet<ExpenseVoucher> ExpenseVouchers => Set<ExpenseVoucher>();
    public DbSet<CashRegisterSession> CashRegisterSessions => Set<CashRegisterSession>();
    public DbSet<JournalEntry> JournalEntries => Set<JournalEntry>();
    public DbSet<JournalLine> JournalLines => Set<JournalLine>();
    public DbSet<PartyLedgerEntry> PartyLedger => Set<PartyLedgerEntry>();
    public DbSet<MetalLedgerEntry> MetalLedger => Set<MetalLedgerEntry>();
    public DbSet<TransactionRegisterEntry> TransactionRegister => Set<TransactionRegisterEntry>();
    public DbSet<CommissionEntry> CommissionEntries => Set<CommissionEntry>();
    public DbSet<Notification> Notifications => Set<Notification>();
    public DbSet<BackupHistory> BackupHistory => Set<BackupHistory>();

    protected override void ConfigureConventions(ModelConfigurationBuilder b)
    {
        b.Properties<decimal>().HavePrecision(18, 2);   // PKR; weights are widened to (18,3) below, never float
        b.Properties<string>().HaveMaxLength(250);
    }

    static readonly Regex WeightName = new(@"(?i)(weight|^fine|fine$|^net|net$|^gross|^stone$|^quantity|quantity$|tolerance|^metaladded|^metalremoved|delta$|^issued|^output|^returned$|^scrap|loss|allowance|^variance$)", RegexOptions.Compiled);
    static readonly HashSet<string> LongText = new() { "Notes", "Description", "Address", "Message", "Reason", "VoidReason", "DesignSpec", "ItemDescription", "Condition", "RequestedWork", "StoneDetails", "AccessoriesReceived", "Memo", "WorkPerformed", "Caption", "ReceiptFooter", "VarianceReason", "DecisionReason", "ApprovalReason", "Note", "MaterialSourceNote", "InputSourceNote", "AssayNote", "WarrantyNote", "RejectionReason", "DeliveryOverrideReason", "VarianceApprovalReason", "VarianceNote", "ApprovalNote", "Skills", "Value", "Categories", "PaymentTerms" };

    protected override void OnModelCreating(ModelBuilder mb)
    {
        var entityTypes = typeof(Entity).Assembly.GetTypes().Where(t => !t.IsAbstract && t.IsClass && typeof(Entity).IsAssignableFrom(t)).ToList();
        var byName = entityTypes.ToDictionary(t => t.Name);

        foreach (var t in entityTypes)
        {
            var eb = mb.Entity(t);
            foreach (var p in t.GetProperties(BindingFlags.Public | BindingFlags.Instance))
            {
                var pt = Nullable.GetUnderlyingType(p.PropertyType) ?? p.PropertyType;
                if (pt == typeof(decimal))
                {
                    if (p.Name is "Factor" or "FactorToGram") eb.Property(p.Name).HasPrecision(18, 6);
                    else if (WeightName.IsMatch(p.Name) && !p.Name.Contains("Value") && !p.Name.Contains("Charge")) eb.Property(p.Name).HasPrecision(18, 3);
                }
                else if (pt == typeof(string))
                {
                    if (p.Name.EndsWith("Json")) eb.Property(p.Name).HasColumnType("nvarchar(max)");
                    else if (LongText.Contains(p.Name)) eb.Property(p.Name).HasMaxLength(2000);
                }
                else if (p.Name == nameof(AuditedEntity.RowVersion) && pt == typeof(byte[]) && typeof(AuditedEntity).IsAssignableFrom(t))
                    eb.Property(p.Name).IsRowVersion();
            }
        }

        ConfigureIndexes(mb, entityTypes);
        ConfigureForeignKeys(mb, entityTypes, byName);
        ConfigureFilters(mb, entityTypes);
    }

    // ---- Global query filters: every query is company + permitted-branch scoped (SRS 21.2) ----
    void ConfigureFilters(ModelBuilder mb, IEnumerable<Type> types)
    {
        var company = GetType().GetMethod(nameof(CompanyFilter), BindingFlags.NonPublic | BindingFlags.Instance)!;
        var branch = GetType().GetMethod(nameof(BranchFilter), BindingFlags.NonPublic | BindingFlags.Instance)!;
        foreach (var t in types)
        {
            if (!typeof(ICompanyScoped).IsAssignableFrom(t)) continue;
            if (t == typeof(StockTransfer)) { mb.Entity<StockTransfer>().HasQueryFilter(e => _scope.Bypass || (e.CompanyId == _scope.CompanyId && (_scope.AllowedBranchIds.Contains(e.OriginBranchId) || _scope.AllowedBranchIds.Contains(e.DestinationBranchId)))); continue; }
            var m = typeof(IBranchScoped).IsAssignableFrom(t) ? branch : company;
            m.MakeGenericMethod(t).Invoke(this, new object[] { mb });
        }
    }
    void CompanyFilter<T>(ModelBuilder mb) where T : class, ICompanyScoped => mb.Entity<T>().HasQueryFilter(e => _scope.Bypass || e.CompanyId == _scope.CompanyId);
    void BranchFilter<T>(ModelBuilder mb) where T : class, ICompanyScoped, IBranchScoped =>
        mb.Entity<T>().HasQueryFilter(e => _scope.Bypass || (e.CompanyId == _scope.CompanyId && _scope.AllowedBranchIds.Contains(e.BranchId)));

    // ---- Foreign keys by naming rule (RESTRICT everywhere; parent/child collections use EF conventions) ----
    static readonly Dictionary<string, string> FkAlias = new()
    {
        ["Salesman"] = nameof(Employee), ["Technician"] = nameof(Employee), ["User"] = nameof(AppUser),
        ["Category"] = nameof(ProductCategory), ["SubCategory"] = nameof(ProductCategory), ["Role"] = nameof(Role)
    };
    static readonly HashSet<string> NotFk = new() { "Id", "OwnerId", "DocId", "RefId", "EntityId", "PartyId", "CustodyRefId", "ReversalOfId", "ParentId", "LinkedDocId", "ReversedByDocId", "RateId" };

    void ConfigureForeignKeys(ModelBuilder mb, List<Type> types, Dictionary<string, Type> byName)
    {
        foreach (var dep in types)
        {
            foreach (var p in dep.GetProperties(BindingFlags.Public | BindingFlags.Instance))
            {
                var pt = Nullable.GetUnderlyingType(p.PropertyType) ?? p.PropertyType;
                if (pt != typeof(long) || !p.Name.EndsWith("Id") || NotFk.Contains(p.Name)) continue;
                var target = ResolveTarget(p.Name, byName);
                if (target == null || target == dep) continue;
                // parent -> child collections are mapped by convention (cascade); do not duplicate them
                if (target.GetProperties().Any(x => x.PropertyType.IsGenericType && x.PropertyType.GetGenericArguments()[0] == dep && typeof(System.Collections.IEnumerable).IsAssignableFrom(x.PropertyType))) continue;
                mb.Entity(dep).HasOne(target).WithMany().HasForeignKey(p.Name).OnDelete(DeleteBehavior.Restrict);
            }
        }
    }

    static Type? ResolveTarget(string prop, Dictionary<string, Type> byName)
    {
        var stem = prop[..^2];
        if (byName.TryGetValue(stem, out var exact) && stem != "Entity") return stem == "User" ? byName["AppUser"] : exact;
        if (FkAlias.TryGetValue(stem, out var alias)) return byName[alias];
        if (stem.EndsWith("Branch")) return byName["Branch"];
        if (stem.EndsWith("Location")) return byName["StoreLocation"];
        if (stem.EndsWith("Purity")) return byName["Purity"];
        if (stem.EndsWith("MetalType")) return byName["MetalType"];
        return null;
    }

    void ConfigureIndexes(ModelBuilder mb, List<Type> types)
    {
        mb.Entity<Branch>(e => { e.HasIndex(x => new { x.CompanyId, x.BranchCode }).IsUnique(); e.HasIndex(x => new { x.CompanyId, x.InvoicePrefix }).IsUnique(); });
        mb.Entity<StoreLocation>(e => e.HasIndex(x => new { x.BranchId, x.Code }).IsUnique());
        mb.Entity<AppUser>(e => { e.HasIndex(x => x.UserName).IsUnique(); e.HasIndex(x => x.Email).IsUnique(); });
        mb.Entity<Role>(e => e.HasIndex(x => new { x.CompanyId, x.Name }).IsUnique());
        mb.Entity<Permission>(e => e.HasIndex(x => x.Code).IsUnique());
        mb.Entity<RolePermission>(e => e.HasIndex(x => new { x.RoleId, x.PermissionId }).IsUnique());
        mb.Entity<UserRole>(e => e.HasIndex(x => new { x.UserId, x.RoleId, x.BranchId }).IsUnique());
        mb.Entity<UserBranchAccess>(e => e.HasIndex(x => new { x.UserId, x.BranchId }).IsUnique());
        mb.Entity<RefreshToken>(e => { e.HasIndex(x => x.TokenHash).IsUnique(); e.HasIndex(x => x.UserId); });
        mb.Entity<LoginAttempt>(e => e.HasIndex(x => new { x.UserNameOrEmail, x.AtUtc }));
        mb.Entity<AuditLog>(e => { e.HasIndex(x => new { x.CompanyId, x.AtUtc }); e.HasIndex(x => new { x.EntityType, x.EntityId }); e.HasIndex(x => x.UserId); });
        mb.Entity<AppSetting>(e => e.HasIndex(x => new { x.CompanyId, x.BranchId, x.Key }).IsUnique());
        mb.Entity<InvoiceSequence>(e => e.HasIndex(x => new { x.CompanyId, x.BranchId, x.DocType, x.Year }).IsUnique());
        mb.Entity<Product>(e =>
        {
            e.HasIndex(x => new { x.CompanyId, x.Sku }).IsUnique();
            e.HasIndex(x => new { x.CompanyId, x.Barcode }).IsUnique().HasFilter("[Barcode] IS NOT NULL");
            e.HasIndex(x => new { x.CompanyId, x.CategoryId, x.PurityId });
        });
        mb.Entity<Customer>(e => { e.HasIndex(x => new { x.CompanyId, x.Code }).IsUnique(); e.HasIndex(x => x.Phone); e.HasIndex(x => x.Name); });
        mb.Entity<Supplier>(e => { e.HasIndex(x => new { x.CompanyId, x.Code }).IsUnique(); e.HasIndex(x => x.Phone); });
        mb.Entity<Employee>(e => e.HasIndex(x => new { x.CompanyId, x.Code }).IsUnique());
        mb.Entity<Worker>(e => e.HasIndex(x => new { x.CompanyId, x.Code }).IsUnique());
        mb.Entity<ChartAccount>(e => e.HasIndex(x => new { x.CompanyId, x.Code }).IsUnique());
        mb.Entity<GoldRate>(e => e.HasIndex(x => new { x.CompanyId, x.MetalTypeId, x.PurityId, x.BranchId, x.EffectiveFromUtc }));
        mb.Entity<Purity>(e => e.HasIndex(x => new { x.CompanyId, x.MetalTypeId, x.Label }).IsUnique());
        mb.Entity<FileAsset>(e => { e.HasIndex(x => new { x.OwnerType, x.OwnerId, x.IsArchived }); e.HasIndex(x => x.StorageKey).IsUnique(); });
        mb.Entity<StockBalance>(e =>
        {
            e.HasIndex(x => new { x.BranchId, x.LocationId, x.ProductId, x.MetalTypeId, x.PurityId, x.Status, x.Ownership, x.CustodyRefId }).IsUnique();
            e.HasIndex(x => new { x.CompanyId, x.BranchId, x.Status });
            e.HasIndex(x => new { x.ProductId, x.Status });
        });
        mb.Entity<StockMovement>(e => { e.HasIndex(x => new { x.CompanyId, x.ProductId, x.PostedAtUtc }); e.HasIndex(x => new { x.RefType, x.RefId }); });
        mb.Entity<PartyLedgerEntry>(e => e.HasIndex(x => new { x.CompanyId, x.PartyType, x.PartyId, x.EntryDateUtc }));
        mb.Entity<MetalLedgerEntry>(e => e.HasIndex(x => new { x.CompanyId, x.PartyType, x.PartyId, x.EntryDateUtc }));
        mb.Entity<JournalEntry>(e => { e.HasIndex(x => new { x.CompanyId, x.Number }).IsUnique(); e.HasIndex(x => new { x.DocType, x.DocId }); });
        mb.Entity<TransactionRegisterEntry>(e =>
        {
            e.HasIndex(x => new { x.CompanyId, x.BranchId, x.PostedAtUtc });
            e.HasIndex(x => new { x.TxnType, x.DocId });
            e.HasIndex(x => x.PartyId); e.HasIndex(x => x.Sku);
        });
        mb.Entity<CommissionEntry>(e => e.HasIndex(x => new { x.CompanyId, x.SalesmanId, x.EntryDateUtc }));
        mb.Entity<ApprovalRequest>(e => e.HasIndex(x => new { x.CompanyId, x.Status, x.BranchId }));

        // every posted document type: unique business number, unique idempotency key, common report filters
        foreach (var t in types.Where(t => typeof(PostableDocument).IsAssignableFrom(t)))
        {
            var eb = mb.Entity(t);
            eb.HasIndex("CompanyId", "Number").IsUnique();
            eb.HasIndex("CompanyId", "BranchId", "DocDateUtc", "Status");
            eb.HasIndex("CompanyId", "IdempotencyKey").IsUnique().HasFilter("[IdempotencyKey] IS NOT NULL");
        }
    }

    public override Task<int> SaveChangesAsync(CancellationToken ct = default) { Stamp(); return base.SaveChangesAsync(ct); }
    public override int SaveChanges() { Stamp(); return base.SaveChanges(); }

    void Stamp()
    {
        var now = DateTime.UtcNow;
        foreach (var e in ChangeTracker.Entries<AuditedEntity>())
        {
            if (e.State == EntityState.Added)
            {
                e.Entity.CreatedAtUtc = now;
                e.Entity.CreatedBy ??= _scope.UserId == 0 ? null : _scope.UserId;
                if (e.Entity is CompanyEntity c && c.CompanyId == 0) c.CompanyId = _scope.CompanyId;
            }
            else if (e.State == EntityState.Modified)
            {
                e.Entity.ModifiedAtUtc = now;
                e.Entity.ModifiedBy = _scope.UserId == 0 ? null : _scope.UserId;
            }
        }
    }
}
