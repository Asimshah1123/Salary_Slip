using System.Net.Sockets;
using System.Text;
using System.Text.RegularExpressions;
using Microsoft.Extensions.Options;

namespace Erp.Infrastructure.Files;

public sealed class StorageOptions
{
    public string Root { get; set; } = "App_Data/files";    // keep OUTSIDE the web root; served only through the authorised files endpoint
    public bool ClamAvEnabled { get; set; }
    public string ClamAvHost { get; set; } = "localhost";
    public int ClamAvPort { get; set; } = 3310;
}

/// <summary>Stores bytes under random keys. User input never reaches the path; uploaded files are never executed or served directly.</summary>
public sealed class LocalFileStorage : IFileStorage
{
    static readonly Regex KeyRx = new(@"^[0-9a-f]{2}/[0-9a-f]{32}\.(jpg|png|webp|gif|pdf)$", RegexOptions.Compiled);
    readonly string _root;
    public LocalFileStorage(IOptions<StorageOptions> o) { _root = Path.GetFullPath(o.Value.Root); Directory.CreateDirectory(_root); }

    public async Task<string> SaveAsync(Stream content, string extension, CancellationToken ct = default)
    {
        var ext = extension.TrimStart('.').ToLowerInvariant();
        if (ext is not ("jpg" or "png" or "webp" or "gif" or "pdf")) throw new ArgumentException("Unsupported extension.", nameof(extension));
        var id = Convert.ToHexString(System.Security.Cryptography.RandomNumberGenerator.GetBytes(16)).ToLowerInvariant();
        var key = $"{id[..2]}/{id}.{ext}";
        var path = Resolve(key);
        Directory.CreateDirectory(Path.GetDirectoryName(path)!);
        await using var fs = new FileStream(path, FileMode.CreateNew, FileAccess.Write, FileShare.None);
        await content.CopyToAsync(fs, ct);
        return key;
    }

    public Task<Stream?> OpenReadAsync(string key, CancellationToken ct = default)
    {
        if (!KeyRx.IsMatch(key)) return Task.FromResult<Stream?>(null);
        var p = Resolve(key);
        return Task.FromResult<Stream?>(File.Exists(p) ? new FileStream(p, FileMode.Open, FileAccess.Read, FileShare.Read) : null);
    }

    public Task DeleteAsync(string key, CancellationToken ct = default)
    {
        if (KeyRx.IsMatch(key)) { var p = Resolve(key); if (File.Exists(p)) File.Delete(p); }
        return Task.CompletedTask;
    }

    string Resolve(string key)
    {
        var full = Path.GetFullPath(Path.Combine(_root, key));
        if (!full.StartsWith(_root, StringComparison.Ordinal)) throw new InvalidOperationException("Path escape blocked.");
        return full;
    }
}

/// <summary>Built-in signature check (EICAR test string) used when ClamAV is not configured. Not a substitute for a real scanner in production.</summary>
public sealed class BasicMalwareScanner : IMalwareScanner
{
    static readonly byte[] Eicar = Encoding.ASCII.GetBytes("X5O!P%@AP[4\\PZX54(P^)7CC)7}$EICAR-STANDARD-ANTIVIRUS-TEST-FILE!$H+H*");
    public Task<ScanResult> ScanAsync(byte[] content, CancellationToken ct = default)
    {
        var hit = content.AsSpan().IndexOf(Eicar) >= 0;
        // polyglot guard: script/executable markers inside an "image"
        var head = Encoding.Latin1.GetString(content, 0, Math.Min(content.Length, 4096));
        var scripty = head.Contains("<?php", StringComparison.OrdinalIgnoreCase) || head.Contains("<script", StringComparison.OrdinalIgnoreCase) || head.StartsWith("MZ", StringComparison.Ordinal);
        return Task.FromResult(hit ? new ScanResult(false, "EICAR-Test-File") : scripty ? new ScanResult(false, "Suspicious-Script-Content") : new ScanResult(true, null));
    }
}

/// <summary>clamd INSTREAM protocol over TCP. Enable with Storage:ClamAvEnabled. Fails closed if the scanner is unreachable.</summary>
public sealed class ClamAvScanner : IMalwareScanner
{
    readonly StorageOptions _o;
    public ClamAvScanner(IOptions<StorageOptions> o) { _o = o.Value; }
    public async Task<ScanResult> ScanAsync(byte[] content, CancellationToken ct = default)
    {
        try
        {
            using var c = new TcpClient();
            await c.ConnectAsync(_o.ClamAvHost, _o.ClamAvPort, ct);
            await using var s = c.GetStream();
            await s.WriteAsync(Encoding.ASCII.GetBytes("zINSTREAM\0"), ct);
            for (int off = 0; off < content.Length; off += 8192)
            {
                var n = Math.Min(8192, content.Length - off);
                var len = BitConverter.GetBytes(System.Net.IPAddress.HostToNetworkOrder(n));
                await s.WriteAsync(len, ct); await s.WriteAsync(content.AsMemory(off, n), ct);
            }
            await s.WriteAsync(new byte[4], ct);
            var buf = new byte[512]; var read = await s.ReadAsync(buf, ct);
            var reply = Encoding.ASCII.GetString(buf, 0, read).TrimEnd('\0', '\n');
            return reply.EndsWith("OK") ? new ScanResult(true, null) : new ScanResult(false, reply.Replace("stream:", "").Replace("FOUND", "").Trim());
        }
        catch (Exception) { return new ScanResult(false, "scanner-unavailable"); }
    }
}
