namespace Erp.Infrastructure.Files;

public sealed record ImageInfo(string Mime, string Extension, int Width, int Height);

/// <summary>
/// Validates uploads by FILE SIGNATURE (never trusting the client MIME type or extension), reads dimensions and strips
/// EXIF/XMP/comments (GPS, device and owner details) from JPEG and PNG. No third-party imaging library required.
/// </summary>
public static class ImageInspector
{
    public const int MinSide = 16, MaxSide = 12000;
    static readonly Dictionary<string, string[]> ExtAllowed = new()
    {
        ["image/jpeg"] = new[] { ".jpg", ".jpeg" }, ["image/png"] = new[] { ".png" }, ["image/webp"] = new[] { ".webp" }, ["image/gif"] = new[] { ".gif" }
    };

    public static ImageInfo Inspect(byte[] d, string? clientFileName)
    {
        if (d.Length < 32) throw new Domain.DomainException("The file is too small to be an image.", "image_invalid");
        string mime; int w, h;
        if (d[0] == 0xFF && d[1] == 0xD8 && d[2] == 0xFF) { mime = "image/jpeg"; (w, h) = JpegSize(d); }
        else if (d[0] == 0x89 && d[1] == 0x50 && d[2] == 0x4E && d[3] == 0x47 && d[4] == 0x0D && d[5] == 0x0A && d[6] == 0x1A && d[7] == 0x0A) { mime = "image/png"; (w, h) = PngSize(d); }
        else if (d[0] == 'G' && d[1] == 'I' && d[2] == 'F' && d[3] == '8' && (d[4] == '7' || d[4] == '9') && d[5] == 'a') { mime = "image/gif"; w = d[6] | d[7] << 8; h = d[8] | d[9] << 8; }
        else if (d[0] == 'R' && d[1] == 'I' && d[2] == 'F' && d[3] == 'F' && d[8] == 'W' && d[9] == 'E' && d[10] == 'B' && d[11] == 'P') { mime = "image/webp"; (w, h) = WebpSize(d); }
        else throw new Domain.DomainException("Only JPEG, PNG, WebP or GIF images are accepted.", "image_type");

        if (w < MinSide || h < MinSide || w > MaxSide || h > MaxSide) throw new Domain.DomainException($"Image dimensions {w}x{h} are outside the allowed range ({MinSide}-{MaxSide}px).", "image_dimensions");
        var ext = ExtAllowed[mime][0];
        if (!string.IsNullOrWhiteSpace(clientFileName))
        {
            var clientExt = Path.GetExtension(clientFileName).ToLowerInvariant();
            if (!ExtAllowed[mime].Contains(clientExt)) throw new Domain.DomainException("The file extension does not match the file contents.", "image_extension_mismatch");
        }
        return new ImageInfo(mime, ext, w, h);
    }

    static (int, int) PngSize(byte[] d)
    {
        if (d[12] != 'I' || d[13] != 'H' || d[14] != 'D' || d[15] != 'R') throw new Domain.DomainException("Corrupt PNG.", "image_invalid");
        return (d[16] << 24 | d[17] << 16 | d[18] << 8 | d[19], d[20] << 24 | d[21] << 16 | d[22] << 8 | d[23]);
    }

    static (int, int) JpegSize(byte[] d)
    {
        int i = 2;
        while (i + 9 < d.Length)
        {
            if (d[i] != 0xFF) { i++; continue; }
            var m = d[i + 1];
            if (m == 0xFF) { i++; continue; }
            if (m == 0xD8 || m == 0x01 || (m >= 0xD0 && m <= 0xD7)) { i += 2; continue; }
            int len = d[i + 2] << 8 | d[i + 3];
            if (m >= 0xC0 && m <= 0xCF && m != 0xC4 && m != 0xC8 && m != 0xCC) return (d[i + 7] << 8 | d[i + 8], d[i + 5] << 8 | d[i + 6]);
            if (len < 2) break;
            i += 2 + len;
        }
        throw new Domain.DomainException("Corrupt JPEG.", "image_invalid");
    }

    static (int, int) WebpSize(byte[] d)
    {
        if (d.Length < 30) throw new Domain.DomainException("Corrupt WebP.", "image_invalid");
        var fourcc = System.Text.Encoding.ASCII.GetString(d, 12, 4);
        switch (fourcc)
        {
            case "VP8 ": return ((d[26] | d[27] << 8) & 0x3FFF, (d[28] | d[29] << 8) & 0x3FFF);
            case "VP8L":
            {
                // signature byte 0x2F at offset 20, then 14 bits (width-1) and 14 bits (height-1), little-endian
                uint v = (uint)(d[21] | d[22] << 8 | d[23] << 16) | (uint)d[24] << 24;
                return ((int)(v & 0x3FFF) + 1, (int)((v >> 14) & 0x3FFF) + 1);
            }
            case "VP8X": return (1 + (d[24] | d[25] << 8 | d[26] << 16), 1 + (d[27] | d[28] << 8 | d[29] << 16));
            default: throw new Domain.DomainException("Unsupported WebP variant.", "image_invalid");
        }
    }

    /// <summary>Removes metadata segments that can leak location/device/owner data. Pixel data is untouched.</summary>
    public static byte[] StripMetadata(byte[] d, string mime)
    {
        if (mime == "image/jpeg") return StripJpeg(d);
        if (mime == "image/png") return StripPng(d);
        return d;
    }

    static byte[] StripJpeg(byte[] d)
    {
        using var ms = new MemoryStream(d.Length);
        ms.Write(d, 0, 2); // SOI
        int i = 2;
        while (i + 3 < d.Length)
        {
            if (d[i] != 0xFF) { ms.Write(d, i, d.Length - i); break; }
            var m = d[i + 1];
            if (m == 0xDA) { ms.Write(d, i, d.Length - i); break; } // start of scan: copy the rest verbatim
            if (m == 0xD9) { ms.Write(d, i, 2); break; }
            int len = d[i + 2] << 8 | d[i + 3];
            bool drop = m == 0xE1 || m == 0xED || m == 0xFE || m == 0xEC || m == 0xEB || m == 0xEA; // EXIF/XMP, IPTC, comments, vendor APPn
            if (!drop) ms.Write(d, i, 2 + len);
            i += 2 + len;
        }
        return ms.ToArray();
    }

    static readonly HashSet<string> DropPng = new() { "eXIf", "tEXt", "iTXt", "zTXt", "tIME" };
    static byte[] StripPng(byte[] d)
    {
        using var ms = new MemoryStream(d.Length);
        ms.Write(d, 0, 8);
        int i = 8;
        while (i + 12 <= d.Length)
        {
            int len = d[i] << 24 | d[i + 1] << 16 | d[i + 2] << 8 | d[i + 3];
            var type = System.Text.Encoding.ASCII.GetString(d, i + 4, 4);
            int total = 12 + len;
            if (len < 0 || i + total > d.Length) { ms.Write(d, i, d.Length - i); break; }
            if (!DropPng.Contains(type)) ms.Write(d, i, total);
            i += total;
            if (type == "IEND") break;
        }
        return ms.ToArray();
    }
}
