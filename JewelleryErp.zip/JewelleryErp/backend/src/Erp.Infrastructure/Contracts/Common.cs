namespace Erp.Infrastructure.Contracts;

public sealed record PagedResult<T>(IReadOnlyList<T> Items, int Total, int Page, int PageSize, IDictionary<string, decimal>? Totals = null);

public class PageQuery
{
    public int Page { get; set; } = 1;
    public int PageSize { get; set; } = 25;
    public string? Search { get; set; }
    public string? Sort { get; set; }
    public bool Desc { get; set; }
    public int Skip => (Math.Max(1, Page) - 1) * Take;
    public int Take => Math.Clamp(PageSize, 1, 200);
}

public sealed record Lookup(long Id, string Name, string? Code = null, string? Extra = null);
