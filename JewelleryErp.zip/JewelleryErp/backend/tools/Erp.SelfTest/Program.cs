using Erp.Domain;
using Erp.Domain.Calc;

// Dependency-free verification of the business rules in Erp.Domain (SRS sections 2, 3, 6, 13, 19-20).
int pass = 0, fail = 0;
void Check(string name, bool ok, string? detail = null)
{
    if (ok) { pass++; Console.WriteLine($"  PASS  {name}"); }
    else { fail++; Console.WriteLine($"  FAIL  {name} {detail}"); }
}
void Throws(string name, string code, Action a)
{
    try { a(); Check(name, false, "(no exception)"); }
    catch (DomainException e) { Check(name, e.Code == code, $"(got {e.Code})"); }
}

Console.WriteLine("Weights & units (SRS 2.1)");
Check("net = gross - stone - other", WeightCalc.NetMetal(12.500m, 1.250m, 0.250m) == 11.000m);
Check("22K fine factor 22/24", WeightCalc.KaratFactor(22) == 0.916667m);
Check("fine = net x factor", WeightCalc.Fine(10m, 0.916667m) == 9.167m);
Throws("stone > gross rejected", "weight_deduction_exceeds_gross", () => WeightCalc.NetMetal(5, 6));
Throws("unapproved ratti refused", "unit_not_approved", () => WeightCalc.ToGrams(10, null, false, "Ratti"));
Check("approved unit converts", WeightCalc.ToGrams(1000, 0.001m, true, "mg") == 1.000m);

Console.WriteLine("Pricing (SRS 2.2)");
var p1 = PricingCalculator.Price(new PricingInput(PricingMode.MetalPlusMaking, 1, 10.000m, 20000m, 0, ChargeType.PerGram, 500m, 0, 0, 0, 0, 0, null, false, 0));
Check("metal 10g x 20000 = 200000", p1.MetalValue == 200000m);
Check("making 500/g x 10g = 5000", p1.MakingCharge == 5000m);
Check("total 205000", p1.Total == 205000m);
var p2 = PricingCalculator.Price(new PricingInput(PricingMode.MetalStoneMakingWastage, 1, 10m, 20000m, 0, ChargeType.Percent, 8m, 3m, 0, 15000m, 250m, 1000m, null, false, 0));
// metal 200000, making 8% = 16000, wastage 3% x 10g x 20000 = 6000, stone 15000, other 250, discount 1000
Check("mode (c) total", p2.GrossBeforeDiscount == 237250m && p2.Total == 236250m, $"got {p2.GrossBeforeDiscount}/{p2.Total}");
var p3 = PricingCalculator.Price(new PricingInput(PricingMode.Tagged, 1, 5m, 20000m, 85000m, ChargeType.None, 0, 0, 0, 0, 0, 5000m, null, true, 5m));
Check("tagged with 5% tax", p3.Taxable == 80000m && p3.Tax == 4000m && p3.Total == 84000m);
var p4 = PricingCalculator.Price(new PricingInput(PricingMode.ManualApproved, 1, 5m, 0, 0, ChargeType.None, 0, 0, 0, 0, 0, 0, 91234.4m, false, 0, RoundingPolicy.PerLine, 10m));
Check("manual flags approval + rounds to step", p4.RequiresApproval && p4.Total == 91230m, $"got {p4.Total}");
Throws("manual price required", "manual_price_required", () => PricingCalculator.Price(new PricingInput(PricingMode.ManualApproved, 1, 5, 0, 0, ChargeType.None, 0, 0, 0, 0, 0, 0, null, false, 0)));
Throws("discount > line rejected", "discount_exceeds_line", () => PricingCalculator.Price(new PricingInput(PricingMode.Tagged, 1, 1, 0, 1000, ChargeType.None, 0, 0, 0, 0, 0, 2000, null, false, 0)));
Check("rate change does not alter snapshot result", PricingCalculator.Price(new PricingInput(PricingMode.MetalPlusMaking, 1, 10m, 20000m, 0, ChargeType.None, 0, 0, 0, 0, 0, 0, null, false, 0)).Total == 200000m
      && PricingCalculator.Price(new PricingInput(PricingMode.MetalPlusMaking, 1, 10m, 21000m, 0, ChargeType.None, 0, 0, 0, 0, 0, 0, null, false, 0)).Total == 210000m);

Console.WriteLine("Invoice totals");
var t = InvoiceMath.Totals(new[] { p1, p3 }, oldGoldCredit: 50000m, paid: 100000m, RoundingPolicy.PerLine, 1m);
Check("total = 289000 - 50000 old gold", t.Total == 239000m, $"got {t.Total}");
Check("due = total - paid", t.Due == 139000m && t.Change == 0m);
var over = InvoiceMath.Totals(new[] { p3 }, 0, 90000m, RoundingPolicy.PerLine, 1m);
Check("overpayment shown as change", over.Change == 6000m && over.Due == 0m);
Throws("old gold > total refused", "oldgold_exceeds_total", () => InvoiceMath.Totals(new[] { p3 }, 999999m, 0, RoundingPolicy.PerLine, 1m));

Console.WriteLine("Weight reconciliation (SRS 6.5, UAT 6)");
var r1 = Reconciliation.Calculate(new ReconInput(100.000m, 0, 90.000m, 5.000m, 3.000m, 1.000m, 0.100m, 1m));
Check("balanced job: variance 1g", r1.Variance == 1.000m);
Check("1g loss within 1% allowance", r1.AllowedWastage == 1.000m && r1.WithinTolerance && !r1.RequiresApproval, r1.Summary);
var r2 = Reconciliation.Calculate(new ReconInput(100m, 0, 80m, 5m, 3m, 0m, 0.1m, 1m));
Check("12g loss needs supervisor approval", r2.Variance == 12.000m && r2.ExcessLoss == 11.000m && r2.RequiresApproval, r2.Summary);
var r3 = Reconciliation.Calculate(new ReconInput(50m, 0, 52m, 0, 0, 0, 0.1m, 0));
Check("unexpected gain flagged", r3.UnexpectedGain == 2.000m && r3.RequiresApproval, r3.Summary);
var r4 = Reconciliation.Calculate(new ReconInput(0, 40m, 39.9m, 0, 0, 0, 0.2m, 0));
Check("OnReceiptOnly: worker-owned input reconciles", r4.WithinTolerance && r4.Variance == 0.1m, r4.Summary);
Throws("negative weight refused", "recon_negative", () => Reconciliation.Calculate(new ReconInput(-1, 0, 0, 0, 0, 0, 0, 0)));

Console.WriteLine("Old gold (SRS 2.4)");
var og = OldGold.Value(new OldGoldInput(20m, 1m, 0m, 0.5m, 0.916667m, 17000m));
Check("net after stone and melting = 18.5g", og.Net == 18.5m);
Check("value = net x accepted rate", og.Value == 314500m);
Check("deduction % recorded", og.DeductionPercent == Math.Round(0.5m / 19m * 100m, 3));
var og2 = OldGold.Value(new OldGoldInput(10m, 0, 0, 0, 0.75m, 0, "ByFineEquivalent", 22000m));
Check("fine-equivalent valuation", og2.Fine == 7.5m && og2.Value == 165000m);
Throws("melting > net refused", "melting_invalid", () => OldGold.Value(new OldGoldInput(5, 0, 0, 9, 0.9m, 1000m)));

Console.WriteLine("Commission");
Check("percent commission", CommissionCalc.Calculate(CommissionType.Percent, 1.5m, 200000m) == 3000m);
Check("fixed per invoice", CommissionCalc.Calculate(CommissionType.Fixed, 500m, 10m) == 500m);
Check("return reverses proportionally", CommissionCalc.ReverseShare(3000m, 200000m, 50000m) == 750m);
Check("manual = 0 until approved", CommissionCalc.Calculate(CommissionType.Manual, 5m, 1000m) == 0m);

Console.WriteLine("Journal (SRS 3.12)");
var j = new JournalBuilder().Dr(Acc.Cash, 100000m).Dr(Acc.Receivable, 139000m).Cr(Acc.SalesRevenue, 239000m);
j.AssertBalanced(); Check("balanced journal passes", true);
var jr = j.Reversed(); jr.AssertBalanced();
Check("reversal mirrors sides", jr.Lines[0].Credit == 100000m && jr.Lines[2].Debit == 239000m);
Throws("unbalanced journal refused", "journal_unbalanced", () => new JournalBuilder().Dr(Acc.Cash, 10).Cr(Acc.SalesRevenue, 9).AssertBalanced());
Throws("empty journal refused", "journal_empty", () => new JournalBuilder().AssertBalanced());

Console.WriteLine("State machines (SRS 3.9, 3.10, 6.4)");
Check("job: Draft -> Approved", JobFlow.CanTransition(JobStatus.Draft, JobStatus.Approved, StockPostingMode.OnIssue));
Check("job: OnIssue may issue material", JobFlow.CanTransition(JobStatus.Approved, JobStatus.MaterialIssued, StockPostingMode.OnIssue));
Check("job: OnReceiptOnly can NOT issue material", !JobFlow.CanTransition(JobStatus.Approved, JobStatus.MaterialIssued, StockPostingMode.OnReceiptOnly));
Check("job: OnReceiptOnly goes straight to InProgress", JobFlow.CanTransition(JobStatus.Approved, JobStatus.InProgress, StockPostingMode.OnReceiptOnly));
Check("job: cannot close before reconciliation", !JobFlow.CanTransition(JobStatus.Completed, JobStatus.Closed, StockPostingMode.OnIssue));
Check("job: partial receipts repeat", JobFlow.CanTransition(JobStatus.PartiallyReceived, JobStatus.PartiallyReceived, StockPostingMode.OnIssue));
Throws("job: illegal transition throws", "job_transition", () => JobFlow.Require(JobStatus.Draft, JobStatus.Closed, StockPostingMode.OnIssue));
Check("repair: full happy path", new[] { RepairStatus.Received, RepairStatus.Inspection, RepairStatus.EstimatePrepared, RepairStatus.AwaitingApproval, RepairStatus.Approved, RepairStatus.InRepair, RepairStatus.QualityCheck, RepairStatus.Ready, RepairStatus.Delivered }
      .Zip(new[] { RepairStatus.Inspection, RepairStatus.EstimatePrepared, RepairStatus.AwaitingApproval, RepairStatus.Approved, RepairStatus.InRepair, RepairStatus.QualityCheck, RepairStatus.Ready, RepairStatus.Delivered })
      .All(p => RepairFlow.CanTransition(p.First, p.Second, true)));
Check("repair: cannot deliver before ready", !RepairFlow.CanTransition(RepairStatus.InRepair, RepairStatus.Delivered, true));
Check("repair: approval-free policy skips approval", RepairFlow.CanTransition(RepairStatus.EstimatePrepared, RepairStatus.Approved, false) && !RepairFlow.CanTransition(RepairStatus.EstimatePrepared, RepairStatus.AwaitingApproval, false));
Check("repair: QC can send back to repair", RepairFlow.CanTransition(RepairStatus.QualityCheck, RepairStatus.InRepair, true));
Throws("transfer: only draft dispatches", "transfer_state", () => TransferFlow.RequireDispatch(TransferStatus.InTransit));

Console.WriteLine("RBAC (SRS 19-20)");
Check("permission codes unique", Perms.All.Distinct().Count() == Perms.All.Count);
var srsNamed = new[] { "Products.View","Products.Create","Products.Edit","Products.Images.Upload","Products.Images.Delete","Sales.Create","Sales.Post","Sales.Return","Sales.Void","Sales.Discount.Override",
  "GoldRate.View","GoldRate.Edit","GoldRate.Override","Inventory.View","Inventory.Transfer","Inventory.Adjust","Inventory.Count.Approve","JobWork.MaterialIssue","JobWork.Receive","JobWork.Reconcile","JobWork.Variance.Approve",
  "Repairs.ViewAssigned","Repairs.ViewBranch","Repairs.Estimate.Approve","Repairs.Deliver","Finance.Expense.Create","Finance.Expense.Approve","Finance.Payment.Post","Finance.Export",
  "Reports.Sales.View","Reports.Cost.View","Reports.Profit.View","Reports.Export","Users.Manage","Roles.Manage","Branches.Manage","AuditLog.View","Branches.ViewAll","Reports.Consolidated.View" };
Check("every permission named in the SRS exists", srsNamed.All(Perms.All.Contains), string.Join(",", srsNamed.Where(x => !Perms.All.Contains(x))));
var defs = RoleTemplates.Defaults();
Check("every template permission exists", defs.Values.SelectMany(x => x).All(p => Perms.All.Contains(p)));
Check("owner has everything", defs[RoleTemplates.Owner].Length == Perms.All.Count);
Check("cashier cannot see profit/cost", !defs[RoleTemplates.Cashier].Contains(Perms.ReportsProfit) && !defs[RoleTemplates.Cashier].Contains(Perms.ReportsCost));
Check("cashier cannot override rate/adjust stock/manage users", !defs[RoleTemplates.Cashier].Contains(Perms.GoldRateOverride) && !defs[RoleTemplates.Cashier].Contains(Perms.InventoryAdjust) && !defs[RoleTemplates.Cashier].Contains(Perms.UsersManage));
Check("cashier can post sales", defs[RoleTemplates.Cashier].Contains(Perms.SalesPost));
Check("worker sees assigned jobs only", defs[RoleTemplates.Worker].SequenceEqual(new[] { Perms.JobWorkViewAssigned, Perms.JobWorkUpdateStage }));
Check("branch manager has no all-branch scope", !defs[RoleTemplates.BranchManager].Contains(Perms.BranchesViewAll) && !defs[RoleTemplates.BranchManager].Contains(Perms.ReportsConsolidated));
Check("auditor is read-only", defs[RoleTemplates.Auditor].All(p => !p.EndsWith(".Create") && !p.EndsWith(".Post") && !p.EndsWith(".Edit") && !p.EndsWith(".Void") && !p.EndsWith(".Adjust")));
Check("inventory controller cannot approve own count", !defs[RoleTemplates.Inventory].Contains(Perms.InventoryCountApprove) && defs[RoleTemplates.Inventory].Contains(Perms.InventoryCount));
Check("accountant cannot manage users/roles", !defs[RoleTemplates.Accountant].Contains(Perms.UsersManage) && !defs[RoleTemplates.Accountant].Contains(Perms.RolesManage));

Console.WriteLine("Numbering");
Check("doc number format", DocNumber.Format("INV", "LHR", 2026, 123) == "INV-LHR-26-000123");
Check("aging buckets", Aging.Bucket(10) == "0-30" && Aging.Bucket(45) == "31-60" && Aging.Bucket(91) == "90+");

Console.WriteLine("Image upload validation (SRS 10, 11)");
var samples = Path.Combine(AppContext.BaseDirectory, "..", "..", "..", "samples");
byte[] Load(string n) => File.ReadAllBytes(Path.Combine(samples, n));
var jpg = Erp.Infrastructure.Files.ImageInspector.Inspect(Load("ring.jpg"), "ring.jpg");
Check("jpeg detected with dimensions", jpg.Mime == "image/jpeg" && jpg.Width == 120 && jpg.Height == 80, $"{jpg}");
var png = Erp.Infrastructure.Files.ImageInspector.Inspect(Load("chain.png"), "chain.PNG");
Check("png detected (case-insensitive ext)", png.Mime == "image/png" && png.Width == 64 && png.Height == 48);
var wl = Erp.Infrastructure.Files.ImageInspector.Inspect(Load("lossy.webp"), "a.webp");
Check("webp lossy dimensions", wl.Mime == "image/webp" && wl.Width == 80 && wl.Height == 40, $"{wl}");
var wx = Erp.Infrastructure.Files.ImageInspector.Inspect(Load("lossless.webp"), "a.webp");
Check("webp lossless dimensions", wx.Width == 90 && wx.Height == 50, $"{wx}");
var gf = Erp.Infrastructure.Files.ImageInspector.Inspect(Load("anim.gif"), "a.gif");
Check("gif dimensions", gf.Width == 33 && gf.Height == 21, $"{gf}");
Throws("php disguised as png rejected", "image_type", () => Erp.Infrastructure.Files.ImageInspector.Inspect(Load("evil.png"), "evil.png"));
Throws("extension/content mismatch rejected", "image_extension_mismatch", () => Erp.Infrastructure.Files.ImageInspector.Inspect(Load("ring_wrongext.png"), "ring.png"));
Throws("tiny image rejected", "image_dimensions", () => Erp.Infrastructure.Files.ImageInspector.Inspect(Load("tiny.png"), "t.png"));
Throws("unknown bytes rejected", "image_type", () => Erp.Infrastructure.Files.ImageInspector.Inspect(Load("eicar.bin"), "x.jpg"));
Directory.CreateDirectory("/tmp/stripped");
File.WriteAllBytes("/tmp/stripped/ring.jpg", Erp.Infrastructure.Files.ImageInspector.StripMetadata(Load("ring.jpg"), "image/jpeg"));
File.WriteAllBytes("/tmp/stripped/chain.png", Erp.Infrastructure.Files.ImageInspector.StripMetadata(Load("chain.png"), "image/png"));
Check("stripped files written", File.Exists("/tmp/stripped/ring.jpg") && File.Exists("/tmp/stripped/chain.png"));

Console.WriteLine("Exporters (SRS 7, 12)");
var tbl = new Erp.Infrastructure.Exports.ReportTable { Title = "Sales Register", Scope = "Branches: Lahore; 2026-10-01..2026-10-24", GeneratedBy = "tester",
  Columns = new() { new("no", "Invoice"), new("cust", "Customer"), new("net", "Net Wt (g)", "weight"), new("total", "Total", "money"), new("date", "Date", "date") } };
tbl.Rows.Add(new object?[] { "INV-LHR-26-000001", "Ali, Ahmed \"Jeweller\"", 12.345m, 245000.5m, new DateTime(2026, 10, 24) });
tbl.Rows.Add(new object?[] { "INV-LHR-26-000002", "=HYPERLINK(\"http://evil\")", 3m, 1000m, new DateTime(2026, 10, 23) });
for (int i = 0; i < 120; i++) tbl.Rows.Add(new object?[] { "INV-" + i, "Customer " + i, 1.5m * i, 1000m * i, new DateTime(2026, 10, 1).AddDays(i % 20) });
tbl.Totals["total"] = tbl.Rows.Sum(r => (decimal)r[3]!);
File.WriteAllBytes("/tmp/report.csv", Erp.Infrastructure.Exports.Exporters.Csv(tbl));
File.WriteAllBytes("/tmp/report.xlsx", Erp.Infrastructure.Exports.Exporters.Xlsx(tbl));
File.WriteAllBytes("/tmp/report.pdf", Erp.Infrastructure.Exports.Exporters.Pdf(tbl));
Check("exports written", new FileInfo("/tmp/report.csv").Length > 100 && new FileInfo("/tmp/report.xlsx").Length > 500 && new FileInfo("/tmp/report.pdf").Length > 500);

Console.WriteLine($"\n{pass} passed, {fail} failed");
return fail == 0 ? 0 : 1;
