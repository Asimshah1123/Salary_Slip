using System.Security.Claims;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Routing;
using Microsoft.Extensions.DependencyInjection;

namespace Microsoft.IdentityModel.Tokens
{
    public abstract class SecurityKey { }
    public class SymmetricSecurityKey : SecurityKey { public SymmetricSecurityKey(byte[] key) { } }
    public class SigningCredentials { public SigningCredentials(SecurityKey key, string algorithm) { } }
    public static class SecurityAlgorithms { public const string HmacSha256 = "HS256"; }
    public class TokenValidationParameters
    {
        public bool ValidateIssuer { get; set; } public bool ValidateAudience { get; set; } public bool ValidateLifetime { get; set; }
        public bool ValidateIssuerSigningKey { get; set; }
        public string? ValidIssuer { get; set; } public string? ValidAudience { get; set; }
        public SecurityKey? IssuerSigningKey { get; set; } public TimeSpan ClockSkew { get; set; }
        public string? NameClaimType { get; set; } public string? RoleClaimType { get; set; }
    }
}
namespace System.IdentityModel.Tokens.Jwt
{
    public static class JwtRegisteredClaimNames { public const string Sub = "sub", Jti = "jti", Email = "email", UniqueName = "unique_name"; }
    public class JwtSecurityToken
    {
        public JwtSecurityToken(string? issuer = null, string? audience = null, IEnumerable<Claim>? claims = null, DateTime? notBefore = null, DateTime? expires = null, Microsoft.IdentityModel.Tokens.SigningCredentials? signingCredentials = null) { }
    }
    public class JwtSecurityTokenHandler { public string WriteToken(JwtSecurityToken t) => ""; }
}
namespace Microsoft.AspNetCore.Authentication.JwtBearer
{
    // stand-in handler: authenticates nobody, challenges with 401 (real JwtBearer validates the token)
    public class StubBearerHandler : AuthenticationHandler<AuthenticationSchemeOptions>
    {
        public StubBearerHandler(Microsoft.Extensions.Options.IOptionsMonitor<AuthenticationSchemeOptions> o, Microsoft.Extensions.Logging.ILoggerFactory l, System.Text.Encodings.Web.UrlEncoder e) : base(o, l, e) { }
        protected override Task<AuthenticateResult> HandleAuthenticateAsync() => Task.FromResult(AuthenticateResult.NoResult());
        protected override Task HandleChallengeAsync(AuthenticationProperties p) { Response.StatusCode = 401; Response.Headers["WWW-Authenticate"] = "Bearer"; return Task.CompletedTask; }
        protected override Task HandleForbiddenAsync(AuthenticationProperties p) { Response.StatusCode = 403; return Task.CompletedTask; }
    }
    public static class JwtBearerDefaults { public const string AuthenticationScheme = "Bearer"; }
    public class JwtBearerOptions
    {
        public bool MapInboundClaims { get; set; } public bool RequireHttpsMetadata { get; set; }
        public Microsoft.IdentityModel.Tokens.TokenValidationParameters TokenValidationParameters { get; set; } = new();
    }
    public static class JwtBearerExtensions
    {
        public static AuthenticationBuilder AddJwtBearer(this AuthenticationBuilder b, string scheme, Action<JwtBearerOptions> o) => b.AddScheme<AuthenticationSchemeOptions, StubBearerHandler>(scheme, null);
    }
}
namespace Microsoft.Extensions.DependencyInjection
{
    public static class OpenApiStubs { public static IServiceCollection AddOpenApi(this IServiceCollection s) => s; }
}
namespace Microsoft.AspNetCore.Builder
{
    public static class OpenApiAppStubs { public static IEndpointConventionBuilder MapOpenApi(this IEndpointRouteBuilder e, string pattern = "/openapi/{documentName}.json") => e.MapGet(pattern, () => "{}"); }
}
