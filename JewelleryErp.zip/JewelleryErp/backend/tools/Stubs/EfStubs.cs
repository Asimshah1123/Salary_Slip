using System.Collections;
using System.Data;
using System.Linq.Expressions;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;

namespace Microsoft.EntityFrameworkCore
{
    public enum DeleteBehavior { Cascade, Restrict, NoAction, SetNull }
    public enum EntityState { Detached, Unchanged, Deleted, Modified, Added }
    public class DbUpdateException : Exception { public DbUpdateException() { } public DbUpdateException(string m, Exception? i) : base(m, i) { } }
    public class DbUpdateConcurrencyException : DbUpdateException { }

    public class DbContextOptions { }
    public class DbContextOptions<T> : DbContextOptions where T : DbContext { }
    public class DbContextOptionsBuilder
    {
        public DbContextOptionsBuilder ConfigureWarnings(Action<WarningsConfigurationBuilder> a) => this;
    }
    public class WarningsConfigurationBuilder { public WarningsConfigurationBuilder Ignore(params object[] ids) => this; }
    public static class CoreEventId { public static readonly object PossibleIncorrectRequiredNavigationWithQueryFilterInteractionWarning = new(); }
    public static class SqlServerDbContextOptionsExtensions
    {
        public static DbContextOptionsBuilder UseSqlServer(this DbContextOptionsBuilder b, string connectionString, Action<object>? o = null) => b;
    }
    public static class EfServiceCollectionExtensions
    {
        public static IServiceCollection AddDbContext<T>(this IServiceCollection s, Action<DbContextOptionsBuilder> a) where T : DbContext { s.AddScoped<DbContextOptions<T>>(_ => new DbContextOptions<T>()); return s.AddScoped<T>(); }
    }

    public class DbContext : IDisposable, IAsyncDisposable
    {
        public DbContext(DbContextOptions o) { }
        public DatabaseFacade Database { get; } = new();
        public ChangeTracker ChangeTracker { get; } = new();
        protected virtual void OnModelCreating(ModelBuilder modelBuilder) { }
        protected virtual void ConfigureConventions(ModelConfigurationBuilder b) { }
        public DbSet<T> Set<T>() where T : class => new();
        public virtual Task<int> SaveChangesAsync(CancellationToken ct = default) => Task.FromResult(0);
        public virtual int SaveChanges() => 0;
        public Microsoft.EntityFrameworkCore.ChangeTracking.EntityEntry<T> Entry<T>(T e) where T : class => new() { Entity = e };
        public void Dispose() { }
        public ValueTask DisposeAsync() => default;
    }

    public class DbSet<T> : IQueryable<T> where T : class
    {
        IQueryable<T> _q = Enumerable.Empty<T>().AsQueryable();
        public Type ElementType => _q.ElementType;
        public Expression Expression => _q.Expression;
        public IQueryProvider Provider => _q.Provider;
        public IEnumerator<T> GetEnumerator() => _q.GetEnumerator();
        IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
        public T Add(T e) => e;
        public Task AddAsync(T e, CancellationToken ct = default) => Task.CompletedTask;
        public void AddRange(IEnumerable<T> e) { }
        public void AddRange(params T[] e) { }
        public T Remove(T e) => e;
        public void RemoveRange(IEnumerable<T> e) { }
        public ValueTask<T?> FindAsync(params object?[]? keys) => default;
    }

    public class DatabaseFacade
    {
        public Task<Microsoft.EntityFrameworkCore.Storage.IDbContextTransaction> BeginTransactionAsync(CancellationToken ct = default) => throw new NotImplementedException();
        public Task<Microsoft.EntityFrameworkCore.Storage.IDbContextTransaction> BeginTransactionAsync(IsolationLevel l, CancellationToken ct = default) => throw new NotImplementedException();
        public Task<bool> EnsureCreatedAsync(CancellationToken ct = default) => Task.FromResult(true);
        public Task MigrateAsync(CancellationToken ct = default) => Task.CompletedTask;
        public Task<bool> CanConnectAsync(CancellationToken ct = default) => Task.FromResult(true);
        public IQueryable<TResult> SqlQuery<TResult>(FormattableString sql) => Enumerable.Empty<TResult>().AsQueryable();
        public Task<int> ExecuteSqlInterpolatedAsync(FormattableString sql, CancellationToken ct = default) => Task.FromResult(0);
        public Microsoft.EntityFrameworkCore.Storage.IDbContextTransaction? CurrentTransaction => null;
    }

    public class ChangeTracker
    {
        public IEnumerable<Microsoft.EntityFrameworkCore.ChangeTracking.EntityEntry<T>> Entries<T>() where T : class => Enumerable.Empty<Microsoft.EntityFrameworkCore.ChangeTracking.EntityEntry<T>>();
    }

    public class ModelConfigurationBuilder
    {
        public PropertiesConfigurationBuilder<T> Properties<T>() => new();
    }
    public class PropertiesConfigurationBuilder<T>
    {
        public PropertiesConfigurationBuilder<T> HavePrecision(int precision, int scale) => this;
        public PropertiesConfigurationBuilder<T> HaveMaxLength(int n) => this;
    }

    public class ModelBuilder
    {
        public ModelBuilder Entity<T>(Action<Microsoft.EntityFrameworkCore.Metadata.Builders.EntityTypeBuilder<T>> a) where T : class => this;
        public Microsoft.EntityFrameworkCore.Metadata.Builders.EntityTypeBuilder<T> Entity<T>() where T : class => new();
        public Microsoft.EntityFrameworkCore.Metadata.Builders.EntityTypeBuilder Entity(Type t) => new();
    }

    public static class EF { public static T Property<T>(object entity, string name) => default!; }

    public static class EntityFrameworkQueryableExtensions
    {
        public static Task<List<T>> ToListAsync<T>(this IQueryable<T> q, CancellationToken ct = default) => Task.FromResult(q.ToList());
        public static Task<T[]> ToArrayAsync<T>(this IQueryable<T> q, CancellationToken ct = default) => Task.FromResult(q.ToArray());
        public static Task<T?> FirstOrDefaultAsync<T>(this IQueryable<T> q, CancellationToken ct = default) => Task.FromResult(q.FirstOrDefault());
        public static Task<T?> FirstOrDefaultAsync<T>(this IQueryable<T> q, Expression<Func<T, bool>> p, CancellationToken ct = default) => Task.FromResult(q.FirstOrDefault(p));
        public static Task<T> FirstAsync<T>(this IQueryable<T> q, CancellationToken ct = default) => Task.FromResult(q.First());
        public static Task<T> FirstAsync<T>(this IQueryable<T> q, Expression<Func<T, bool>> p, CancellationToken ct = default) => Task.FromResult(q.First(p));
        public static Task<T?> SingleOrDefaultAsync<T>(this IQueryable<T> q, Expression<Func<T, bool>> p, CancellationToken ct = default) => Task.FromResult(q.SingleOrDefault(p));
        public static Task<bool> AnyAsync<T>(this IQueryable<T> q, CancellationToken ct = default) => Task.FromResult(q.Any());
        public static Task<bool> AnyAsync<T>(this IQueryable<T> q, Expression<Func<T, bool>> p, CancellationToken ct = default) => Task.FromResult(q.Any(p));
        public static Task<bool> AllAsync<T>(this IQueryable<T> q, Expression<Func<T, bool>> p, CancellationToken ct = default) => Task.FromResult(q.All(p));
        public static Task<int> CountAsync<T>(this IQueryable<T> q, CancellationToken ct = default) => Task.FromResult(q.Count());
        public static Task<int> CountAsync<T>(this IQueryable<T> q, Expression<Func<T, bool>> p, CancellationToken ct = default) => Task.FromResult(q.Count(p));
        public static Task<long> LongCountAsync<T>(this IQueryable<T> q, CancellationToken ct = default) => Task.FromResult(q.LongCount());
        public static Task<decimal> SumAsync(this IQueryable<decimal> q, CancellationToken ct = default) => Task.FromResult(q.Sum());
        public static Task<decimal> SumAsync<T>(this IQueryable<T> q, Expression<Func<T, decimal>> s, CancellationToken ct = default) => Task.FromResult(q.Sum(s));
        public static Task<decimal?> SumAsync<T>(this IQueryable<T> q, Expression<Func<T, decimal?>> s, CancellationToken ct = default) => Task.FromResult(q.Sum(s));
        public static Task<int> SumAsync<T>(this IQueryable<T> q, Expression<Func<T, int>> s, CancellationToken ct = default) => Task.FromResult(q.Sum(s));
        public static Task<TR> MaxAsync<T, TR>(this IQueryable<T> q, Expression<Func<T, TR>> s, CancellationToken ct = default) => Task.FromResult(q.Max(s)!);
        public static Task<TR> MinAsync<T, TR>(this IQueryable<T> q, Expression<Func<T, TR>> s, CancellationToken ct = default) => Task.FromResult(q.Min(s)!);
        public static Task<Dictionary<TK, TV>> ToDictionaryAsync<T, TK, TV>(this IQueryable<T> q, Func<T, TK> k, Func<T, TV> v, CancellationToken ct = default) where TK : notnull => Task.FromResult(q.ToDictionary(k, v));
        public static Task<Dictionary<TK, T>> ToDictionaryAsync<T, TK>(this IQueryable<T> q, Func<T, TK> k, CancellationToken ct = default) where TK : notnull => Task.FromResult(q.ToDictionary(k));
        public static IQueryable<T> AsNoTracking<T>(this IQueryable<T> q) where T : class => q;
        public static IQueryable<T> IgnoreQueryFilters<T>(this IQueryable<T> q) where T : class => q;
        public static Microsoft.EntityFrameworkCore.Query.IIncludableQueryable<T, TP> Include<T, TP>(this IQueryable<T> q, Expression<Func<T, TP>> p) where T : class => new Microsoft.EntityFrameworkCore.Query.IncludableStub<T, TP>(q);
    }
}

namespace Microsoft.EntityFrameworkCore.Query
{
    public interface IIncludableQueryable<out T, out TP> : IQueryable<T> { }
    public class IncludableStub<T, TP> : IIncludableQueryable<T, TP>
    {
        readonly IQueryable<T> _q;
        public IncludableStub(IQueryable<T> q) { _q = q; }
        public Type ElementType => _q.ElementType;
        public Expression Expression => _q.Expression;
        public IQueryProvider Provider => _q.Provider;
        public IEnumerator<T> GetEnumerator() => _q.GetEnumerator();
        IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
    }
}

namespace Microsoft.EntityFrameworkCore.Storage
{
    public interface IDbContextTransaction : IDisposable, IAsyncDisposable
    {
        Task CommitAsync(CancellationToken ct = default);
        Task RollbackAsync(CancellationToken ct = default);
    }
}

namespace Microsoft.EntityFrameworkCore.ChangeTracking
{
    public class EntityEntry<T> where T : class { public T Entity { get; set; } = default!; public EntityState State { get; set; } }
}

namespace Microsoft.EntityFrameworkCore.Metadata.Builders
{
    public class EntityTypeBuilder
    {
        public PropertyBuilder Property(string name) => new();
        public ReferenceNavigationBuilder HasOne(Type related, string? nav = null) => new();
        public EntityTypeBuilder HasQueryFilter(LambdaExpression f) => this;
        public IndexBuilder HasIndex(params string[] names) => new();
    }
    public class ReferenceNavigationBuilder { public ReferenceCollectionBuilder WithMany(string? nav = null) => new(); }
    public class ReferenceCollectionBuilder
    {
        public ReferenceCollectionBuilder HasForeignKey(params string[] names) => this;
        public ReferenceCollectionBuilder OnDelete(DeleteBehavior b) => this;
    }
    public class EntityTypeBuilder<T> where T : class
    {
        public EntityTypeBuilder<T> HasKey(Expression<Func<T, object?>> k) => this;
        public IndexBuilder<T> HasIndex(Expression<Func<T, object?>> k) => new();
        public PropertyBuilder<P> Property<P>(Expression<Func<T, P>> p) => new();
        public EntityTypeBuilder<T> ToTable(string name) => this;
        public EntityTypeBuilder<T> HasQueryFilter(Expression<Func<T, bool>> f) => this;
        public EntityTypeBuilder<T> Ignore(Expression<Func<T, object?>> p) => this;
    }
    public class IndexBuilder { public IndexBuilder IsUnique(bool u = true) => this; public IndexBuilder HasFilter(string f) => this; }
    public class IndexBuilder<T> { public IndexBuilder<T> IsUnique(bool u = true) => this; public IndexBuilder<T> HasFilter(string f) => this; }
    public class PropertyBuilder
    {
        public PropertyBuilder HasPrecision(int p, int s) => this;
        public PropertyBuilder IsRowVersion() => this;
        public PropertyBuilder HasMaxLength(int n) => this;
        public PropertyBuilder HasColumnType(string t) => this;
    }
    public class PropertyBuilder<P>
    {
        public PropertyBuilder<P> HasPrecision(int p, int s) => this;
        public PropertyBuilder<P> IsRowVersion() => this;
        public PropertyBuilder<P> HasMaxLength(int n) => this;
        public PropertyBuilder<P> IsRequired(bool r = true) => this;
    }
}
