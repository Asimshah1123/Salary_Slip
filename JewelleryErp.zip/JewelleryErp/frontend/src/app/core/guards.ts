import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { Session } from './session';

export const authGuard: CanActivateFn = () => { const s = inject(Session); return s.isAuthed() ? true : inject(Router).parseUrl('/login'); };

/** UI convenience only - the API enforces every permission regardless (hiding a link is not security). */
export const permGuard = (...any: string[]): CanActivateFn => () => { const s = inject(Session); return any.length === 0 || s.canAny(...any) ? true : inject(Router).parseUrl('/forbidden'); };
