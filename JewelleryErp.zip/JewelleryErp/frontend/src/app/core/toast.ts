import { Component, Injectable, signal } from '@angular/core';

export interface ToastMsg { id: number; text: string; kind: 'ok' | 'err' | 'info'; }

@Injectable({ providedIn: 'root' })
export class Toast {
  readonly items = signal<ToastMsg[]>([]);
  private n = 0;
  private push(text: string, kind: ToastMsg['kind'], ms: number) {
    const id = ++this.n; this.items.update(l => [...l, { id, text, kind }]);
    setTimeout(() => this.items.update(l => l.filter(x => x.id !== id)), ms);
  }
  ok(t: string) { this.push(t, 'ok', 3500); }
  info(t: string) { this.push(t, 'info', 4500); }
  err(t: string) { this.push(t, 'err', 8000); }
}

@Component({
  selector: 'app-toasts',
  template: `<div class="toasts" aria-live="polite">@for (t of toast.items(); track t.id) {<div class="toast" [class]="t.kind" role="status">{{ t.text }}</div>}</div>`,
})
export class Toasts { constructor(public toast: Toast) {} }
