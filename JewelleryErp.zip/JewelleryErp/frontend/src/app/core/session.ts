import { HttpClient } from '@angular/common/http';
import { Injectable, computed, inject, signal } from '@angular/core';
import { Router } from '@angular/router';
import { firstValueFrom } from 'rxjs';
import { API } from './api';

export interface BranchRef { id: number; code: string; name: string; isActive: boolean; }
export interface Profile { id: number; userName: string; fullName: string; email: string; language: string; defaultBranchId: number | null; employeeId: number | null; workerId: number | null; branches: BranchRef[]; permissions: string[]; roles: string[]; mustChangePassword: boolean; }

/** The access token lives only in memory (never localStorage). The refresh token is an HttpOnly cookie the script cannot read. */
@Injectable({ providedIn: 'root' })
export class Session {
  private http = inject(HttpClient);
  private router = inject(Router);
  readonly token = signal<string | null>(null);
  readonly user = signal<Profile | null>(null);
  readonly ready = signal(false);
  readonly branch = signal<number | 'all' | null>(null);
  readonly isAuthed = computed(() => !!this.token() && !!this.user());
  private perms = computed(() => new Set(this.user()?.permissions ?? []));
  private timer?: any;
  private refreshing?: Promise<boolean>;

  can = (p: string) => this.perms().has(p);
  canAny = (...p: string[]) => p.some(x => this.perms().has(x));
  readonly canAll = computed(() => this.perms().has('Branches.ViewAll') || this.perms().has('Reports.Consolidated.View'));
  readonly activeBranch = computed(() => { const b = this.branch(); return typeof b === 'number' ? this.user()?.branches.find(x => x.id === b) : undefined; });

  private apply(r: { accessToken: string; expiresUtc: string; user: Profile }) {
    this.token.set(r.accessToken); this.user.set(r.user);
    const saved = sessionStorage.getItem('erp.branch');
    const ids = r.user.branches.map(b => b.id);
    const pick = saved === 'all' && this.canAll() ? 'all' : (saved && ids.includes(+saved) ? +saved : (r.user.defaultBranchId ?? ids[0] ?? null));
    this.branch.set(pick as any);
    clearTimeout(this.timer);
    const ms = Math.max(10_000, new Date(r.expiresUtc).getTime() - Date.now() - 60_000);
    this.timer = setTimeout(() => this.refresh(), ms);
  }

  async login(userName: string, password: string) {
    const r = await firstValueFrom(this.http.post<any>(`${API}/auth/login`, { userName, password }, { withCredentials: true }));
    this.apply(r);
  }

  refresh(): Promise<boolean> {
    if (this.refreshing) return this.refreshing;
    this.refreshing = firstValueFrom(this.http.post<any>(`${API}/auth/refresh`, {}, { withCredentials: true, headers: { 'X-Requested-With': 'erp-web' } }))
      .then(r => { this.apply(r); return true; }).catch(() => { this.clear(); return false; }).finally(() => (this.refreshing = undefined));
    return this.refreshing;
  }

  async bootstrap() { await this.refresh(); this.ready.set(true); }

  async logout() {
    try { await firstValueFrom(this.http.post(`${API}/auth/logout`, {}, { withCredentials: true, headers: { 'X-Requested-With': 'erp-web' } })); } catch { /* ignore */ }
    this.clear(); this.router.navigateByUrl('/login');
  }

  clear() { clearTimeout(this.timer); this.token.set(null); this.user.set(null); }

  setBranch(b: number | 'all') { sessionStorage.setItem('erp.branch', String(b)); this.branch.set(b); location.reload(); }   // reload: drops every branch-specific cache (SRS 21.3)
  async reloadProfile() { const p = await firstValueFrom(this.http.get<Profile>(`${API}/me`)); this.user.set(p); }
}
