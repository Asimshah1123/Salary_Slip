import { Injectable, signal } from '@angular/core';
import { Pipe, PipeTransform, inject } from '@angular/core';

const UR: Record<string, string> = {
  'Dashboard': 'ڈیش بورڈ', 'Sales (POS)': 'فروخت (POS)', 'Products': 'مصنوعات', 'Gallery': 'گیلری', 'Gold rates': 'سونے کے نرخ', 'Customers': 'گاہک', 'Suppliers': 'سپلائرز',
  'Purchases': 'خریداری', 'Inventory': 'اسٹاک', 'Karigar jobs': 'کاریگر کام', 'Repairs': 'مرمت', 'Finance': 'مالیات', 'Reports': 'رپورٹس', 'Administration': 'انتظامیہ',
  'Sign in': 'لاگ ان', 'Sign out': 'لاگ آؤٹ', 'Save': 'محفوظ کریں', 'Cancel': 'منسوخ', 'Search': 'تلاش', 'Total': 'کل', 'Paid': 'ادا شدہ', 'Due': 'باقی', 'Print': 'پرنٹ',
  'Invoice': 'انوائس', 'Customer': 'گاہک', 'Salesman': 'سیلزمین', 'Net weight': 'خالص وزن', 'Making': 'مزدوری', 'Discount': 'رعایت', 'Post sale': 'فروخت پوسٹ کریں', 'Hold': 'روکیں',
};

/** English/Urdu labels. Extend the dictionary above; unknown keys fall back to the English text. */
@Injectable({ providedIn: 'root' })
export class Lang {
  readonly lang = signal<'en' | 'ur'>((localStorage.getItem('erp.lang') as any) === 'ur' ? 'ur' : 'en');
  constructor() { this.apply(); }
  toggle() { this.lang.set(this.lang() === 'en' ? 'ur' : 'en'); localStorage.setItem('erp.lang', this.lang()); this.apply(); }
  private apply() { document.documentElement.lang = this.lang(); document.documentElement.dir = this.lang() === 'ur' ? 'rtl' : 'ltr'; }
  t(s: string) { return this.lang() === 'ur' ? (UR[s] ?? s) : s; }
}

@Pipe({ name: 't', pure: false })
export class TPipe implements PipeTransform { private l = inject(Lang); transform(v: string) { return this.l.t(v); } }
