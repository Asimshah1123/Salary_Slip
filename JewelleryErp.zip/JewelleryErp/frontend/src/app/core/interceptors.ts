import { HttpErrorResponse, HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';
import { Router } from '@angular/router';
import { catchError, from, switchMap, throwError } from 'rxjs';
import { Session } from './session';
import { Toast } from './toast';

const uid = () => (crypto as any).randomUUID?.() ?? Math.random().toString(36).slice(2) + Date.now().toString(36);

export const authInterceptor: HttpInterceptorFn = (req, next) => {
  const s = inject(Session); const toast = inject(Toast); const router = inject(Router);
  const isAuthCall = req.url.includes('/auth/');
  const decorate = (r: typeof req) => {
    let h = r.headers;
    const t = s.token(); if (t && !isAuthCall) h = h.set('Authorization', `Bearer ${t}`);
    const b = s.branch(); if (b !== null && !isAuthCall) h = h.set('X-Branch-Id', String(b));
    // every state-changing call carries an idempotency key so a retried request can never double-post a sale, payment or stock move
    if (['POST', 'PUT', 'PATCH'].includes(r.method) && !isAuthCall && !h.has('Idempotency-Key')) h = h.set('Idempotency-Key', uid());
    return r.clone({ headers: h });
  };
  const sent = decorate(req);
  return next(sent).pipe(catchError((e: HttpErrorResponse) => {
    if (e.status === 401 && !isAuthCall && s.token()) {
      return from(s.refresh()).pipe(switchMap(ok => { if (ok) return next(decorate(req)); router.navigateByUrl('/login'); return throwError(() => e); }));
    }
    if (e.status === 401 && !isAuthCall) { router.navigateByUrl('/login'); }
    const body: any = e.error;
    let msg = body?.title ?? (e.status === 0 ? 'Cannot reach the server.' : e.status === 429 ? 'Too many requests - please wait a moment.' : 'Unexpected error');
    if (body?.errors && typeof body.errors === 'object') { const first = Object.values(body.errors as Record<string, string[]>)[0]; if (first?.length) msg = first[0]; }
    if (e.status !== 401 || isAuthCall) toast.err(msg + (body?.correlationId && e.status >= 500 ? ` (ref ${body.correlationId})` : ''));
    return throwError(() => e);
  }));
};
