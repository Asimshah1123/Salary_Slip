import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable } from 'rxjs';

export const API = '/api/v1';

export function qs(o: Record<string, any> | undefined): HttpParams {
  let p = new HttpParams();
  for (const [k, v] of Object.entries(o ?? {})) {
    if (v === undefined || v === null || v === '') continue;
    if (Array.isArray(v)) v.forEach(x => (p = p.append(k, String(x))));
    else if (v instanceof Date) p = p.set(k, v.toISOString());
    else p = p.set(k, String(v));
  }
  return p;
}

@Injectable({ providedIn: 'root' })
export class Api {
  private http = inject(HttpClient);
  get<T = any>(url: string, params?: Record<string, any>): Observable<T> { return this.http.get<T>(API + url, { params: qs(params) }); }
  post<T = any>(url: string, body: any = {}): Observable<T> { return this.http.post<T>(API + url, body); }
  put<T = any>(url: string, body: any = {}): Observable<T> { return this.http.put<T>(API + url, body); }
  patch<T = any>(url: string, body: any = {}): Observable<T> { return this.http.patch<T>(API + url, body); }
  delete<T = any>(url: string, params?: Record<string, any>): Observable<T> { return this.http.delete<T>(API + url, { params: qs(params) }); }
  blob(url: string, params?: Record<string, any>) { return this.http.get(API + url, { params: qs(params), responseType: 'blob', observe: 'response' }); }
  upload<T = any>(url: string, form: FormData) { return this.http.post<T>(API + url, form, { reportProgress: true, observe: 'events' }); }

  /** Download a server-generated file (CSV/XLSX/PDF) with the Authorization header, then hand it to the browser. */
  download(url: string, params: Record<string, any>, fallbackName: string) {
    this.blob(url, params).subscribe(r => {
      const cd = r.headers.get('Content-Disposition') ?? '';
      const m = /filename\*?=(?:UTF-8'')?"?([^";]+)"?/i.exec(cd);
      const a = document.createElement('a');
      a.href = URL.createObjectURL(r.body as Blob); a.download = m?.[1] ?? fallbackName;
      document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(a.href), 5000);
    });
  }
}
