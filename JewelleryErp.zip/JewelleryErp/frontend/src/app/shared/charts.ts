import { Component, computed, input } from '@angular/core';

export interface Pt { label: string; value: number; }
const PALETTE = ['#b8860b', '#2f6f8f', '#7a5195', '#2e8b57', '#c0504d', '#6b7a8f', '#d98e04', '#4f8a8b'];
const compact = (v: number) => (Math.abs(v) >= 1e6 ? (v / 1e6).toFixed(1) + 'M' : Math.abs(v) >= 1e3 ? (v / 1e3).toFixed(0) + 'k' : String(Math.round(v)));

@Component({
  selector: 'app-bars',
  template: `<div class="bars">@for (d of data(); track d.label; let i = $index) {<div class="barrow"><span class="lbl" [title]="d.label">{{ d.label }}</span><span class="track"><i [style.width.%]="pct(d.value)" [style.background]="color(i)"></i></span><b>{{ fmt(d.value) }}</b></div>} @empty {<p class="muted">No data for this period.</p>}</div>`,
})
export class Bars {
  data = input<Pt[]>([]);
  max = computed(() => Math.max(1, ...this.data().map(d => d.value)));
  pct = (v: number) => Math.max(1.5, (v / this.max()) * 100); color = (i: number) => PALETTE[i % PALETTE.length]; fmt = compact;
}

@Component({
  selector: 'app-line',
  template: `@if (data().length > 1) { <svg viewBox="0 0 400 140" preserveAspectRatio="none" class="line" role="img" aria-label="Trend"><polyline [attr.points]="points()" fill="none" stroke="#b8860b" stroke-width="2" vector-effect="non-scaling-stroke" />
    @for (p of dots(); track $index) { <circle [attr.cx]="p[0]" [attr.cy]="p[1]" r="2.5" fill="#b8860b" /> }</svg>
    <div class="axis"><span>{{ data()[0].label }}</span><span>peak {{ fmt(top()) }}</span><span>{{ data()[data().length - 1].label }}</span></div> } @else { <p class="muted">Not enough data for a trend.</p> }`,
})
export class Line {
  data = input<Pt[]>([]);
  top = computed(() => Math.max(1, ...this.data().map(d => d.value)));
  dots = computed(() => this.data().map((d, i, a) => [10 + (380 * i) / Math.max(1, a.length - 1), 130 - (120 * d.value) / this.top()]));
  points = computed(() => this.dots().map(p => p.join(',')).join(' '));
  fmt = compact;
}

@Component({
  selector: 'app-donut',
  template: `@if (total() > 0) { <div class="donut"><svg viewBox="0 0 42 42" role="img" aria-label="Share"><circle cx="21" cy="21" r="15.9" fill="none" stroke="#eee" stroke-width="6" />
    @for (s of segs(); track s.label) { <circle cx="21" cy="21" r="15.9" fill="none" [attr.stroke]="s.color" stroke-width="6" [attr.stroke-dasharray]="s.dash" [attr.stroke-dashoffset]="s.off" transform="rotate(-90 21 21)" /> }</svg>
    <ul>@for (s of segs(); track s.label) {<li><i [style.background]="s.color"></i>{{ s.label }} <b>{{ s.pct }}%</b></li>}</ul></div> } @else { <p class="muted">No data for this period.</p> }`,
})
export class Donut {
  data = input<Pt[]>([]);
  total = computed(() => this.data().reduce((a, d) => a + d.value, 0));
  segs = computed(() => { let acc = 0; const t = this.total(); return this.data().map((d, i) => { const p = (d.value / t) * 100; const s = { label: d.label, color: PALETTE[i % PALETTE.length], pct: Math.round(p), dash: `${p} ${100 - p}`, off: -acc }; acc += p; return s; }); });
}
