import { HttpClient, HttpEventType } from '@angular/common/http';
import { Component, OnDestroy, effect, inject, input, output, signal } from '@angular/core';
import { API } from '../core/api';
import { Api } from '../core/api';
import { Toast } from '../core/toast';
import { Dialog } from './dialog';

const cache = new Map<number, Promise<string>>();

/** Images require the Authorization header, so they are fetched as blobs (an <img src> cannot send it) and shown via object URLs. */
@Component({
  selector: 'app-img',
  template: `@if (url()) { <img [src]="url()" [alt]="alt()" [style.width.px]="size()" [style.height.px]="size()" [class.zoomable]="zoom()" (click)="zoom() && zoomed.emit(id())" loading="lazy" /> } @else { <span class="noimg" [style.width.px]="size()" [style.height.px]="size()"></span> }`,
})
export class SecureImg {
  private http = inject(HttpClient);
  id = input.required<number>(); alt = input(''); size = input(64); zoom = input(false);
  zoomed = output<number>();
  url = signal<string | null>(null);
  constructor() { effect(() => { const id = this.id(); if (!cache.has(id)) cache.set(id, new Promise<string>((res, rej) => this.http.get(`${API}/files/${id}`, { responseType: 'blob' }).subscribe({ next: b => res(URL.createObjectURL(b)), error: rej }))); cache.get(id)!.then(u => this.url.set(u)).catch(() => this.url.set(null)); }); }
}

const OK = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];

@Component({
  selector: 'app-uploader',
  template: `
  <div class="uploader" (dragover)="$event.preventDefault()" (drop)="drop($event)">
    <label class="btn ghost">＋ {{ label() }}<input type="file" accept="image/jpeg,image/png,image/webp,image/gif" multiple hidden (change)="pick($any($event.target))" /></label>
    <small class="hint">JPEG / PNG / WebP / GIF, up to {{ maxMb() }} MB each. Files are verified again on the server.</small>
    @for (j of jobs(); track j.name + $index) {
      <div class="job" [class.fail]="j.error">
        @if (j.preview) { <img [src]="j.preview" alt="" /> }
        <div class="grow"><div>{{ j.name }}</div>
          @if (j.error) { <small class="error">{{ j.error }}</small> } @else { <div class="bar"><i [style.width.%]="j.pct"></i></div> }
        </div>
        <span>{{ j.error ? '✕' : j.done ? '✓' : j.pct + '%' }}</span>
      </div>
    }
  </div>`,
})
export class ImageUploader {
  private api = inject(Api); private toast = inject(Toast);
  ownerType = input.required<string>(); ownerId = input.required<number>();
  kind = input('General'); label = input('Upload image'); maxMb = input(8); makePrimary = input(false); caption = input('');
  uploaded = output<any>();
  jobs = signal<{ name: string; pct: number; done: boolean; error?: string; preview?: string }[]>([]);

  drop(e: DragEvent) { e.preventDefault(); this.start(Array.from(e.dataTransfer?.files ?? [])); }
  pick(el: HTMLInputElement) { this.start(Array.from(el.files ?? [])); el.value = ''; }
  private start(files: File[]) {
    for (const f of files) {
      const j = { name: f.name, pct: 0, done: false, error: undefined as string | undefined, preview: undefined as string | undefined };
      this.jobs.update(l => [...l, j]); const upd = (p: Partial<typeof j>) => this.jobs.update(l => l.map(x => (x === j ? Object.assign(j, p) : x)).map(x => ({ ...x })));
      if (!OK.includes(f.type)) { upd({ error: 'Only JPEG, PNG, WebP or GIF images are accepted.' }); continue; }
      if (f.size > this.maxMb() * 1024 * 1024) { upd({ error: `Larger than ${this.maxMb()} MB.` }); continue; }
      j.preview = URL.createObjectURL(f);
      const fd = new FormData(); fd.append('File', f); fd.append('Kind', this.kind()); fd.append('MakePrimary', String(this.makePrimary())); if (this.caption()) fd.append('Caption', this.caption());
      this.api.upload(`/files/${this.ownerType()}/${this.ownerId()}`, fd).subscribe({
        next: ev => { if (ev.type === HttpEventType.UploadProgress && ev.total) upd({ pct: Math.round((100 * ev.loaded) / ev.total) }); else if (ev.type === HttpEventType.Response) { upd({ pct: 100, done: true }); this.toast.ok(`${f.name} uploaded`); this.uploaded.emit(ev.body); } },
        error: e => upd({ error: e.error?.title ?? 'Upload failed' }),
      });
    }
  }
}

@Component({
  selector: 'app-gallery',
  imports: [SecureImg, Dialog],
  template: `
  <div class="thumbs">
    @for (i of images(); track i.id; let idx = $index) {
      <figure [class.primary]="i.isPrimary">
        <app-img [id]="i.id" [size]="110" [zoom]="true" (zoomed)="viewing.set(i)" />
        <figcaption>
          <small>{{ i.kind }} · {{ i.width }}×{{ i.height }}</small>
          @if (canEdit()) { <span class="row-actions">
            @if (!i.isPrimary) { <button class="icon" title="Set primary" (click)="primary(i)">★</button> }
            <button class="icon" title="Move earlier" [disabled]="idx === 0" (click)="move(idx, -1)">◀</button>
            <button class="icon" title="Move later" [disabled]="idx === images().length - 1" (click)="move(idx, 1)">▶</button>
            @if (canDelete()) { <button class="icon danger" title="Remove" (click)="remove(i)">✕</button> }
          </span> }
        </figcaption>
      </figure>
    } @empty { <p class="muted">No images yet.</p> }
  </div>
  @if (viewing(); as v) {
    <app-dialog [title]="v.caption || ('Image ' + v.id)" [width]="980" (closed)="viewing.set(null)">
      <div class="viewer"><app-img [id]="v.id" [size]="640" /></div>
      <div class="actions"><button class="btn ghost" (click)="download(v)" [disabled]="!canDownload()">Download original</button></div>
    </app-dialog>
  }`,
})
export class Gallery {
  private api = inject(Api); private toast = inject(Toast);
  ownerType = input.required<string>(); ownerId = input.required<number>(); kind = input<string | null>(null);
  canEdit = input(false); canDelete = input(false); canDownload = input(false);
  images = signal<any[]>([]); viewing = signal<any | null>(null);
  changed = output<void>();
  constructor() { effect(() => { this.ownerId(); this.reload(); }); }
  reload() { this.api.get(`/files/${this.ownerType()}/${this.ownerId()}`, { kind: this.kind() }).subscribe(r => this.images.set(r)); }
  primary(i: any) { this.api.post(`/files/${i.id}/primary`).subscribe(() => { this.reload(); this.changed.emit(); }); }
  remove(i: any) { const reason = prompt('Why is this image being removed? (kept in the audit archive)'); if (reason === null) return; this.api.delete(`/files/${i.id}`, { reason }).subscribe(() => { this.toast.ok('Image archived'); this.reload(); this.changed.emit(); }); }
  move(idx: number, d: number) { const l = [...this.images()]; [l[idx], l[idx + d]] = [l[idx + d], l[idx]]; this.images.set(l); this.api.put(`/files/${this.ownerType()}/${this.ownerId()}/order`, { ids: l.map(x => x.id) }).subscribe(); }
  download(i: any) { this.api.download(`/files/${i.id}`, { download: true }, `image-${i.id}`); }
}
