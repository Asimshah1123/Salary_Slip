import { Pipe, PipeTransform } from '@angular/core';

const nf2 = new Intl.NumberFormat('en-PK', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const nf3 = new Intl.NumberFormat('en-PK', { minimumFractionDigits: 3, maximumFractionDigits: 3 });
const pad = (n: number) => String(n).padStart(2, '0');
export const fmtDate = (v: any) => { if (!v) return ''; const d = new Date(v); return isNaN(+d) ? String(v) : `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`; };
export const fmtDateTime = (v: any) => { if (!v) return ''; const d = new Date(v); return isNaN(+d) ? String(v) : `${fmtDate(d)} ${pad(d.getHours())}:${pad(d.getMinutes())}`; };
export const fmtMoney = (v: any) => (v === null || v === undefined || v === '' ? '' : nf2.format(+v));
export const fmtWeight = (v: any) => (v === null || v === undefined || v === '' ? '' : nf3.format(+v));

@Pipe({ name: 'money' }) export class MoneyPipe implements PipeTransform { transform(v: any) { return fmtMoney(v); } }
@Pipe({ name: 'weight' }) export class WeightPipe implements PipeTransform { transform(v: any) { return fmtWeight(v); } }
@Pipe({ name: 'dt' }) export class DtPipe implements PipeTransform { transform(v: any, withTime = true) { return withTime ? fmtDateTime(v) : fmtDate(v); } }
/** "SalesInvoice" -> "Sales Invoice", "PartiallyPaid" -> "Partially Paid" */
@Pipe({ name: 'nice' }) export class NicePipe implements PipeTransform { transform(v: any) { return v == null ? '' : String(v).replace(/([a-z])([A-Z])/g, '$1 $2'); } }
