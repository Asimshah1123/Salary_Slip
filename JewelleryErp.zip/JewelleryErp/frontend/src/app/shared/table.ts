import { Component, TemplateRef, contentChild, effect, input, output, signal } from '@angular/core';
import { NgTemplateOutlet } from '@angular/common';
import { RouterLink } from '@angular/router';
import { Observable } from 'rxjs';
import { MoneyPipe, WeightPipe, DtPipe, NicePipe } from './pipes';
import { SecureImg } from './img';

export interface Col { key: string; label: string; type?: 'text' | 'money' | 'weight' | 'number' | 'date' | 'datetime' | 'status' | 'bool' | 'img'; sortable?: boolean; link?: (r: any) => any[]; fmt?: (r: any) => any; cls?: string; }

@Component({
  selector: 'app-table',
  imports: [RouterLink, NgTemplateOutlet, MoneyPipe, WeightPipe, DtPipe, NicePipe, SecureImg],
  template: `
  @if (searchable()) { <div class="toolbar"><input type="search" class="search" placeholder="Search…" [value]="search()" (input)="onSearch($any($event.target).value)" aria-label="Search" /></div> }
  <div class="tablewrap">
  <table class="grid">
    <thead><tr>
      @for (c of columns(); track c.key) { <th [class.sortable]="c.sortable" [class]="c.cls ?? ''" (click)="c.sortable && sortBy(c.key)" [attr.aria-sort]="sort() === c.key ? (desc() ? 'descending' : 'ascending') : null">{{ c.label }}@if (sort() === c.key) { {{ desc() ? '▼' : '▲' }} }</th> }
      @if (actions()) { <th></th> }
    </tr></thead>
    <tbody>
      @for (r of rows(); track $index) {
        <tr [class.clickable]="clickable()" (click)="rowClick.emit(r)">
          @for (c of columns(); track c.key) {
            <td [class]="(c.cls ?? '') + (c.type === 'money' || c.type === 'weight' || c.type === 'number' ? ' num' : '')">
              @let v = c.fmt ? c.fmt(r) : r[c.key];
              @switch (c.type ?? 'text') {
                @case ('money') { {{ v | money }} } @case ('weight') { {{ v | weight }} } @case ('number') { {{ v }} }
                @case ('date') { {{ v | dt: false }} } @case ('datetime') { {{ v | dt }} }
                @case ('bool') { {{ v ? '✓' : '' }} }
                @case ('status') { @if (v) { <span class="badge" [attr.data-s]="v">{{ v | nice }}</span> } }
                @case ('img') { @if (v) { <app-img [id]="v" [size]="40" /> } @else { <span class="noimg"></span> } }
                @default { @if (c.link) { <a [routerLink]="c.link(r)" (click)="$event.stopPropagation()">{{ v }}</a> } @else { {{ v }} } }
              }
            </td>
          }
          @if (actions()) { <td class="rowactions" (click)="$event.stopPropagation()"><ng-container [ngTemplateOutlet]="actions()!" [ngTemplateOutletContext]="{ $implicit: r }" /></td> }
        </tr>
      } @empty { <tr><td [attr.colspan]="columns().length + (actions() ? 1 : 0)" class="empty">{{ loading() ? 'Loading…' : 'Nothing to show.' }}</td></tr> }
    </tbody>
  </table></div>
  <div class="pager">
    <span>{{ total() }} record(s) @if (totalsText()) { · <b>{{ totalsText() }}</b> }</span>
    <span class="grow"></span>
    <button class="btn ghost sm" [disabled]="page() <= 1" (click)="go(page() - 1)">‹ Prev</button>
    <span>Page {{ page() }} / {{ pages() }}</span>
    <button class="btn ghost sm" [disabled]="page() >= pages()" (click)="go(page() + 1)">Next ›</button>
  </div>`,
})
export class DataTable {
  columns = input.required<Col[]>();
  loader = input.required<(q: any) => Observable<any>>();
  searchable = input(true);
  pageSize = input(25);
  /** change this value (e.g. the filter object) to trigger a reload from page 1 */
  refresh = input<any>(null);
  rowClick = output<any>();
  clickable = input(false);
  actions = contentChild<TemplateRef<any>>('actions');
  rows = signal<any[]>([]); total = signal(0); page = signal(1); loading = signal(false);
  search = signal(''); sort = signal<string | null>(null); desc = signal(false); totals = signal<Record<string, number> | null>(null);
  private t?: any;
  pages = () => Math.max(1, Math.ceil(this.total() / this.pageSize()));
  totalsText = () => { const t = this.totals(); return t ? Object.entries(t).map(([k, v]) => `${k}: ${Number(v).toLocaleString('en-PK', { maximumFractionDigits: 3 })}`).join('  ·  ') : ''; };

  constructor() { effect(() => { this.refresh(); this.page.set(1); this.load(); }); }
  onSearch(v: string) { this.search.set(v); clearTimeout(this.t); this.t = setTimeout(() => { this.page.set(1); this.load(); }, 300); }
  sortBy(k: string) { if (this.sort() === k) this.desc.set(!this.desc()); else { this.sort.set(k); this.desc.set(false); } this.load(); }
  go(p: number) { this.page.set(p); this.load(); }
  reload() { this.load(); }
  load() {
    this.loading.set(true);
    this.loader()({ page: this.page(), pageSize: this.pageSize(), search: this.search(), sort: this.sort(), desc: this.desc() }).subscribe({
      next: r => { const items = Array.isArray(r) ? r : r.items; this.rows.set(items); this.total.set(Array.isArray(r) ? items.length : r.total); this.totals.set(r.totals ?? null); this.loading.set(false); },
      error: () => this.loading.set(false),
    });
  }
}
