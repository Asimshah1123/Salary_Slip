import { Component, HostListener, input, output } from '@angular/core';

@Component({
  selector: 'app-dialog',
  template: `
  <div class="overlay" (mousedown)="$event.target === $event.currentTarget && closed.emit()">
    <div class="dialog" role="dialog" aria-modal="true" [attr.aria-label]="title()" [style.maxWidth.px]="width()">
      <header><h3>{{ title() }}</h3><button type="button" class="icon" (click)="closed.emit()" aria-label="Close">✕</button></header>
      <div class="body"><ng-content /></div>
    </div>
  </div>`,
})
export class Dialog {
  title = input('');
  width = input(720);
  closed = output<void>();
  @HostListener('document:keydown.escape') esc() { this.closed.emit(); }
}
