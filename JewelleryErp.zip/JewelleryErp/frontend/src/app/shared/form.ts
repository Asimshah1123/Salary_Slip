import { Component, OnInit, effect, inject, input, output, signal } from '@angular/core';
import { Lookups, Opt } from './lookups';

export type FieldType = 'text' | 'number' | 'date' | 'datetime' | 'select' | 'multiselect' | 'checkbox' | 'textarea' | 'password' | 'lines' | 'email';
export interface Field {
  key: string; label: string; type?: FieldType; required?: boolean; options?: Opt[]; lookup?: string; default?: any; hint?: string; step?: string; min?: number;
  fields?: Field[]; showIf?: (v: any) => boolean; col?: 1 | 2 | 3; placeholder?: string; readonly?: boolean; nullable?: boolean; addLabel?: string;
}

@Component({
  selector: 'app-form',
  template: `
  <form (submit)="submit($event)" novalidate class="form" [class.cols]="true">
    @for (f of fields(); track f.key) {
      @if (!f.showIf || f.showIf(model())) {
      <div class="field" [class.span2]="f.col === 2 || f.type === 'lines' || f.type === 'textarea' || f.type === 'multiselect'" [class.span3]="f.col === 3" [class.err]="errors()[f.key]">
        @if (f.type !== 'checkbox') { <label [attr.for]="'f_' + f.key">{{ f.label }}@if (f.required) {<span class="req"> *</span>}</label> }
        @switch (f.type ?? 'text') {
          @case ('textarea') { <textarea [id]="'f_' + f.key" rows="3" [value]="model()[f.key] ?? ''" (input)="set(f.key, $any($event.target).value)" [readOnly]="!!f.readonly"></textarea> }
          @case ('checkbox') { <label class="check"><input type="checkbox" [checked]="!!model()[f.key]" (change)="set(f.key, $any($event.target).checked)" /> {{ f.label }}</label> }
          @case ('select') {
            <select [id]="'f_' + f.key" (change)="pick(f, $any($event.target).value)" [disabled]="!!f.readonly">
              <option value="">{{ f.placeholder ?? '— select —' }}</option>
              @for (o of optsOf(f); track o.value) { <option [value]="o.value" [selected]="same(model()[f.key], o.value)">{{ o.label }}</option> }
            </select> }
          @case ('multiselect') {
            <div class="chips">@for (o of optsOf(f); track o.value) { <label class="check"><input type="checkbox" [checked]="has(f.key, o.value)" (change)="toggle(f.key, o.value, $any($event.target).checked)" /> {{ o.label }}</label> }</div> }
          @case ('lines') {
            <div class="lines">
              <table><thead><tr>@for (c of f.fields; track c.key) {<th>{{ c.label }}@if (c.required) {<span class="req">*</span>}</th>}<th></th></tr></thead>
              <tbody>
              @for (row of rows(f.key); track $index; let i = $index) {
                <tr>@for (c of f.fields; track c.key) {
                  <td>@switch (c.type ?? 'text') {
                    @case ('select') { <select (change)="pickRow(f.key, i, c, $any($event.target).value)"><option value="">—</option>@for (o of optsOf(c); track o.value) {<option [value]="o.value" [selected]="same(row[c.key], o.value)">{{ o.label }}</option>}</select> }
                    @case ('checkbox') { <input type="checkbox" [checked]="!!row[c.key]" (change)="setRow(f.key, i, c.key, $any($event.target).checked)" /> }
                    @case ('number') { <input type="number" [attr.step]="c.step ?? 'any'" [value]="row[c.key] ?? ''" (input)="setRow(f.key, i, c.key, $any($event.target).value)" /> }
                    @default { <input [type]="c.type === 'date' ? 'date' : 'text'" [value]="row[c.key] ?? ''" (input)="setRow(f.key, i, c.key, $any($event.target).value)" /> }
                  }</td> }
                  <td><button type="button" class="icon danger" (click)="removeRow(f.key, i)" aria-label="Remove row">✕</button></td></tr>
              }
              </tbody></table>
              <button type="button" class="btn ghost sm" (click)="addRow(f)">＋ {{ f.addLabel ?? 'Add line' }}</button>
            </div> }
          @default {
            <input [id]="'f_' + f.key" [type]="f.type === 'number' ? 'number' : f.type === 'date' ? 'date' : f.type === 'datetime' ? 'datetime-local' : f.type === 'password' ? 'password' : f.type === 'email' ? 'email' : 'text'"
              [attr.step]="f.type === 'number' ? (f.step ?? 'any') : null" [attr.min]="f.min ?? null" [value]="model()[f.key] ?? ''" [placeholder]="f.placeholder ?? ''" [readOnly]="!!f.readonly"
              (input)="set(f.key, $any($event.target).value)" [attr.autocomplete]="f.type === 'password' ? 'new-password' : 'off'" />
          }
        }
        @if (errors()[f.key]) { <small class="error">{{ errors()[f.key] }}</small> } @else if (f.hint) { <small class="hint">{{ f.hint }}</small> }
      </div>
      }
    }
    <div class="actions span3">
      @if (cancelLabel()) { <button type="button" class="btn ghost" (click)="cancelled.emit()">{{ cancelLabel() }}</button> }
      <button type="submit" class="btn primary" [disabled]="busy()">{{ busy() ? 'Working…' : submitLabel() }}</button>
    </div>
  </form>`,
})
export class DynamicForm implements OnInit {
  private lk = inject(Lookups);
  fields = input.required<Field[]>();
  value = input<any>(null);
  submitLabel = input('Save');
  cancelLabel = input<string | null>(null);
  busy = input(false);
  submitted = output<any>();
  cancelled = output<void>();
  model = signal<Record<string, any>>({});
  errors = signal<Record<string, string>>({});
  private looked = signal<Record<string, Opt[]>>({});

  constructor() { effect(() => { const v = this.value(); if (v) this.model.set({ ...this.defaults(), ...v }); }); }
  ngOnInit() {
    if (!this.value()) this.model.set(this.defaults());
    const load = (fs: Field[]) => { for (const f of fs) { if (f.lookup) this.lk.resolve(f.lookup).then(o => this.looked.update(m => ({ ...m, [f.lookup!]: o }))); if (f.fields) load(f.fields); } };
    load(this.fields());
  }
  private defaults() { const m: Record<string, any> = {}; for (const f of this.fields()) { if (f.default !== undefined) m[f.key] = f.default; if (f.type === 'lines') m[f.key] = f.default ?? []; if (f.type === 'multiselect') m[f.key] = f.default ?? []; } return m; }

  optsOf(f: Field): Opt[] { return f.options ?? (f.lookup ? this.looked()[f.lookup] ?? [] : []); }
  same(a: any, b: any) { return a !== undefined && a !== null && String(a) === String(b); }
  set(k: string, v: any) { this.model.update(m => ({ ...m, [k]: v })); if (this.errors()[k]) this.errors.update(e => { const { [k]: _, ...r } = e; return r; }); }
  pick(f: Field, raw: string) { const o = this.optsOf(f).find(x => String(x.value) === raw); this.set(f.key, o ? o.value : null); }
  has(k: string, v: any) { return (this.model()[k] ?? []).some((x: any) => String(x) === String(v)); }
  toggle(k: string, v: any, on: boolean) { const cur: any[] = this.model()[k] ?? []; this.set(k, on ? [...cur.filter(x => String(x) !== String(v)), v] : cur.filter(x => String(x) !== String(v))); }
  rows(k: string): any[] { return this.model()[k] ?? []; }
  addRow(f: Field) { const r: any = {}; for (const c of f.fields ?? []) if (c.default !== undefined) r[c.key] = c.default; this.set(f.key, [...this.rows(f.key), r]); }
  removeRow(k: string, i: number) { this.set(k, this.rows(k).filter((_, j) => j !== i)); }
  setRow(k: string, i: number, ck: string, v: any) { this.set(k, this.rows(k).map((r, j) => (j === i ? { ...r, [ck]: v } : r))); }
  pickRow(k: string, i: number, c: Field, raw: string) { const o = this.optsOf(c).find(x => String(x.value) === raw); this.setRow(k, i, c.key, o ? o.value : null); }

  private clean(fs: Field[], src: any, errs: Record<string, string>, prefix = ''): any {
    const out: any = {};
    for (const f of fs) {
      if (f.showIf && !f.showIf(src)) continue;
      let v = src[f.key];
      if (f.type === 'lines') {
        const rows = (v ?? []).map((r: any, i: number) => this.clean(f.fields ?? [], r, errs, `${prefix}${f.key}[${i + 1}].`));
        if (f.required && rows.length === 0) errs[prefix + f.key] = 'Add at least one line.';
        out[f.key] = rows; continue;
      }
      if (f.type === 'number') v = v === '' || v === undefined || v === null ? null : Number(v);
      else if (f.type === 'checkbox') v = !!v;
      else if (f.type === 'multiselect') v = v ?? [];
      else if (typeof v === 'string') { v = v.trim(); if (v === '') v = null; }
      if (f.required && (v === null || v === undefined || (Array.isArray(v) && v.length === 0))) errs[prefix + f.key] = `${f.label} is required.`;
      if (f.type === 'number' && v !== null && Number.isNaN(v)) errs[prefix + f.key] = `${f.label} must be a number.`;
      out[f.key] = v;
    }
    return out;
  }

  submit(e: Event) {
    e.preventDefault(); const errs: Record<string, string> = {};
    const data = this.clean(this.fields(), this.model(), errs);
    this.errors.set(errs);
    if (Object.keys(errs).length === 0) this.submitted.emit(data);
  }
}
