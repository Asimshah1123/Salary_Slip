import { Injectable, inject } from '@angular/core';
import { firstValueFrom } from 'rxjs';
import { Api } from '../core/api';

export interface Opt { value: any; label: string; extra?: any; }

/** Small cached dropdown sources (masters). Cache lives for the page session; switching branch reloads the app. */
@Injectable({ providedIn: 'root' })
export class Lookups {
  private api = inject(Api);
  private cache = new Map<string, Promise<Opt[]>>();

  get(name: string, fresh = false): Promise<Opt[]> {
    if (fresh) this.cache.delete(name);
    if (!this.cache.has(name)) this.cache.set(name, firstValueFrom(this.api.get<any[]>(`/lookups/${name}`, { take: 200 })).then(r => r.map(x => ({ value: x.id, label: x.code && !['purities', 'payment-methods', 'cash-bank-accounts', 'locations', 'chart-accounts', 'products', 'branches'].includes(name) ? `${x.name} (${x.code})` : x.name, extra: x }))).catch(() => []));
    return this.cache.get(name)!;
  }

  /** "Gold 22K" style options (purity + its metal). */
  async purities(): Promise<Opt[]> {
    const [p, m] = await Promise.all([this.get('purities'), this.get('metals')]);
    return p.map(x => ({ value: x.value, label: `${m.find(y => y.value === +x.extra.code)?.extra.name ?? ''} ${x.label}`.trim(), extra: { metalTypeId: +x.extra.code, factor: x.extra.extra } }));
  }
  async resolve(name: string): Promise<Opt[]> { return name === 'purities+' ? this.purities() : this.get(name); }
  invalidate(name?: string) { name ? this.cache.delete(name) : this.cache.clear(); }
}
