import { Routes } from '@angular/router';
import { authGuard, permGuard } from './core/guards';

const P = {
  sales: ['Sales.View', 'Sales.Create'], products: ['Products.View'], inv: ['Inventory.View', 'Inventory.Transfer', 'Inventory.Count'], purch: ['Purchases.View'],
  job: ['JobWork.View', 'JobWork.ViewAssigned'], repair: ['Repairs.ViewBranch', 'Repairs.ViewAssigned', 'Repairs.Create'], fin: ['Finance.View', 'Finance.Expense.Create', 'Finance.Payment.Post'],
  rep: ['Reports.Dashboard.View', 'Reports.Sales.View', 'Reports.Transactions.View'],
};

export const routes: Routes = [
  { path: 'login', loadComponent: () => import('./features/auth').then(m => m.Login) },
  { path: 'forgot', loadComponent: () => import('./features/auth').then(m => m.Forgot) },
  { path: 'forbidden', loadComponent: () => import('./features/auth').then(m => m.Forbidden) },
  {
    path: '', canActivate: [authGuard], loadComponent: () => import('./features/shell').then(m => m.Shell),
    children: [
      { path: '', pathMatch: 'full', redirectTo: 'dashboard' },
      { path: 'dashboard', loadComponent: () => import('./features/dashboard').then(m => m.Dashboard) },
      { path: 'pos', canActivate: [permGuard('Sales.Create')], loadComponent: () => import('./features/pos').then(m => m.Pos) },
      { path: 'sales', canActivate: [permGuard(...P.sales)], loadComponent: () => import('./features/sales').then(m => m.SalesList) },
      { path: 'sales/:id', canActivate: [permGuard(...P.sales)], loadComponent: () => import('./features/sales').then(m => m.SaleDetail) },
      { path: 'old-gold', canActivate: [permGuard('OldGold.Create', 'OldGold.View')], loadComponent: () => import('./features/sales').then(m => m.OldGold) },
      { path: 'products', canActivate: [permGuard(...P.products)], loadComponent: () => import('./features/products').then(m => m.ProductList) },
      { path: 'products/new', canActivate: [permGuard('Products.Create')], loadComponent: () => import('./features/products').then(m => m.ProductForm) },
      { path: 'products/:id', canActivate: [permGuard(...P.products)], loadComponent: () => import('./features/products').then(m => m.ProductForm) },
      { path: 'gallery', canActivate: [permGuard('Products.Images.View')], loadComponent: () => import('./features/products').then(m => m.GalleryPage) },
      { path: 'gold-rates', canActivate: [permGuard('GoldRate.View')], loadComponent: () => import('./features/products').then(m => m.GoldRates) },
      { path: 'masters/:kind', loadComponent: () => import('./features/crud').then(m => m.Crud) },
      { path: 'list/:kind', loadComponent: () => import('./features/crud').then(m => m.Crud) },
      { path: 'ledger/:type/:id', loadComponent: () => import('./features/finance').then(m => m.Statement) },
      { path: 'purchases/:id', canActivate: [permGuard(...P.purch)], loadComponent: () => import('./features/purchases').then(m => m.PurchaseDetail) },
      { path: 'purchases/new', canActivate: [permGuard('Purchases.Create')], loadComponent: () => import('./features/purchases').then(m => m.PurchaseNew) },
      { path: 'inventory/stock', canActivate: [permGuard(...P.inv)], loadComponent: () => import('./features/inventory').then(m => m.Stock) },
      { path: 'inventory/transfers/:id', canActivate: [permGuard(...P.inv)], loadComponent: () => import('./features/inventory').then(m => m.TransferDetail) },
      { path: 'inventory/counts/:id', canActivate: [permGuard(...P.inv)], loadComponent: () => import('./features/inventory').then(m => m.CountDetail) },
      { path: 'job-work/:id', canActivate: [permGuard(...P.job)], loadComponent: () => import('./features/jobwork').then(m => m.JobDetail) },
      { path: 'repairs/new', canActivate: [permGuard('Repairs.Create')], loadComponent: () => import('./features/repairs').then(m => m.RepairNew) },
      { path: 'repairs/:id', canActivate: [permGuard(...P.repair)], loadComponent: () => import('./features/repairs').then(m => m.RepairDetail) },
      { path: 'finance/register', canActivate: [permGuard('Finance.CashRegister', 'Finance.View')], loadComponent: () => import('./features/finance').then(m => m.Register) },
      { path: 'finance/commission', canActivate: [permGuard('Reports.Commission.View', 'Commission.Approve')], loadComponent: () => import('./features/finance').then(m => m.Commission) },
      { path: 'reports', canActivate: [permGuard(...P.rep)], loadComponent: () => import('./features/reports').then(m => m.ReportsCentre) },
      { path: 'reports/transactions', canActivate: [permGuard('Reports.Transactions.View')], loadComponent: () => import('./features/reports').then(m => m.TransactionRegister) },
      { path: 'admin/users', canActivate: [permGuard('Users.Manage')], loadComponent: () => import('./features/admin').then(m => m.Users) },
      { path: 'admin/roles', canActivate: [permGuard('Roles.Manage', 'Users.Manage')], loadComponent: () => import('./features/admin').then(m => m.Roles) },
      { path: 'admin/settings', canActivate: [permGuard('Settings.Manage', 'Backup.Manage')], loadComponent: () => import('./features/admin').then(m => m.Settings) },
      { path: 'profile', loadComponent: () => import('./features/auth').then(m => m.Profile) },
      { path: '**', loadComponent: () => import('./features/auth').then(m => m.NotFound) },
    ],
  },
];
