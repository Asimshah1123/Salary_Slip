import { Component, inject, signal } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Api } from '../core/api';
import { Session } from '../core/session';
import { Toast } from '../core/toast';
import { DynamicForm, Field } from '../shared/form';
import { MoneyPipe, WeightPipe, DtPipe } from '../shared/pipes';
import { Dialog } from '../shared/dialog';

@Component({
  selector: 'app-statement', imports: [MoneyPipe, WeightPipe, DtPipe, DynamicForm],
  template: `@if (s(); as x) {
  <div class="pagehead"><h1>{{ x.name }}</h1><div class="sub">{{ type }} statement — {{ x.balanceMeaning }}</div></div>
  <div class="card"><app-form [fields]="f" [value]="range()" submitLabel="Apply" (submitted)="apply($event)" /></div>
  <div class="grid2">
    <div class="card"><h3>PKR ledger</h3><table class="grid"><thead><tr><th>Date</th><th>Doc</th><th>Type</th><th>Description</th><th>Debit</th><th>Credit</th><th>Balance</th></tr></thead>
    <tbody><tr><td colspan="6">Opening</td><td class="num">{{ x.opening | money }}</td></tr>@for (r of x.rows; track $index) {<tr [class.muted]="r.isReversal"><td>{{ r.dateUtc | dt:false }}</td><td>{{ r.docNo }}</td><td>{{ r.type }}</td><td>{{ r.description }}</td><td class="num">{{ r.debit | money }}</td><td class="num">{{ r.credit | money }}</td><td class="num">{{ r.balance | money }}</td></tr>} @empty {<tr><td colspan="7" class="empty">No activity in this range.</td></tr>}</tbody>
    <tfoot><tr><td colspan="6"><b>Closing</b></td><td class="num"><b>{{ x.closing | money }}</b></td></tr></tfoot></table></div>
    <div class="card"><h3>Metal ledger (independent of PKR)</h3><table class="grid"><thead><tr><th>Metal</th><th>Purity</th><th>In g</th><th>Out g</th><th>Fine in</th><th>Fine out</th></tr></thead><tbody>@for (m of x.metal; track $index) {<tr><td>{{ m.metal }}</td><td>{{ m.purity }}</td><td class="num">{{ m.netIn | weight }}</td><td class="num">{{ m.netOut | weight }}</td><td class="num">{{ m.fineIn | weight }}</td><td class="num">{{ m.fineOut | weight }}</td></tr>} @empty {<tr><td colspan="6" class="empty">No metal activity.</td></tr>}</tbody></table>
      <p class="num">Opening fine: {{ x.metalOpeningFine | weight }} g · Balance fine: {{ x.metalBalanceFine | weight }} g</p>
      @if (x.custody?.length) { <h4>In worker custody now</h4>@for (c of x.custody; track $index) {<p>{{ c.metal }} {{ c.purity }} — {{ c.net | weight }} g</p>} }</div>
  </div> }`,
})
export class Statement {
  private api = inject(Api); private route = inject(ActivatedRoute);
  type = this.route.snapshot.params['type']; id = +this.route.snapshot.params['id'];
  s = signal<any>(null); range = signal<any>({});
  f: Field[] = [{ key: 'from', label: 'From', type: 'date' }, { key: 'to', label: 'To', type: 'date' }];
  constructor() { this.load(); }
  apply(v: any) { this.range.set(v); this.load(); }
  load() { this.api.get(`/parties/${this.type}/${this.id}/statement`, this.range()).subscribe(r => this.s.set(r)); }
}

@Component({
  selector: 'app-register', imports: [MoneyPipe, DtPipe, DynamicForm, Dialog],
  template: `<div class="pagehead"><h1>Cash Register</h1></div>
  <div class="grid2">
    @if (!open()) { <div class="card"><h3>Open register</h3><app-form [fields]="openFields" submitLabel="Open" (submitted)="openReg($event)" /></div> }
    @else { <div class="card"><h3>{{ open().account }}</h3><dl class="kv"><dt>Opened</dt><dd>{{ open().openedAtUtc | dt }}</dd><dt>Opening amount</dt><dd>{{ open().openingAmount | money }}</dd></dl>
      <button class="btn primary" (click)="dlg.set(true)">Close register</button></div> }
    <div class="card"><h3>Recent sessions</h3><table class="grid"><thead><tr><th>Account</th><th>Opened</th><th>Closed</th><th>Expected</th><th>Counted</th><th>Variance</th></tr></thead>
      <tbody>@for (r of all(); track r.id) {<tr><td>{{ r.account }}</td><td>{{ r.openedAtUtc | dt }}</td><td>{{ r.closedAtUtc | dt }}</td><td class="num">{{ r.expected | money }}</td><td class="num">{{ r.counted | money }}</td><td class="num">{{ r.variance | money }}</td></tr>}</tbody></table></div>
  </div>
  @if (dlg()) { <app-dialog title="Close register" (closed)="dlg.set(false)"><app-form [fields]="closeFields" submitLabel="Close" (submitted)="closeReg($event)" /></app-dialog> }`,
})
export class Register {
  private api = inject(Api); private toast = inject(Toast);
  open = signal<any>(null); all = signal<any[]>([]); dlg = signal(false);
  openFields: Field[] = [{ key: 'accountId', label: 'Cash account', type: 'select', lookup: 'cash-bank-accounts', required: true }, { key: 'openingAmount', label: 'Opening amount', type: 'number', required: true }];
  closeFields: Field[] = [{ key: 'countedClosing', label: 'Physically counted amount', type: 'number', required: true }, { key: 'varianceNote', label: 'Variance note (if different from expected)' }];
  constructor() { this.load(); }
  load() { this.api.get('/registers', { openOnly: true }).subscribe((r: any[]) => this.open.set(r[0] ?? null)); this.api.get('/registers').subscribe(r => this.all.set(r)); }
  openReg(v: any) { this.api.post('/registers', v).subscribe({ next: () => { this.toast.ok('Opened'); this.load(); }, error: () => {} }); }
  closeReg(v: any) { this.api.post(`/registers/${this.open().id}/close`, v).subscribe({ next: () => { this.toast.ok('Closed'); this.dlg.set(false); this.load(); }, error: () => {} }); }
}

@Component({
  selector: 'app-commission', imports: [MoneyPipe, DynamicForm],
  template: `<div class="pagehead"><h1>Salesman Commission</h1></div>
  <div class="card"><app-form [fields]="f" [value]="range()" submitLabel="Apply" (submitted)="apply($event)" /></div>
  <div class="card"><table class="grid"><thead><tr><th><input type="checkbox" (change)="selectAll($any($event.target).checked)" /></th><th>Salesman</th><th>Eligible</th><th>Calculated</th><th>Approved</th><th>Paid</th><th>Unpaid</th></tr></thead>
  <tbody>@for (r of rows(); track r.salesmanId) {<tr><td><input type="checkbox" [checked]="sel.has(r.salesmanId)" (change)="toggle(r.salesmanId,$any($event.target).checked)" /></td><td>{{ r.salesman }}</td><td class="num">{{ r.eligible | money }}</td><td class="num">{{ r.calculated | money }}</td><td class="num">{{ r.approved | money }}</td><td class="num">{{ r.paid | money }}</td><td class="num">{{ r.unpaid | money }}</td></tr>} @empty {<tr><td colspan="7" class="empty">No entries.</td></tr>}</tbody></table>
  @if (sess.can('Commission.Approve')) { <button class="btn primary" style="margin-top:8px" [disabled]="!sel.size" (click)="approve()">Approve selected</button> }</div>`,
})
export class Commission {
  private api = inject(Api); private toast = inject(Toast); sess = inject(Session);
  rows = signal<any[]>([]); range = signal<any>({}); sel = new Set<number>();
  f: Field[] = [{ key: 'from', label: 'From', type: 'date' }, { key: 'to', label: 'To', type: 'date' }];
  constructor() { this.load(); }
  apply(v: any) { this.range.set(v); this.load(); }
  load() { this.api.get('/commission', this.range()).subscribe(r => this.rows.set(r)); }
  toggle(id: number, on: boolean) { on ? this.sel.add(id) : this.sel.delete(id); }
  selectAll(on: boolean) { this.sel = new Set(on ? this.rows().map(r => r.salesmanId) : []); }
  async approve() {
    const ids: number[] = [];
    for (const salesmanId of this.sel) { const details = await new Promise<any[]>(res => this.api.get(`/commission/${salesmanId}`, this.range()).subscribe(res)); ids.push(...details.filter(d => !d.isApproved).map(d => d.id)); }
    if (!ids.length) { this.toast.info('Nothing unapproved in the selected rows.'); return; }
    this.api.post('/commission/approve', { entryIds: ids }).subscribe({ next: () => { this.toast.ok('Approved'); this.sel.clear(); this.load(); }, error: () => {} });
  }
}
