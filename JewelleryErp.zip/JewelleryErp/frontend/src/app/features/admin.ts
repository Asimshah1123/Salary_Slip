import { Component, inject, signal } from '@angular/core';
import { Observable } from 'rxjs';
import { Api } from '../core/api';
import { Session } from '../core/session';
import { Toast } from '../core/toast';
import { DataTable, Col } from '../shared/table';
import { Dialog } from '../shared/dialog';
import { DynamicForm, Field } from '../shared/form';
import { Lookups } from '../shared/lookups';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-users', imports: [DataTable, Dialog, DynamicForm],
  template: `<div class="pagehead"><h1>Users</h1><span class="grow"></span><button class="btn primary" (click)="openCreate()">＋ New user</button></div>
  <app-table #tbl [columns]="cols" [loader]="loader">
    <ng-template #actions let-r>
      <button class="btn ghost sm" (click)="openEdit(r)">Edit</button>
      <button class="btn ghost sm" (click)="reset(r)">Reset password</button>
      @if (r.locked) { <button class="btn ghost sm" (click)="unlock(r)">Unlock</button> }
    </ng-template>
  </app-table>
  @if (dlg(); as d) { <app-dialog [title]="d.title" [width]="760" (closed)="dlg.set(null)"><app-form [fields]="d.fields" [value]="d.value" [busy]="busy()" (submitted)="d.submit($event)" /></app-dialog> }`,
})
export class Users {
  private api = inject(Api); private toast = inject(Toast); private lk = inject(Lookups);
  busy = signal(false); dlg = signal<any>(null); roles: any[] = []; branches: any[] = [];
  cols: Col[] = [{ key: 'userName', label: 'User', sortable: true }, { key: 'fullName', label: 'Name' }, { key: 'email', label: 'Email' }, { key: 'roles', label: 'Roles', fmt: (r: any) => r.roles.join(', ') }, { key: 'isActive', label: 'Active', type: 'bool' }, { key: 'locked', label: 'Locked', type: 'bool' }, { key: 'lastLoginUtc', label: 'Last login', type: 'datetime' }];
  loader = (q: any): Observable<any> => this.api.get('/users', q);
  constructor() { this.api.get<any[]>('/roles').subscribe(r => (this.roles = r)); this.lk.get('branches').then(r => (this.branches = r)); }
  fields(edit = false): Field[] { return [
    { key: 'userName', label: 'User name', required: true, readonly: edit }, { key: 'fullName', label: 'Full name', required: true }, { key: 'email', label: 'Email', type: 'email', required: true },
    { key: 'roleIds', label: 'Roles', type: 'multiselect', required: true, options: this.roles.map(r => ({ value: r.id, label: r.name })) },
    { key: 'branchIds', label: 'Branches', type: 'multiselect', required: true, options: this.branches.map(b => ({ value: b.value, label: b.label })) },
    { key: 'defaultBranchId', label: 'Default branch', type: 'select', options: this.branches.map(b => ({ value: b.value, label: b.label })) },
    { key: 'employeeId', label: 'Linked employee', type: 'select', lookup: 'employees' }, { key: 'workerId', label: 'Linked worker (karigar login)', type: 'select', lookup: 'workers' },
    ...(edit ? [] : [{ key: 'password', label: 'Temporary password', type: 'password' as const, required: true, hint: '10+ chars, a letter and a digit; user must change it at first sign-in' }]),
    { key: 'isActive', label: 'Active', type: 'checkbox', default: true },
  ]; }
  openCreate() { this.dlg.set({ title: 'New user', fields: this.fields(false), submit: (v: any) => { this.busy.set(true); this.api.post('/users', v).subscribe({ next: () => { this.toast.ok('Created'); this.dlg.set(null); this.busy.set(false); }, error: () => this.busy.set(false) }); } }); }
  openEdit(r: any) { this.dlg.set({ title: 'Edit user', fields: this.fields(true), value: r, submit: (v: any) => { this.busy.set(true); this.api.put(`/users/${r.id}`, v).subscribe({ next: () => { this.toast.ok('Saved'); this.dlg.set(null); this.busy.set(false); }, error: () => this.busy.set(false) }); } }); }
  reset(r: any) { this.dlg.set({ title: 'Reset password for ' + r.userName, fields: [{ key: 'password', label: 'New temporary password', type: 'password', required: true, col: 3 }], submit: (v: any) => this.api.post(`/users/${r.id}/reset-password`, v).subscribe(() => { this.toast.ok('Password reset'); this.dlg.set(null); }) }); }
  unlock(r: any) { this.api.post(`/users/${r.id}/unlock`).subscribe(() => this.toast.ok('Unlocked')); }
}

@Component({
  selector: 'app-roles', imports: [Dialog, DynamicForm],
  template: `<div class="pagehead"><h1>Roles & Permissions</h1><span class="grow"></span><button class="btn primary" (click)="openCreate()">＋ New role</button></div>
  <div class="grid2">@for (r of roles(); track r.id) { <div class="card"><div class="row"><h3 class="grow">{{ r.name }} <small class="muted">({{ r.users }} user(s))</small></h3>@if (!r.isSystem || r.name !== 'System Owner') { <button class="btn ghost sm" (click)="openEdit(r)">Edit</button> } </div><p class="muted">{{ r.description }}</p><p class="hint">{{ r.permissions.length }} permission(s)</p></div> }</div>
  @if (dlg(); as d) { <app-dialog [title]="d.title" [width]="900" (closed)="dlg.set(null)"><app-form [fields]="d.fields" [value]="d.value" [busy]="busy()" (submitted)="d.submit($event)" /></app-dialog> }`,
})
export class Roles {
  private api = inject(Api); private toast = inject(Toast); s = inject(Session);
  roles = signal<any[]>([]); busy = signal(false); dlg = signal<any>(null); catalogue: any[] = [];
  constructor() { this.load(); this.api.get<any[]>('/permissions').subscribe(r => (this.catalogue = r)); }
  load() { this.api.get('/roles').subscribe((r: any[]) => this.roles.set(r)); }
  fields(): Field[] { return [{ key: 'name', label: 'Role name', required: true }, { key: 'description', label: 'Description', col: 2 },
    { key: 'permissions', label: 'Permissions (only yours can be granted)', type: 'multiselect', required: true, col: 3, options: this.catalogue.flatMap((g: any) => g.permissions.filter((p: string) => this.s.can(p)).map((p: string) => ({ value: p, label: `${g.module}: ${p}` }))) },
    { key: 'limits', label: 'Approval limits', type: 'lines', col: 3, fields: [{ key: 'type', label: 'Type', type: 'select', options: ['DiscountOverLimit', 'ExpenseOverLimit', 'StockAdjustment', 'MetalLoss', 'PurchaseVariance', 'RefundOverLimit', 'RateOverride', 'OldGoldDeduction', 'JobVariance', 'TransferVariance'].map(x => ({ value: x, label: x })) }, { key: 'maxValue', label: 'Max value', type: 'number' }, { key: 'branchId', label: 'Branch (blank=all)', type: 'select', lookup: 'branches' }] },
    { key: 'isActive', label: 'Active', type: 'checkbox', default: true }]; }
  openCreate() { this.dlg.set({ title: 'New role', fields: this.fields(), submit: (v: any) => { this.busy.set(true); this.api.post('/roles', v).subscribe({ next: () => { this.toast.ok('Created'); this.dlg.set(null); this.busy.set(false); this.load(); }, error: () => this.busy.set(false) }); } }); }
  openEdit(r: any) { this.dlg.set({ title: 'Edit role: ' + r.name, fields: this.fields(), value: { ...r, limits: r.limits }, submit: (v: any) => { this.busy.set(true); this.api.put(`/roles/${r.id}`, v).subscribe({ next: () => { this.toast.ok('Saved'); this.dlg.set(null); this.busy.set(false); this.load(); }, error: () => this.busy.set(false) }); } }); }
}

@Component({
  selector: 'app-settings', imports: [DatePipe],
  template: `<div class="pagehead"><h1>Settings & Backup</h1></div>
  <div class="grid2">
    <div class="card"><h3>Operational settings</h3>@for (s of settings(); track s.key) { <div class="row" style="justify-content:space-between;border-bottom:1px solid var(--line);padding:5px 0">
      <div><b>{{ s.key }}</b><br><small class="muted">default: {{ s.default }}</small></div>
      <input style="width:140px" [value]="s.value" (change)="set(s.key, $any($event.target).value)" /></div> }</div>
    <div class="card"><h3>Backups</h3><button class="btn primary" (click)="runBackup()">Run backup now</button>
      <table class="grid" style="margin-top:8px"><thead><tr><th>Started</th><th>Status</th><th>Encrypted</th><th>Restore tested</th></tr></thead>
      <tbody>@for (b of backups(); track b.id) {<tr><td>{{ b.startedUtc | date:'short' }}</td><td><span class="badge" [attr.data-s]="b.status">{{ b.status }}</span></td><td>{{ b.encrypted ? '✓' : '✗ configure a certificate before go-live' }}</td><td>@if (!b.restoreTestedUtc && b.status==='Succeeded') {<button class="btn ghost sm" (click)="markTested(b)">Mark tested</button>} @else {{{ b.restoreTestedUtc | date:'short' }}}</td></tr>}</tbody></table></div>
  </div>`,
})
export class Settings {
  private api = inject(Api); private toast = inject(Toast);
  settings = signal<any[]>([]); backups = signal<any[]>([]);
  constructor() { this.load(); }
  load() { this.api.get('/settings').subscribe(r => this.settings.set(r)); this.api.get('/backups/status').subscribe(r => this.backups.set(r)); }
  set(key: string, value: string) { this.api.put(`/settings/${key}`, { value }).subscribe({ next: () => { this.toast.ok('Saved'); this.load(); }, error: () => {} }); }
  runBackup() { this.api.post('/backups').subscribe(() => { this.toast.ok('Backup started'); this.load(); }); }
  markTested(b: any) { const note = prompt('What was verified in the restore drill?'); if (!note) return; this.api.post(`/backups/${b.id}/restore-tested`, { note }).subscribe(() => { this.toast.ok('Recorded'); this.load(); }); }
}
