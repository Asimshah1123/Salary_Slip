import { Component, computed, inject, signal } from '@angular/core';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { Observable } from 'rxjs';
import { Api } from '../core/api';
import { Session } from '../core/session';
import { Toast } from '../core/toast';
import { DataTable, Col } from '../shared/table';
import { DynamicForm, Field } from '../shared/form';
import { DatePipe } from '@angular/common';
import { MoneyPipe, WeightPipe } from '../shared/pipes';
import { SecureImg, Gallery, ImageUploader } from '../shared/img';

@Component({
  selector: 'app-product-list', imports: [DataTable, RouterLink],
  template: `<div class="pagehead"><h1>Products</h1><span class="grow"></span>@if (sess.can('Products.Create')) {<a class="btn primary" routerLink="/products/new">＋ New item</a>}</div>
  <app-table [columns]="cols" [loader]="loader" [clickable]="true" (rowClick)="go($event)" />`,
})
export class ProductList {
  private api = inject(Api); private router = inject(Router); sess = inject(Session);
  cols: Col[] = [{ key: 'primaryImageId', label: '', type: 'img' }, { key: 'sku', label: 'SKU', sortable: true }, { key: 'name', label: 'Name', sortable: true }, { key: 'category', label: 'Category' }, { key: 'metal', label: 'Metal' }, { key: 'purity', label: 'Purity' }, { key: 'netMetalWeight', label: 'Net g', type: 'weight', sortable: true }, { key: 'tagPrice', label: 'Tag price', type: 'money' }, { key: 'availableQty', label: 'Available', type: 'number' }, { key: 'isActive', label: 'Active', type: 'bool' }];
  loader = (q: any): Observable<any> => this.api.get('/products', q);
  go(r: any) { this.router.navigate(['/products', r.id]); }
}

@Component({
  selector: 'app-product-form', imports: [DynamicForm, Gallery, ImageUploader],
  template: `<div class="pagehead"><h1>{{ id ? 'Edit item' : 'New item' }}</h1></div>
  <div class="grid2">
    <div class="card"><app-form [fields]="f" [value]="v()" submitLabel="Save" [busy]="busy()" (submitted)="save($event)" /></div>
    @if (id) { <div class="card"><h3>Images</h3><app-uploader ownerType="Product" [ownerId]="id" (uploaded)="reload()" /><app-gallery ownerType="Product" [ownerId]="id" [canEdit]="true" [canDelete]="sess.can('Products.Images.Delete')" [canDownload]="sess.can('Products.Images.Download')" /></div> }
  </div>`,
})
export class ProductForm {
  private api = inject(Api); private route = inject(ActivatedRoute); private router = inject(Router); private toast = inject(Toast); sess = inject(Session);
  id = this.route.snapshot.params['id'] ? +this.route.snapshot.params['id'] : null;
  v = signal<any>(null); busy = signal(false);
  f: Field[] = [
    { key: 'sku', label: 'SKU', hint: 'blank = auto' }, { key: 'barcode', label: 'Barcode' }, { key: 'name', label: 'Name', required: true }, { key: 'nameUrdu', label: 'Urdu name' },
    { key: 'categoryId', label: 'Category', type: 'select', lookup: 'categories' }, { key: 'tracking', label: 'Tracking', type: 'select', options: [{ value: 'Serialized', label: 'Unique piece' }, { value: 'Quantity', label: 'Quantity item' }, { value: 'LooseMetal', label: 'Loose metal' }, { value: 'LooseStone', label: 'Loose stone' }, { value: 'RepairPart', label: 'Repair part' }, { value: 'Service', label: 'Service (non-stock)' }], default: 'Serialized' },
    { key: 'metalTypeId', label: 'Metal', type: 'select', lookup: 'metals' }, { key: 'purityId', label: 'Purity', type: 'select', lookup: 'purities' }, { key: 'design', label: 'Design/model' }, { key: 'size', label: 'Size' },
    { key: 'grossWeight', label: 'Gross weight (g)', type: 'number', default: 0 }, { key: 'stoneWeight', label: 'Stone weight (g)', type: 'number', default: 0 }, { key: 'otherDeduction', label: 'Other deduction (g)', type: 'number', default: 0 },
    { key: 'stoneDetails', label: 'Stone details', col: 2 }, { key: 'stoneValue', label: 'Stone value (PKR)', type: 'number', default: 0 },
    { key: 'pricingMode', label: 'Pricing model', type: 'select', options: [{ value: 'Tagged', label: 'Tagged / fixed price' }, { value: 'MetalPlusMaking', label: 'Metal + making' }, { value: 'MetalStoneMakingWastage', label: 'Metal + stone + making/wastage' }, { value: 'ManualApproved', label: 'Manual (needs approval)' }], default: 'MetalPlusMaking' },
    { key: 'makingType', label: 'Making charge type', type: 'select', options: [{ value: 'None', label: 'None' }, { value: 'Fixed', label: 'Fixed' }, { value: 'PerGram', label: 'Per gram' }, { value: 'Percent', label: '% of metal value' }], default: 'PerGram' }, { key: 'makingValue', label: 'Making value', type: 'number', default: 0 },
    { key: 'wastagePercent', label: 'Wastage %', type: 'number', default: 0 }, { key: 'tagPrice', label: 'Tag price (PKR)', type: 'number', default: 0 }, { key: 'costPrice', label: 'Cost price (restricted)', type: 'number' },
    { key: 'minStock', label: 'Minimum stock', type: 'number', default: 0 }, { key: 'supplierId', label: 'Supplier', type: 'select', lookup: 'suppliers' }, { key: 'defaultBranchId', label: 'Default branch', type: 'select', lookup: 'branches' },
    { key: 'isStockItem', label: 'Stock item', type: 'checkbox', default: true }, { key: 'isActive', label: 'Active', type: 'checkbox', default: true }, { key: 'notes', label: 'Notes', type: 'textarea' },
  ];
  constructor() { if (this.id) this.reload(); }
  reload() { this.api.get(`/products/${this.id}`).subscribe(r => this.v.set(r)); }
  save(v: any) { this.busy.set(true); const o = this.id ? this.api.put(`/products/${this.id}`, v) : this.api.post('/products', v); o.subscribe({ next: (r: any) => { this.toast.ok('Saved'); this.busy.set(false); if (!this.id) this.router.navigate(['/products', r.id]); else this.reload(); }, error: () => this.busy.set(false) }); }
}

@Component({
  selector: 'app-gallery-page', imports: [DataTable, SecureImg],
  template: `<div class="pagehead"><h1>Product Image Gallery</h1><div class="sub">Browse every product's photos without opening each edit form.</div></div>
  <app-table [columns]="cols" [loader]="loader">
    <ng-template #actions let-r><div class="thumbs" style="flex-wrap:nowrap">@for (im of r.images; track im.id) { <app-img [id]="im.id" [size]="56" [zoom]="true" /> }</div></ng-template>
  </app-table>`,
})
export class GalleryPage {
  private api = inject(Api);
  cols: Col[] = [{ key: 'id', label: 'SKU', fmt: (r: any) => r.product?.sku }, { key: 'name', label: 'Name', fmt: (r: any) => r.product?.name }, { key: 'purity', label: 'Purity', fmt: (r: any) => r.product?.purity }, { key: 'net', label: 'Net g', type: 'weight', fmt: (r: any) => r.product?.netMetalWeight }, { key: 'count', label: 'Images', type: 'number', fmt: (r: any) => r.images.length }];
  loader = (q: any): Observable<any> => this.api.get('/product-gallery', q);
}

@Component({
  selector: 'app-gold-rates', imports: [MoneyPipe, DynamicForm, DataTable, DatePipe],
  template: `<div class="pagehead"><h1>Gold Rates</h1><span class="grow"></span>@if (sess.can('GoldRate.Edit')) {<button class="btn primary" (click)="editing.set(!editing())">{{ editing() ? 'Close' : '＋ Set rates' }}</button>}</div>
  <div class="card"><h3>Current rates</h3><table class="grid"><thead><tr><th>Metal</th><th>Purity</th><th>Buy</th><th>Sell</th><th>Effective</th></tr></thead><tbody>@for (r of current(); track r.purityId) {<tr><td>{{ r.metal }}</td><td>{{ r.purity }}</td><td class="num">{{ r.buyRate | money }}</td><td class="num">{{ r.sellRate | money }}</td><td>{{ r.effectiveFromUtc | date: 'short' }}</td></tr>} @empty {<tr><td colspan="5" class="empty">No rate set yet.</td></tr>}</tbody></table></div>
  @if (editing()) { <div class="card"><h3>Set today's rate card</h3><app-form [fields]="f" submitLabel="Save rates" [busy]="busy()" (submitted)="save($event)" /></div> }
  <div class="card"><h3>History</h3><app-table [columns]="hcols" [loader]="hloader" /></div>`,
})
export class GoldRates {
  private api = inject(Api); private toast = inject(Toast); sess = inject(Session);
  current = signal<any[]>([]); editing = signal(false); busy = signal(false);
  f: Field[] = [{ key: 'metalTypeId', label: 'Metal', type: 'select', lookup: 'metals', required: true }, { key: 'branchId', label: 'Branch (blank = company-wide)', type: 'select', lookup: 'branches' }, { key: 'reason', label: 'Reason (required if overriding/backdating)' },
    { key: 'items', label: 'Purity rates', type: 'lines', required: true, fields: [{ key: 'purityId', label: 'Purity', type: 'select', lookup: 'purities', required: true }, { key: 'buyRate', label: 'Buy rate', type: 'number', required: true }, { key: 'sellRate', label: 'Sell rate', type: 'number', required: true }] }];
  hcols: Col[] = [{ key: 'effectiveFromUtc', label: 'When', type: 'datetime' }, { key: 'metal', label: 'Metal' }, { key: 'purity', label: 'Purity' }, { key: 'buyRate', label: 'Buy', type: 'money' }, { key: 'sellRate', label: 'Sell', type: 'money' }, { key: 'isOverride', label: 'Override', type: 'bool' }, { key: 'changedBy', label: 'By' }, { key: 'reason', label: 'Reason' }];
  hloader = (q: any) => this.api.get('/gold-rates/history', q);
  constructor() { this.load(); }
  load() { this.api.get('/gold-rates/current').subscribe(r => this.current.set(r)); }
  save(v: any) { this.busy.set(true); this.api.post('/gold-rates', v).subscribe({ next: () => { this.toast.ok('Rates saved'); this.busy.set(false); this.editing.set(false); this.load(); }, error: () => this.busy.set(false) }); }
}
