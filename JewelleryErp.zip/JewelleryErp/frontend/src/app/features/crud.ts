import { Component, computed, effect, inject, input, signal, viewChild } from '@angular/core';
import { Router } from '@angular/router';
import { Observable, map } from 'rxjs';
import { Api } from '../core/api';
import { Session } from '../core/session';
import { Toast } from '../core/toast';
import { Dialog } from '../shared/dialog';
import { DynamicForm, Field } from '../shared/form';
import { DataTable } from '../shared/table';
import { Lookups } from '../shared/lookups';
import { SCREENS, RowAction, Screen } from './screens';

/** One component renders every list/CRUD screen from its declarative definition in screens.ts. */
@Component({
  selector: 'app-crud', imports: [DataTable, Dialog, DynamicForm],
  template: `
  @if (screen(); as sc) {
    <div class="pagehead"><div><h1>{{ sc.title }}</h1>@if (sc.sub) { <div class="sub">{{ sc.sub }}</div> }</div><span class="grow"></span>
      @if (sc.create && s.canAny(...sc.create.perm)) { <button class="btn primary" (click)="openCreate()">＋ {{ sc.create.label }}</button> }</div>
    @if (sc.filters?.length) { <div class="toolbar card"><app-form [fields]="filterFields()" [value]="filterValue()" submitLabel="Apply filters" (submitted)="filters.set($event)" /></div> }
    <app-table #tbl [columns]="sc.columns" [loader]="loader" [refresh]="filters()" [searchable]="sc.searchable !== false" [clickable]="!!sc.rowClick" (rowClick)="rowClick($event)">
      <ng-template #actions let-r>
        @if (sc.edit && s.canAny(...sc.edit.perm)) { <button class="btn ghost sm" (click)="openEdit(r)">Edit</button> }
        @for (a of visible(r); track a.label) { <button class="btn sm" [class.danger]="a.danger" (click)="run(a, r)">{{ a.label }}</button> }
        @if (sc.toggle && s.canAny(...sc.toggle.perm) && r.isActive !== undefined) { <button class="btn ghost sm" (click)="flip(r)">{{ r.isActive ? 'Deactivate' : 'Activate' }}</button> }
      </ng-template>
    </app-table>
    @if (dlg(); as d) { <app-dialog [title]="d.title" [width]="d.width ?? 720" (closed)="dlg.set(null)"><app-form [fields]="d.fields" [value]="d.value" [busy]="busy()" [cancelLabel]="'Cancel'" (cancelled)="dlg.set(null)" (submitted)="d.submit($event)" /></app-dialog> }
  }`,
})
export class Crud {
  s = inject(Session); private api = inject(Api); private toast = inject(Toast); private router = inject(Router); private lk = inject(Lookups);
  kind = input<string>();   // bound from the route parameter
  tbl = viewChild<DataTable>('tbl');
  filters = signal<any>({});
  busy = signal(false);
  dlg = signal<{ title: string; fields: Field[]; value?: any; width?: number; submit: (v: any) => void } | null>(null);
  screen = computed<Screen | undefined>(() => SCREENS[this.kind() ?? '']);
  filterFields = computed<Field[]>(() => (this.screen()?.filters ?? []).map(f => ({ ...f, col: 1 as const })));
  filterValue = computed(() => Object.fromEntries((this.screen()?.filters ?? []).filter(f => f.default !== undefined).map(f => [f.key, f.default])));

  constructor() { effect(() => { this.kind(); this.filters.set(this.filterValue()); }); }

  loader = (q: any): Observable<any> => {
    const sc = this.screen()!; const f = this.filters();
    const params = { ...q, ...(sc.list.params ? sc.list.params(f) : {}) };
    return this.api.get(sc.list.url, params).pipe(map(r => (sc.list.adapter ? sc.list.adapter(r) : r)));
  };
  visible(r: any) { return (this.screen()?.actions ?? []).filter(a => (!a.perm || this.s.canAny(...a.perm)) && (!a.show || a.show(r))); }
  rowClick(r: any) { const sc = this.screen(); if (sc?.rowClick) this.router.navigate(sc.rowClick(r)); }
  private done(msg: string) { this.busy.set(false); this.dlg.set(null); this.toast.ok(msg); this.tbl()?.reload(); this.lk.invalidate(); }

  openCreate() {
    const c = this.screen()!.create!;
    if (c.navigate) { this.router.navigate(c.navigate); return; }
    this.dlg.set({ title: c.title, fields: c.fields, width: c.width, submit: v => { this.busy.set(true); this.api.post(c.url!, c.body ? c.body(v) : v).subscribe({ next: () => this.done('Saved'), error: () => this.busy.set(false) }); } });
  }
  openEdit(r: any) {
    const e = this.screen()!.edit!;
    this.dlg.set({ title: 'Edit', fields: e.fields, value: r, submit: v => { this.busy.set(true); const url = e.url(r); (e.method === 'post' ? this.api.post(url, v) : this.api.put(url, v)).subscribe({ next: () => this.done('Saved'), error: () => this.busy.set(false) }); } });
  }
  flip(r: any) { this.api.post(this.screen()!.toggle!.url(r) + `?value=${!r.isActive}`).subscribe(() => { this.toast.ok('Updated'); this.tbl()?.reload(); }); }

  run(a: RowAction, r: any) {
    if (a.navigate) { this.router.navigate(a.navigate(r)); return; }
    const call = (body: any) => {
      this.busy.set(true); const url = a.url!(r);
      const o = a.method === 'delete' ? this.api.delete(url) : a.method === 'put' ? this.api.put(url, body) : this.api.post(url, body);
      o.subscribe({ next: () => this.done(a.label + ' done'), error: () => this.busy.set(false) });
    };
    if (a.fields) { this.dlg.set({ title: a.title ?? a.label, fields: a.fields, value: a.init?.(r), submit: v => call(a.body ? a.body(v, r) : v) }); return; }
    if (a.reason) { this.dlg.set({ title: a.label, fields: [{ key: 'reason', label: a.reason, type: 'textarea', required: !a.danger ? false : true, col: 3 }], submit: v => call(a.body ? a.body(v, r) : v) }); return; }
    if (a.confirm && !confirm(a.confirm)) return;
    call(a.body ? a.body({}, r) : {});
  }
}
