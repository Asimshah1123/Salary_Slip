import { Col } from '../shared/table';
import { Field } from '../shared/form';
import { Opt } from '../shared/lookups';

export interface RowAction {
  label: string; perm?: string[]; show?: (r: any) => boolean; method?: 'post' | 'put' | 'delete'; url?: (r: any) => string; body?: (v: any, r: any) => any; fields?: Field[]; confirm?: string;
  title?: string; danger?: boolean; navigate?: (r: any) => any[]; reason?: string; init?: (r: any) => any;
}
export interface Screen {
  title: string; sub?: string; perms?: string[];
  list: { url: string; adapter?: (r: any) => any; params?: (f: any) => any };
  columns: Col[]; filters?: Field[]; searchable?: boolean;
  create?: { label: string; perm: string[]; title: string; fields: Field[]; url?: string; body?: (v: any) => any; width?: number; navigate?: any[] };
  edit?: { perm: string[]; fields: Field[]; url: (r: any) => string; body?: (v: any) => any; method?: 'put' | 'post' };
  rowClick?: (r: any) => any[]; actions?: RowAction[]; toggle?: { url: (r: any) => string; perm: string[] };
}

const opts = (...l: string[]): Opt[] => l.map(x => ({ value: x, label: x.replace(/([a-z])([A-Z])/g, '$1 $2') }));
const nameCol: Col = { key: 'name', label: 'Name', sortable: true };
const codeCol: Col = { key: 'code', label: 'Code', sortable: true };
/** Report tables come back as {columns, rows[][]}; turn them into plain objects for the list view. */
const tableAdapter = (t: any) => ({ items: t.rows.map((r: any[]) => Object.fromEntries(t.columns.map((c: any, i: number) => [c.key, r[i]]))), total: t.rows.length, totals: t.totals });
const pay = (extra: Field[] = []): Field[] => [{ key: 'paymentMethodId', label: 'Method', type: 'select', lookup: 'payment-methods', required: true }, { key: 'accountId', label: 'Account', type: 'select', lookup: 'cash-bank-accounts' }, { key: 'amount', label: 'Amount', type: 'number', required: true }, ...extra];
const commonParty: Field[] = [{ key: 'code', label: 'Code', hint: 'blank = auto' }, { key: 'name', label: 'Name', required: true }, { key: 'phone', label: 'Phone' }, { key: 'whatsApp', label: 'WhatsApp' }, { key: 'email', label: 'Email', type: 'email' }, { key: 'city', label: 'City' }, { key: 'address', label: 'Address', col: 2 }, { key: 'notes', label: 'Notes', type: 'textarea' }];
const opening: Field[] = [{ key: 'openingBalance', label: 'Opening balance (PKR)', type: 'number', default: 0, hint: 'Cutover figure; use the controlled opening journal to post it' }, { key: 'openingMetalFine', label: 'Opening metal (fine g)', type: 'number', default: 0 }];
const status: Col = { key: 'status', label: 'Status', type: 'status' };

export const SCREENS: Record<string, Screen> = {
  // ------------------------------------------------------------------ masters
  customers: {
    title: 'Customers', sub: 'Company-wide customer master with PKR and metal ledgers', perms: ['Customers.View'],
    list: { url: '/customers', params: f => ({ active: f.active }) }, filters: [{ key: 'active', label: 'Show', type: 'select', options: [{ value: true, label: 'Active' }, { value: false, label: 'Inactive' }] }],
    columns: [codeCol, { ...nameCol, link: r => ['/ledger', 'Customer', r.id] }, { key: 'phone', label: 'Phone' }, { key: 'city', label: 'City' }, { key: 'openingBalance', label: 'Opening', type: 'money' }, { key: 'isActive', label: 'Active', type: 'bool' }],
    create: { label: 'New customer', perm: ['Customers.Edit'], title: 'New customer', url: '/customers', fields: [...commonParty, { key: 'cnic', label: 'CNIC', hint: 'Sensitive: visible only with Customers.ViewSensitive' }, { key: 'creditLimit', label: 'Credit limit', type: 'number' }, ...opening, { key: 'marketingConsent', label: 'Marketing consent', type: 'checkbox' }] },
    edit: { perm: ['Customers.Edit'], url: r => `/customers/${r.id}`, fields: [...commonParty, { key: 'creditLimit', label: 'Credit limit', type: 'number' }, { key: 'marketingConsent', label: 'Marketing consent', type: 'checkbox' }] },
    toggle: { url: r => `/customers/${r.id}/active`, perm: ['Customers.Edit'] },
    actions: [{ label: 'Statement', navigate: r => ['/ledger', 'Customer', r.id], perm: ['Customers.Ledger.View'] }],
  },
  suppliers: {
    title: 'Suppliers', perms: ['Suppliers.View'], list: { url: '/suppliers' },
    columns: [codeCol, { ...nameCol, link: r => ['/ledger', 'Supplier', r.id] }, { key: 'phone', label: 'Phone' }, { key: 'city', label: 'City' }, { key: 'paymentTerms', label: 'Terms' }, { key: 'openingBalance', label: 'Opening', type: 'money' }],
    create: { label: 'New supplier', perm: ['Suppliers.Edit'], title: 'New supplier', url: '/suppliers', fields: [...commonParty, { key: 'categories', label: 'Metal / product categories' }, { key: 'paymentTerms', label: 'Payment terms' }, { key: 'creditDays', label: 'Credit days', type: 'number' }, ...opening] },
    edit: { perm: ['Suppliers.Edit'], url: r => `/suppliers/${r.id}`, fields: [...commonParty, { key: 'categories', label: 'Categories' }, { key: 'paymentTerms', label: 'Payment terms' }, { key: 'creditDays', label: 'Credit days', type: 'number' }] },
    toggle: { url: r => `/suppliers/${r.id}/active`, perm: ['Suppliers.Edit'] },
    actions: [{ label: 'Statement', navigate: r => ['/ledger', 'Supplier', r.id], perm: ['Suppliers.Ledger.View'] }],
  },
  employees: {
    title: 'Employees & salesmen', sub: 'An employee record is separate from a login account', perms: ['Employees.View'], list: { url: '/employees' },
    columns: [codeCol, nameCol, { key: 'jobTitle', label: 'Title' }, { key: 'phone', label: 'Phone' }, { key: 'hireDate', label: 'Hired', type: 'date' }, { key: 'isActive', label: 'Active', type: 'bool' }],
    create: { label: 'New employee', perm: ['Employees.Manage'], title: 'New employee', url: '/employees', fields: [{ key: 'name', label: 'Name', required: true }, { key: 'jobTitle', label: 'Job title' }, { key: 'phone', label: 'Phone' }, { key: 'email', label: 'Email', type: 'email' }, { key: 'hireDate', label: 'Hire date', type: 'date' }, { key: 'baseSalary', label: 'Base salary', type: 'number' }] },
    edit: { perm: ['Employees.Manage'], url: r => `/employees/${r.id}`, fields: [{ key: 'name', label: 'Name', required: true }, { key: 'jobTitle', label: 'Job title' }, { key: 'phone', label: 'Phone' }, { key: 'email', label: 'Email', type: 'email' }, { key: 'exitDate', label: 'Exit date', type: 'date' }] },
    toggle: { url: r => `/employees/${r.id}/active`, perm: ['Employees.Manage'] },
    actions: [{ label: 'Commission rule', perm: ['Employees.Manage'], title: 'Salesman commission rule', method: 'post', url: () => '/salesman-profiles', init: () => ({ commissionType: 'Percent', commissionValue: 1 }), body: (v, r) => ({ ...v, employeeId: r.id }), fields: [{ key: 'commissionType', label: 'Type', type: 'select', options: opts('Fixed', 'Percent', 'CategoryBased', 'Manual'), required: true }, { key: 'commissionValue', label: 'Rate (% or PKR per invoice)', type: 'number', required: true }, { key: 'categoryId', label: 'Category (category-based only)', type: 'select', lookup: 'categories' }] }],
  },
  workers: {
    title: 'Karigars / workers', perms: ['Workers.View'], list: { url: '/workers' },
    columns: [codeCol, { ...nameCol, link: r => ['/ledger', 'Worker', r.id] }, { key: 'phone', label: 'Phone' }, { key: 'skills', label: 'Skills' }, { key: 'rateType', label: 'Rate type' }, { key: 'rateValue', label: 'Rate', type: 'money' }, { key: 'defaultWastagePercent', label: 'Wastage %', type: 'number' }],
    create: { label: 'New worker', perm: ['Workers.Manage'], title: 'New karigar', url: '/workers', fields: [{ key: 'name', label: 'Name', required: true }, { key: 'phone', label: 'Phone' }, { key: 'address', label: 'Address' }, { key: 'skills', label: 'Skills' }, { key: 'rateType', label: 'Rate type', type: 'select', options: opts('PerGram', 'Fixed', 'Percent'), default: 'PerGram' }, { key: 'rateValue', label: 'Agreed rate', type: 'number' }, { key: 'defaultWastagePercent', label: 'Default wastage allowance %', type: 'number' }, ...opening] },
    edit: { perm: ['Workers.Manage'], url: r => `/workers/${r.id}`, fields: [{ key: 'name', label: 'Name', required: true }, { key: 'phone', label: 'Phone' }, { key: 'skills', label: 'Skills' }, { key: 'rateType', label: 'Rate type', type: 'select', options: opts('PerGram', 'Fixed', 'Percent') }, { key: 'rateValue', label: 'Agreed rate', type: 'number' }, { key: 'defaultWastagePercent', label: 'Wastage %', type: 'number' }] },
    toggle: { url: r => `/workers/${r.id}/active`, perm: ['Workers.Manage'] },
    actions: [{ label: 'Statement', navigate: r => ['/ledger', 'Worker', r.id] }],
  },
  categories: { title: 'Product categories', list: { url: '/categories' }, columns: [nameCol, { key: 'nameUrdu', label: 'Urdu name' }, { key: 'isActive', label: 'Active', type: 'bool' }], create: { label: 'New category', perm: ['Masters.Manage'], title: 'New category', url: '/categories', fields: [{ key: 'name', label: 'Name', required: true }, { key: 'nameUrdu', label: 'Urdu name' }] }, edit: { perm: ['Masters.Manage'], url: r => `/categories/${r.id}`, fields: [{ key: 'name', label: 'Name', required: true }, { key: 'nameUrdu', label: 'Urdu name' }] }, toggle: { url: r => `/categories/${r.id}/active`, perm: ['Masters.Manage'] } },
  metals: { title: 'Metals', list: { url: '/metals' }, columns: [codeCol, nameCol], create: { label: 'New metal', perm: ['Masters.Manage'], title: 'New metal', url: '/metals', fields: [{ key: 'code', label: 'Code', required: true }, { key: 'name', label: 'Name', required: true }, { key: 'nameUrdu', label: 'Urdu name' }] }, toggle: { url: r => `/metals/${r.id}/active`, perm: ['Masters.Manage'] } },
  purities: {
    title: 'Purity / karat', sub: 'Fineness factor is configurable - the conventional k/24 is only a default', list: { url: '/purities' },
    columns: [{ key: 'label', label: 'Label' }, { key: 'metalTypeId', label: 'Metal id' }, { key: 'karat', label: 'Karat', type: 'number' }, { key: 'factor', label: 'Fineness factor', type: 'number' }],
    create: { label: 'New purity', perm: ['Masters.Manage'], title: 'New purity', url: '/purities', fields: [{ key: 'metalTypeId', label: 'Metal', type: 'select', lookup: 'metals', required: true }, { key: 'label', label: 'Label (e.g. 22K)' }, { key: 'karat', label: 'Karat', type: 'number' }, { key: 'factor', label: 'Fineness factor', type: 'number', hint: 'blank = karat / 24' }] },
    edit: { perm: ['Masters.Manage'], url: r => `/purities/${r.id}`, fields: [{ key: 'label', label: 'Label' }, { key: 'factor', label: 'Fineness factor', type: 'number' }] },
  },
  units: {
    title: 'Weight units', sub: 'A unit can only be used once its conversion to grams is approved in writing (tola / ratti are NOT assumed)', perms: ['Settings.Manage'], list: { url: '/units' },
    columns: [codeCol, nameCol, { key: 'isMetalWeight', label: 'Metal weight', type: 'bool' }],
    actions: [{ label: 'Approve conversion', perm: ['Settings.Manage'], title: 'Approve conversion to grams', method: 'post', url: r => `/units/${r.id}/conversion`, show: r => r.isMetalWeight, fields: [{ key: 'factorToGram', label: 'Grams per 1 unit', type: 'number', required: true }, { key: 'approvalNote', label: 'Approved by / document reference', required: true, col: 3 }] }],
  },
  'cash-bank-accounts': { title: 'Cash & bank accounts', perms: ['Finance.View'], list: { url: '/cash-bank-accounts' }, columns: [nameCol, { key: 'type', label: 'Type' }, { key: 'bankName', label: 'Bank' }, { key: 'accountNumberMasked', label: 'Account (masked)' }, { key: 'openingBalance', label: 'Opening', type: 'money' }, { key: 'isActive', label: 'Active', type: 'bool' }],
    create: { label: 'New account', perm: ['Finance.Accounts.Manage'], title: 'New cash / bank account', url: '/cash-bank-accounts', fields: [{ key: 'name', label: 'Name', required: true }, { key: 'type', label: 'Type', type: 'select', options: opts('Cash', 'Bank'), required: true }, { key: 'bankName', label: 'Bank' }, { key: 'accountNumberMasked', label: 'Account no. (last digits only)', hint: 'Never enter the full number' }, { key: 'openingBalance', label: 'Opening balance', type: 'number', default: 0 }] }, toggle: { url: r => `/cash-bank-accounts/${r.id}/active`, perm: ['Finance.Accounts.Manage'] } },
  'expense-heads': { title: 'Expense heads', list: { url: '/expense-heads' }, columns: [nameCol, { key: 'isActive', label: 'Active', type: 'bool' }], create: { label: 'New head', perm: ['Finance.Accounts.Manage'], title: 'New expense head', url: '/expense-heads', fields: [{ key: 'name', label: 'Name', required: true }, { key: 'accountId', label: 'Ledger account', type: 'select', lookup: 'chart-accounts' }] }, toggle: { url: r => `/expense-heads/${r.id}/active`, perm: ['Finance.Accounts.Manage'] } },
  'payment-methods': { title: 'Payment methods', list: { url: '/payment-methods' }, columns: [nameCol, { key: 'kind', label: 'Kind' }, { key: 'isActive', label: 'Active', type: 'bool' }], create: { label: 'New method', perm: ['Finance.Accounts.Manage'], title: 'New payment method', url: '/payment-methods', fields: [{ key: 'name', label: 'Name', required: true }, { key: 'kind', label: 'Kind', type: 'select', options: opts('Cash', 'Bank', 'Card', 'Cheque', 'Digital') }] }, toggle: { url: r => `/payment-methods/${r.id}/active`, perm: ['Finance.Accounts.Manage'] } },
  locations: { title: 'Store locations', list: { url: '/locations' }, columns: [codeCol, nameCol, { key: 'kind', label: 'Kind' }, { key: 'branchId', label: 'Branch id' }, { key: 'isDefault', label: 'Default', type: 'bool' }], create: { label: 'New location', perm: ['Branches.Manage'], title: 'New store location', url: '/locations', fields: [{ key: 'branchId', label: 'Branch', type: 'select', lookup: 'branches', required: true }, { key: 'code', label: 'Code', required: true }, { key: 'name', label: 'Name', required: true }, { key: 'kind', label: 'Kind', type: 'select', options: opts('Showroom', 'Vault', 'Inspection', 'Workshop', 'Warehouse') }] } },
  'chart-accounts': { title: 'Chart of accounts', list: { url: '/chart-accounts' }, columns: [codeCol, nameCol, { key: 'type', label: 'Type' }, { key: 'isControl', label: 'System-posted', type: 'bool' }], create: { label: 'New account', perm: ['Finance.Accounts.Manage'], title: 'New ledger account', url: '/chart-accounts', fields: [{ key: 'code', label: 'Code', required: true }, { key: 'name', label: 'Name', required: true }, { key: 'type', label: 'Type', type: 'select', options: opts('Asset', 'Liability', 'Equity', 'Revenue', 'Expense'), required: true }] } },

  // ------------------------------------------------------------------ purchasing
  purchases: {
    title: 'Purchases', perms: ['Purchases.View'], list: { url: '/purchases', params: f => ({ status: f.status, received: f.received }) },
    filters: [{ key: 'status', label: 'Status', type: 'select', options: opts('Draft', 'Posted', 'PartiallyPaid', 'Reversed') }, { key: 'received', label: 'Receipt', type: 'select', options: [{ value: true, label: 'Received' }, { value: false, label: 'Awaiting receipt' }] }],
    columns: [{ key: 'dateUtc', label: 'Date', type: 'date' }, { key: 'number', label: 'Number' }, { key: 'supplierInvoiceNo', label: 'Supplier inv.' }, { key: 'supplier', label: 'Supplier' }, { key: 'total', label: 'Total', type: 'money' }, { key: 'paid', label: 'Paid', type: 'money' }, { key: 'due', label: 'Due', type: 'money' }, { key: 'received', label: 'Received', type: 'bool' }, status],
    create: { label: 'New purchase', perm: ['Purchases.Create'], title: '', navigate: ['/purchases/new'], fields: [] }, rowClick: r => ['/purchases', r.id],
  },
  'supplier-payments': {
    title: 'Supplier payments', sub: 'One payment can settle several invoices; the unallocated part stays visible as supplier credit', perms: ['Finance.Payment.Post'],
    list: { url: '/reports/run/supplier-payments', adapter: tableAdapter }, searchable: false,
    columns: [{ key: 'd', label: 'Date', type: 'date' }, { key: 'no', label: 'Payment' }, { key: 's', label: 'Supplier' }, { key: 'a', label: 'Amount', type: 'money' }, { key: 'al', label: 'Allocated', type: 'money' }, { key: 'u', label: 'Advance', type: 'money' }, { key: 'r', label: 'Reference' }],
    create: { label: 'New supplier payment', perm: ['Finance.Payment.Post'], title: 'Supplier payment', url: '/supplier-payments', fields: [{ key: 'supplierId', label: 'Supplier', type: 'select', lookup: 'suppliers', required: true }, ...pay([{ key: 'reference', label: 'Reference' }]), { key: 'allocations', label: 'Allocate to purchase invoices (leave empty = advance)', type: 'lines', addLabel: 'Add allocation', fields: [{ key: 'purchaseInvoiceId', label: 'Purchase invoice id', type: 'number', required: true }, { key: 'amount', label: 'Amount', type: 'number', required: true }] }] },
  },

  // ------------------------------------------------------------------ inventory
  movements: {
    title: 'Stock movement ledger', sub: 'Immutable: every posting writes a movement; corrections are reversing movements', perms: ['Inventory.View'], list: { url: '/inventory/movements' },
    columns: [{ key: 'postedAtUtc', label: 'When', type: 'datetime' }, { key: 'refNo', label: 'Document' }, { key: 'refType', label: 'Type' }, { key: 'sku', label: 'SKU' }, { key: 'item', label: 'Item' }, { key: 'fromBranch', label: 'From' }, { key: 'fromStatus', label: '', type: 'status' }, { key: 'toBranch', label: 'To' }, { key: 'toStatus', label: '', type: 'status' }, { key: 'qty', label: 'Qty', type: 'number' }, { key: 'net', label: 'Net g', type: 'weight' }, { key: 'kind', label: 'Kind' }, { key: 'postedBy', label: 'By' }],
  },
  transfers: {
    title: 'Inter-branch transfers', sub: 'Stock is In Transit after dispatch and is available at the destination only after receipt is posted', perms: ['Inventory.View', 'Inventory.Transfer'], list: { url: '/inventory/transfers' },
    columns: [{ key: 'number', label: 'Number' }, { key: 'origin', label: 'From' }, { key: 'destination', label: 'To' }, { key: 'transferStatus', label: 'Transfer', type: 'status' }, { key: 'dispatchedAtUtc', label: 'Dispatched', type: 'datetime' }, { key: 'receivedAtUtc', label: 'Received', type: 'datetime' }],
    create: { label: 'New transfer', perm: ['Inventory.Transfer'], title: 'New stock transfer', url: '/inventory/transfers', width: 880, fields: [{ key: 'originBranchId', label: 'From branch', type: 'select', lookup: 'branches', required: true }, { key: 'destinationBranchId', label: 'To branch', type: 'select', lookup: 'branches', required: true }, { key: 'dispatchNow', label: 'Dispatch immediately', type: 'checkbox', default: true }, { key: 'notes', label: 'Notes', col: 2 }, { key: 'lines', label: 'Items', type: 'lines', required: true, fields: [{ key: 'productId', label: 'Item', type: 'select', lookup: 'products' }, { key: 'quantity', label: 'Qty', type: 'number', default: 1 }, { key: 'metalTypeId', label: 'Loose metal', type: 'select', lookup: 'metals' }, { key: 'purityId', label: 'Purity', type: 'select', lookup: 'purities+' }, { key: 'netWeight', label: 'Net g (loose)', type: 'number' }] }] },
    rowClick: r => ['/inventory/transfers', r.id],
  },
  adjustments: {
    title: 'Stock adjustments', sub: 'Adjustments over your approval limit wait for an approver (never your own)', perms: ['Inventory.Adjust'], list: { url: '/inventory/adjustments' },
    columns: [{ key: 'number', label: 'Number' }, { key: 'kind', label: 'Kind' }, { key: 'reason', label: 'Reason' }, { key: 'totalValue', label: 'Value', type: 'money' }, { key: 'lines', label: 'Lines', type: 'number' }, status],
    create: { label: 'New adjustment', perm: ['Inventory.Adjust'], title: 'Stock adjustment / damage / opening stock', url: '/inventory/adjustments', width: 880, fields: [{ key: 'kind', label: 'Kind', type: 'select', options: opts('Adjustment', 'Damage', 'Quarantine', 'Loss', 'Scrap', 'Opening'), default: 'Adjustment', required: true }, { key: 'reason', label: 'Reason', required: true, col: 2 }, { key: 'lines', label: 'Lines', type: 'lines', required: true, fields: [{ key: 'productId', label: 'Item', type: 'select', lookup: 'products' }, { key: 'metalTypeId', label: 'Loose metal', type: 'select', lookup: 'metals' }, { key: 'purityId', label: 'Purity', type: 'select', lookup: 'purities+' }, { key: 'quantityDelta', label: 'Qty ±', type: 'number' }, { key: 'netDelta', label: 'Net g ±', type: 'number' }, { key: 'unitCost', label: 'Unit cost', type: 'number' }] }] },
    actions: [{ label: 'Post', perm: ['Inventory.Adjust'], show: r => r.status === 'Approved', method: 'post', url: r => `/inventory/adjustments/${r.id}/post`, confirm: 'Post this approved adjustment?' }],
  },
  counts: {
    title: 'Stock counts', sub: 'Count sheets freeze the system figures; a different person approves the variance', perms: ['Inventory.Count', 'Inventory.View'], list: { url: '/inventory/counts' },
    columns: [{ key: 'number', label: 'Number' }, { key: 'branchId', label: 'Branch id' }, { key: 'status', label: 'Status', type: 'status' }, { key: 'lines', label: 'Lines', fmt: r => r.lines?.length, type: 'number' }, { key: 'notes', label: 'Notes' }],
    create: { label: 'New count sheet', perm: ['Inventory.Count'], title: 'New stock count', url: '/inventory/counts', fields: [{ key: 'locationId', label: 'Location (blank = whole branch)', type: 'select', lookup: 'locations' }, { key: 'notes', label: 'Notes', col: 3 }] },
    rowClick: r => ['/inventory/counts', r.id],
  },
  reservations: {
    title: 'Reservations', sub: 'Reserved items cannot be sold until released or expired', perms: ['Inventory.Reserve', 'Inventory.View'], list: { url: '/inventory/reservations' }, searchable: false,
    columns: [{ key: 'sku', label: 'SKU' }, { key: 'item', label: 'Item' }, { key: 'reservedUntilUtc', label: 'Until', type: 'datetime' }, { key: 'note', label: 'Note' }, { key: 'isActive', label: 'Active', type: 'bool' }],
    create: { label: 'Reserve an item', perm: ['Inventory.Reserve'], title: 'Reserve item', url: '/inventory/reservations', fields: [{ key: 'productId', label: 'Item', type: 'select', lookup: 'products', required: true }, { key: 'customerId', label: 'Customer', type: 'select', lookup: 'customers' }, { key: 'hours', label: 'Hold for (hours)', type: 'number', default: 24 }, { key: 'note', label: 'Note', col: 3 }] },
    actions: [{ label: 'Release', perm: ['Inventory.Reserve'], show: r => r.isActive, method: 'delete', url: r => `/inventory/reservations/${r.id}`, confirm: 'Release this reservation?' }],
  },

  // ------------------------------------------------------------------ work
  jobs: {
    title: 'Karigar job cards', perms: ['JobWork.View', 'JobWork.ViewAssigned'], list: { url: '/job-cards', params: f => ({ status: f.status, overdue: f.overdue }) },
    filters: [{ key: 'status', label: 'Stage', type: 'select', options: opts('Draft', 'Approved', 'MaterialIssued', 'InProgress', 'PartiallyReceived', 'Completed', 'Reconciled', 'Closed') }, { key: 'overdue', label: 'Overdue', type: 'select', options: [{ value: true, label: 'Overdue only' }] }],
    columns: [{ key: 'number', label: 'Job' }, { key: 'worker', label: 'Worker' }, { key: 'jobStatus', label: 'Stage', type: 'status' }, { key: 'mode', label: 'Stock mode' }, { key: 'dueDateUtc', label: 'Due', type: 'date' }, { key: 'overdue', label: 'Overdue', type: 'bool' }, { key: 'issuedFine', label: 'Issued fine g', type: 'weight' }, { key: 'outputFine', label: 'Output fine g', type: 'weight' }, { key: 'varianceFine', label: 'Variance g', type: 'weight' }, { key: 'payable', label: 'Payable', type: 'money' }],
    create: { label: 'New job card', perm: ['JobWork.Create'], title: 'New job card', width: 860, url: '/job-cards', fields: [{ key: 'workerId', label: 'Karigar', type: 'select', lookup: 'workers', required: true }, { key: 'mode', label: 'Stock posting mode', type: 'select', options: [{ value: 'OnIssue', label: 'On issue - shop metal moves to the worker' }, { value: 'OnReceiptOnly', label: 'On receipt only - planning card, no stock moves' }], default: 'OnIssue', required: true, hint: 'Cannot change after the first posting' }, { key: 'materialOwnership', label: 'Metal owner', type: 'select', options: opts('Shop', 'Worker', 'Customer'), default: 'Shop' }, { key: 'materialSourceNote', label: 'Who provides the metal (planning cards)', showIf: v => v.mode === 'OnReceiptOnly', col: 2 }, { key: 'designSpec', label: 'Design / specification', type: 'textarea', required: true }, { key: 'dueDateUtc', label: 'Due date', type: 'date' }, { key: 'targetPieces', label: 'Target pieces', type: 'number', default: 1 }, { key: 'makingType', label: 'Making charge type', type: 'select', options: opts('PerGram', 'Fixed', 'Percent') }, { key: 'makingValue', label: 'Making value', type: 'number' }, { key: 'wastageAllowancePercent', label: 'Wastage allowance %', type: 'number' }, { key: 'toleranceFineGrams', label: 'Tolerance (fine g)', type: 'number', hint: 'blank = shop default' }] },
    rowClick: r => ['/job-work', r.id],
  },
  repairs: {
    title: 'Repair tickets', perms: ['Repairs.ViewBranch', 'Repairs.ViewAssigned'], list: { url: '/repairs', params: f => ({ status: f.status, overdue: f.overdue }) },
    filters: [{ key: 'status', label: 'Status', type: 'select', options: opts('Received', 'Inspection', 'EstimatePrepared', 'AwaitingApproval', 'Approved', 'InRepair', 'QualityCheck', 'Ready', 'Delivered', 'Rejected', 'Cancelled', 'Unrepairable') }, { key: 'overdue', label: 'Overdue', type: 'select', options: [{ value: true, label: 'Past promised date' }] }],
    columns: [{ key: 'number', label: 'Ticket' }, { key: 'customer', label: 'Customer' }, { key: 'itemDescription', label: 'Item' }, { key: 'repairStatus', label: 'Status', type: 'status' }, { key: 'promisedDateUtc', label: 'Promised', type: 'date' }, { key: 'overdue', label: 'Overdue', type: 'bool' }, { key: 'technician', label: 'Technician' }, { key: 'estimate', label: 'Estimate', type: 'money' }, { key: 'balance', label: 'Balance', type: 'money' }],
    create: { label: 'New repair intake', perm: ['Repairs.Create'], title: '', navigate: ['/repairs/new'], fields: [] }, rowClick: r => ['/repairs', r.id],
  },

  // ------------------------------------------------------------------ finance
  expenses: {
    title: 'Expenses', perms: ['Finance.View', 'Finance.Expense.Create'], list: { url: '/expenses' },
    columns: [{ key: 'dateUtc', label: 'Date', type: 'date' }, { key: 'number', label: 'Voucher' }, { key: 'head', label: 'Head' }, { key: 'payee', label: 'Payee' }, { key: 'description', label: 'Description' }, { key: 'amount', label: 'Amount', type: 'money' }, { key: 'account', label: 'Paid from' }, status],
    create: { label: 'New expense', perm: ['Finance.Expense.Create'], title: 'Expense voucher', url: '/expenses', fields: [{ key: 'expenseHeadId', label: 'Expense head', type: 'select', lookup: 'expense-heads', required: true }, { key: 'payee', label: 'Payee' }, { key: 'amount', label: 'Amount', type: 'number', required: true }, { key: 'taxAmount', label: 'Tax included', type: 'number', default: 0 }, { key: 'paymentAccountId', label: 'Paid from', type: 'select', lookup: 'cash-bank-accounts', required: true }, { key: 'dateUtc', label: 'Date', type: 'date' }, { key: 'description', label: 'Description', col: 3 }] },
    actions: [{ label: 'Post', perm: ['Finance.Expense.Create'], show: r => r.status === 'Approved', method: 'post', url: r => `/expenses/${r.id}/post`, confirm: 'Post this approved expense?' },
      { label: 'Reverse', perm: ['Finance.Reverse'], danger: true, show: r => r.status === 'Posted', method: 'post', url: () => '/reversals', reason: 'Reason for reversing this expense', body: (v, r) => ({ kind: 'expense', id: r.id, reason: v.reason }) }],
  },
  vouchers: {
    title: 'Cash & bank vouchers', perms: ['Finance.View', 'Finance.Payment.Post'], list: { url: '/vouchers' },
    columns: [{ key: 'dateUtc', label: 'Date', type: 'date' }, { key: 'number', label: 'Voucher' }, { key: 'voucherType', label: 'Type' }, { key: 'account', label: 'Account' }, { key: 'toAccount', label: 'To account' }, { key: 'party', label: 'Party' }, { key: 'amount', label: 'Amount', type: 'money' }, { key: 'description', label: 'Description' }, status],
    create: { label: 'New voucher', perm: ['Finance.Payment.Post'], title: 'Cash / bank voucher', width: 800, url: '/cash-vouchers', fields: [{ key: 'type', label: 'Type', type: 'select', options: opts('Receipt', 'Payment', 'Transfer', 'Deposit', 'Withdrawal'), required: true }, { key: 'accountId', label: 'Account', type: 'select', lookup: 'cash-bank-accounts', required: true }, { key: 'toAccountId', label: 'To account', type: 'select', lookup: 'cash-bank-accounts', showIf: v => ['Transfer', 'Deposit', 'Withdrawal'].includes(v.type) }, { key: 'amount', label: 'Amount', type: 'number', required: true }, { key: 'partyType', label: 'Party type', type: 'select', options: [{ value: 'Customer', label: 'Customer (receipt)' }], showIf: v => v.type === 'Receipt' }, { key: 'partyId', label: 'Customer', type: 'select', lookup: 'customers', showIf: v => v.type === 'Receipt' && v.partyType === 'Customer', hint: 'Oldest invoices are settled first' }, { key: 'counterAccountId', label: 'Credit / expense account', type: 'select', lookup: 'chart-accounts', showIf: v => v.type === 'Payment' || (v.type === 'Receipt' && !v.partyId) }, { key: 'reference', label: 'Reference' }, { key: 'description', label: 'Description', col: 3 }] },
    actions: [{ label: 'Reverse', perm: ['Finance.Reverse'], danger: true, show: r => r.status === 'Posted', method: 'post', url: () => '/reversals', reason: 'Reason for reversing this voucher', body: (v, r) => ({ kind: 'voucher', id: r.id, reason: v.reason }) }],
  },

  // ------------------------------------------------------------------ admin
  approvals: {
    title: 'Approvals', sub: 'Requests above a user\'s limit wait here. You cannot approve your own request.', perms: ['Approvals.View', 'Approvals.Decide'], list: { url: '/approvals', params: f => ({ status: f.status ?? 'Pending' }) },
    filters: [{ key: 'status', label: 'Status', type: 'select', options: opts('Pending', 'Approved', 'Rejected'), default: 'Pending' }],
    columns: [{ key: 'requestedAtUtc', label: 'Requested', type: 'datetime' }, { key: 'type', label: 'Type' }, { key: 'number', label: 'Document', fmt: r => r.number ?? `${r.entityType} #${r.entityId}` }, { key: 'value', label: 'Value', type: 'number' }, { key: 'limit', label: 'Your limit', type: 'number' }, { key: 'reason', label: 'Reason' }, { key: 'requestedBy', label: 'By' }, { key: 'status', label: 'Status', type: 'status' }, { key: 'decidedBy', label: 'Decided by' }],
    actions: [{ label: 'Approve', perm: ['Approvals.Decide'], show: r => r.status === 'Pending', method: 'post', url: r => `/approvals/${r.id}/decision`, body: (v) => ({ approve: true, reason: v.reason }), reason: 'Approval note (optional)' },
      { label: 'Reject', perm: ['Approvals.Decide'], danger: true, show: r => r.status === 'Pending', method: 'post', url: r => `/approvals/${r.id}/decision`, body: (v) => ({ approve: false, reason: v.reason }), reason: 'Reason for rejecting' }],
  },
  branches: {
    title: 'Branches', sub: 'Each branch has its own numbering, locations, cash drawer and stock. Inactive branches keep their history but cannot post.', perms: ['Branches.Manage'], list: { url: '/branches' }, searchable: false,
    columns: [{ key: 'branchCode', label: 'Code' }, { key: 'branchName', label: 'Name' }, { key: 'city', label: 'City' }, { key: 'branchType', label: 'Type' }, { key: 'invoicePrefix', label: 'Prefix' }, { key: 'isActive', label: 'Active', type: 'bool' }, { key: 'isHeadOffice', label: 'HQ', type: 'bool' }],
    create: { label: 'New branch', perm: ['Branches.Manage'], title: 'New branch', url: '/branches', fields: [{ key: 'branchCode', label: 'Code', required: true }, { key: 'branchName', label: 'Name', required: true }, { key: 'city', label: 'City' }, { key: 'phone', label: 'Phone' }, { key: 'address', label: 'Address', col: 2 }, { key: 'branchType', label: 'Type', type: 'select', options: opts('Retail', 'Workshop', 'Warehouse', 'HeadOffice'), default: 'Retail' }, { key: 'invoicePrefix', label: 'Numbering prefix', hint: 'Embedded in every document number' }, { key: 'receiptFooter', label: 'Receipt footer', col: 3 }] },
    edit: { perm: ['Branches.Manage'], url: r => `/branches/${r.id}`, method: 'put', fields: [{ key: 'branchCode', label: 'Code', required: true }, { key: 'branchName', label: 'Name', required: true }, { key: 'city', label: 'City' }, { key: 'phone', label: 'Phone' }, { key: 'address', label: 'Address', col: 2 }, { key: 'branchType', label: 'Type', type: 'select', options: opts('Retail', 'Workshop', 'Warehouse', 'HeadOffice') }, { key: 'invoicePrefix', label: 'Numbering prefix' }, { key: 'isActive', label: 'Active', type: 'checkbox' }, { key: 'receiptFooter', label: 'Receipt footer', col: 3 }] },
  },
  audit: {
    title: 'Audit log', sub: 'Who did what, where and when - including denied attempts', perms: ['AuditLog.View'], list: { url: '/audit-logs', params: f => ({ action: f.action, entityType: f.entityType, denied: f.denied, from: f.from, to: f.to }) },
    filters: [{ key: 'action', label: 'Action contains' }, { key: 'entityType', label: 'Entity type' }, { key: 'denied', label: 'Outcome', type: 'select', options: [{ value: true, label: 'Denied only' }] }, { key: 'from', label: 'From', type: 'date' }, { key: 'to', label: 'To', type: 'date' }],
    columns: [{ key: 'atUtc', label: 'When', type: 'datetime' }, { key: 'user', label: 'User' }, { key: 'action', label: 'Action' }, { key: 'entityType', label: 'Entity' }, { key: 'entityId', label: 'Id' }, { key: 'activeBranchId', label: 'Active br.' }, { key: 'targetBranchId', label: 'Target br.' }, { key: 'reason', label: 'Reason' }, { key: 'denied', label: 'Denied', type: 'bool' }, { key: 'correlationId', label: 'Correlation' }],
  },
};
