import { Component, computed, inject, signal } from '@angular/core';
import { Router } from '@angular/router';
import { firstValueFrom } from 'rxjs';
import { Api } from '../core/api';
import { Session } from '../core/session';
import { Toast } from '../core/toast';
import { Lookups, Opt } from '../shared/lookups';
import { MoneyPipe, WeightPipe } from '../shared/pipes';
import { SecureImg } from '../shared/img';
import { Dialog } from '../shared/dialog';
import { DynamicForm, Field } from '../shared/form';

interface Line { productId: number; sku: string; name: string; purity?: string; net: number; qty: number; pricingMode?: string; manualPrice?: number; discount: number; otherCharges: number; rateOverride?: number; rateOverrideReason?: string; img?: number; priced?: any; }

@Component({
  selector: 'app-pos', imports: [MoneyPipe, WeightPipe, SecureImg, Dialog, DynamicForm],
  template: `
  <div class="pagehead"><h1>Sales (POS)</h1><span class="grow"></span>
    <button class="btn ghost" (click)="hold()" [disabled]="!cart().length">Hold</button></div>
  <div class="pos">
    <div class="card"><h3>Item search</h3>
      <input class="search" placeholder="Scan barcode or type SKU/name and press Enter" [value]="query()" (input)="onType($any($event.target).value)" (keydown.enter)="scan()" autofocus />
      @for (p of results(); track p.id) { <div class="itemcard" (click)="add(p)"><app-img [id]="p.primaryImageId" [size]="44" /><div class="grow"><b>{{ p.sku }}</b> {{ p.name }}<br><small class="muted">{{ p.purity }} · {{ p.netMetalWeight | weight }} g · avail {{ p.availableQty }}</small></div><b>{{ p.tagPrice || '' }}</b></div> }
    </div>
    <div class="card"><h3>Cart</h3>
      <table class="grid"><thead><tr><th>Item</th><th>Purity</th><th>Net g</th><th>Mode</th><th>Rate</th><th>Disc</th><th>Total</th><th></th></tr></thead>
      <tbody>@for (l of cart(); track l.productId; let i = $index) {
        <tr><td>{{ l.sku }} {{ l.name }}</td><td>{{ l.purity }}</td><td class="num">{{ l.net | weight }}</td>
          <td><select [value]="l.pricingMode" (change)="setMode(i, $any($event.target).value)"><option value="MetalPlusMaking">Metal+Making</option><option value="MetalStoneMakingWastage">+Stone/Wastage</option><option value="Tagged">Tagged</option><option value="ManualApproved">Manual</option></select></td>
          <td><input type="number" style="width:90px" [value]="l.rateOverride ?? ''" placeholder="card" (change)="setRate(i, $any($event.target).value)" /></td>
          <td><input type="number" style="width:70px" [value]="l.discount" (change)="setField(i,'discount',$any($event.target).value)" /></td>
          <td class="num">{{ linePrice(i)?.total | money }}</td>
          <td><button class="icon danger" (click)="remove(i)">✕</button></td></tr>
      } @empty { <tr><td colspan="8" class="empty">Cart is empty - search or scan an item.</td></tr> }</tbody></table>
    </div>
    <div class="card"><h3>Payment</h3>
      <div class="field"><label>Customer</label><select (change)="customerId.set($any($event.target).value ? +$any($event.target).value : null)"><option value="">Walk-in</option>@for (o of customers(); track o.value) {<option [value]="o.value">{{ o.label }}</option>}</select></div>
      <div class="field"><label>Salesman</label><select (change)="salesmanId.set($any($event.target).value ? +$any($event.target).value : null)"><option value="">—</option>@for (o of salesmen(); track o.value) {<option [value]="o.value">{{ o.label }}</option>}</select></div>
      @if (customerId() && oldGold().length) { <div class="field"><label>Apply old gold credit</label>@for (o of oldGold(); track o.id) { <label class="check"><input type="checkbox" [checked]="oldGoldIds().includes(o.id)" (change)="toggleOg(o.id, $any($event.target).checked)" /> {{ o.number }} — {{ fmtNum(o.value - o.paidOut) }} PKR</label> } </div> }
      <div class="totals"><span>Subtotal</span><b class="num">{{ quote()?.totals?.subtotal | money }}</b><span>Discount</span><b class="num">{{ quote()?.totals?.discount | money }}</b><span>Tax</span><b class="num">{{ quote()?.totals?.tax | money }}</b><span>Old gold</span><b class="num">{{ quote()?.totals?.oldGoldCredit | money }}</b><span class="big">Total</span><b class="num big">{{ quote()?.totals?.total | money }}</b></div>
      <h4>Payments</h4>@for (p of payments(); track $index; let i = $index) { <div class="row"><select style="flex:2" (change)="setPay(i,'paymentMethodId',$any($event.target).value)"><option value="">Method</option>@for (o of methods(); track o.value) {<option [value]="o.value" [selected]="p.paymentMethodId===o.value">{{ o.label }}</option>}</select><input type="number" style="flex:1" placeholder="Amount" [value]="p.amount" (change)="setPay(i,'amount',$any($event.target).value)" /><button class="icon danger" (click)="removePay(i)">✕</button></div> }
      <button class="btn ghost sm" (click)="addPay()">＋ Add payment</button>
      <p class="num">Due now: <b>{{ due() | money }}</b></p>
      <div class="actions"><button class="btn primary" [disabled]="!cart().length || busy()" (click)="post()">Post sale</button></div>
    </div>
  </div>
  @if (manualDlg(); as m) { <app-dialog title="Manual price (needs approval)" (closed)="manualDlg.set(null)"><app-form [fields]="manualFields" [value]="m" (submitted)="applyManual($event)" /></app-dialog> }
  `,
})
export class Pos {
  private api = inject(Api); private lk = inject(Lookups); private toast = inject(Toast); private router = inject(Router); s = inject(Session);
  query = signal(''); results = signal<any[]>([]); cart = signal<Line[]>([]); customerId = signal<number | null>(null); salesmanId = signal<number | null>(null);
  payments = signal<any[]>([]); quote = signal<any>(null); customers = signal<Opt[]>([]); salesmen = signal<Opt[]>([]); methods = signal<Opt[]>([]); oldGold = signal<any[]>([]); oldGoldIds = signal<number[]>([]);
  busy = signal(false); manualDlg = signal<any>(null); manualIdx = -1;
  manualFields: Field[] = [{ key: 'manualPrice', label: 'Approved manual price', type: 'number', required: true, col: 3 }];

  constructor() { this.lk.get('customers').then(this.customers.set); this.lk.get('employees').then(this.salesmen.set); this.lk.get('payment-methods').then(this.methods.set); }

  private searchTimer: any;
  onType(v: string) { this.query.set(v); clearTimeout(this.searchTimer); this.searchTimer = setTimeout(() => this.search(), 250); }
  async scan() { if (!this.query().trim()) return; try { const p = await firstValueFrom(this.api.get<any>('/products/scan', { code: this.query().trim() })); this.add(p); this.query.set(''); } catch { this.toast.err('Item not found or not available here.'); } }
  search() { const q = this.query().trim(); if (q.length < 2) { this.results.set([]); return; } this.api.get('/products', { search: q, active: true, pageSize: 8 }).subscribe((r: any) => this.results.set(r.items)); }
  add(p: any) { if (this.cart().some(l => l.productId === p.id)) return; this.cart.update(c => [...c, { productId: p.id, sku: p.sku, name: p.name, purity: p.purity, net: p.netMetalWeight, qty: 1, pricingMode: p.pricingMode, discount: 0, otherCharges: 0, img: p.primaryImageId }]); this.results.set([]); this.query.set(''); this.requote(); }
  remove(i: number) { this.cart.update(c => c.filter((_, j) => j !== i)); this.requote(); }
  setField(i: number, k: string, v: any) { this.cart.update(c => c.map((l, j) => (j === i ? { ...l, [k]: +v || 0 } : l))); this.requote(); }
  setRate(i: number, v: string) { if (!v) { this.cart.update(c => c.map((l, j) => (j === i ? { ...l, rateOverride: undefined } : l))); this.requote(); return; } const reason = prompt('Reason for overriding the gold rate:'); if (!reason) return; this.cart.update(c => c.map((l, j) => (j === i ? { ...l, rateOverride: +v, rateOverrideReason: reason } : l))); this.requote(); }
  setMode(i: number, v: string) { if (v === 'ManualApproved') { this.manualIdx = i; this.manualDlg.set({ manualPrice: '' }); return; } this.cart.update(c => c.map((l, j) => (j === i ? { ...l, pricingMode: v } : l))); this.requote(); }
  applyManual(v: any) { this.cart.update(c => c.map((l, j) => (j === this.manualIdx ? { ...l, pricingMode: 'ManualApproved', manualPrice: +v.manualPrice } : l))); this.manualDlg.set(null); this.requote(); }
  linePrice(i: number) { return this.quote()?.lines?.[i]?.price; }
  addPay() { this.payments.update(p => [...p, { paymentMethodId: null, amount: this.due() }]); }
  removePay(i: number) { this.payments.update(p => p.filter((_, j) => j !== i)); }
  setPay(i: number, k: string, v: any) { this.payments.update(p => p.map((x, j) => (j === i ? { ...x, [k]: k === 'amount' ? +v : +v } : x))); }
  due = computed(() => Math.max(0, (this.quote()?.totals?.total ?? 0) - this.payments().reduce((a, p) => a + (p.amount || 0), 0)));
  toggleOg(id: number, on: boolean) { this.oldGoldIds.update(l => (on ? [...l, id] : l.filter(x => x !== id))); this.requote(); }

  payload() { return { customerId: this.customerId(), salesmanId: this.salesmanId(), oldGoldIds: this.oldGoldIds(), lines: this.cart().map(l => ({ productId: l.productId, quantity: l.qty, pricingMode: l.pricingMode, discount: l.discount, otherCharges: l.otherCharges, rateOverride: l.rateOverride, rateOverrideReason: l.rateOverrideReason, manualPrice: (l as any).manualPrice })), payments: this.payments().filter(p => p.paymentMethodId && p.amount > 0) }; }
  requote() {
    if (!this.cart().length) { this.quote.set(null); return; }
    if (this.customerId()) this.api.get(`/customers/${this.customerId()}/old-gold`).subscribe(r => this.oldGold.set(r)); else { this.oldGold.set([]); this.oldGoldIds.set([]); }
    this.api.post('/sales/quotes', this.payload()).subscribe({ next: q => this.quote.set(q), error: () => this.quote.set(null) });
  }
  hold() { this.api.post('/sales', { ...this.payload(), hold: true, postNow: false }).subscribe(() => { this.toast.ok('Sale held'); this.reset(); }); }
  post() { this.busy.set(true); this.api.post('/sales', this.payload()).subscribe({ next: s => { this.toast.ok('Sale posted: ' + s.number); this.reset(); this.router.navigate(['/sales', s.id]); }, error: () => this.busy.set(false) }); }
  fmtNum(v: number) { return Math.round(v).toLocaleString(); }
  reset() { this.cart.set([]); this.payments.set([]); this.customerId.set(null); this.quote.set(null); this.busy.set(false); }
}
