import { Component, computed, inject, signal } from '@angular/core';
import { Router, RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import { Session } from '../core/session';
import { Lang, TPipe } from '../core/i18n';

interface Nav { label: string; link: string; perms: string[]; }
interface Group { title: string; items: Nav[]; }

@Component({
  selector: 'app-shell', imports: [RouterOutlet, RouterLink, RouterLinkActive, TPipe],
  template: `
  <div class="shell">
    <nav class="side" [class.open]="open()" aria-label="Main">
      <div class="brand">💎 Jewellery <b>ERP</b></div>
      @for (g of groups(); track g.title) { <h4>{{ g.title | t }}</h4>@for (n of g.items; track n.link) { <a [routerLink]="n.link" routerLinkActive="active" (click)="open.set(false)">{{ n.label | t }}</a> } }
    </nav>
    <div class="main">
      <header class="top no-print">
        <button class="icon menu-btn" (click)="open.set(!open())" aria-label="Menu">☰</button>
        <span class="grow muted">{{ s.user()?.roles?.join(' · ') }}</span>
        @if (showBranch()) {
          <label class="row">Branch
            <select (change)="s.setBranch($any($event.target).value === 'all' ? 'all' : +$any($event.target).value)" aria-label="Active branch">
              @if (s.canAll()) { <option value="all" [selected]="s.branch() === 'all'">All permitted branches</option> }
              @for (b of s.user()?.branches; track b.id) { <option [value]="b.id" [selected]="s.branch() === b.id">{{ b.name }}{{ b.isActive ? '' : ' (inactive)' }}</option> }
            </select></label>
        } @else { <span class="badge">{{ s.activeBranch()?.name }}</span> }
        <button class="btn ghost sm" (click)="lang.toggle()">{{ lang.lang() === 'en' ? 'اردو' : 'English' }}</button>
        <a routerLink="/profile">{{ s.user()?.fullName }}</a>
        <button class="btn sm" (click)="s.logout()">{{ 'Sign out' | t }}</button>
      </header>
      @if (s.branch() === 'all') { <div class="alert info no-print" style="margin:10px 22px 0">Consolidated view: reports aggregate all permitted branches. Posting documents needs a single branch - pick one above.</div> }
      <main class="page"><router-outlet /></main>
    </div>
  </div>`,
})
export class Shell {
  s = inject(Session); lang = inject(Lang); private r = inject(Router);
  open = signal(false);
  showBranch = computed(() => (this.s.user()?.branches.length ?? 0) > 1 || this.s.canAll());   // selector only when there is a real choice (SRS 21.3)
  private all: Group[] = [
    { title: 'Dashboard', items: [{ label: 'Dashboard', link: '/dashboard', perms: [] }] },
    { title: 'Sales (POS)', items: [{ label: 'Sales (POS)', link: '/pos', perms: ['Sales.Create'] }, { label: 'Invoices', link: '/sales', perms: ['Sales.View'] }, { label: 'Old gold / buy-back', link: '/old-gold', perms: ['OldGold.Create', 'OldGold.View'] }, { label: 'Customers', link: '/masters/customers', perms: ['Customers.View'] }] },
    { title: 'Products', items: [{ label: 'Products', link: '/products', perms: ['Products.View'] }, { label: 'Gallery', link: '/gallery', perms: ['Products.Images.View'] }, { label: 'Gold rates', link: '/gold-rates', perms: ['GoldRate.View'] }, { label: 'Categories', link: '/masters/categories', perms: ['Masters.Manage', 'Products.Create'] }] },
    { title: 'Purchases', items: [{ label: 'Purchases', link: '/list/purchases', perms: ['Purchases.View'] }, { label: 'Suppliers', link: '/masters/suppliers', perms: ['Suppliers.View'] }, { label: 'Supplier payments', link: '/list/supplier-payments', perms: ['Finance.Payment.Post'] }] },
    { title: 'Inventory', items: [{ label: 'Stock', link: '/inventory/stock', perms: ['Inventory.View'] }, { label: 'Movements', link: '/list/movements', perms: ['Inventory.View'] }, { label: 'Transfers', link: '/list/transfers', perms: ['Inventory.View', 'Inventory.Transfer'] }, { label: 'Adjustments', link: '/list/adjustments', perms: ['Inventory.Adjust'] }, { label: 'Stock counts', link: '/list/counts', perms: ['Inventory.Count', 'Inventory.View'] }, { label: 'Reservations', link: '/list/reservations', perms: ['Inventory.Reserve', 'Inventory.View'] }] },
    { title: 'Karigar jobs', items: [{ label: 'Job cards', link: '/list/jobs', perms: ['JobWork.View', 'JobWork.ViewAssigned'] }, { label: 'Workers', link: '/masters/workers', perms: ['Workers.View'] }] },
    { title: 'Repairs', items: [{ label: 'Repair tickets', link: '/list/repairs', perms: ['Repairs.ViewBranch', 'Repairs.ViewAssigned'] }, { label: 'New repair intake', link: '/repairs/new', perms: ['Repairs.Create'] }] },
    { title: 'Finance', items: [{ label: 'Expenses', link: '/list/expenses', perms: ['Finance.View', 'Finance.Expense.Create'] }, { label: 'Cash / bank vouchers', link: '/list/vouchers', perms: ['Finance.View', 'Finance.Payment.Post'] }, { label: 'Cash register', link: '/finance/register', perms: ['Finance.CashRegister', 'Finance.View'] }, { label: 'Commission', link: '/finance/commission', perms: ['Reports.Commission.View', 'Commission.Approve'] }, { label: 'Accounts', link: '/masters/cash-bank-accounts', perms: ['Finance.View'] }, { label: 'Employees', link: '/masters/employees', perms: ['Employees.View'] }] },
    { title: 'Reports', items: [{ label: 'Reports centre', link: '/reports', perms: ['Reports.Sales.View', 'Reports.Stock.View', 'Reports.Finance.View', 'Reports.Purchase.View', 'Reports.Workshop.View'] }, { label: 'Transaction register', link: '/reports/transactions', perms: ['Reports.Transactions.View'] }] },
    { title: 'Administration', items: [{ label: 'Approvals', link: '/list/approvals', perms: ['Approvals.View', 'Approvals.Decide'] }, { label: 'Users', link: '/admin/users', perms: ['Users.Manage'] }, { label: 'Roles & permissions', link: '/admin/roles', perms: ['Roles.Manage', 'Users.Manage'] }, { label: 'Branches', link: '/list/branches', perms: ['Branches.Manage'] }, { label: 'Audit log', link: '/list/audit', perms: ['AuditLog.View'] }, { label: 'Settings & backup', link: '/admin/settings', perms: ['Settings.Manage', 'Backup.Manage'] }, { label: 'Units', link: '/masters/units', perms: ['Settings.Manage'] }] },
  ];
  groups = computed(() => this.all.map(g => ({ ...g, items: g.items.filter(i => i.perms.length === 0 || this.s.canAny(...i.perms)) })).filter(g => g.items.length > 0));
}
