import { Component, inject, signal } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { DynamicForm, Field } from '../shared/form';
import { Api } from '../core/api';
import { Session } from '../core/session';
import { Toast } from '../core/toast';

@Component({
  selector: 'app-login', imports: [DynamicForm, RouterLink],
  template: `<div class="login"><div class="card"><h1>Jewellery ERP</h1><p class="muted">Sign in to continue</p>
    @if (locked()) { <p class="warnbox">Too many attempts - wait a few minutes or ask an administrator to unlock the account.</p> }
    <app-form [fields]="f" submitLabel="Sign in" [busy]="busy()" (submitted)="go($event)" /><p><a routerLink="/forgot">Forgot password?</a></p></div></div>`,
})
export class Login {
  private s = inject(Session); private r = inject(Router); private toast = inject(Toast);
  busy = signal(false); locked = signal(false);
  f: Field[] = [{ key: 'userName', label: 'User name or email', required: true, col: 3 }, { key: 'password', label: 'Password', type: 'password', required: true, col: 3 }];
  constructor() { if (this.s.isAuthed()) this.r.navigateByUrl('/dashboard'); }
  async go(v: any) {
    this.busy.set(true);
    try { await this.s.login(v.userName, v.password); if (this.s.user()?.mustChangePassword) this.toast.info('Please change your temporary password.'); this.r.navigateByUrl(this.s.user()?.mustChangePassword ? '/profile' : '/dashboard'); }
    catch (e: any) { this.locked.set(e?.status === 429); }
    this.busy.set(false);
  }
}

@Component({
  selector: 'app-forgot', imports: [DynamicForm, RouterLink],
  template: `<div class="login"><div class="card"><h1>Reset password</h1>
    @if (step() === 1) { <p class="muted">Enter your email. If it is registered, a one-time code is sent.</p><app-form [fields]="a" submitLabel="Send code" [busy]="busy()" (submitted)="send($event)" /> }
    @else { <p class="muted">Enter the code you received and a new password (10+ characters, with a letter and a digit).</p><app-form [fields]="b" submitLabel="Set password" [busy]="busy()" (submitted)="reset($event)" /> }
    <p><a routerLink="/login">Back to sign in</a></p></div></div>`,
})
export class Forgot {
  private api = inject(Api); private r = inject(Router); private toast = inject(Toast);
  step = signal(1); busy = signal(false);
  a: Field[] = [{ key: 'email', label: 'Email', type: 'email', required: true, col: 3 }];
  b: Field[] = [{ key: 'token', label: 'Reset code', required: true, col: 3 }, { key: 'newPassword', label: 'New password', type: 'password', required: true, col: 3 }];
  send(v: any) { this.busy.set(true); this.api.post('/auth/forgot-password', v).subscribe({ next: () => { this.step.set(2); this.busy.set(false); this.toast.info('If that email is registered, a code is on its way.'); }, error: () => this.busy.set(false) }); }
  reset(v: any) { this.busy.set(true); this.api.post('/auth/reset-password', v).subscribe({ next: () => { this.toast.ok('Password updated - sign in.'); this.r.navigateByUrl('/login'); }, error: () => this.busy.set(false) }); }
}

@Component({ selector: 'app-forbidden', imports: [RouterLink], template: `<div class="login"><div class="card"><h1>No access</h1><p>Your role does not include this area. Permissions are checked by the server, so this is not just a hidden menu.</p><a routerLink="/dashboard">Back</a></div></div>` })
export class Forbidden {}
@Component({ selector: 'app-nf', imports: [RouterLink], template: `<div class="card"><h1>Page not found</h1><a routerLink="/dashboard">Dashboard</a></div>` })
export class NotFound {}

@Component({
  selector: 'app-profile', imports: [DynamicForm],
  template: `<div class="pagehead"><h1>My account</h1></div>
  <div class="grid2"><div class="card"><h3>Profile</h3><dl class="kv"><dt>Name</dt><dd>{{ s.user()?.fullName }}</dd><dt>User</dt><dd>{{ s.user()?.userName }}</dd><dt>Email</dt><dd>{{ s.user()?.email }}</dd><dt>Roles</dt><dd>{{ s.user()?.roles?.join(', ') }}</dd>
    <dt>Branches</dt><dd>{{ names() }}</dd></dl></div>
  <div class="card"><h3>Change password</h3><app-form [fields]="f" submitLabel="Change password" [busy]="busy()" (submitted)="save($event)" /></div></div>`,
})
export class Profile {
  s = inject(Session); private api = inject(Api); private toast = inject(Toast); private r = inject(Router);
  busy = signal(false);
  f: Field[] = [{ key: 'currentPassword', label: 'Current password', type: 'password', required: true, col: 3 }, { key: 'newPassword', label: 'New password', type: 'password', required: true, col: 3, hint: '10+ characters with a letter and a digit' }];
  names = () => this.s.user()?.branches.map(b => b.name).join(', ');
  save(v: any) { this.busy.set(true); this.api.post('/auth/change-password', v).subscribe({ next: () => { this.toast.ok('Password changed - please sign in again.'); this.s.clear(); this.r.navigateByUrl('/login'); }, error: () => this.busy.set(false) }); }
}
