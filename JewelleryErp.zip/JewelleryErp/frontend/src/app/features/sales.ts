import { Component, inject, signal } from '@angular/core';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { Observable, map } from 'rxjs';
import { Api } from '../core/api';
import { Session } from '../core/session';
import { Toast } from '../core/toast';
import { DataTable, Col } from '../shared/table';
import { Dialog } from '../shared/dialog';
import { DynamicForm, Field } from '../shared/form';
import { MoneyPipe, WeightPipe, DtPipe } from '../shared/pipes';
import { SecureImg } from '../shared/img';

@Component({
  selector: 'app-sales-list', imports: [DataTable, RouterLink],
  template: `<div class="pagehead"><h1>Sales invoices</h1><span class="grow"></span><a class="btn primary" routerLink="/pos">＋ New sale (POS)</a></div>
  <app-table [columns]="cols" [loader]="loader" [clickable]="true" (rowClick)="go($event)" />`,
})
export class SalesList {
  private api = inject(Api); private router = inject(Router);
  cols: Col[] = [{ key: 'dateUtc', label: 'Date', type: 'date', sortable: true }, { key: 'number', label: 'Invoice', sortable: true }, { key: 'branch', label: 'Branch' }, { key: 'customer', label: 'Customer' }, { key: 'salesman', label: 'Salesman' }, { key: 'total', label: 'Total', type: 'money', sortable: true }, { key: 'paid', label: 'Paid', type: 'money' }, { key: 'due', label: 'Due', type: 'money' }, { key: 'status', label: 'Status', type: 'status' }];
  loader = (q: any): Observable<any> => this.api.get('/sales', q);
  go(r: any) { this.router.navigate(['/sales', r.id]); }
}

@Component({
  selector: 'app-sale-detail', imports: [MoneyPipe, WeightPipe, DtPipe, SecureImg, Dialog, DynamicForm],
  template: `
  @if (s(); as x) {
  <div class="pagehead"><div><h1>Invoice {{ x.number }}</h1><div class="sub">{{ x.dateUtc | dt }} · {{ x.branch }} · {{ x.customer || 'Walk-in' }} <span class="badge" [attr.data-s]="x.status">{{ x.status }}</span></div></div><span class="grow"></span>
    @if (sess.can('Sales.View')) { <button class="btn ghost" (click)="print()">Print</button> }
    @if (x.status==='PendingApproval' && x.pendingReason) { <span class="warnbox">{{ x.pendingReason }}</span> }
    @if (x.status==='Posted' || x.status==='PartiallyPaid' || x.status==='Closed') { <button class="btn ghost" [disabled]="!sess.can('Sales.Return')" (click)="showReturn.set(true)">Return / exchange</button><button class="btn danger" [disabled]="!sess.can('Sales.Void')" (click)="voidInvoice()">Void</button> }
  </div>
  <div class="card"><table class="grid"><thead><tr><th></th><th>SKU</th><th>Item</th><th>Purity</th><th>Net</th><th>Rate</th><th>Making</th><th>Wastage</th><th>Stone</th><th>Disc</th><th>Total</th><th>Returned</th></tr></thead>
    <tbody>@for (l of x.lines; track l.id) {<tr><td>@if (l.imageId) {<app-img [id]="l.imageId" [size]="32" />}</td><td>{{ l.sku }}</td><td>{{ l.description }}</td><td>{{ l.purity }}</td><td class="num">{{ l.net | weight }}</td><td class="num">{{ l.rate | money }}</td><td class="num">{{ l.making | money }}</td><td class="num">{{ l.wastage | money }}</td><td class="num">{{ l.stoneValue | money }}</td><td class="num">{{ l.discount | money }}</td><td class="num">{{ l.lineTotal | money }}</td><td class="num">{{ l.returnedQuantity }}</td></tr>}</tbody></table></div>
  <div class="grid2"><div class="card"><h3>Totals</h3><div class="totals"><span>Subtotal</span><b class="num">{{ x.subtotal | money }}</b><span>Discount</span><b class="num">{{ x.discount | money }}</b><span>Tax</span><b class="num">{{ x.tax | money }}</b><span>Old gold</span><b class="num">{{ x.oldGoldCredit | money }}</b><span class="big">Total</span><b class="num big">{{ x.total | money }}</b><span>Paid</span><b class="num">{{ x.paid | money }}</b><span>Due</span><b class="num">{{ x.due | money }}</b></div></div>
    <div class="card"><h3>Payments</h3>@for (p of x.payments; track $index) {<p>{{ p.method }} — {{ p.amount | money }} <small class="muted">{{ p.reference }}</small></p>}</div></div>
  @if (returns().length) { <div class="card"><h3>Returns</h3><table class="grid"><thead><tr><th>Number</th><th>Subtotal</th><th>Refunded</th><th>Status</th></tr></thead><tbody>@for (r of returns(); track r.id) {<tr><td>{{ r.number }}</td><td class="num">{{ r.subtotal | money }}</td><td class="num">{{ r.refunded | money }}</td><td><span class="badge" [attr.data-s]="r.status">{{ r.status }}</span></td></tr>}</tbody></table></div> }
  @if (showReturn()) { <app-dialog title="Return / exchange" [width]="760" (closed)="showReturn.set(false)"><app-form [fields]="returnFields(x)" submitLabel="Submit return" (submitted)="doReturn($event)" /></app-dialog> }
  }`,
})
export class SaleDetail {
  private api = inject(Api); private route = inject(ActivatedRoute); private toast = inject(Toast); sess = inject(Session);
  id = +this.route.snapshot.params['id']; s = signal<any>(null); returns = signal<any[]>([]); showReturn = signal(false);
  constructor() { this.load(); }
  load() { this.api.get(`/sales/${this.id}`).subscribe(r => this.s.set(r)); this.api.get(`/sales/${this.id}/returns`).subscribe(r => this.returns.set(r)); }
  print() { this.api.post(`/sales/${this.id}/print`).subscribe(() => { this.api.download(`/sales/${this.id}/pdf`, {}, `invoice-${this.id}.pdf`); this.load(); }); }
  returnFields(x: any): Field[] { return [{ key: 'reason', label: 'Reason', required: true, col: 2 }, { key: 'lines', label: 'Items to return', type: 'lines', required: true, fields: [{ key: 'originalLineId', label: 'Line', type: 'select', options: x.lines.filter((l: any) => l.returnedQuantity < l.quantity).map((l: any) => ({ value: l.id, label: `${l.sku} (left ${l.quantity - l.returnedQuantity})` })) }, { key: 'quantity', label: 'Qty', type: 'number', default: 1 }] }, { key: 'refunds', label: 'Refund via', type: 'lines', fields: [{ key: 'paymentMethodId', label: 'Method', type: 'select', lookup: 'payment-methods' }, { key: 'amount', label: 'Amount', type: 'number' }] }]; }
  doReturn(v: any) { this.api.post(`/sales/${this.id}/returns`, v).subscribe({ next: () => { this.toast.ok('Return recorded'); this.showReturn.set(false); this.load(); }, error: () => {} }); }
  voidInvoice() { const reason = prompt('Reason for voiding this invoice:'); if (!reason) return; this.api.post(`/sales/${this.id}/void`, { reason }).subscribe(() => { this.toast.ok('Invoice voided'); this.load(); }); }
}

@Component({
  selector: 'app-old-gold', imports: [DataTable, Dialog, DynamicForm],
  template: `<div class="pagehead"><h1>Old gold / buy-back</h1><span class="grow"></span><button class="btn primary" [disabled]="!sess.can('OldGold.Create')" (click)="open.set(true)">＋ New transaction</button></div>
  <app-table [columns]="cols" [loader]="loader" />
  @if (open()) { <app-dialog title="Old gold / buy-back" [width]="760" (closed)="open.set(false)"><app-form [fields]="f" submitLabel="Record" (submitted)="save($event)" /></app-dialog> }`,
})
export class OldGold {
  private api = inject(Api); private toast = inject(Toast); sess = inject(Session);
  open = signal(false);
  cols: Col[] = [{ key: 'no', label: 'Number' }, { key: 'c', label: 'Customer' }, { key: 'p', label: 'Purity' }, { key: 'g', label: 'Gross', type: 'weight' }, { key: 'n', label: 'Net', type: 'weight' }, { key: 'r', label: 'Rate', type: 'money' }, { key: 'v', label: 'Value', type: 'money' }, { key: 'dd', label: 'Deduct %', type: 'number' }, { key: 's', label: 'Status', type: 'status' }];
  loader = (q: any): Observable<any> => this.api.get<any>('/reports/run/old-gold', q).pipe(map((t: any) => ({ items: t.rows.map((r: any[]) => Object.fromEntries(t.columns.map((c: any, i: number) => [c.key, r[i]]))), total: t.rows.length, totals: t.totals })));
  f: Field[] = [{ key: 'customerId', label: 'Customer (blank = walk-in, paid in full)', type: 'select', lookup: 'customers' }, { key: 'metalTypeId', label: 'Metal', type: 'select', lookup: 'metals', required: true }, { key: 'purityId', label: 'Tested purity', type: 'select', lookup: 'purities', required: true }, { key: 'grossWeight', label: 'Gross weight (g)', type: 'number', required: true }, { key: 'stoneWeight', label: 'Stone/other weight (g)', type: 'number', default: 0 }, { key: 'meltingDeductionWeight', label: 'Melting/testing deduction (g)', type: 'number', default: 0 }, { key: 'itemDescription', label: 'Item description', col: 2 }, { key: 'assayNote', label: 'Assay note', col: 2 }, { key: 'payOutNow', label: 'Pay out now (PKR)', type: 'number', default: 0 }, { key: 'payOutAccountId', label: 'Paid from account', type: 'select', lookup: 'cash-bank-accounts' }];
  save(v: any) { this.api.post('/old-gold-transactions', v).subscribe({ next: () => { this.toast.ok('Recorded'); this.open.set(false); }, error: () => {} }); }
}
