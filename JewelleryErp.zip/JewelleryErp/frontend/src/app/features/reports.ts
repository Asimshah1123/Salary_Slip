import { Component, computed, inject, signal } from '@angular/core';
import { Api } from '../core/api';
import { DecimalPipe } from '@angular/common';
import { MoneyPipe, WeightPipe, DtPipe } from '../shared/pipes';
import { DynamicForm, Field } from '../shared/form';
import { Lookups } from '../shared/lookups';

interface Cat { group: string; reports: { key: string; title: string }[]; }

@Component({
  selector: 'app-reports-centre', imports: [DynamicForm, DecimalPipe],
  template: `
  <div class="pagehead"><h1>Reports Centre</h1></div>
  <div class="grid2" style="grid-template-columns:260px 1fr">
    <div class="card"><h3>Reports</h3>
      @for (g of cats(); track g.group) { <h4 class="muted" style="margin:10px 0 4px">{{ g.group }}</h4>
        @for (r of g.reports; track r.key) { <div><button class="btn ghost sm" [class.on]="key() === r.key" style="width:100%;text-align:left" (click)="pick(r.key)">{{ r.title }}</button></div> } }
    </div>
    <div class="card">
      @if (key()) {
        <div class="row"><h3 class="grow">{{ title() }}</h3>
          <button class="btn ghost sm" (click)="export('csv')">CSV</button><button class="btn ghost sm" (click)="export('xlsx')">Excel</button><button class="btn ghost sm" (click)="export('pdf')">PDF</button></div>
        <app-form [fields]="filterFields" [value]="filters()" submitLabel="Run" (submitted)="run($event)" />
        @if (t(); as tbl) {
          <p class="muted">{{ tbl.scope }}</p>
          @if (tbl.note) { <p class="warnbox">{{ tbl.note }}</p> }
          <div class="tablewrap"><table class="grid"><thead><tr>@for (c of tbl.columns; track c.key) {<th>{{ c.title }}</th>}</tr></thead>
            <tbody>@for (r of tbl.rows; track $index) {<tr>@for (c of tbl.columns; track c.key; let i = $index) {<td [class.num]="c.type==='money'||c.type==='weight'||c.type==='number'">{{ cell(r[i], c.type) }}</td>}</tr>} @empty {<tr><td [attr.colspan]="tbl.columns.length" class="empty">No rows.</td></tr>}</tbody>
          </table></div>
          @if (tbl.totals && objKeys(tbl.totals).length) { <div class="totals">@for (k of objKeys(tbl.totals); track k) { <span>{{ k }}</span><b class="num">{{ tbl.totals[k] | number: '1.0-2' }}</b> }</div> }
          @if (tbl.truncated) { <p class="warnbox">Result truncated to the export cap - narrow the filters for a complete set.</p> }
        }
      } @else { <p class="muted">Pick a report from the list.</p> }
    </div>
  </div>`,
})
export class ReportsCentre {
  private api = inject(Api);
  cats = signal<Cat[]>([]); key = signal<string | null>(null); t = signal<any>(null); filters = signal<any>({});
  title = computed(() => this.cats().flatMap(c => c.reports).find(r => r.key === this.key())?.title ?? '');
  filterFields: Field[] = [{ key: 'from', label: 'From', type: 'date' }, { key: 'to', label: 'To', type: 'date' }, { key: 'by', label: 'Group by', type: 'select', options: [{ value: 'salesman', label: 'Salesman' }, { value: 'branch', label: 'Branch' }, { value: 'customer', label: 'Customer' }, { value: 'category', label: 'Category' }, { value: 'karat', label: 'Karat' }, { value: 'day', label: 'Day' }, { value: 'month', label: 'Month' }, { value: 'product', label: 'Product' }], placeholder: '(default)' }];
  constructor() { this.api.get('/reports/catalogue').subscribe(r => this.cats.set(r)); }
  pick(k: string) { this.key.set(k); this.filters.set({}); this.run({}); }
  run(v: any) { this.filters.set(v); this.api.get(`/reports/run/${this.key()}`, v).subscribe(r => this.t.set(r)); }
  export(fmt: string) { this.api.download(`/reports/run/${this.key()}/export`, { ...this.filters(), format: fmt }, `${this.key()}.${fmt}`); }
  objKeys = Object.keys;
  cell(v: any, type: string) { if (v === null || v === undefined) return ''; if (type === 'money') return Number(v).toFixed(2); if (type === 'weight') return Number(v).toFixed(3); if (type === 'date') return String(v).slice(0, 10); if (type === 'datetime') return String(v).replace('T', ' ').slice(0, 16); if (type === 'bool') return v ? '✓' : ''; return v; }
}

@Component({
  selector: 'app-transaction-register', imports: [DynamicForm, MoneyPipe, WeightPipe, DtPipe],
  template: `
  <div class="pagehead"><h1>Comprehensive Transaction Register</h1><div class="sub">Every posted sale, purchase, return, worker movement, repair, expense and payment, filterable and exportable.</div>
    <span class="grow"></span><button class="btn ghost" (click)="export('csv')">CSV</button><button class="btn ghost" (click)="export('xlsx')">Excel</button><button class="btn ghost" (click)="export('pdf')">PDF</button></div>
  <div class="card"><app-form [fields]="f" [value]="filters()" submitLabel="Apply" (submitted)="run($event)" /></div>
  @if (r(); as x) {
    <div class="totals"><span>Debit</span><b class="num">{{ x.totals.debit | money }}</b><span>Credit</span><b class="num">{{ x.totals.credit | money }}</b></div>
    <div class="tablewrap"><table class="grid"><thead><tr><th>When</th><th>Branch</th><th>Type</th><th>No.</th><th>Status</th><th>Party</th><th>SKU</th><th>Item</th><th>Net</th><th>Fine</th><th>Debit</th><th>Credit</th><th>By</th></tr></thead>
    <tbody>@for (row of x.items; track row.id) {<tr (click)="open(row)" class="clickable"><td>{{ row.postedAtUtc | dt }}</td><td>{{ row.branch }}</td><td>{{ row.txnType }}</td><td>{{ row.docNo }}</td><td><span class="badge" [attr.data-s]="row.status">{{ row.status }}</span></td><td>{{ row.party }}</td><td>{{ row.sku }}</td><td>{{ row.item }}</td><td class="num">{{ row.net | weight }}</td><td class="num">{{ row.fine | weight }}</td><td class="num">{{ row.pkrDebit | money }}</td><td class="num">{{ row.pkrCredit | money }}</td><td>{{ row.enteredBy }}</td></tr>} @empty {<tr><td colspan="13" class="empty">No rows.</td></tr>}</tbody></table></div>
    <div class="pager"><span>{{ x.total }} record(s)</span><span class="grow"></span><button class="btn ghost sm" [disabled]="page()<=1" (click)="go(page()-1)">‹ Prev</button><span>Page {{ page() }}</span><button class="btn ghost sm" [disabled]="x.items.length < pageSize" (click)="go(page()+1)">Next ›</button></div>
  }
  @if (detail(); as d) { <div class="card"><h3>Drill-through: {{ selected()?.docNo }}</h3>
    <h4>Stock movements</h4><div class="tablewrap"><table class="grid"><thead><tr><th>When</th><th>Kind</th><th>From</th><th>To</th><th>Qty</th><th>Net g</th><th>Reason</th></tr></thead><tbody>@for (m of d.movements; track m.id) {<tr><td>{{ m.postedAtUtc | dt }}</td><td>{{ m.kind }}</td><td>{{ m.from }}</td><td>{{ m.to }}</td><td class="num">{{ m.quantity }}</td><td class="num">{{ m.netWeight | weight }}</td><td>{{ m.reason }}</td></tr>} @empty {<tr><td colspan="7" class="empty">None.</td></tr>}</tbody></table></div>
    <h4>Journal postings</h4>@for (j of d.journals; track j.number) {<p><b>{{ j.number }}</b> — {{ j.description }} ({{ j.entryDateUtc | dt }}){{ j.isReversal ? ' [reversal]' : '' }}</p><div class="tablewrap"><table class="grid"><thead><tr><th>Account</th><th>Debit</th><th>Credit</th></tr></thead><tbody>@for (l of j.lines; track $index) {<tr><td>{{ l.account }}</td><td class="num">{{ l.debit | money }}</td><td class="num">{{ l.credit | money }}</td></tr>}</tbody></table></div>}
  </div> }`,
})
export class TransactionRegister {
  private api = inject(Api);
  filters = signal<any>({}); page = signal(1); pageSize = 50; r = signal<any>(null); detail = signal<any>(null); selected = signal<any>(null);
  f: Field[] = [{ key: 'from', label: 'From', type: 'date' }, { key: 'to', label: 'To', type: 'date' }, { key: 'txnType', label: 'Type', type: 'select', options: ['Sale', 'SaleReturn', 'Purchase', 'PurchaseReceipt', 'SupplierReturn', 'OldGold', 'StockTransferOut', 'StockTransferIn', 'StockAdjustment', 'JobIssue', 'JobReceipt', 'JobReconcile', 'WorkerPayment', 'RepairIntake', 'RepairDelivery', 'Expense', 'CashReceipt', 'CashPayment', 'SupplierPayment', 'CustomerReceipt'].map(x => ({ value: x, label: x })) }, { key: 'sku', label: 'SKU' }, { key: 'search', label: 'Search' }];
  run(v: any) { this.filters.set(v); this.page.set(1); this.load(); }
  go(p: number) { this.page.set(p); this.load(); }
  load() { this.api.get('/reports/transactions', { ...this.filters(), page: this.page(), pageSize: this.pageSize }).subscribe(r => this.r.set(r)); }
  export(fmt: string) { this.api.download('/reports/transactions/export', { ...this.filters(), format: fmt }, `register.${fmt}`); }
  open(row: any) { this.selected.set(row); this.api.get(`/reports/transactions/${row.txnTypeCode}/${row.docId}`).subscribe(d => this.detail.set(d)); }
}
