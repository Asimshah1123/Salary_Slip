import { Component, inject, signal } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Api } from '../core/api';
import { Session } from '../core/session';
import { Toast } from '../core/toast';
import { DynamicForm, Field } from '../shared/form';
import { MoneyPipe, WeightPipe, DtPipe, NicePipe } from '../shared/pipes';
import { Dialog } from '../shared/dialog';
import { Gallery, ImageUploader } from '../shared/img';

@Component({
  selector: 'app-repair-new', imports: [DynamicForm],
  template: `<div class="pagehead"><h1>New repair intake</h1></div><div class="card"><app-form [fields]="f" submitLabel="Record intake" [busy]="busy()" (submitted)="save($event)" /></div>
  <p class="hint">After saving, upload intake photos and capture the customer's acknowledgement before moving to Inspection.</p>`,
})
export class RepairNew {
  private api = inject(Api); private router = inject(Router); private toast = inject(Toast);
  busy = signal(false);
  f: Field[] = [
    { key: 'customerId', label: 'Customer', type: 'select', lookup: 'customers', required: true }, { key: 'branchId', label: 'Branch', type: 'select', lookup: 'branches' }, { key: 'technicianId', label: 'Technician', type: 'select', lookup: 'employees' },
    { key: 'itemDescription', label: 'Item description', required: true, col: 2 }, { key: 'condition', label: 'Visible condition/damage', type: 'textarea', col: 2 }, { key: 'requestedWork', label: 'Requested work', type: 'textarea', required: true, col: 2 },
    { key: 'metalTypeId', label: 'Metal', type: 'select', lookup: 'metals' }, { key: 'purityId', label: 'Purity', type: 'select', lookup: 'purities' }, { key: 'grossWeight', label: 'Gross weight (g)', type: 'number', default: 0 }, { key: 'stoneWeight', label: 'Stone weight (g)', type: 'number', default: 0 },
    { key: 'stoneDetails', label: 'Stone details' }, { key: 'accessoriesReceived', label: 'Accessories received' }, { key: 'promisedDateUtc', label: 'Promised date', type: 'date' },
    { key: 'estimateAmount', label: 'Initial estimate (PKR)', type: 'number', default: 0 }, { key: 'advanceAmount', label: 'Advance collected', type: 'number', default: 0 }, { key: 'advanceMethodId', label: 'Advance method', type: 'select', lookup: 'payment-methods', showIf: v => v.advanceAmount > 0 },
    { key: 'acknowledgementName', label: 'Customer acknowledgement name', col: 2 }, { key: 'customerAcknowledged', label: 'Customer acknowledged condition & accessories', type: 'checkbox' },
  ];
  save(v: any) { this.busy.set(true); this.api.post('/repairs', v).subscribe({ next: (r: any) => { this.toast.ok('Intake recorded: ' + r.number); this.router.navigate(['/repairs', r.id]); }, error: () => this.busy.set(false) }); }
}

@Component({
  selector: 'app-repair-detail', imports: [MoneyPipe, WeightPipe, DtPipe, NicePipe, Dialog, DynamicForm, Gallery, ImageUploader],
  template: `@if (r(); as x) {
  <div class="pagehead"><div><h1>Repair {{ x.number }}</h1><div class="sub">{{ x.customer }} · {{ x.itemDescription }} · <span class="badge" [attr.data-s]="x.repairStatus">{{ x.repairStatus | nice }}</span>@if (x.overdue) { <span class="badge" data-s="Damaged">Overdue</span> }</div></div><span class="grow"></span>
    @if (x.repairStatus==='Received' && sess.can('Repairs.UpdateStatus')) { <button class="btn ghost" (click)="status('Inspection')">Move to Inspection</button> }
    @if (x.repairStatus==='Inspection' && sess.canAny('Repairs.Estimate','Repairs.UpdateStatus')) { <button class="btn ghost" (click)="dlg.set('estimate')">Prepare estimate</button> }
    @if (x.repairStatus==='EstimatePrepared') { @if (x.approvalRequired) { <button class="btn ghost" (click)="submitApproval()">Send for approval</button> } @else { <button class="btn ghost" (click)="dlg.set('approve')">Mark approved</button> } }
    @if (x.repairStatus==='AwaitingApproval' && sess.can('Repairs.Estimate.Approve')) { <button class="btn primary" (click)="dlg.set('approve')">Record decision</button> }
    @if (x.repairStatus==='Approved' && sess.can('Repairs.UpdateStatus')) { <button class="btn ghost" (click)="status('InRepair')">Start repair</button> }
    @if (x.repairStatus==='InRepair') { @if (sess.can('Repairs.UpdateStatus')) { <button class="btn ghost" (click)="dlg.set('qc')">Send to quality check</button> } <button class="btn ghost" (click)="dlg.set('part')">Add part/metal</button> }
    @if (x.repairStatus==='QualityCheck' && sess.can('Repairs.UpdateStatus')) { <button class="btn primary" (click)="dlg.set('ready')">Mark ready</button> }
    @if (x.repairStatus==='Ready' && sess.can('Repairs.Deliver')) { <button class="btn primary" (click)="dlg.set('deliver')">Deliver</button> }
  </div>
  <div class="grid2">
    <div class="card"><h3>Details</h3><dl class="kv"><dt>Condition</dt><dd>{{ x.condition }}</dd><dt>Requested work</dt><dd>{{ x.requestedWork }}</dd><dt>Metal</dt><dd>{{ x.metal }} {{ x.purity }}</dd><dt>Weight</dt><dd>{{ x.gross | weight }} g (final {{ x.finalGross | weight }} g)</dd><dt>Accessories</dt><dd>{{ x.accessories }}</dd><dt>Promised</dt><dd>{{ x.promisedDateUtc | dt:false }}</dd><dt>Technician</dt><dd>{{ x.technician }}</dd></dl></div>
    @if (x.isCustomerProperty !== undefined) { <div class="card"><h3>Money</h3><dl class="kv"><dt>Estimate</dt><dd>{{ x.estimate | money }}</dd><dt>Actual</dt><dd>{{ x.actual | money }}</dd><dt>Advance</dt><dd>{{ x.advance | money }}</dd><dt>Paid</dt><dd>{{ x.paid | money }}</dd><dt>Balance</dt><dd>{{ x.balance | money }}</dd></dl></div> }
  </div>
  @if (x.parts.length) { <div class="card"><h3>Parts & metal used</h3><table class="grid"><thead><tr><th>Description</th><th>Qty</th><th>Metal added</th><th>Metal removed</th><th>Charge</th></tr></thead><tbody>@for (p of x.parts; track p.id) {<tr><td>{{ p.description }}</td><td class="num">{{ p.quantity }}</td><td class="num">{{ p.metalAddedNet | weight }}</td><td class="num">{{ p.metalRemovedNet | weight }}</td><td class="num">{{ p.charge | money }}</td></tr>}</tbody></table></div> }
  <div class="card"><h3>Photos</h3><app-uploader ownerType="RepairTicket" [ownerId]="x.id" kind="Intake" label="Upload intake photo" (uploaded)="load()" /><app-uploader ownerType="RepairTicket" [ownerId]="x.id" kind="After" label="Upload after-repair photo" (uploaded)="load()" /><app-gallery ownerType="RepairTicket" [ownerId]="x.id" [canEdit]="sess.can('Repairs.UpdateStatus')" /></div>
  <div class="card"><h3>History</h3><ul class="timeline">@for (l of x.log; track $index) {<li>{{ l.atUtc | dt }} — {{ l.from | nice }} → {{ l.to | nice }} @if (l.work) { — {{ l.work }} }</li>}</ul></div>

  @if (dlg()==='estimate') { <app-dialog title="Prepare estimate" (closed)="dlg.set(null)"><app-form [fields]="[{key:'amount',label:'Amount',type:'number',required:true},{key:'description',label:'Description',type:'textarea'}]" submitLabel="Save" (submitted)="run('estimate',$event)" /></app-dialog> }
  @if (dlg()==='approve') { <app-dialog title="Customer decision on estimate" (closed)="dlg.set(null)"><app-form [fields]="approveFields" submitLabel="Record" (submitted)="approve($event)" /></app-dialog> }
  @if (dlg()==='qc') { <app-dialog title="Quality check" (closed)="dlg.set(null)"><app-form [fields]="[{key:'to',label:'',type:'select',default:'QualityCheck'},{key:'workPerformed',label:'Work performed',type:'textarea',required:true,col:3}]" submitLabel="Send" (submitted)="run('status',$event)" /></app-dialog> }
  @if (dlg()==='ready') { <app-dialog title="Mark ready" (closed)="dlg.set(null)"><app-form [fields]="[{key:'to',label:'',type:'select',default:'Ready'},{key:'finalGrossWeight',label:'Final gross weight (g)',type:'number',required:true},{key:'warrantyNote',label:'Warranty note'}]" submitLabel="Mark ready" (submitted)="run('status',$event)" /></app-dialog> }
  @if (dlg()==='part') { <app-dialog title="Add part / metal" (closed)="dlg.set(null)"><app-form [fields]="partFields" submitLabel="Add" (submitted)="run('parts',$event)" /></app-dialog> }
  @if (dlg()==='deliver') { <app-dialog title="Deliver" (closed)="dlg.set(null)"><app-form [fields]="deliverFields" submitLabel="Deliver" (submitted)="deliver($event)" /></app-dialog> }
  }`,
})
export class RepairDetail {
  private api = inject(Api); private route = inject(ActivatedRoute); private toast = inject(Toast); sess = inject(Session);
  id = +this.route.snapshot.params['id']; r = signal<any>(null); dlg = signal<string | null>(null);
  approveFields: Field[] = [{ key: 'approve', label: 'Decision', type: 'select', options: [{ value: true, label: 'Approved' }, { value: false, label: 'Rejected' }], default: true }, { key: 'approvedByCustomer', label: 'Approved by (customer name)', showIf: v => v.approve !== false }, { key: 'channel', label: 'Channel', type: 'select', options: [{ value: 'InPerson', label: 'In person' }, { value: 'Phone', label: 'Phone' }, { value: 'WhatsApp', label: 'WhatsApp' }], showIf: v => v.approve !== false }, { key: 'reason', label: 'Rejection reason', showIf: v => v.approve === false }];
  partFields: Field[] = [{ key: 'description', label: 'Description', required: true }, { key: 'metalTypeId', label: 'Metal', type: 'select', lookup: 'metals' }, { key: 'purityId', label: 'Purity', type: 'select', lookup: 'purities' }, { key: 'quantity', label: 'Qty', type: 'number', default: 1 }, { key: 'metalAddedNet', label: 'Metal added (g)', type: 'number', default: 0 }, { key: 'metalRemovedNet', label: 'Metal removed (g)', type: 'number', default: 0 }, { key: 'charge', label: 'Charge', type: 'number', default: 0 }];
  deliverFields: Field[] = [{ key: 'collectorName', label: 'Collector name', required: true }, { key: 'collectorIsCustomer', label: 'Collector is the customer', type: 'checkbox', default: true }, { key: 'collectorCnic', label: 'Collector CNIC', showIf: v => !v.collectorIsCustomer }, { key: 'allowCredit', label: 'Release on credit (needs override)', type: 'checkbox' }, { key: 'overrideReason', label: 'Override reason', showIf: v => v.allowCredit }, { key: 'payments', label: 'Payments', type: 'lines', fields: [{ key: 'paymentMethodId', label: 'Method', type: 'select', lookup: 'payment-methods' }, { key: 'amount', label: 'Amount', type: 'number' }] }];
  constructor() { this.load(); }
  load() { this.api.get(`/repairs/${this.id}`).subscribe(r => this.r.set(r)); }
  status(to: string) { this.api.patch(`/repairs/${this.id}/status`, { to }).subscribe({ next: () => { this.toast.ok('Updated'); this.load(); }, error: () => {} }); }
  submitApproval() { this.api.post(`/repairs/${this.id}/submit-approval`).subscribe(() => { this.toast.ok('Sent'); this.load(); }); }
  approve(v: any) { this.api.post(`/repairs/${this.id}/approve`, v).subscribe({ next: () => { this.toast.ok('Recorded'); this.dlg.set(null); this.load(); }, error: () => {} }); }
  run(seg: string, v: any) { const o = seg === 'status' ? this.api.patch(`/repairs/${this.id}/status`, v) : this.api.post(`/repairs/${this.id}/${seg}`, v); o.subscribe({ next: () => { this.toast.ok('Saved'); this.dlg.set(null); this.load(); }, error: () => {} }); }
  deliver(v: any) { this.api.post(`/repairs/${this.id}/deliver`, v).subscribe({ next: () => { this.toast.ok('Delivered'); this.dlg.set(null); this.load(); }, error: () => {} }); }
}
