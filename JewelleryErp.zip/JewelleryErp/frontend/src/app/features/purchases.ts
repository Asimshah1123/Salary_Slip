import { Component, inject, signal } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Api } from '../core/api';
import { Session } from '../core/session';
import { Toast } from '../core/toast';
import { DynamicForm, Field } from '../shared/form';
import { MoneyPipe, WeightPipe, DtPipe } from '../shared/pipes';
import { Dialog } from '../shared/dialog';

@Component({
  selector: 'app-purchase-new', imports: [DynamicForm],
  template: `<div class="pagehead"><h1>New purchase</h1></div><div class="card"><app-form [fields]="f" submitLabel="Save purchase" [busy]="busy()" (submitted)="save($event)" /></div>`,
})
export class PurchaseNew {
  private api = inject(Api); private router = inject(Router); private toast = inject(Toast);
  busy = signal(false);
  f: Field[] = [
    { key: 'supplierId', label: 'Supplier', type: 'select', lookup: 'suppliers', required: true }, { key: 'branchId', label: 'Branch', type: 'select', lookup: 'branches' },
    { key: 'supplierInvoiceNo', label: 'Supplier invoice number', required: true }, { key: 'dateUtc', label: 'Date', type: 'date' }, { key: 'postNow', label: 'Post now', type: 'checkbox', default: true },
    { key: 'lines', label: 'Lines', type: 'lines', required: true, col: 3, fields: [
      { key: 'productId', label: 'Existing item (blank = new)', type: 'select', lookup: 'products' }, { key: 'description', label: 'Description' }, { key: 'metalTypeId', label: 'Metal', type: 'select', lookup: 'metals' }, { key: 'purityId', label: 'Purity', type: 'select', lookup: 'purities' },
      { key: 'quantity', label: 'Qty', type: 'number', default: 1 }, { key: 'grossWeight', label: 'Gross g', type: 'number' }, { key: 'stoneWeight', label: 'Stone g', type: 'number', default: 0 }, { key: 'rate', label: 'Rate (blank = card)', type: 'number' },
      { key: 'makingCharges', label: 'Making', type: 'number', default: 0 }, { key: 'stoneValue', label: 'Stone value', type: 'number', default: 0 }, { key: 'taxAmount', label: 'Tax', type: 'number', default: 0 },
    ] },
    { key: 'payments', label: 'Payments made now', type: 'lines', col: 3, fields: [{ key: 'paymentMethodId', label: 'Method', type: 'select', lookup: 'payment-methods' }, { key: 'accountId', label: 'Account', type: 'select', lookup: 'cash-bank-accounts' }, { key: 'amount', label: 'Amount', type: 'number' }] },
    { key: 'notes', label: 'Notes', type: 'textarea', col: 3 },
  ];
  save(v: any) { this.busy.set(true); this.api.post('/purchases', v).subscribe({ next: (r: any) => { this.toast.ok('Purchase saved'); this.router.navigate(['/purchases', r.id]); }, error: () => this.busy.set(false) }); }
}

@Component({
  selector: 'app-purchase-detail', imports: [MoneyPipe, WeightPipe, DtPipe, Dialog, DynamicForm],
  template: `@if (p(); as x) {
  <div class="pagehead"><div><h1>Purchase {{ x.number }}</h1><div class="sub">{{ x.dateUtc | dt }} · {{ x.supplier }} · Supplier inv. {{ x.supplierInvoiceNo }} <span class="badge" [attr.data-s]="x.status">{{ x.status }}</span></div></div><span class="grow"></span>
    @if (x.status==='Draft' && sess.can('Purchases.Post')) { <button class="btn primary" (click)="post()">Post</button> }
    @if (!x.received && (x.status==='Posted'||x.status==='PartiallyPaid') && sess.can('Purchases.Receive')) { <button class="btn primary" (click)="showReceive.set(true)">Receive stock</button> }
    @if (x.received && sess.can('Purchases.Return')) { <button class="btn ghost" (click)="showReturn.set(true)">Supplier return</button> }
  </div>
  <div class="card"><table class="grid"><thead><tr><th>SKU</th><th>Description</th><th>Purity</th><th>Gross</th><th>Net</th><th>Rate</th><th>Total</th><th>Received net</th><th>Variance reason</th></tr></thead>
    <tbody>@for (l of x.lines; track l.id) {<tr><td>{{ l.sku }}</td><td>{{ l.description }}</td><td>{{ l.purity }}</td><td class="num">{{ l.gross | weight }}</td><td class="num">{{ l.net | weight }}</td><td class="num">{{ l.rate | money }}</td><td class="num">{{ l.lineTotal | money }}</td><td class="num">{{ l.receivedNet | weight }}</td><td>{{ l.varianceReason }}</td></tr>}</tbody></table></div>
  <div class="totals"><span>Total</span><b class="num">{{ x.total | money }}</b><span>Paid</span><b class="num">{{ x.paid | money }}</b><span>Due</span><b class="num">{{ x.due | money }}</b></div>
  @if (showReceive()) { <app-dialog title="Receive stock" [width]="820" (closed)="showReceive.set(false)"><app-form [fields]="receiveFields(x)" submitLabel="Confirm receipt" (submitted)="receive($event)" /></app-dialog> }
  @if (showReturn()) { <app-dialog title="Supplier return" (closed)="showReturn.set(false)"><app-form [fields]="returnFields(x)" submitLabel="Submit return" (submitted)="doReturn($event)" /></app-dialog> }
  }`,
})
export class PurchaseDetail {
  private api = inject(Api); private route = inject(ActivatedRoute); private toast = inject(Toast); sess = inject(Session);
  id = +this.route.snapshot.params['id']; p = signal<any>(null); showReceive = signal(false); showReturn = signal(false);
  constructor() { this.load(); }
  load() { this.api.get(`/purchases/${this.id}`).subscribe(r => this.p.set(r)); }
  post() { this.api.post(`/purchases/${this.id}/post`).subscribe(() => { this.toast.ok('Posted'); this.load(); }); }
  receiveFields(x: any): Field[] { return [{ key: 'lines', label: 'Measured weights', type: 'lines', required: true, fields: [{ key: 'lineId', label: 'Line', type: 'select', options: x.lines.filter((l: any) => !l.receivedNet).map((l: any) => ({ value: l.id, label: `${l.sku || l.description} (${l.net} g invoiced)` })) }, { key: 'receivedGrossWeight', label: 'Gross g', type: 'number' }, { key: 'receivedStoneWeight', label: 'Stone g', type: 'number', default: 0 }, { key: 'varianceReason', label: 'Variance reason (if any)' }] }]; }
  receive(v: any) { this.api.post(`/purchases/${this.id}/receive`, v.lines).subscribe({ next: () => { this.toast.ok('Received'); this.showReceive.set(false); this.load(); }, error: () => {} }); }
  returnFields(x: any): Field[] { return [{ key: 'reason', label: 'Reason', required: true, col: 2 }, { key: 'lines', label: 'Lines', type: 'lines', required: true, fields: [{ key: 'purchaseInvoiceLineId', label: 'Line', type: 'select', options: x.lines.map((l: any) => ({ value: l.id, label: l.sku || l.description })) }, { key: 'quantity', label: 'Qty', type: 'number', default: 1 }] }]; }
  doReturn(v: any) { this.api.post(`/purchases/${this.id}/supplier-return`, v).subscribe({ next: () => { this.toast.ok('Return recorded'); this.showReturn.set(false); this.load(); }, error: () => {} }); }
}
