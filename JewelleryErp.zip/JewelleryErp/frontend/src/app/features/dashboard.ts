import { Component, inject, signal } from '@angular/core';
import { RouterLink } from '@angular/router';
import { Api } from '../core/api';
import { Session } from '../core/session';
import { MoneyPipe, WeightPipe, NicePipe } from '../shared/pipes';
import { Bars, Line, Donut } from '../shared/charts';
import { DynamicForm, Field } from '../shared/form';

@Component({
  selector: 'app-dashboard', imports: [RouterLink, MoneyPipe, WeightPipe, NicePipe, Bars, Line, Donut, DynamicForm],
  template: `
  <div class="pagehead"><div><h1>Dashboard</h1><div class="sub">{{ d()?.scope }}</div></div><span class="grow"></span>
    <app-form [fields]="f" [value]="range()" submitLabel="Apply" (submitted)="apply($event)" /></div>

  @if (d(); as x) {
    @if (x.alerts.length) { <div class="card">@for (a of x.alerts; track a.type) { <div class="alert" [class]="a.severity"><a [routerLink]="a.route">{{ a.message }}</a></div> } </div> }

    <div class="kpis">@for (k of x.kpis; track k.key) { <div class="kpi"><div class="l">{{ k.label }}</div><div class="v">{{ fmt(k) }}</div>@if (k.hint) {<small class="hint">{{ k.hint }}</small>}</div> }</div>

    <div class="grid2">
      @if (x.charts.salesTrend) { <div class="card"><h3>Sales trend</h3><app-line [data]="pts(x.charts.salesTrend)" /></div> }
      @if (x.charts.categoryMix) { <div class="card"><h3>Category mix</h3><app-donut [data]="pts(x.charts.categoryMix)" /></div> }
      @if (x.charts.karatMix) { <div class="card"><h3>Karat mix</h3><app-bars [data]="pts(x.charts.karatMix)" /></div> }
      @if (x.charts.paymentMethods) { <div class="card"><h3>Payment methods</h3><app-donut [data]="pts(x.charts.paymentMethods)" /></div> }
      @if (x.charts.topProducts) { <div class="card"><h3>Top products</h3><app-bars [data]="pts(x.charts.topProducts)" /></div> }
      @if (x.charts.branchPerformance) { <div class="card"><h3>Branch performance</h3><app-bars [data]="pts(x.charts.branchPerformance)" /></div> }
      @if (x.charts.salesmanPerformance) { <div class="card"><h3>Salesman performance</h3><app-bars [data]="pts(x.charts.salesmanPerformance)" /></div> }
      @if (x.charts.expenseDistribution) { <div class="card"><h3>Expense distribution</h3><app-donut [data]="pts(x.charts.expenseDistribution)" /></div> }
      @if (repairStatuses().length) { <div class="card"><h3>Repairs by status</h3><app-bars [data]="repairStatuses()" /></div> }
    </div>
  } @else { <p class="muted">Loading…</p> }`,
})
export class Dashboard {
  private api = inject(Api); s = inject(Session);
  d = signal<any>(null);
  range = signal<any>({});
  f: Field[] = [{ key: 'from', label: 'From', type: 'date' }, { key: 'to', label: 'To', type: 'date' }];
  constructor() { this.load(); }
  apply(v: any) { this.range.set(v); this.load(); }
  load() { this.api.get('/reports/dashboard', this.range()).subscribe(r => this.d.set(r)); }
  fmt(k: any) { return k.format === 'money' ? new Intl.NumberFormat('en-PK', { maximumFractionDigits: 0 }).format(k.value ?? 0) + ' PKR' : k.format === 'weight' ? (k.value ?? 0).toFixed(3) + ' g' : (k.value ?? 0).toLocaleString(); }
  pts(s: any[]) { return s.map(x => ({ label: x.label, value: x.value })); }
  repairStatuses() { const r = this.d()?.repairsByStatus ?? {}; return Object.entries(r).map(([k, v]) => ({ label: k.replace(/([a-z])([A-Z])/g, '$1 $2'), value: v as number })); }
}
