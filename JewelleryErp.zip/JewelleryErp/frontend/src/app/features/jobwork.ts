import { Component, inject, signal } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Api } from '../core/api';
import { Session } from '../core/session';
import { Toast } from '../core/toast';
import { DynamicForm, Field } from '../shared/form';
import { MoneyPipe, WeightPipe, DtPipe, NicePipe } from '../shared/pipes';
import { Dialog } from '../shared/dialog';
import { Gallery, ImageUploader } from '../shared/img';

@Component({
  selector: 'app-job-detail', imports: [MoneyPipe, WeightPipe, DtPipe, NicePipe, Dialog, DynamicForm, Gallery, ImageUploader],
  template: `@if (j(); as x) {
  <div class="pagehead"><div><h1>Job {{ x.number }}</h1><div class="sub">{{ x.worker }} · {{ x.mode | nice }} · <span class="badge" [attr.data-s]="x.jobStatus">{{ x.jobStatus | nice }}</span>@if (x.overdue) { <span class="badge" data-s="Damaged">Overdue</span> }</div></div><span class="grow"></span>
    @if (x.jobStatus==='Draft' && sess.can('JobWork.Approve')) { <button class="btn primary" (click)="act('approve')">Approve</button> }
    @if (x.mode==='OnIssue' && ['Approved','MaterialIssued','InProgress','PartiallyReceived'].includes(x.jobStatus) && sess.can('JobWork.MaterialIssue')) { <button class="btn ghost" (click)="dlg.set('issue')">Issue material</button> }
    @if (['Approved','MaterialIssued','InProgress','PartiallyReceived'].includes(x.jobStatus) && sess.can('JobWork.Receive')) { <button class="btn ghost" (click)="dlg.set('receive')">Record receipt</button> }
    @if (x.jobStatus==='Completed' && sess.can('JobWork.Reconcile')) { <button class="btn primary" (click)="dlg.set('reconcile')">Reconcile</button> }
    @if (x.jobStatus==='Reconciled' && sess.can('JobWork.Close')) { <button class="btn primary" (click)="act('close')">Close</button> }
    @if (sess.can('JobWork.UpdateStage') && ['Approved','MaterialIssued'].includes(x.jobStatus)) { <button class="btn ghost" (click)="stage('InProgress')">Mark In Progress</button> }
  </div>
  <div class="grid2">
    <div class="card"><h3>Specification</h3><p>{{ x.designSpec }}</p><dl class="kv"><dt>Due</dt><dd>{{ x.dueDateUtc | dt:false }}</dd><dt>Pieces</dt><dd>{{ x.targetPieces }}</dd><dt>Making</dt><dd>{{ x.makingType }} {{ x.makingValue }}</dd><dt>Wastage allowance</dt><dd>{{ x.wastageAllowancePercent }}%</dd><dt>Tolerance</dt><dd>{{ x.toleranceFine | weight }} g</dd><dt>Material status</dt><dd>{{ x.materialStatus }}</dd></dl></div>
    <div class="card"><h3>Weight reconciliation</h3><dl class="kv"><dt>Issued</dt><dd>{{ x.issuedFine | weight }} g</dd><dt>Additional input</dt><dd>{{ x.additionalInputFine | weight }} g</dd><dt>Output</dt><dd>{{ x.outputFine | weight }} g</dd><dt>Returned</dt><dd>{{ x.returnedFine | weight }} g</dd><dt>Scrap</dt><dd>{{ x.scrapFine | weight }} g</dd><dt>Approved loss</dt><dd>{{ x.approvedLossFine | weight }} g</dd><dt>Variance</dt><dd>{{ x.reconciliation.variance | weight }} g — {{ x.reconciliation.summary }}</dd></dl>
      @if (x.custody.length) { <h4>In custody</h4>@for (c of x.custody; track $index) { <p>{{ c.metal }} {{ c.purity }} — {{ c.net | weight }} g</p> } }</div>
  </div>
  <div class="grid2"><div class="card"><h3>Issues</h3>@for (i of x.issues; track i.id) {<p>{{ i.number }} ({{ i.dateUtc | dt }}) — {{ i.summary }} — {{ i.fine | weight }} g</p>} @empty {<p class="muted">None.</p>}</div>
    <div class="card"><h3>Receipts</h3>@for (r of x.receipts; track r.id) {<p>{{ r.number }} ({{ r.dateUtc | dt }}) — {{ r.summary }} — making {{ r.amount | money }}</p>} @empty {<p class="muted">None.</p>}</div></div>
  <div class="card"><h3>Making charges</h3><dl class="kv"><dt>Accrued</dt><dd>{{ x.makingAccrued | money }}</dd><dt>Paid</dt><dd>{{ x.makingPaid | money }}</dd></dl>
    @if (sess.canAny('JobWork.Pay','Finance.Payment.Post')) { <button class="btn ghost sm" (click)="dlg.set('pay')">Pay worker</button> }</div>
  <div class="card"><h3>Reference images</h3><app-uploader ownerType="JobCard" [ownerId]="x.id" (uploaded)="load()" /><app-gallery ownerType="JobCard" [ownerId]="x.id" [canEdit]="true" /></div>
  <div class="card"><h3>Stage history</h3><ul class="timeline">@for (s of x.stages; track $index) {<li>{{ s.at | dt }} — {{ s.from | nice }} → {{ s.to | nice }} @if (s.note) { — {{ s.note }} }</li>}</ul></div>

  @if (dlg()==='issue') { <app-dialog title="Issue material" (closed)="dlg.set(null)"><app-form [fields]="issueFields" submitLabel="Issue" (submitted)="run('issue-material', $event)" /></app-dialog> }
  @if (dlg()==='receive') { <app-dialog title="Record receipt" [width]="820" (closed)="dlg.set(null)"><app-form [fields]="receiveFields" submitLabel="Record" (submitted)="run('receipts', $event)" /></app-dialog> }
  @if (dlg()==='reconcile') { <app-dialog title="Reconcile" (closed)="dlg.set(null)"><p>Variance: {{ x.reconciliation.variance | weight }} g — {{ x.reconciliation.summary }}</p><app-form [fields]="reconcileFields" submitLabel="Reconcile" (submitted)="run('reconcile', $event)" /></app-dialog> }
  @if (dlg()==='pay') { <app-dialog title="Pay worker" (closed)="dlg.set(null)"><app-form [fields]="payFields" submitLabel="Pay" (submitted)="pay($event)" /></app-dialog> }
  }`,
})
export class JobDetail {
  private api = inject(Api); private route = inject(ActivatedRoute); private toast = inject(Toast); sess = inject(Session);
  id = +this.route.snapshot.params['id']; j = signal<any>(null); dlg = signal<string | null>(null);
  issueFields: Field[] = [{ key: 'acknowledgedBy', label: 'Acknowledged by' }, { key: 'lines', label: 'Metal to issue', type: 'lines', required: true, fields: [{ key: 'metalTypeId', label: 'Metal', type: 'select', lookup: 'metals' }, { key: 'purityId', label: 'Purity', type: 'select', lookup: 'purities' }, { key: 'grossWeight', label: 'Gross g', type: 'number' }, { key: 'netWeight', label: 'Net g', type: 'number' }, { key: 'isAdditional', label: 'Additional', type: 'checkbox' }] }];
  receiveFields: Field[] = [{ key: 'isFinal', label: 'This is the final receipt', type: 'checkbox' }, { key: 'makingChargeOverride', label: 'Making charge override (needs Variance.Approve)', type: 'number' },
    { key: 'inputMaterial', label: 'Worker/customer-supplied metal (planning jobs)', type: 'lines', fields: [{ key: 'metalTypeId', label: 'Metal', type: 'select', lookup: 'metals' }, { key: 'purityId', label: 'Purity', type: 'select', lookup: 'purities' }, { key: 'netWeight', label: 'Net g', type: 'number' }] },
    { key: 'lines', label: 'Output / returned / scrap', type: 'lines', required: true, fields: [{ key: 'kind', label: 'Kind', type: 'select', options: [{ value: 'Output', label: 'Output' }, { value: 'ReturnedMetal', label: 'Returned metal' }, { value: 'Scrap', label: 'Scrap' }] }, { key: 'description', label: 'Description' }, { key: 'metalTypeId', label: 'Metal', type: 'select', lookup: 'metals' }, { key: 'purityId', label: 'Purity', type: 'select', lookup: 'purities' }, { key: 'quantity', label: 'Qty', type: 'number', default: 1 }, { key: 'grossWeight', label: 'Gross g', type: 'number' }, { key: 'stoneWeight', label: 'Stone g', type: 'number', default: 0 }, { key: 'stoneValue', label: 'Stone value', type: 'number', default: 0 }] }];
  reconcileFields: Field[] = [{ key: 'approvedLossFine', label: 'Approved loss (fine g)', type: 'number', default: 0 }, { key: 'reason', label: 'Reason (required for any variance/loss)', col: 3 }];
  payFields: Field[] = [{ key: 'paymentMethodId', label: 'Method', type: 'select', lookup: 'payment-methods', required: true }, { key: 'accountId', label: 'Account', type: 'select', lookup: 'cash-bank-accounts' }, { key: 'amount', label: 'Amount', type: 'number', required: true }, { key: 'reference', label: 'Reference' }];
  constructor() { this.load(); }
  load() { this.api.get(`/job-cards/${this.id}`).subscribe(r => this.j.set(r)); }
  act(a: string) { this.api.post(`/job-cards/${this.id}/${a}`).subscribe(() => { this.toast.ok('Done'); this.load(); }); }
  stage(to: string) { this.api.post(`/job-cards/${this.id}/stage`, { to }).subscribe(() => { this.toast.ok('Updated'); this.load(); }); }
  run(seg: string, v: any) { this.api.post(`/job-cards/${this.id}/${seg}`, v).subscribe({ next: () => { this.toast.ok('Posted'); this.dlg.set(null); this.load(); }, error: () => {} }); }
  pay(v: any) { this.api.post('/worker-payments', { ...v, workerId: this.j().workerId, jobCardId: this.id }).subscribe({ next: () => { this.toast.ok('Paid'); this.dlg.set(null); this.load(); }, error: () => {} }); }
}
