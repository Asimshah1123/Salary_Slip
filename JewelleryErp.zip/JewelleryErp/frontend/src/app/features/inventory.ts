import { Component, inject, signal } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs';
import { Api } from '../core/api';
import { Session } from '../core/session';
import { Toast } from '../core/toast';
import { DataTable, Col } from '../shared/table';
import { DynamicForm, Field } from '../shared/form';
import { MoneyPipe, WeightPipe, DtPipe } from '../shared/pipes';

@Component({
  selector: 'app-stock', imports: [DataTable],
  template: `<div class="pagehead"><h1>Stock</h1><div class="sub">Excludes sold items; in-transit stock is shown once at the destination.</div></div><app-table [columns]="cols" [loader]="loader" [refresh]="status()">
  <ng-template #actions><select (change)="status.set($any($event.target).value || null)" aria-label="Status filter"><option value="">All statuses</option><option>Available</option><option>Reserved</option><option>InTransit</option><option>WithWorker</option><option>InInspection</option><option>RepairIntake</option><option>Damaged</option><option>Quarantine</option></select></ng-template></app-table>`,
})
export class Stock {
  private api = inject(Api);
  status = signal<string | null>(null);
  cols: Col[] = [{ key: 'branch', label: 'Branch' }, { key: 'location', label: 'Location' }, { key: 'sku', label: 'SKU' }, { key: 'name', label: 'Item' }, { key: 'metal', label: 'Metal' }, { key: 'purity', label: 'Purity' }, { key: 'status', label: 'Status', type: 'status' }, { key: 'ownership', label: 'Owner' }, { key: 'qty', label: 'Qty', type: 'number' }, { key: 'net', label: 'Net g', type: 'weight' }, { key: 'fine', label: 'Fine g', type: 'weight' }, { key: 'costValue', label: 'Cost', type: 'money' }];
  loader = (q: any): Observable<any> => this.api.get('/inventory/stock', { ...q, status: this.status() });
}

@Component({
  selector: 'app-transfer-detail', imports: [WeightPipe, DynamicForm],
  template: `@if (t(); as x) { <div class="pagehead"><div><h1>Transfer {{ x.number }}</h1><div class="sub">{{ x.origin }} → {{ x.destination }} <span class="badge" [attr.data-s]="x.transferStatus">{{ x.transferStatus }}</span></div></div><span class="grow"></span>
  @if (x.transferStatus==='Draft' && sess.can('Inventory.Transfer')) { <button class="btn primary" (click)="dispatch()">Dispatch</button> }
  @if ((x.transferStatus==='InTransit'||x.transferStatus==='PartiallyReceived') && sess.can('Inventory.Transfer.Receive')) { <button class="btn primary" (click)="show.set(true)">Receive</button> }</div>
  <div class="card"><table class="grid"><thead><tr><th>Item</th><th>Purity</th><th>Qty</th><th>Net</th><th>Received qty</th><th>Received net</th></tr></thead><tbody>@for (l of x.lines; track l.id) {<tr><td>{{ l.sku || l.item }}</td><td>{{ l.purity }}</td><td class="num">{{ l.qty }}</td><td class="num">{{ l.net | weight }}</td><td class="num">{{ l.receivedQty }}</td><td class="num">{{ l.receivedNet | weight }}</td></tr>}</tbody></table></div>
  @if (show()) { <div class="card"><h3>Receive</h3><app-form [fields]="f(x)" submitLabel="Confirm receipt" (submitted)="receive($event)" /></div> } }`,
})
export class TransferDetail {
  private api = inject(Api); private route = inject(ActivatedRoute); private toast = inject(Toast); sess = inject(Session);
  id = +this.route.snapshot.params['id']; t = signal<any>(null); show = signal(false);
  constructor() { this.load(); }
  load() { this.api.get(`/inventory/transfers/${this.id}`).subscribe(r => this.t.set(r)); }
  dispatch() { this.api.post(`/inventory/transfers/${this.id}/dispatch`).subscribe(() => { this.toast.ok('Dispatched'); this.load(); }); }
  f(x: any): Field[] { return [{ key: 'varianceReason', label: 'Variance reason (if any)' }, { key: 'closeWithShortage', label: 'Close with shortage', type: 'checkbox' }, { key: 'lines', label: 'Received amounts', type: 'lines', fields: [{ key: 'lineId', label: 'Line', type: 'select', options: x.lines.map((l: any) => ({ value: l.id, label: l.sku || l.item })) }, { key: 'receivedQuantity', label: 'Qty', type: 'number' }, { key: 'receivedGrossWeight', label: 'Gross g', type: 'number' }, { key: 'receivedNetWeight', label: 'Net g', type: 'number' }] }]; }
  receive(v: any) { this.api.post(`/inventory/transfers/${this.id}/receive`, v).subscribe({ next: () => { this.toast.ok('Receipt posted'); this.show.set(false); this.load(); }, error: () => {} }); }
}

@Component({
  selector: 'app-count-detail', imports: [WeightPipe],
  template: `@if (c(); as x) { <div class="pagehead"><div><h1>Stock count {{ x.number }}</h1><span class="badge" [attr.data-s]="x.status">{{ x.status }}</span></div><span class="grow"></span>
    @if (x.status==='Draft') { <button class="btn ghost" (click)="save()">Save counts</button><button class="btn primary" (click)="submit()">Submit for approval</button> }
    @if (x.status==='PendingApproval' && sess.can('Inventory.Count.Approve')) { <button class="btn primary" (click)="decide(true)">Approve</button><button class="btn danger" (click)="decide(false)">Reject</button> }</div>
  <div class="card"><table class="grid"><thead><tr><th>Item</th><th>Purity</th><th>System qty</th><th>Counted qty</th><th>System net</th><th>Counted net</th><th>Note</th></tr></thead>
  <tbody>@for (l of x.lines; track l.id; let i = $index) {<tr><td>{{ l.sku || l.item }}</td><td>{{ l.purity }}</td><td class="num">{{ l.systemQty }}</td><td><input type="number" style="width:80px" [value]="entries[l.id]?.countedQuantity ?? l.countedQty ?? ''" [disabled]="x.status!=='Draft'" (change)="set(l.id,'countedQuantity',$any($event.target).value)" /></td><td class="num">{{ l.systemNet | weight }}</td><td><input type="number" style="width:90px" [value]="entries[l.id]?.countedNetWeight ?? l.countedNet ?? ''" [disabled]="x.status!=='Draft'" (change)="set(l.id,'countedNetWeight',$any($event.target).value)" /></td><td><input [value]="entries[l.id]?.note ?? l.note ?? ''" [disabled]="x.status!=='Draft'" (change)="set(l.id,'note',$any($event.target).value)" /></td></tr>}</tbody></table></div> }`,
})
export class CountDetail {
  private api = inject(Api); private route = inject(ActivatedRoute); private toast = inject(Toast); sess = inject(Session);
  id = +this.route.snapshot.params['id']; c = signal<any>(null); entries: Record<number, any> = {};
  constructor() { this.load(); }
  load() { this.api.get(`/inventory/counts/${this.id}`).subscribe(r => this.c.set(r)); }
  set(id: number, k: string, v: any) { this.entries[id] = { ...this.entries[id], lineId: id, [k]: k === 'note' ? v : v === '' ? null : +v }; }
  save() { this.api.put(`/inventory/counts/${this.id}/entries`, Object.values(this.entries)).subscribe({ next: () => { this.toast.ok('Saved'); this.load(); }, error: () => {} }); }
  submit() { this.save(); this.api.post(`/inventory/counts/${this.id}/submit`).subscribe({ next: () => { this.toast.ok('Submitted'); this.load(); }, error: () => {} }); }
  decide(approve: boolean) { const reason = approve ? undefined : prompt('Reason for rejecting:') ?? undefined; this.api.post(`/inventory/counts/${this.id}/decision`, { approve, reason }).subscribe(() => { this.toast.ok(approve ? 'Approved' : 'Rejected'); this.load(); }); }
}
