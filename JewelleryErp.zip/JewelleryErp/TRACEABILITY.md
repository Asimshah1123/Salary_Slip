# Requirements → code map

SRS section references are to `Pakistani_Jewellery_Retail_ERP_SRS_Technical_Documentation_v1_1_Branch_Role_Based.docx`. "Not verified" items are listed once in the README and not repeated for every row below.

| SRS section | Requirement area | Backend | Frontend |
|---|---|---|---|
| 1.2 | In-scope modules | `Erp.Infrastructure/Services/*.cs` (one service family per module) | `features/*` |
| 2.1 | Weight/unit rules, unapproved-unit block | `Erp.Domain/Calc/Money.cs` (`WeightCalc`), seeded `UnitConversion` rows | `features/screens.ts` (`units` screen, "Approve conversion" action) |
| 2.2 | Pricing model (a)-(d) | `Erp.Domain/Calc/Pricing.cs` | `features/pos.ts`, `features/products.ts` (pricing fields) |
| 2.3 | Gold rate management, snapshot, override | `Services/Masters.cs` (`GoldRateService`), `Services/Core.cs` (`RateService`) | `features/products.ts` (`GoldRates`) |
| 2.4 | Old gold / buy-back | `Erp.Domain/Calc/Reconciliation.cs` (`OldGold`), `Services/Sales.cs` | `features/sales.ts` (`OldGold`) |
| 3.1 | Login, roles, permissions, lockout, JWT | `Services/Auth.cs`, `Erp.Domain/Permissions.cs`, `Api/Infrastructure/Middleware.cs` | `features/auth.ts`, `core/session.ts` |
| 3.2 | Product & item master, image gallery | `Services/Products.cs` | `features/products.ts` |
| 3.3 / 3.4 | Customers / suppliers | `Services/Masters.cs` (`MasterRegistry`) | `features/screens.ts` (customers/suppliers) |
| 3.5 | Employees, salesmen, commission | `Services/Masters.cs`, `Services/Sales.cs` (accrual), `Services/Finance.cs` (approve/pay) | `features/screens.ts`, `features/finance.ts` (`Commission`) |
| 3.6 | Purchase & supplier returns | `Services/Purchasing.cs` | `features/purchases.ts` |
| 3.7 | Sales / POS / invoices | `Services/Sales.cs` | `features/pos.ts`, `features/sales.ts` |
| 3.8 | Inventory & stock control | `Services/Inventory.cs`, `Services/Core.cs` (`PostingEngine`) | `features/inventory.ts` |
| 3.9 | Karigar job work | `Services/JobWork.cs`, `Erp.Domain/Calc/JournalAndFlows.cs` (`JobFlow`) | `features/jobwork.ts` |
| 3.10 | Customer repairs | `Services/Repairs.cs`, `JournalAndFlows.cs` (`RepairFlow`) | `features/repairs.ts` |
| 3.11 / 3.12 | Expenses, cash/bank, accounting | `Services/Finance.cs` | `features/screens.ts` (expenses/vouchers), `features/finance.ts` (register) |
| 3.13 | Dashboard & alerts | `Services/Reports.cs` (`Dashboard`, `Alerts`) | `features/dashboard.ts` |
| 4 / 5 | Forms/screens inventory, wireframes | one Angular feature or `screens.ts` entry per row | `features/*` |
| 6.1–6.4 | Worker workflows, stock-posting mode | `Services/JobWork.cs`, `JobStatus`/`StockPostingMode` enums | `features/jobwork.ts` |
| 6.5 | Weight reconciliation | `Erp.Domain/Calc/Reconciliation.cs` | `features/jobwork.ts` (reconcile dialog) |
| 7 / 7.1 | Reports catalogue, transaction register | `Services/Reports.cs` (`Catalogue`, `Register`) | `features/reports.ts` |
| 8 / 8.1 | Database design, key data rules | `Erp.Domain/Entities/*.cs`, `Erp.Infrastructure/Data/ErpDbContext.cs` | — |
| 9 / 9.1 | API design, idempotency, concurrency | `Erp.Api/Controllers/*.cs`, `Idempotency-Key` handling in `PostingEngine.InTransaction` | `core/interceptors.ts` (auto idempotency key) |
| 10 | Security & JWT | `Services/Auth.cs`, `Api/Program.cs`, `Api/Infrastructure/Middleware.cs` | `core/session.ts` (token never in localStorage) |
| 11 | Image upload & gallery | `Services/Products.cs` (`FileService`), `Infrastructure/Files/*.cs` | `shared/img.ts` |
| 12 | Non-functional (backup, observability) | `Services/Admin.cs` (`BackupService`), `CorrelationMiddleware` | `features/admin.ts` (`Settings`) |
| 13 | Acceptance criteria | covered by `tools/Erp.SelfTest` at the unit level; **not run end-to-end** | — |
| 14 | Delivery phases | this codebase delivers all phases at once, pre-UAT | — |
| 15 | Open decisions | left configurable via `Services/Core.cs` (`SettingsService`) and `Services/Admin.cs` (`Settings`, unit approval) — **not pre-decided** | `features/admin.ts` (`Settings`) |
| 18 | Multi-branch | `ErpDbContext` global query filters, `UserContext.ResolveScope`/`PostingBranch` | `features/shell.ts` (branch selector) |
| 19 / 20 | RBAC, approval limits | `Erp.Domain/Permissions.cs` (`RoleTemplates`), `Services/Core.cs` (`ApprovalService`) | `features/admin.ts` (`Roles`), `features/screens.ts` (`approvals`) |
| 21 | DB/API/UI changes for branch+roles | as above, plus `Api/Infrastructure/Middleware.cs` (`UserContextMiddleware`) | `core/session.ts`, `core/guards.ts` |
| 22 | Branch/role UAT | not run — see README | — |
| 23 | Revised scope statement | this document | — |
