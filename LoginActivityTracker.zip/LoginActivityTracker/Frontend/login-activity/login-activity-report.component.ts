import { Component, OnInit } from '@angular/core';
import { LoginActivityService } from './login-activity.service';
import { LoginActivityLog } from './login-activity.model';

@Component({
  selector: 'app-login-activity-report',
  templateUrl: './login-activity-report.component.html',
  styleUrls: ['./login-activity-report.component.css']
})
export class LoginActivityReportComponent implements OnInit {
  activities: LoginActivityLog[] = [];
  totalCount = 0;
  page = 1;
  pageSize = 20;
  isLoading = false;

  fromDate = '';
  toDate = '';
  userNameFilter = '';

  constructor(private loginActivityService: LoginActivityService) {}

  ngOnInit(): void {
    this.loadData();
  }

  loadData(): void {
    this.isLoading = true;
    this.loginActivityService
      .getLoginActivities(
        this.fromDate || undefined,
        this.toDate || undefined,
        this.userNameFilter || undefined,
        this.page,
        this.pageSize
      )
      .subscribe(
        (result) => {
          this.activities = result.items;
          this.totalCount = result.totalCount;
          this.isLoading = false;
        },
        () => {
          this.isLoading = false;
          alert('Login activity load nahi ho saki — API connection check karein.');
        }
      );
  }

  applyFilters(): void {
    this.page = 1;
    this.loadData();
  }

  clearFilters(): void {
    this.fromDate = '';
    this.toDate = '';
    this.userNameFilter = '';
    this.page = 1;
    this.loadData();
  }

  get totalPages(): number {
    return Math.max(1, Math.ceil(this.totalCount / this.pageSize));
  }

  goToPage(p: number): void {
    if (p < 1 || p > this.totalPages) { return; }
    this.page = p;
    this.loadData();
  }
}
