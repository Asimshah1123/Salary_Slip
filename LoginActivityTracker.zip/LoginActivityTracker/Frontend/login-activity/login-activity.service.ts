import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { LoginActivityPagedResult } from './login-activity.model';

@Injectable({
  providedIn: 'root'
})
export class LoginActivityService {

  // TODO: point this at your existing API base URL (reuse whatever pattern your other
  // services already use — e.g. a shared environment.apiUrl constant).
  private apiUrl = 'https://your-api-domain.com/api/loginactivity';

  constructor(private http: HttpClient) {}

  getLoginActivities(
    fromDate?: string,
    toDate?: string,
    userName?: string,
    page: number = 1,
    pageSize: number = 20
  ): Observable<LoginActivityPagedResult> {

    let params = new HttpParams()
      .set('page', page.toString())
      .set('pageSize', pageSize.toString());

    if (fromDate) { params = params.set('fromDate', fromDate); }
    if (toDate) { params = params.set('toDate', toDate); }
    if (userName) { params = params.set('userName', userName); }

    return this.http.get<LoginActivityPagedResult>(this.apiUrl, { params });
  }
}
