export interface LoginActivityLog {
  id: number;
  userId: number;
  userName: string;
  loginTime: string;      // ISO date string from the API
  ipAddress: string;
  browser: string;
  operatingSystem: string;
  deviceType: string;     // Desktop / Mobile / Tablet
}

export interface LoginActivityPagedResult {
  items: LoginActivityLog[];
  totalCount: number;
}
