# User Login Activity Tracker

Jab bhi koi user login karega, uski activity (kaun, kab, kis IP/browser/OS/device se)
database mein save ho jayegi, aur Angular mein ek live grid/report page is data ko dikhayega.

## Honest note on "device"

Browser se **exact device ka naam** (jaise "Ali's Laptop") kabhi nahi mil sakta — yeh
privacy ki wajah se koi bhi website nahi le sakti. Jo milta hai woh **Browser**, **OS**, aur
**Device Type** (Desktop/Mobile/Tablet) — User-Agent string se nikala gaya — plus IP address.
Yeh har real-world "login activity" feature (Gmail, Facebook, etc.) ka bhi yehi standard hai.

## What's included

```
Backend/
  Models/LoginActivityLog.cs              -> EF entity + paged-result DTO
  Helpers/DeviceDetectionHelper.cs        -> parses User-Agent into Browser/OS/DeviceType
  Services/LoginActivityService.cs        -> LogLogin() + GetLoginActivities()
  Controllers/LoginActivityController.cs  -> GET /api/loginactivity (feeds the grid)
  Scripts/create_login_activity_table.sql -> run once against your database

Frontend/login-activity/
  login-activity.model.ts
  login-activity.service.ts
  login-activity-report.component.ts/.html/.css
```

## Step 1 — Create the database table

Run `Backend/Scripts/create_login_activity_table.sql` against your existing database (no new
database needed, just one new table).

## Step 2 — Add the backend files

1. Copy `Models/`, `Helpers/`, `Services/`, `Controllers/` files into your existing ASP.NET
   project's matching folders. Adjust `namespace` lines to match your project's root namespace
   if different.
2. In **your existing EF DbContext class**, add this line alongside your other `DbSet<>`
   properties:
   ```csharp
   public DbSet<LoginActivityLog> LoginActivityLogs { get; set; }
   ```
3. In both `LoginActivityService.cs` places marked `TODO`, replace `YourDbContext` with your
   actual DbContext class name.
4. In `LoginActivityController.cs`, replace the `[Authorize]` attribute with whatever your
   other admin-facing API endpoints already use (session-based, JWT, etc.) — so random people
   can't read everyone's login history.

## Step 3 — Hook the logging call into your existing login action (the important part)

Find your existing login endpoint — wherever you currently validate username/password and
return success. Add **one line** right after a successful login, before returning the
response:

```csharp
[HttpPost]
[Route("api/account/login")]
public IHttpActionResult Login(LoginModel model)
{
    var user = ValidateUser(model.Username, model.Password); // your existing check

    if (user != null)
    {
        // ADD THIS ONE LINE:
        new LoginActivityService().LogLogin(user.Id, user.UserName);

        return Ok(GenerateToken(user)); // your existing success response
    }

    return Unauthorized();
}
```

That's it — every successful login from now on writes a row automatically.

## Step 4 — Add the Angular files

1. Copy the 5 files from `Frontend/login-activity/` into a new folder in your Angular project,
   e.g. `src/app/login-activity/`.
2. Open `login-activity.service.ts` and update `apiUrl` to match your existing API base URL
   pattern (reuse whatever constant/environment file your other services already use).
3. Register the component in whichever `NgModule` should own this page (likely an existing
   "admin" or "reports" module). Add to that module's `declarations`:
   ```typescript
   import { LoginActivityReportComponent } from './login-activity/login-activity-report.component';
   // ...
   declarations: [
     // ...your existing components
     LoginActivityReportComponent
   ]
   ```
   Make sure that module also imports `FormsModule` and `HttpClientModule` (most apps already
   have these globally, but double check).
4. Add a route so it's reachable, e.g. in your routing module:
   ```typescript
   { path: 'login-activity', component: LoginActivityReportComponent }
   ```
5. Add a menu/sidebar link pointing to `/login-activity` wherever your other admin links live.

## Step 5 — One global check: JSON casing

The Angular model files above use **camelCase** (`userName`, `loginTime`, etc.) since that's
the JS convention. Classic ASP.NET Web API serializes JSON in **PascalCase** by default
(`UserName`, `LoginTime`). If your existing APIs already return camelCase to Angular
elsewhere, you likely already have this fix in place — skip this step. If not, add this once
in `WebApiConfig.cs` (affects all your API responses, in a good way):

```csharp
config.Formatters.JsonFormatter.SerializerSettings.ContractResolver =
    new Newtonsoft.Json.Serialization.CamelCasePropertyNamesContractResolver();
```

## Step 6 — Test it

1. Deploy the backend + database change.
2. Log into your app normally (any user).
3. Check the `LoginActivityLogs` table — a new row should appear immediately.
4. Open `/login-activity` in Angular — that row should show up in the grid, with filters for
   date range and username, and pagination if the list grows long.

## Optional next steps

- Add a "Logout" timestamp too (same pattern — call a `LogLogout()` method from your logout
  action) if you also want session duration tracking.
- Add an "Export to Excel/CSV" button on the grid later if your client wants to download the
  list, not just view it — that's a small addition to the existing component.
