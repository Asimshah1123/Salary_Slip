-- Run this against your existing database (no new database needed)

CREATE TABLE LoginActivityLogs (
    Id INT IDENTITY(1,1) PRIMARY KEY,

    -- TODO: if your Users table's primary key is not an INT (e.g. GUID), change this type to match
    UserId INT NOT NULL,

    UserName NVARCHAR(150) NOT NULL,
    LoginTime DATETIME2 NOT NULL DEFAULT GETDATE(),
    IPAddress NVARCHAR(50) NULL,
    UserAgent NVARCHAR(500) NULL,
    Browser NVARCHAR(100) NULL,
    OperatingSystem NVARCHAR(100) NULL,
    DeviceType NVARCHAR(50) NULL   -- Desktop / Mobile / Tablet
);

CREATE INDEX IX_LoginActivityLogs_LoginTime ON LoginActivityLogs(LoginTime DESC);
CREATE INDEX IX_LoginActivityLogs_UserId ON LoginActivityLogs(UserId);
GO
