using System;
using System.Linq;
using System.Web;
using LoginActivityTracker.Helpers;
using LoginActivityTracker.Models;

namespace LoginActivityTracker.Services
{
    public class LoginActivityService
    {
        /// <summary>
        /// Call this ONE line right after a successful login check in your existing login action
        /// (see README.md "Step 3" for exactly where). Everything else (IP, browser, OS, device
        /// type) is captured automatically from the current request — you only pass the user's
        /// id and name.
        /// </summary>
        public void LogLogin(int userId, string userName)
        {
            var ip = GetClientIp();
            var userAgent = HttpContext.Current?.Request?.UserAgent ?? "";
            var device = DeviceDetectionHelper.Parse(userAgent);

            using (var context = new YourDbContext()) // TODO: replace with your actual EF DbContext class name
            {
                context.LoginActivityLogs.Add(new LoginActivityLog
                {
                    UserId = userId,
                    UserName = userName,
                    LoginTime = DateTime.Now,
                    IPAddress = ip,
                    UserAgent = userAgent,
                    Browser = device.Browser,
                    OperatingSystem = device.OperatingSystem,
                    DeviceType = device.DeviceType
                });

                context.SaveChanges();
            }
        }

        /// <summary>
        /// Feeds the Angular grid: filtered, paged login activity, newest first.
        /// </summary>
        public LoginActivityPagedResult GetLoginActivities(DateTime? fromDate, DateTime? toDate, string userName, int page, int pageSize)
        {
            using (var context = new YourDbContext()) // TODO: same DbContext class as above
            {
                var query = context.LoginActivityLogs.AsQueryable();

                if (fromDate.HasValue)
                    query = query.Where(x => x.LoginTime >= fromDate.Value.Date);

                if (toDate.HasValue)
                    query = query.Where(x => x.LoginTime < toDate.Value.Date.AddDays(1));

                if (!string.IsNullOrWhiteSpace(userName))
                    query = query.Where(x => x.UserName.Contains(userName));

                var totalCount = query.Count();

                var items = query
                    .OrderByDescending(x => x.LoginTime)
                    .Skip((page - 1) * pageSize)
                    .Take(pageSize)
                    .ToList();

                return new LoginActivityPagedResult { Items = items, TotalCount = totalCount };
            }
        }

        private string GetClientIp()
        {
            var context = HttpContext.Current;
            if (context == null) return "Unknown";

            // If the site sits behind a load balancer/reverse proxy, the real client IP
            // shows up in X-Forwarded-For instead of the direct connection IP.
            var forwarded = context.Request.ServerVariables["HTTP_X_FORWARDED_FOR"];
            if (!string.IsNullOrEmpty(forwarded))
                return forwarded.Split(',')[0].Trim();

            return context.Request.UserHostAddress ?? "Unknown";
        }
    }
}
