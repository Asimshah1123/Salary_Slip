using System;
using System.Web.Http;
using LoginActivityTracker.Services;

namespace LoginActivityTracker.Controllers
{
    /// <summary>
    /// GET api/loginactivity?fromDate=2026-10-01&toDate=2026-10-07&userName=ali&page=1&pageSize=20
    /// Powers the Angular login-activity grid.
    /// </summary>
    [RoutePrefix("api/loginactivity")]
    public class LoginActivityController : ApiController
    {
        [HttpGet]
        [Route("")]
        [Authorize] // TODO: replace with whatever auth attribute/scheme your other admin APIs already use
        public IHttpActionResult GetLoginActivities(
            DateTime? fromDate = null,
            DateTime? toDate = null,
            string userName = null,
            int page = 1,
            int pageSize = 20)
        {
            try
            {
                var service = new LoginActivityService();
                var result = service.GetLoginActivities(fromDate, toDate, userName, page, pageSize);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return InternalServerError(ex);
            }
        }
    }
}
