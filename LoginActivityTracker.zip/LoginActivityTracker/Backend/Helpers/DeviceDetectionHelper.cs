using System.Text.RegularExpressions;

namespace LoginActivityTracker.Helpers
{
    public class DeviceInfo
    {
        public string Browser { get; set; }
        public string OperatingSystem { get; set; }
        public string DeviceType { get; set; } // Desktop / Mobile / Tablet
    }

    /// <summary>
    /// Simple regex-based User-Agent parser — no NuGet package required, works offline.
    /// Covers the common cases (Chrome, Firefox, Edge, Safari, Opera / Windows, macOS, Android,
    /// iOS, Linux). Note: a browser can only reveal OS + browser + device *type* (desktop/mobile/
    /// tablet) via its User-Agent string — it cannot reveal the exact device model/name (e.g.
    /// "Ali's Laptop") for privacy reasons; no website can get that from any browser.
    /// If you need more precise/robust parsing later, the "UAParser" NuGet package is a drop-in
    /// upgrade that uses the same approach shown here, just with a more complete rule set.
    /// </summary>
    public static class DeviceDetectionHelper
    {
        public static DeviceInfo Parse(string userAgent)
        {
            if (string.IsNullOrWhiteSpace(userAgent))
            {
                return new DeviceInfo { Browser = "Unknown", OperatingSystem = "Unknown", DeviceType = "Unknown" };
            }

            return new DeviceInfo
            {
                Browser = DetectBrowser(userAgent),
                OperatingSystem = DetectOperatingSystem(userAgent),
                DeviceType = DetectDeviceType(userAgent)
            };
        }

        private static string DetectBrowser(string ua)
        {
            // Order matters: Edge/Opera/Chrome UAs all also contain "Safari", so check the
            // more specific tokens first.
            if (Regex.IsMatch(ua, "Edg/")) return "Microsoft Edge";
            if (Regex.IsMatch(ua, "OPR/|Opera")) return "Opera";
            if (Regex.IsMatch(ua, "Chrome/")) return "Chrome";
            if (Regex.IsMatch(ua, "Firefox/")) return "Firefox";
            if (Regex.IsMatch(ua, "Safari/") && !Regex.IsMatch(ua, "Chrome")) return "Safari";
            if (Regex.IsMatch(ua, "MSIE |Trident/")) return "Internet Explorer";
            return "Other";
        }

        private static string DetectOperatingSystem(string ua)
        {
            if (Regex.IsMatch(ua, "Windows NT 10")) return "Windows 10/11";
            if (Regex.IsMatch(ua, "Windows NT 6.3")) return "Windows 8.1";
            if (Regex.IsMatch(ua, "Windows NT 6.2")) return "Windows 8";
            if (Regex.IsMatch(ua, "Windows NT 6.1")) return "Windows 7";
            if (Regex.IsMatch(ua, "Windows")) return "Windows";
            if (Regex.IsMatch(ua, "iPhone|iPad|iPod")) return "iOS";
            if (Regex.IsMatch(ua, "Mac OS X")) return "macOS";
            if (Regex.IsMatch(ua, "Android")) return "Android";
            if (Regex.IsMatch(ua, "Linux")) return "Linux";
            return "Other";
        }

        private static string DetectDeviceType(string ua)
        {
            if (Regex.IsMatch(ua, "iPad|Tablet", RegexOptions.IgnoreCase)) return "Tablet";
            if (Regex.IsMatch(ua, "Mobi|Android.*Mobile|iPhone", RegexOptions.IgnoreCase)) return "Mobile";
            return "Desktop";
        }
    }
}
