using System;

namespace LoginActivityTracker.Models
{
    public class LoginActivityLog
    {
        public int Id { get; set; }
        public int UserId { get; set; }          // TODO: change type if your Users table's PK isn't int
        public string UserName { get; set; }
        public DateTime LoginTime { get; set; }
        public string IPAddress { get; set; }
        public string UserAgent { get; set; }
        public string Browser { get; set; }
        public string OperatingSystem { get; set; }
        public string DeviceType { get; set; }    // Desktop / Mobile / Tablet
    }

    /// <summary>
    /// Shape returned to Angular — paged list + total count for the grid's pagination.
    /// </summary>
    public class LoginActivityPagedResult
    {
        public System.Collections.Generic.List<LoginActivityLog> Items { get; set; }
        public int TotalCount { get; set; }
    }
}
